import { redirect } from "next/navigation";
import { CrmAuthMeResponse, CrmItemResponse, CrmUser } from "@/lib/crm-api";
import { fetchCrmServer, fetchCrmServerOptional } from "@/lib/crm-api-server";
import { canAccessCrmAllEstates, canAccessCrmClients, canAccessCrmQueues, canAccessCrmUsers, getCrmLandingPathForUser, isCrmAdminLike } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

export function getCrmLandingPath(user: CrmUser): string {
  const pathname = getCrmLandingPathForUser(user);
  if (pathname === "/profile") {
    return crmRoutes.profile;
  }
  if (pathname === "/estates") {
    return crmRoutes.estates;
  }
  return crmRoutes.myEstates;
}

export async function getCrmCurrentUser(): Promise<CrmUser | null> {
  const response = await fetchCrmServerOptional<CrmAuthMeResponse>("/api/v1/crm/auth/me");
  return response?.user ?? null;
}

export async function requireCrmUser(): Promise<CrmUser> {
  const response = await fetchCrmServerOptional<CrmAuthMeResponse>("/api/v1/crm/auth/me");

  if (!response?.user) {
    redirect(crmRoutes.login);
  }

  return response.user;
}

export async function requireCrmAdmin(): Promise<CrmUser> {
  const user = await requireCrmUser();

  if (!isCrmAdminLike(user)) {
    redirect(getCrmLandingPath(user));
  }

  return user;
}

export async function requireCrmEstatesAccess(): Promise<CrmUser> {
  const user = await requireCrmUser();

  if (!canAccessCrmAllEstates(user)) {
    redirect(crmRoutes.profile);
  }

  return user;
}

export async function requireCrmUsersAccess(): Promise<CrmUser> {
  const user = await requireCrmUser();

  if (!canAccessCrmUsers(user)) {
    redirect(getCrmLandingPath(user));
  }

  return user;
}

export async function requireCrmClientsAccess(): Promise<CrmUser> {
  const user = await requireCrmUser();

  if (!canAccessCrmClients(user)) {
    redirect(getCrmLandingPath(user));
  }

  return user;
}

export async function requireCrmQueueAccess(): Promise<CrmUser> {
  const user = await requireCrmUser();

  if (!canAccessCrmQueues(user)) {
    redirect(getCrmLandingPath(user));
  }

  return user;
}

export async function redirectIfCrmAuthenticated(): Promise<void> {
  const response = await fetchCrmServerOptional<CrmAuthMeResponse>("/api/v1/crm/auth/me");

  if (response?.user) {
    redirect(getCrmLandingPath(response.user));
  }
}

export async function getCrmProfile() {
  return fetchCrmServer<CrmItemResponse<Record<string, unknown>>>("/api/v1/crm/profile");
}
