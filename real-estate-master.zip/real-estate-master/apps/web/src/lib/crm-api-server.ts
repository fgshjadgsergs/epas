import { cookies, headers as requestHeaders } from "next/headers";
import { CrmApiError, getCrmApiBaseUrl, parseCrmResponsePayload } from "@/lib/crm-api";

const DEFAULT_CRM_SERVER_API_TIMEOUT_MS = 8000;

function getCrmServerApiTimeoutMs(): number {
  const rawValue = process.env.CRM_API_FETCH_TIMEOUT_MS ?? process.env.FRONTEND_API_FETCH_TIMEOUT_MS;
  const parsedValue = Number.parseInt(rawValue ?? "", 10);

  return Number.isFinite(parsedValue) && parsedValue > 0 ? parsedValue : DEFAULT_CRM_SERVER_API_TIMEOUT_MS;
}

function getErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

async function getServerCookieHeader(): Promise<string> {
  const headerCookie = (await requestHeaders()).get("cookie");
  if (headerCookie) {
    return headerCookie;
  }

  const store = await cookies();

  return store
    .getAll()
    .map((item) => `${item.name}=${item.value}`)
    .join("; ");
}

export async function fetchCrmServer<T>(path: string, init?: RequestInit): Promise<T> {
  const startedAt = Date.now();
  const timeoutMs = getCrmServerApiTimeoutMs();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  const headers = new Headers(init?.headers);
  const existingCookieHeader = headers.get("cookie");
  const cookieHeader = existingCookieHeader ?? (await getServerCookieHeader());
  const hasCookieHeader = Boolean(cookieHeader);
  if (cookieHeader) {
    headers.set("cookie", cookieHeader);
  }
  headers.set("accept", "application/json");

  console.info(`[CRM API FETCH] start path=${path} hasCookieHeader=${hasCookieHeader} timeoutMs=${timeoutMs}`);

  try {
    const response = await fetch(`${getCrmApiBaseUrl()}${path}`, {
      ...init,
      headers,
      cache: "no-store",
      signal: init?.signal ?? controller.signal,
    });

    console.info(`[CRM API FETCH] end path=${path} status=${response.status} durationMs=${Date.now() - startedAt} hasCookieHeader=${hasCookieHeader}`);

    if (!response.ok) {
      throw new CrmApiError(`CRM API request failed: ${path}`, response.status, await parseCrmResponsePayload(response));
    }

    return (await response.json()) as T;
  } catch (error) {
    console.warn(`[CRM API FETCH] error path=${path} durationMs=${Date.now() - startedAt} hasCookieHeader=${hasCookieHeader} message=${getErrorMessage(error)}`);
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

export async function fetchCrmServerOptional<T>(path: string): Promise<T | null> {
  try {
    return await fetchCrmServer<T>(path);
  } catch (error) {
    if (error instanceof CrmApiError && [401, 403].includes(error.status)) {
      return null;
    }

    throw error;
  }
}
