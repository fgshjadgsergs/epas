const integerFormatter = new Intl.NumberFormat("ru-RU", {
  maximumFractionDigits: 0,
});

const profitFormatter = new Intl.NumberFormat("ru-RU", {
  minimumFractionDigits: 0,
  maximumFractionDigits: 1,
});

export function formatInteger(value: number): string {
  return integerFormatter.format(Math.round(value));
}

export function formatPricePerArea(price: number, area: number): string | null {
  if (!Number.isFinite(price) || !Number.isFinite(area) || area <= 0) {
    return null;
  }

  return formatInteger(price / area);
}

export function formatProfit(value: number | null): string | null {
  if (value === null || !Number.isFinite(value)) {
    return null;
  }

  return profitFormatter.format(value);
}

export function includesRent(dealType: string): boolean {
  return dealType.toLowerCase().includes("аренд");
}

export function isRentBusiness(dealType: string): boolean {
  const normalized = dealType.toLowerCase().trim();
  return normalized !== "продажа" && normalized !== "аренда";
}
