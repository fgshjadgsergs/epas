export interface CrmParityNotes {
  exact?: string[];
  approximate?: string[];
  intentionally_changed?: string[];
}

export interface CrmUser {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  role?: "OWNER" | "ADMIN" | "ROP" | "BROKER" | "VIEWER";
  rop_id?: number | null;
  is_admin: boolean;
  created_at?: string;
  update_at?: string;
}

export interface CrmAuthMeResponse {
  user: CrmUser;
}

export interface CrmImage {
  id: number;
  url: string;
  thumbnail_url?: string | null;
  public_url: string;
  is_main: boolean;
  is_plan: boolean;
}

export interface CrmOwnerContact {
  owner_phone: string;
  owner_name: string;
}

export type CrmPipelineStatus = "new" | "in_progress" | "showing" | "negotiation" | "closed" | "rejected";

export interface CrmEstateClientLink {
  link_id: number;
  client_id: number;
  client_name: string;
  client_broker_id: number;
  client_broker_rop_id?: number | null;
  status: CrmPipelineStatus;
  created_at?: string;
  update_at?: string;
}

export interface CrmCianPhoneContact {
  code: string;
  number: string;
}

export interface CrmEstateCianPayload {
  include: boolean;
  type: string | null;
  owner_contacts: CrmCianPhoneContact[];
  vat_type: string | null;
  ready_business_type: string | null;
  specialty: string | null;
  garage_type: string | null;
  land_area: number | null;
  land_area_unit: string | null;
  building_area: number | null;
}

export type AvitoModerationStatus = "DRAFT" | "PENDING_REVIEW" | "APPROVED" | "CHANGES_REQUESTED";
export type AvitoPublicationStatus =
  | "NOT_INCLUDED"
  | "READY"
  | "SENT"
  | "PROCESSING"
  | "PUBLISHED"
  | "REJECTED"
  | "ERROR"
  | "REMOVED";

export interface AvitoValidationIssue {
  code: string;
  field: string;
  message: string;
  severity?: "error" | "warning";
}

export interface AvitoValidationResult {
  ok: boolean;
  errors: AvitoValidationIssue[];
}

export interface AvitoFeedData {
  object_type?: string;
  property_rights?: string;
  office_type?: string;
  entrance?: string;
  layout?: string[];
  decoration?: string;
  building_type?: string;
  parking_type?: string;
  rental_type?: string;
  transaction_type?: string;
}

export interface AvitoFeedSettingsPayload extends AvitoFeedData {
  avitoTitle?: string | null;
}

export interface CrmEstateAvitoBlock {
  moderation_status: AvitoModerationStatus;
  publication_status: AvitoPublicationStatus;
  included: boolean;
  avito_id: number | null;
  external_id: string | null;
  avitoTitle: string | null;
  last_error: AvitoValidationIssue[] | Record<string, unknown> | string | null;
  last_validated_at: string | null;
  last_synced_at: string | null;
  review_comment: string | null;
  review_requested_at: string | null;
  approved_at: string | null;
  approved_by_id: number | null;
  feed_data: AvitoFeedData;
}

export interface CrmEstateAvitoListBlock {
  moderation_status: AvitoModerationStatus;
  publication_status: AvitoPublicationStatus;
  included: boolean;
  last_error: AvitoValidationIssue[] | Record<string, unknown> | string | null;
}

export interface AvitoModerationListItem {
  id: number;
  title: string;
  address: string;
  deal_type: string;
  estate_type: string | null;
  price: number | null;
  area: number | null;
  active: boolean;
  deleted_at: string | null;
  is_private_sale: boolean;
  broker: CrmUser | null;
  avito: CrmEstateAvitoBlock;
  main_image: {
    id: number;
    url: string;
    thumbnail_url: string | null;
    public_url: string;
  } | null;
}

export interface AvitoModerationActionResponse {
  item: AvitoModerationListItem;
  validation?: AvitoValidationResult;
}

export interface AvitoFeedListItem {
  id: number;
  title: string;
  deal_type: string | null;
  estate_type: string | null;
  price: number | null;
  area: number | null;
  broker: CrmUser | null;
  avito: {
    moderation_status: AvitoModerationStatus;
    publication_status: AvitoPublicationStatus;
    included: boolean;
    external_id: string | null;
    last_error: AvitoValidationIssue[] | Record<string, unknown> | string | null;
    last_validated_at: string | null;
    last_synced_at: string | null;
    approved_at: string | null;
  };
  main_image: {
    id: number;
    url: string;
    public_url: string;
  } | null;
  reasons: AvitoValidationIssue[];
}

export interface CrmEstateListItem {
  id: number;
  title: string;
  status?: string | null;
  deal_type: string;
  area: number | null;
  price: number;
  presentation_price: string;
  metro_station: string | null;
  district: string | null;
  active: boolean;
  priority: boolean;
  is_private_sale: boolean;
  avito: CrmEstateAvitoListBlock;
  user_id: number | null;
  assigned_user_ids: number[];
  assigned_users: CrmUser[];
  client_links?: CrmEstateClientLink[];
  images: CrmImage[];
  profit: number | null;
}

export interface CrmEstateDetail extends CrmEstateListItem {
  coordinates: string | null;
  description: string;
  area_description: string | null;
  internal_info: string | null;
  status: string | null;
  tags: string | null;
  estate_type: string | null;
  tenant_type: string | null;
  map_: number | null;
  contract_term: string | null;
  indexing: string | null;
  gap: number | null;
  power_kw: number | null;
  ceiling_height_m: number | null;
  floor: number | null;
  all_floors: number | null;
  levels_count: number | null;
  occupied_floors_text: string | null;
  region: string;
  owner_type?: string | null;
  owner_contacts?: CrmOwnerContact[];
  user: CrmUser | null;
  cian: CrmEstateCianPayload;
  avito: CrmEstateAvitoBlock;
}

export interface CrmMetaResponse {
  estate: {
    form: {
      choice_fields: {
        deal_type: string[];
        region: string[];
        district: string[];
        owner_type: string[];
      };
      free_text_fields: string[];
      required_fields?: {
        always?: string[];
        create_only?: string[];
        conditional?: {
          rent_business?: string[];
        };
      };
    };
    list: {
      default_limit: number;
      supported_filters: string[];
    };
  };
  cian: {
    choice_fields: {
      type: string[];
      vat_type: string[];
      garage_type: string[];
      ready_business_type: string[];
      land_area_unit: string[];
      specialty: string[];
    };
  };
  users: {
    list: {
      default_limit: number;
      supported_filters: string[];
    };
  };
  clients: {
    list: {
      default_limit: number;
      supported_filters: string[];
    };
  };
  parity: {
    exact: string[];
    approximate: string[];
  };
}

export interface CrmClientBrokerItem {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  rop_id: number | null;
}

export interface CrmClientEstateItem {
  link_id: number;
  id: number;
  title: string;
  deal_type: string;
  price: number | null;
  area: number | null;
  user_id: number | null;
  assigned_user_ids: number[];
  status: CrmPipelineStatus;
  thumbnail_url: string | null;
  image_url: string | null;
  public_page_url: string | null;
  broker: {
    id: number;
    email: string;
    first_name: string;
    last_name: string;
  };
  update_at: string;
  created_at: string;
}

export interface CrmClientListItem {
  id: number;
  broker_id: number;
  name: string;
  phone?: string | null;
  email?: string | null;
  source?: string | null;
  comment?: string | null;
  created_at: string;
  update_at: string;
  broker: CrmUser;
  estates: CrmClientEstateItem[];
}

export interface CrmClientDetail extends CrmClientListItem {}

export interface CrmClientMatchingProfile {
  client_id: number;
  deal_type: string;
  price_from: number | null;
  price_to: number | null;
  area_from: number | null;
  area_to: number | null;
  created_at: string;
  update_at: string;
}

export interface CrmClientMatchingProfileWritePayload {
  deal_type: string;
  price_from?: number | null;
  price_to?: number | null;
  area_from?: number | null;
  area_to?: number | null;
}

export interface CrmMatchedEstateItem {
  estate_id: number;
  title: string;
  deal_type: string;
  price: number | null;
  presentation_price: string | null;
  area: number | null;
  district: string | null;
  metro_station: string | null;
  estate_type: string | null;
  broker_id: number | null;
  broker_name: string | null;
  image_url?: string | null;
}

export interface CrmMatchedClientItem {
  client_id: number;
  name: string;
  contacts_visible: boolean;
  phone?: string | null;
  email?: string | null;
  source: string | null;
  comment: string | null;
  broker_id: number;
  broker_name: string;
  profile: CrmClientMatchingProfile;
}

export interface CrmClientMatchesResponse {
  profile: CrmClientMatchingProfile | null;
  items: CrmMatchedEstateItem[];
  total: number;
}

export interface CrmEstateMatchesResponse {
  items: CrmMatchedClientItem[];
  total: number;
}

export interface CrmDealListItem {
  link_id: number;
  status: CrmPipelineStatus;
  client_id: number;
  client_name: string;
  phone?: string | null;
  email?: string | null;
  contacts_visible: boolean;
  source: string | null;
  comment: string | null;
  estate_id: number;
  estate_title: string;
  estate_price: number | null;
  estate_presentation_price: string | null;
  district: string | null;
  metro_station: string | null;
  broker_id: number;
  broker_name: string;
  created_at: string;
  update_at: string;
}

export interface CrmDealDetail extends CrmDealListItem {}

export interface CrmDealCreatePayload {
  client_id: number;
  estate_id: number;
  stage: CrmPipelineStatus;
  comment?: string | null;
}

export interface CrmDealMutationResponse {
  item: CrmDealDetail;
  reused?: boolean;
}

export interface CrmDealConflictPayload {
  code?: string;
  message?: string;
  existing_deal?: CrmDealDetail;
  deal_url?: string;
}

export interface CrmDealBrokerItem {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  rop_id: number | null;
}

export type CrmDealTaskType = "CALL" | "MEETING" | "MESSAGE";

export interface CrmDealCommentItem {
  id: number;
  author_id: number;
  author_name: string;
  text: string;
  created_at: string;
}

export interface CrmDealTaskItem {
  id: number;
  author_id: number;
  author_name: string;
  type: CrmDealTaskType;
  text: string;
  due_at: string | null;
  done: boolean;
  created_at: string;
  update_at: string;
}

export interface CrmDealActivityResponse<T> {
  items: T[];
}

export interface CrmClientEstateLinkWrite {
  estate_id: number;
  status: CrmPipelineStatus;
}

export interface CrmClientWritePayload {
  broker_id?: number | null;
  name: string;
  phone?: string | null;
  email?: string | null;
  source?: string | null;
  comment?: string | null;
  estate_links?: CrmClientEstateLinkWrite[];
}

export interface CrmListResponse<T> {
  items: T[];
  total: number;
  skip?: number;
  limit?: number;
  filters?: Record<string, unknown>;
  parity?: CrmParityNotes;
}

export interface CrmItemResponse<T> {
  item: T;
  parity?: CrmParityNotes | Record<string, unknown>;
}

export interface CrmMessageResponse {
  message?: string;
  updated?: number;
  deleted?: boolean;
  path?: string;
  generated_objects?: number;
  parity?: CrmParityNotes | Record<string, unknown>;
}

export class CrmApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly payload: unknown,
  ) {
    super(message);
    this.name = "CrmApiError";
  }
}

export function getCrmApiBaseUrl(): string {
  return process.env.ESTATE_API_BASE_URL ?? process.env.NEXT_PUBLIC_ESTATE_API_BASE_URL ?? "http://127.0.0.1:3000";
}

const DEFAULT_CRM_CLIENT_API_TIMEOUT_MS = 8000;

function getCrmClientApiTimeoutMs(): number {
  const rawValue = process.env.NEXT_PUBLIC_CRM_API_FETCH_TIMEOUT_MS ?? process.env.NEXT_PUBLIC_FRONTEND_API_FETCH_TIMEOUT_MS;
  const parsedValue = Number.parseInt(rawValue ?? "", 10);

  return Number.isFinite(parsedValue) && parsedValue > 0 ? parsedValue : DEFAULT_CRM_CLIENT_API_TIMEOUT_MS;
}

function getCrmFetchErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export async function parseCrmResponsePayload(response: Response): Promise<unknown> {
  const contentType = response.headers.get("content-type") ?? "";

  if (contentType.includes("application/json")) {
    return response.json();
  }

  return response.text();
}

export async function crmClientFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const startedAt = Date.now();
  const timeoutMs = getCrmClientApiTimeoutMs();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  console.info(`[CRM CLIENT FETCH] start path=${path} timeoutMs=${timeoutMs}`);

  try {
    const response = await fetch(path, {
      ...init,
      credentials: init?.credentials ?? "include",
      headers: {
        Accept: "application/json",
        ...(init?.headers ?? {}),
      },
      signal: init?.signal ?? controller.signal,
    });

    console.info(`[CRM CLIENT FETCH] end path=${path} status=${response.status} durationMs=${Date.now() - startedAt}`);

    if (!response.ok) {
      throw new CrmApiError(`CRM API request failed: ${path}`, response.status, await parseCrmResponsePayload(response));
    }

    return (await response.json()) as T;
  } catch (error) {
    console.warn(`[CRM CLIENT FETCH] error path=${path} durationMs=${Date.now() - startedAt} message=${getCrmFetchErrorMessage(error)}`);
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

export function createCrmDeal(payload: CrmDealCreatePayload): Promise<CrmDealMutationResponse> {
  return crmClientFetch<CrmDealMutationResponse>("/api/v1/crm/deals", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

export function updateCrmDealStage(linkId: number, stage: CrmPipelineStatus): Promise<CrmDealMutationResponse> {
  return crmClientFetch<CrmDealMutationResponse>(`/api/v1/crm/deals/${linkId}/stage`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ stage }),
  });
}
export function getEstateAvitoValidation(estateId: number): Promise<AvitoValidationResult> {
  return crmClientFetch<AvitoValidationResult>(`/api/v1/crm/estates/${estateId}/avito/validation`);
}

export function updateEstateAvitoFeedSettings(
  estateId: number,
  feedData: AvitoFeedSettingsPayload,
): Promise<AvitoModerationActionResponse> {
  return crmClientFetch<AvitoModerationActionResponse>(`/api/v1/crm/estates/${estateId}/avito/settings`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(feedData),
  });
}

export function submitEstateToAvitoReview(estateId: number): Promise<AvitoModerationActionResponse> {
  return crmClientFetch<AvitoModerationActionResponse>(`/api/v1/crm/estates/${estateId}/avito/submit-review`, {
    method: "POST",
  });
}

export function approveEstateForAvito(estateId: number): Promise<AvitoModerationActionResponse> {
  return crmClientFetch<AvitoModerationActionResponse>(`/api/v1/crm/estates/${estateId}/avito/approve`, {
    method: "POST",
  });
}

export function requestEstateAvitoChanges(estateId: number, comment: string): Promise<AvitoModerationActionResponse> {
  return crmClientFetch<AvitoModerationActionResponse>(`/api/v1/crm/estates/${estateId}/avito/request-changes`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ comment }),
  });
}

export function getAvitoModerationQueue(params?: {
  status?: AvitoModerationStatus;
  skip?: number;
  limit?: number;
}): Promise<CrmListResponse<AvitoModerationListItem>> {
  const searchParams = new URLSearchParams();
  if (params?.status) {
    searchParams.set("status", params.status);
  }
  if (params?.skip !== undefined) {
    searchParams.set("skip", String(params.skip));
  }
  if (params?.limit !== undefined) {
    searchParams.set("limit", String(params.limit));
  }

  const query = searchParams.toString();
  return crmClientFetch<CrmListResponse<AvitoModerationListItem>>(`/api/v1/crm/avito/moderation${query ? `?${query}` : ""}`);
}
