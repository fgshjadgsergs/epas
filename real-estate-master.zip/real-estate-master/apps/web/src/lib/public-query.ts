export type SearchParamsValue = string | string[] | undefined;
export type SearchParamsRecord = Record<string, SearchParamsValue>;

type SearchParamsUpdates = Record<string, string | number | null | undefined>;

export function getSingleValue(value: SearchParamsValue): string | undefined {
  if (Array.isArray(value)) {
    return value[0];
  }

  return value;
}

export function toUrlSearchParams(searchParams: SearchParamsRecord): URLSearchParams {
  const params = new URLSearchParams();

  for (const [key, value] of Object.entries(searchParams)) {
    if (value === undefined) {
      continue;
    }

    if (Array.isArray(value)) {
      for (const item of value) {
        params.append(key, item);
      }
      continue;
    }

    params.set(key, value);
  }

  return params;
}

export function buildPathWithSearchParams(
  pathname: string,
  searchParams: SearchParamsRecord,
  updates: SearchParamsUpdates = {},
): string {
  const params = toUrlSearchParams(searchParams);

  for (const [key, value] of Object.entries(updates)) {
    params.delete(key);

    if (value === null || value === undefined || value === "") {
      continue;
    }

    params.set(key, String(value));
  }

  const query = params.toString();
  return query ? `${pathname}?${query}` : pathname;
}
