export type CrmEstateDealTypeVariant = "rent" | "sale" | "rent-business" | "other";

export interface CrmEstateDealTypePresentation {
  label: string;
  variant: CrmEstateDealTypeVariant;
}

export function getCrmEstateDealTypePresentation(dealType: string | null | undefined): CrmEstateDealTypePresentation {
  const value = dealType?.trim() ?? "";
  const normalized = value.toLocaleLowerCase("ru-RU");

  if (normalized.includes("арендный бизнес")) {
    return { label: "Арендный бизнес", variant: "rent-business" };
  }

  if (normalized.includes("аренд")) {
    return { label: "Аренда", variant: "rent" };
  }

  if (normalized.includes("прод")) {
    return { label: "Продажа", variant: "sale" };
  }

  return { label: value || "Не указано", variant: "other" };
}