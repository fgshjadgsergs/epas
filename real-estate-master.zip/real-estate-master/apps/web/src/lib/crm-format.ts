export function formatCrmCurrency(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return "—";
  }

  return new Intl.NumberFormat("ru-RU").format(value);
}

export function formatCrmDate(value: string | null | undefined): string {
  if (!value) {
    return "—";
  }

  return new Intl.DateTimeFormat("ru-RU", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export function formatBooleanLabel(value: boolean): string {
  return value ? "Да" : "Нет";
}

export function formatOwnerContacts(contacts: Array<{ owner_phone: string; owner_name: string }>): string {
  if (contacts.length === 0) {
    return "—";
  }

  return contacts.map((contact) => `${contact.owner_phone} / ${contact.owner_name}`).join(", ");
}

