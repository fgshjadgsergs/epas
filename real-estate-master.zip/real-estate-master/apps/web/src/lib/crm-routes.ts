export const CRM_INTERNAL_PREFIX = "/crm-app";

export const crmRoutes = {
  index: "/",
  login: "/login",
  profile: "/profile",
  myEstates: "/my-estates",
  myEstatesArchive: "/my-estates-archive",
  estates: "/estates",
  estatesArchive: "/estates-archive",
  clients: "/clients",
  client: (id: number | string) => `/crm/clients/${id}`,
  deals: "/deals",
  deal: (id: number | string) => `/crm/deals/${id}`,
  newEstate: "/estates/new",
  estate: (id: number | string) => `/estates/${id}`,
  users: "/users",
  newUser: "/users/new",
  user: (id: number | string) => `/users/${id}`,
  moderationEstates: "/moderation-estates",
  uploadEstates: "/upload-estates",
} as const;

export function getPublicSiteUrl(pathname: string): string {
  const normalizedPath = pathname.startsWith("/") ? pathname : `/${pathname}`;

  if (typeof window === "undefined") {
    return normalizedPath;
  }

  const url = new URL(normalizedPath, window.location.origin);
  if (url.hostname.startsWith("crm.")) {
    url.hostname = url.hostname.slice(4);
  }

  return url.toString();
}

export function crmInternalPath(pathname: string): string {
  const normalizedPathname =
    pathname === "/crm" ? "/" : pathname.startsWith("/crm/") ? pathname.slice("/crm".length) : pathname;

  if (!normalizedPathname || normalizedPathname === "/") {
    return CRM_INTERNAL_PREFIX;
  }

  return `${CRM_INTERNAL_PREFIX}${normalizedPathname}`;
}

export function isCrmHost(hostHeader: string | null | undefined): boolean {
  const host = (hostHeader ?? "").split(",")[0].trim().toLowerCase().split(":")[0];
  const expected = (process.env.ESTATE_CRM_HOST ?? "crm.epas.agency").trim().toLowerCase().split(":")[0];

  return host === expected || host === `www.${expected}`;
}

export function isCrmBypassPath(pathname: string): boolean {
  return (
    pathname.startsWith("/api/") ||
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/static/") ||
    pathname.startsWith("/storage/") ||
    pathname === "/favicon.ico" ||
    pathname === "/robots.txt" ||
    pathname === "/sitemap.xml"
  );
}
