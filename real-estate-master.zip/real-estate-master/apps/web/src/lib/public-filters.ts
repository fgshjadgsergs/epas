import { SearchParamsRecord, getSingleValue } from "@/lib/public-query";

export const PUBLIC_PRICE_RANGE = {
  min: 0,
  max: 500000000,
  step: 100000,
} as const;

export const PUBLIC_AREA_RANGE = {
  min: 0,
  max: 30000,
  step: 10,
} as const;

export const PUBLIC_DEAL_TYPES = {
  sale: {
    key: "sale",
    label: "Продажа",
    queryValue: "Продажа",
  },
  rent: {
    key: "rent",
    label: "Аренда",
    queryValue: "Аренда",
  },
  rentBusiness: {
    key: "rentBusiness",
    label: "Арендный бизнес",
    queryValue: "Арендный бизнес",
  },
} as const;

export const PUBLIC_LOCATIONS = {
  moscow: {
    key: "moscow",
    label: "Москва",
  },
  region: {
    key: "region",
    label: "Московская область",
  },
} as const;

export type PublicDealTypeKey = keyof typeof PUBLIC_DEAL_TYPES;
export type PublicLocationKey = keyof typeof PUBLIC_LOCATIONS;

export interface PublicFiltersDraft {
  searchByAddress: string;
  dealType: PublicDealTypeKey | "";
  location: PublicLocationKey | "";
  priceFrom: string;
  priceTo: string;
  areaFrom: string;
  areaTo: string;
}

export interface PublicFiltersValidationErrors {
  priceRange?: string;
  areaRange?: string;
}

export function formatNumberRu(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") {
    return "";
  }

  const digits = String(value).replace(/[^\d]/g, "");
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

export function parseNumberInput(value: string): number | null {
  const digits = value.replace(/[^\d]/g, "");

  if (!digits) {
    return null;
  }

  const parsed = Number(digits);
  return Number.isFinite(parsed) ? parsed : null;
}

export function sanitizeNumericDraft(value: string): string {
  const parsed = parseNumberInput(value);
  return parsed === null ? "" : String(parsed);
}

function parseNumericDraft(value: string): number | null {
  if (!value) {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeSearchNumber(value: string | undefined): string {
  if (!value) {
    return "";
  }

  return sanitizeNumericDraft(value);
}

export function buildPublicFiltersDraft(searchParams: SearchParamsRecord): PublicFiltersDraft {
  const dealType = (getSingleValue(searchParams.deal_type) ?? "").toLowerCase();
  const isMoscow = getSingleValue(searchParams.is_moscow) !== undefined;
  const isRegion = getSingleValue(searchParams.is_region) !== undefined;

  let dealTypeKey: PublicDealTypeKey | "" = "";
  for (const value of Object.values(PUBLIC_DEAL_TYPES)) {
    if (value.queryValue.toLowerCase() === dealType) {
      dealTypeKey = value.key;
      break;
    }
  }

  let location: PublicLocationKey | "" = "";
  if (isMoscow && !isRegion) {
    location = "moscow";
  } else if (isRegion && !isMoscow) {
    location = "region";
  }

  return {
    searchByAddress: getSingleValue(searchParams.search_by_address) ?? "",
    dealType: dealTypeKey,
    location,
    priceFrom: normalizeSearchNumber(getSingleValue(searchParams.price_from)),
    priceTo: normalizeSearchNumber(getSingleValue(searchParams.price_to)),
    areaFrom: normalizeSearchNumber(getSingleValue(searchParams.area_from)),
    areaTo: normalizeSearchNumber(getSingleValue(searchParams.area_to)),
  };
}

export function validatePublicFiltersDraft(draft: PublicFiltersDraft): PublicFiltersValidationErrors {
  const errors: PublicFiltersValidationErrors = {};
  const priceFrom = parseNumericDraft(draft.priceFrom);
  const priceTo = parseNumericDraft(draft.priceTo);
  const areaFrom = parseNumericDraft(draft.areaFrom);
  const areaTo = parseNumericDraft(draft.areaTo);

  if (priceFrom !== null && priceTo !== null && priceFrom > priceTo) {
    errors.priceRange = "Минимальная цена не может быть больше максимальной.";
  }

  if (areaFrom !== null && areaTo !== null && areaFrom > areaTo) {
    errors.areaRange = "Минимальная площадь не может быть больше максимальной.";
  }

  return errors;
}

export function buildPublicFilterSearchUpdates(draft: PublicFiltersDraft): Record<string, string | number | null> {
  const updates: Record<string, string | number | null> = {
    search_by_address: draft.searchByAddress.trim() || null,
    deal_type: draft.dealType ? PUBLIC_DEAL_TYPES[draft.dealType].queryValue : null,
    price_from: draft.priceFrom || null,
    price_to: draft.priceTo || null,
    area_from: draft.areaFrom || null,
    area_to: draft.areaTo || null,
    is_moscow: null,
    is_region: null,
    page: 1,
  };

  if (draft.location === "moscow") {
    updates.is_moscow = "1";
  }

  if (draft.location === "region") {
    updates.is_region = "1";
  }

  return updates;
}

export function resolveSliderRange(
  draftFrom: string,
  draftTo: string,
  bounds: { min: number; max: number },
): [number, number] {
  const from = parseNumericDraft(draftFrom);
  const to = parseNumericDraft(draftTo);
  const resolvedFrom = Math.min(Math.max(from ?? bounds.min, bounds.min), bounds.max);
  const resolvedTo = Math.min(Math.max(to ?? bounds.max, bounds.min), bounds.max);

  return [Math.min(resolvedFrom, resolvedTo), Math.max(resolvedFrom, resolvedTo)];
}
