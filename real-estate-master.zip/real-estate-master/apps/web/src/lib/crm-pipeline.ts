import { CrmPipelineStatus, CrmUser } from "@/lib/crm-api";
import { canManageCrmClient } from "@/lib/crm-role";

export const CRM_PIPELINE_OPTIONS: Array<{ value: CrmPipelineStatus; label: string }> = [
  { value: "new", label: "Новый" },
  { value: "in_progress", label: "В работе" },
  { value: "showing", label: "Показ" },
  { value: "negotiation", label: "Переговоры" },
  { value: "closed", label: "Закрыто" },
  { value: "rejected", label: "Отказ" },
];

export function getCrmPipelineLabel(status: CrmPipelineStatus): string {
  return CRM_PIPELINE_OPTIONS.find((option) => option.value === status)?.label ?? status;
}

export function getCrmPipelineClassName(status: CrmPipelineStatus): string {
  switch (status) {
    case "new":
      return "crm-pipeline-badge--new";
    case "in_progress":
      return "crm-pipeline-badge--in-progress";
    case "showing":
      return "crm-pipeline-badge--showing";
    case "negotiation":
      return "crm-pipeline-badge--negotiation";
    case "closed":
      return "crm-pipeline-badge--closed";
    case "rejected":
      return "crm-pipeline-badge--rejected";
  }
}

export function canUpdateCrmPipelineStatus(
  viewer: Pick<CrmUser, "id" | "role" | "is_admin">,
  targetBroker: Pick<CrmUser, "id"> & Partial<Pick<CrmUser, "rop_id">>,
): boolean {
  return canManageCrmClient(viewer, {
    id: targetBroker.id,
    rop_id: targetBroker.rop_id ?? null,
  });
}
