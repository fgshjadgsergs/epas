﻿import type { AvitoModerationStatus, AvitoPublicationStatus, AvitoValidationIssue } from "@/lib/crm-api";

export const AVITO_MODERATION_STATUS_LABELS: Record<AvitoModerationStatus, string> = {
  DRAFT: "Черновик",
  PENDING_REVIEW: "На проверке",
  APPROVED: "Одобрено",
  CHANGES_REQUESTED: "Требуются изменения",
};

export const AVITO_PUBLICATION_STATUS_LABELS: Record<AvitoPublicationStatus, string> = {
  NOT_INCLUDED: "Не включён",
  READY: "Готов к выгрузке",
  SENT: "Отправлен",
  PROCESSING: "Обрабатывается",
  PUBLISHED: "Опубликован",
  REJECTED: "Отклонён",
  ERROR: "Ошибка",
  REMOVED: "Снят",
};

export function getAvitoModerationStatusLabel(status: AvitoModerationStatus | null | undefined): string {
  return status ? AVITO_MODERATION_STATUS_LABELS[status] ?? status : "Не указан";
}

export function getAvitoPublicationStatusLabel(status: AvitoPublicationStatus | null | undefined): string {
  return status ? AVITO_PUBLICATION_STATUS_LABELS[status] ?? status : "Не указан";
}

export type AvitoListStatusVariant = "neutral" | "review" | "ready" | "progress" | "published" | "error";

export interface AvitoListStatusPresentation {
  label: string;
  variant: AvitoListStatusVariant;
  title?: string;
}

export function getAvitoListStatusPresentation(
  avito:
    | {
        moderation_status: AvitoModerationStatus;
        publication_status: AvitoPublicationStatus;
        included: boolean;
        last_error: unknown;
      }
    | null
    | undefined,
): AvitoListStatusPresentation {
  if (!avito) {
    return { label: "Не настроено", variant: "neutral" };
  }

  const issueTitle = normalizeAvitoIssues(avito.last_error)
    .map((issue) => issue.message)
    .join("\n");

  if (avito.publication_status === "ERROR" || issueTitle) {
    return { label: "Ошибка", variant: "error", title: issueTitle || "Ошибка выгрузки" };
  }

  if (avito.publication_status === "PUBLISHED") {
    return { label: "Опубликован", variant: "published" };
  }

  if (avito.publication_status === "SENT" || avito.publication_status === "PROCESSING") {
    return {
      label: getAvitoPublicationStatusLabel(avito.publication_status),
      variant: "progress",
    };
  }

  if (avito.publication_status === "REJECTED") {
    return { label: "Отклонён", variant: "error" };
  }

  if (avito.publication_status === "REMOVED") {
    return { label: "Снят", variant: "neutral" };
  }

  if (avito.included) {
    return { label: "Включён в фид", variant: "ready" };
  }

  if (avito.publication_status === "READY") {
    return { label: "Готов к выгрузке", variant: "ready" };
  }

  if (avito.moderation_status === "PENDING_REVIEW") {
    return { label: "На модерации", variant: "review" };
  }

  if (avito.moderation_status === "CHANGES_REQUESTED") {
    return { label: "Требуются изменения", variant: "error" };
  }

  if (avito.moderation_status === "APPROVED") {
    return { label: "Одобрено", variant: "ready" };
  }

  return { label: "Черновик", variant: "neutral" };
}

export function formatAvitoDate(value: string | null | undefined): string {
  if (!value) {
    return "-";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function normalizeAvitoIssues(value: unknown): AvitoValidationIssue[] {
  if (!value) {
    return [];
  }

  if (Array.isArray(value)) {
    const issues: AvitoValidationIssue[] = [];

    for (const item of value) {
      if (!item || typeof item !== "object") {
        continue;
      }

      const issue = item as Partial<AvitoValidationIssue>;
      issues.push({
        code: String(issue.code ?? "unknown"),
        field: String(issue.field ?? "-"),
        message: String(issue.message ?? "Неизвестная ошибка"),
        severity: issue.severity === "warning" ? "warning" : "error",
      });
    }

    return issues;
  }

  if (typeof value === "string") {
    return [{ code: "message", field: "-", message: value, severity: "error" }];
  }

  return [{ code: "payload", field: "-", message: JSON.stringify(value), severity: "error" }];
}

