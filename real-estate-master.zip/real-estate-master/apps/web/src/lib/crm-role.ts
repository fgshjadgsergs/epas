import { CrmEstateDetail, CrmEstateListItem, CrmUser } from "@/lib/crm-api";

export type CrmRole = "OWNER" | "ADMIN" | "ROP" | "BROKER" | "VIEWER";

export const CRM_ROLE_OPTIONS: Array<{ value: CrmRole; label: string }> = [
  { value: "OWNER", label: "Владелец" },
  { value: "ADMIN", label: "Администратор" },
  { value: "ROP", label: "РОП" },
  { value: "BROKER", label: "Брокер" },
  { value: "VIEWER", label: "Наблюдатель" },
] as const;

export function getCrmRole(user: Pick<CrmUser, "role"> & Partial<Pick<CrmUser, "is_admin">>): CrmRole {
  const normalized = String(user.role ?? "").toUpperCase();
  if (normalized === "OWNER" || normalized === "ADMIN" || normalized === "ROP" || normalized === "BROKER" || normalized === "VIEWER") {
    return normalized;
  }

  return user.is_admin ? "ADMIN" : "BROKER";
}

export function getCrmRoleLabel(userOrRole: (Pick<CrmUser, "role"> & Partial<Pick<CrmUser, "is_admin">>) | CrmRole): string {
  const role = typeof userOrRole === "string" ? userOrRole : getCrmRole(userOrRole);

  switch (role) {
    case "OWNER":
      return "Владелец";
    case "ADMIN":
      return "Администратор";
    case "ROP":
      return "РОП";
    case "BROKER":
      return "Брокер";
    case "VIEWER":
      return "Наблюдатель";
  }
}

export function isCrmAdminLike(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  const role = getCrmRole(user);
  return role === "OWNER" || role === "ADMIN";
}

export function canAccessCrmUsers(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  const role = getCrmRole(user);
  return role === "OWNER" || role === "ADMIN" || role === "ROP";
}

export function canAccessCrmQueues(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  const role = getCrmRole(user);
  return role === "OWNER" || role === "ADMIN" || role === "ROP";
}

export function canAccessCrmClients(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  return getCrmRole(user) !== "VIEWER";
}

export function canAccessCrmAllEstates(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  return getCrmRole(user) !== "VIEWER";
}

export function canCreateCrmEstate(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  return canAccessCrmAllEstates(user);
}

export function getCrmLandingPathForUser(user: Pick<CrmUser, "role" | "is_admin">): string {
  const role = getCrmRole(user);

  if (role === "VIEWER") {
    return "/profile";
  }

  if (canAccessCrmAllEstates(user)) {
    return "/estates";
  }

  return "/my-estates";
}

export function canManageEstate(
  viewer: Pick<CrmUser, "id" | "role" | "is_admin">,
  estate:
    | Pick<CrmEstateListItem, "user_id" | "assigned_user_ids" | "assigned_users">
    | Pick<CrmEstateDetail, "user_id" | "user" | "assigned_user_ids" | "assigned_users">,
): boolean {
  const role = getCrmRole(viewer);
  const assignedUserIds =
    estate.assigned_user_ids.length > 0
      ? estate.assigned_user_ids
      : estate.user_id === null
        ? []
        : [estate.user_id];

  if (role === "OWNER" || role === "ADMIN") {
    return true;
  }

  if (role === "ROP") {
    const assignedUsers = estate.assigned_users.length > 0 ? estate.assigned_users : "user" in estate && estate.user ? [estate.user] : [];
    return assignedUsers.some((user) => getCrmRole(user) === "BROKER" && user.rop_id === viewer.id);
  }

  if (role === "BROKER") {
    return assignedUserIds.includes(viewer.id);
  }

  return false;
}

export function hasEstateOwnerContacts(estate: Pick<CrmEstateDetail, "owner_contacts">): boolean {
  return Array.isArray(estate.owner_contacts);
}

export function getAssignableCrmRoles(user: Pick<CrmUser, "role" | "is_admin">): CrmRole[] {
  const role = getCrmRole(user);

  switch (role) {
    case "OWNER":
      return ["OWNER", "ADMIN", "ROP", "BROKER", "VIEWER"];
    case "ADMIN":
      return ["ADMIN", "ROP", "BROKER", "VIEWER"];
    case "ROP":
      return ["BROKER", "VIEWER"];
    default:
      return [];
  }
}

export function requiresRopAssignment(role: CrmRole): boolean {
  return role === "BROKER" || role === "VIEWER";
}

export function canManageCrmUser(
  actor: Pick<CrmUser, "id" | "role" | "is_admin">,
  target: Pick<CrmUser, "role" | "rop_id">,
): boolean {
  const actorRole = getCrmRole(actor);
  const targetRole = getCrmRole(target);

  if (actorRole === "OWNER") {
    return true;
  }

  if (actorRole === "ADMIN") {
    return targetRole !== "OWNER";
  }

  if (actorRole === "ROP") {
    return (targetRole === "BROKER" || targetRole === "VIEWER") && target.rop_id === actor.id;
  }

  return false;
}

export function canDeleteCrmUser(
  actor: Pick<CrmUser, "id" | "role" | "is_admin">,
  target: Pick<CrmUser, "role" | "rop_id">,
): boolean {
  const actorRole = getCrmRole(actor);
  const targetRole = getCrmRole(target);

  if (actorRole === "OWNER") {
    return true;
  }

  if (actorRole === "ADMIN") {
    return targetRole !== "OWNER";
  }

  return false;
}

export function canResetCrmUserPassword(user: Pick<CrmUser, "role" | "is_admin">): boolean {
  return isCrmAdminLike(user);
}

export function canManageCrmClient(
  actor: Pick<CrmUser, "id" | "role" | "is_admin">,
  target: Pick<CrmUser, "id" | "rop_id">,
): boolean {
  const actorRole = getCrmRole(actor);

  if (actorRole === "OWNER" || actorRole === "ADMIN") {
    return true;
  }

  if (actorRole === "ROP") {
    return target.rop_id === actor.id;
  }

  if (actorRole === "BROKER") {
    return target.id === actor.id;
  }

  return false;
}
