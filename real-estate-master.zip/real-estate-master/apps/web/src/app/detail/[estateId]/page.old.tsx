import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { DetailGallery } from "@/components/public/detail-gallery";
import { DetailMap } from "@/components/public/detail-map";
import { PublicApiError, getEstateDetail, resolveStoragePath } from "@/lib/public-api";
import { formatProfit, includesRent } from "@/lib/public-format";

interface DetailPageParams {
  estateId: string;
}

interface DetailPageProps {
  params: Promise<DetailPageParams>;
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatEstateDescription(description: string | null | undefined) {
  const normalized = description?.trim() ?? "";
  if (!normalized) {
    return "<p>Описание отсутствует.</p>";
  }

  const containsHtml = /<\/?[a-z][^>]*>/i.test(normalized);
  if (containsHtml) {
    return normalized;
  }

  const paragraphs = normalized
    .split(/\r?\n\r?\n+/)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean)
    .map((paragraph) => `<p>${escapeHtml(paragraph).replace(/\r?\n/g, "<br />")}</p>`);

  return paragraphs.join("") || "<p>Описание отсутствует.</p>";
}

async function loadEstate(estateId: number) {
  try {
    return await getEstateDetail(estateId);
  } catch (error) {
    if (error instanceof PublicApiError && error.status === 404) {
      notFound();
    }

    throw error;
  }
}

export async function generateMetadata({ params }: DetailPageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const estateId = Number.parseInt(resolvedParams.estateId, 10);

  if (!Number.isInteger(estateId) || estateId <= 0) {
    return {
      title: "Недвижимость в Москве",
    };
  }

  try {
    const estate = await getEstateDetail(estateId);

    return {
      title: estate.title,
      description: estate.description.replace(/<[^>]+>/g, "").slice(0, 160) || undefined,
    };
  } catch {
    return {
      title: "Недвижимость в Москве",
    };
  }
}

export default async function DetailPage({ params }: DetailPageProps) {
  const resolvedParams = await params;
  const estateId = Number.parseInt(resolvedParams.estateId, 10);

  if (!Number.isInteger(estateId) || estateId <= 0) {
    notFound();
  }

  const estate = await loadEstate(estateId);
  const images = (estate.images.length > 0 ? estate.images : ["/static/img/logo-light.png"]).map((image) =>
    image.startsWith("/static/") ? image : resolveStoragePath(image),
  );
  const planImage = estate.planImagePublicUrl
    ? estate.planImagePublicUrl
    : estate.planImage
      ? resolveStoragePath(estate.planImage)
      : null;
  const mapsApiKey = process.env.YANDEX_MAPS_API_KEY ?? process.env.NEXT_PUBLIC_YANDEX_MAPS_API_KEY ?? "";
  const profit = formatProfit(estate.profit);
  const isRent = includesRent(estate.dealType);

  return (
    <main>
      <section id="listing-detail-hero-1" className="section detail-hero py-4 py-lg-5">
        <div className="hero__bg position-absolute" />
        <div className="hero__overlay position-absolute" />

        <div className="container-xl position-relative">
          <div className="row g-4 align-items-stretch">
            <div className="col-12 col-lg-8">
              <div className="gallery-frame gallery-frame--card position-relative h-100">
                <DetailGallery images={images} title={estate.title} />
              </div>
            </div>

            <div className="col-12 col-lg-4">
              <aside className="detail-summary card shadow-sm border-0">
                <div className="card-body p-3">
                  <div className="detail-summary__head">
                    <div className="detail-summary__head-text">
                      <p className="detail-summary__title mb-1">{estate.title}</p>

                      <div className="detail-chips">
                        <span className="chip">{estate.dealType}</span>
                        <span className="chip">
                          {estate.area} м<sup>2</sup>
                        </span>
                        {estate.floor ? <span className="chip">Этаж {estate.floor}</span> : null}
                        {estate.metroStation ? (
                          <span className="chip chip--metro">
                            <img src="/static/img/16px-Mosmetro_logo_M.svg.png" alt="Метро" />
                            {estate.metroStation}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  <div className="detail-price mt-3">
                    <div className="detail-price__main">₽{estate.presentationPrice}</div>
                    <div className="detail-price__sub">{estate.areaPrice ? `₽${estate.areaPrice} за м²` : "-"}</div>
                  </div>

                  <div className="detail-kv mt-2">
                    {estate.tenantType ? (
                      <div className="detail-kv__item">
                        <i className="fas fa-user-tag" />
                        <span className="arend">
                          Арендатор: <strong>{estate.tenantType}</strong>
                        </span>
                      </div>
                    ) : null}

                    {isRent && (estate.presentationMap || profit) ? (
                      <div className="detail-kv__row-inline">
                        {estate.presentationMap ? (
                          <div className="detail-kv__pill detail-kv__pill--map" title="Месячный арендный поток">
                            <span className="detail-kv__pill-label">МАП</span>
                            <span className="detail-kv__pill-value">₽{estate.presentationMap}</span>
                          </div>
                        ) : null}

                        {profit ? (
                          <div className="detail-kv__pill detail-kv__pill--profit" title="Окупаемость">
                            <span className="detail-kv__pill-label">Окупаемость</span>
                            <span className="detail-kv__pill-value">{profit} лет</span>
                          </div>
                        ) : null}
                      </div>
                    ) : null}
                  </div>

                  <div className="action-panel mt-3">
                    <div className="action-panel__head">
                      <div className="action-panel__title">Действия</div>
                      <div className="action-panel__subtitle">Быстрый доступ к информации</div>
                    </div>

                    <div className="action-panel__body">
                      <div className="detail-actions">
                        <a href="#detail-overview" className="btn btn-outline-secondary">
                          Описание
                        </a>

                        <a href="#detail-map" className="btn btn-outline-secondary">
                          Карта
                        </a>
                      </div>

                      <button type="button" className="btn btn-primary w-100 mt-2" id="requestPresentationBtn">
                        Запросить презентацию
                      </button>

                      {planImage ? (
                        <a href={planImage} target="_blank" rel="noopener noreferrer" className="btn btn-outline-secondary w-100 mt-2" id="planBtn">
                          План
                        </a>
                      ) : null}
                    </div>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </div>
      </section>

      <section id="listing-detail-1" className="section pb-6 pt-2">
        <div className="container-xl position-relative">
          <section id="detail-overview" className="detail-section card shadow-sm border-0">
            <header className="detail-section__head">
              <div className="detail-section__title-row">
                <h2 className="detail-section__title">Описание</h2>
                <div className="detail-section__rule" aria-hidden="true" />
              </div>
            </header>

            <div className="detail-section__body">
              <div className="detail-panel__inner">
                <div className="detail-description" dangerouslySetInnerHTML={{ __html: formatEstateDescription(estate.description) }} />
              </div>
            </div>
          </section>

          <section id="detail-map" className="detail-section card shadow-sm border-0 mt-3">
            <header className="detail-section__head">
              <div className="detail-section__title-row">
                <h2 className="detail-section__title">Карта</h2>
                <div className="detail-section__rule" aria-hidden="true" />
              </div>
            </header>

            <div className="detail-section__body">
              <div className="detail-panel__inner">
                <DetailMap coordinates={estate.coordinatesTuple} apiKey={mapsApiKey} />
              </div>
            </div>
          </section>
        </div>
      </section>
    </main>
  );
}
