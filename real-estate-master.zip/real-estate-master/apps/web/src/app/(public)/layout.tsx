import { ReactNode } from "react";
import { RequestModal } from "@/components/layout/request-modal";
import { SiteFooter } from "@/components/layout/site-footer";
import { SiteHeader } from "@/components/layout/site-header";

export default function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="page-shell">
      <SiteHeader />
      {children}
      <SiteFooter />
      <RequestModal />
    </div>
  );
}
