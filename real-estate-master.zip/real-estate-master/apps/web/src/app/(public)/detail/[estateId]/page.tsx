export { generateMetadata, default } from "../../../detail/[estateId]/page.old";
