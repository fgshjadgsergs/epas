import type { Metadata } from "next";
import Link from "next/link";
import { EstateCard } from "@/components/public/estate-card";
import { Pagination } from "@/components/public/pagination";
import { getListingData } from "@/lib/public-api";
import { buildPathWithSearchParams, SearchParamsRecord } from "@/lib/public-query";
import FiltersPanel from "@/components/public/filters-panel"; // 🔥 добавили

export const metadata: Metadata = {
  title: "Недвижимость в Москве",
};

interface ListingPageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function ListingPage({ searchParams }: ListingPageProps) {
  const resolvedSearchParams = (await searchParams) ?? {};
  const data = await getListingData(resolvedSearchParams);

  return (
    <main>
      <section
        id="page-hero"
        className="section section__inverse justify-content-center pt-6 pb-4 pb-lg-5 pb-xl-6"
      >
        <div className="hero__bg position-absolute" />
        <div className="hero__overlay position-absolute" />

        <div className="container-xl position-relative section-content text-center py-4">
          <h2 className="display-5 text-white mt-3 mt-lg-4">{data.title}</h2>

          <div className="section-filter pt-4">
            <div className="row g-3">
              <div className="col-12 col-md section-content text-center text-md-start">
                <p className="mb-0">
                  &nbsp;Найденные&nbsp;объекты:&nbsp;
                  <strong>{data.totalCount}</strong>
                </p>
              </div>

              <div className="col col-md-auto text-md-end ms-md-auto">
                <div className="btn-group btn-select-dropdown w-100">
                  <span className="input-group-text fs-sm rounded-0 rounded-start py-0">
                    Отобразить на странице
                  </span>

                  <button
                    type="button"
                    className="btn btn-sm btn-primary btn-default dropdown-toggle d-flex align-items-center justify-content-between shadow-none fw-bold"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    {data.perPage}
                  </button>

                  <ul className="dropdown-menu dropdown-menu-end w-100">
                    {[10, 30, 50].map((perPage) => (
                      <li key={perPage}>
                        <Link
                          className={`dropdown-item fs-sm${
                            perPage === data.perPage ? " active" : ""
                          }`}
                          href={buildPathWithSearchParams(
                            "/listing",
                            resolvedSearchParams,
                            {
                              page: data.page,
                              "per-page": perPage,
                            }
                          )}
                        >
                          {perPage}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="listing-1" className="section pb-6 mt-n4 mt-lg-n5 mt-xl-n6">
        <div className="bg bg-img position-absolute" data-bg-img=".img" />

        <div className="container-xl position-relative">

          {/* 🔥 ВОТ ОНО — ФИЛЬТРЫ */}
          <div className="mb-4">
            <FiltersPanel searchParams={resolvedSearchParams} submitPath="/listing" />
          </div>

          {data.items.length > 0 ? (
            <div className="listing-grid mb-5">
              {data.items.map((estate) => (
                <EstateCard
                  key={estate.dbId}
                  estate={estate}
                  variant="listing"
                />
              ))}
            </div>
          ) : (
            <div className="section-content text-center py-5">
              <h2 className="fs-3 mb-3">Объекты не найдены</h2>
              <p className="mb-0">
                Попробуйте изменить параметры поиска или очистить фильтры.
              </p>
            </div>
          )}

          <Pagination
            page={data.page}
            perPage={data.perPage}
            totalCount={data.totalCount}
            createHref={(page) =>
              buildPathWithSearchParams("/listing", resolvedSearchParams, {
                page,
                "per-page": data.perPage,
              })
            }
          />
        </div>
      </section>
    </main>
  );
}
