﻿import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-[60vh] max-w-3xl items-center justify-center px-6 py-20">
      <div className="rounded-2xl bg-white px-8 py-6 text-center shadow-soft">
        <p className="text-sm uppercase tracking-[0.18em] text-slate-400">Public Frontend MVP</p>
        <h1 className="mt-2 text-2xl font-semibold text-slate-900">Страница не найдена</h1>
        <p className="mt-2 text-sm text-slate-500">Запрошенный объект или страница сейчас недоступны.</p>
        <div className="mt-6">
          <Button asChild>
            <Link href="/">На главную</Link>
          </Button>
        </div>
      </div>
    </main>
  );
}

