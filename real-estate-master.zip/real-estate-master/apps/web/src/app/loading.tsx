﻿export default function Loading() {
  return (
    <main className="mx-auto flex min-h-[60vh] max-w-3xl items-center justify-center px-6 py-20">
      <div className="rounded-2xl bg-white px-8 py-6 text-center shadow-soft">
        <p className="text-sm uppercase tracking-[0.18em] text-slate-400">EPAS Development</p>
        <h1 className="mt-2 text-2xl font-semibold text-slate-900">Загрузка страницы</h1>
        <p className="mt-2 text-sm text-slate-500">Проверяем данные объекта и собираем текущую витрину.</p>
      </div>
    </main>
  );
}

