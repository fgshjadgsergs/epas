﻿"use client";

import { Button } from "@/components/ui/button";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="mx-auto flex min-h-[60vh] max-w-3xl items-center justify-center px-6 py-20">
      <div className="rounded-2xl bg-white px-8 py-6 text-center shadow-soft">
        <p className="text-sm uppercase tracking-[0.18em] text-slate-400">Public Frontend MVP</p>
        <h1 className="mt-2 text-2xl font-semibold text-slate-900">Не удалось загрузить страницу</h1>
        <p className="mt-2 text-sm text-slate-500">{error.message || "Ошибка при обращении к Node public API."}</p>
        <div className="mt-6">
          <Button onClick={() => reset()}>Повторить</Button>
        </div>
      </div>
    </main>
  );
}

