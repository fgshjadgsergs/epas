import { redirect } from "next/navigation";
import { getCrmCurrentUser, getCrmLandingPath } from "@/lib/crm-auth";
import { crmRoutes } from "@/lib/crm-routes";

export default async function CrmIndexPage() {
  const user = await getCrmCurrentUser();

  redirect(user ? getCrmLandingPath(user) : crmRoutes.login);
}
