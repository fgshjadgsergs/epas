import { redirectIfCrmAuthenticated } from "@/lib/crm-auth";
import { CrmLoginForm } from "@/components/crm/auth/crm-login-form";

export default async function CrmLoginPage() {
  await redirectIfCrmAuthenticated();

  return <CrmLoginForm />;
}

