import { CrmEstateFilters } from "@/components/crm/estates/crm-estate-filters";
import { CrmEstateTable } from "@/components/crm/estates/crm-estate-table";
import { CrmHeaderLink, CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPagination } from "@/components/crm/shared/crm-pagination";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import { CrmEstateListItem, CrmListResponse, CrmMetaResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmEstatesAccess } from "@/lib/crm-auth";
import { canCreateCrmEstate, getCrmRoleLabel } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

function withActiveDefaults(searchParams: SearchParamsRecord): SearchParamsRecord {
  if (searchParams.active !== undefined) {
    return searchParams;
  }

  return {
    ...searchParams,
    active: "true",
  };
}

export default async function CrmEstatesPage({ searchParams }: PageProps) {
  const user = await requireCrmEstatesAccess();
  const resolvedSearchParams = withActiveDefaults((await searchParams) ?? {});
  const query = toUrlSearchParams(resolvedSearchParams).toString();
  const [meta, list] = await Promise.all([
    fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta"),
    fetchCrmServer<CrmListResponse<CrmEstateListItem>>(`/api/v1/crm/estates${query ? `?${query}` : ""}`),
  ]);

  return (
    <>
      <CrmPageHeader
        title="Все объекты"
        description={`Общий список объектов CRM. Доступ в соответствии с ролью: ${getCrmRoleLabel(user)}.`}
        action={
          <div className="crm-actions">
            <CrmHeaderLink href={crmRoutes.estatesArchive}>Архив</CrmHeaderLink>
            {canCreateCrmEstate(user) ? <CrmHeaderLink href={crmRoutes.newEstate}>Новый объект</CrmHeaderLink> : null}
          </div>
        }
      />

      <div className="crm-stack">
        <CrmPanel>
          <CrmEstateFilters
            searchParams={resolvedSearchParams}
            dealTypes={meta.estate.form.choice_fields.deal_type}
            regions={meta.estate.form.choice_fields.region}
            districts={meta.estate.form.choice_fields.district}
            defaultActive="true"
          />
        </CrmPanel>

        <CrmPanel>
          {list.items.length > 0 ? (
            <>
              <CrmEstateTable items={list.items} viewer={user} mode="default" archivedOnly={false} />
              <CrmPagination
                pathname={crmRoutes.estates}
                searchParams={resolvedSearchParams}
                skip={list.skip ?? 0}
                limit={list.limit ?? meta.estate.list.default_limit}
                total={list.total}
              />
            </>
          ) : (
            <CrmEmptyState title="Объекты не найдены" description="Попробуйте ослабить фильтры или создать новый объект." />
          )}
        </CrmPanel>
      </div>
    </>
  );
}
