import { notFound } from "next/navigation";
import { CrmUserEditor } from "@/components/crm/users/crm-user-editor";
import { CrmApiError, CrmItemResponse, CrmUser } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmUsersAccess } from "@/lib/crm-auth";

interface PageProps {
  params: Promise<{ userId: string }>;
}

export default async function CrmUserDetailPage({ params }: PageProps) {
  const viewer = await requireCrmUsersAccess();
  const { userId } = await params;
  const numericId = Number.parseInt(userId, 10);

  if (!Number.isInteger(numericId) || numericId <= 0) {
    notFound();
  }

  try {
    const result = await fetchCrmServer<CrmItemResponse<CrmUser>>(`/api/v1/crm/users/${numericId}`);
    return <CrmUserEditor mode="edit" viewer={viewer} user={result.item} />;
  } catch (error) {
    if (error instanceof CrmApiError && error.status === 404) {
      notFound();
    }

    throw error;
  }
}
