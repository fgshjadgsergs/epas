import { CrmProfileScreen } from "@/components/crm/profile/crm-profile-screen";
import { getCrmProfile, requireCrmUser } from "@/lib/crm-auth";

export default async function CrmProfilePage() {
  const user = await requireCrmUser();
  const profile = await getCrmProfile();

  return <CrmProfileScreen viewer={user} profile={profile.item} />;
}

