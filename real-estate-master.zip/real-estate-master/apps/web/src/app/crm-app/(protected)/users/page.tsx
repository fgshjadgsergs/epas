import { CrmHeaderLink, CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPagination } from "@/components/crm/shared/crm-pagination";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import { CrmUsersTable } from "@/components/crm/users/crm-users-table";
import { CrmListResponse, CrmMetaResponse, CrmUser } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmUsersAccess } from "@/lib/crm-auth";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord, buildPathWithSearchParams, getSingleValue, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function CrmUsersPage({ searchParams }: PageProps) {
  const user = await requireCrmUsersAccess();
  const resolvedSearchParams = (await searchParams) ?? {};
  const query = toUrlSearchParams(resolvedSearchParams).toString();
  const [meta, list] = await Promise.all([
    fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta"),
    fetchCrmServer<CrmListResponse<CrmUser>>(`/api/v1/crm/users${query ? `?${query}` : ""}`),
  ]);
  const limit = Number(getSingleValue(resolvedSearchParams.limit) ?? meta.users.list.default_limit);
  const skip = Number(getSingleValue(resolvedSearchParams.skip) ?? 0);

  return (
    <>
      <CrmPageHeader
        title="Пользователи"
        description="Управление ролями и рабочими учетными записями CRM."
        action={<CrmHeaderLink href={crmRoutes.newUser}>Новый пользователь</CrmHeaderLink>}
      />

      <div className="crm-stack">
        <CrmPanel>
          <form className="crm-inline-filters" method="GET">
            <label className="crm-field">
              <span className="crm-field__label">Поиск</span>
              <input className="crm-input" type="search" name="search" defaultValue={getSingleValue(resolvedSearchParams.search) ?? ""} />
            </label>
            <label className="crm-field">
              <span className="crm-field__label">Лимит</span>
              <select className="crm-select" name="limit" defaultValue={String(limit)}>
                {[10, 20, 50, 100].map((value) => (
                  <option key={value} value={value}>
                    {value}
                  </option>
                ))}
              </select>
            </label>
            <input type="hidden" name="skip" value="0" />
            <div className="crm-filters__actions">
              <button className="crm-button" type="submit">
                Применить
              </button>
              <a className="crm-button crm-button--ghost" href={buildPathWithSearchParams(crmRoutes.users, {}, {})}>
                Сбросить
              </a>
            </div>
          </form>
        </CrmPanel>

        <CrmPanel>
          {list.items.length > 0 ? (
            <>
              <CrmUsersTable items={list.items} />
              <CrmPagination pathname={crmRoutes.users} searchParams={resolvedSearchParams} skip={skip} limit={limit} total={list.total} />
            </>
          ) : (
            <CrmEmptyState title="Пользователи не найдены" description="Попробуйте очистить поиск или создать нового пользователя." />
          )}
        </CrmPanel>
      </div>
    </>
  );
}
