import Link from "next/link";
import { CrmClientProposals } from "@/components/crm/clients/crm-client-proposals";
import { CrmDealActivity } from "@/components/crm/deals/crm-deal-activity";
import { CrmDealStageControl } from "@/components/crm/deals/crm-deal-stage-control";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmErrorState, CrmPanel } from "@/components/crm/shared/crm-state";
import {
  CrmClientDetail,
  CrmDealActivityResponse,
  CrmDealCommentItem,
  CrmDealDetail,
  CrmDealTaskItem,
  CrmItemResponse,
} from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmClientsAccess } from "@/lib/crm-auth";
import { formatCrmCurrency, formatCrmDate } from "@/lib/crm-format";
import { getCrmPipelineLabel } from "@/lib/crm-pipeline";
import { crmRoutes } from "@/lib/crm-routes";

interface PageProps {
  params: Promise<{
    linkId: string;
  }>;
}

function getDealPriceLabel(item: CrmDealDetail): string {
  if (item.estate_presentation_price) {
    return `${item.estate_presentation_price} ₽`;
  }

  if (item.estate_price !== null && item.estate_price !== undefined) {
    return `${formatCrmCurrency(item.estate_price)} ₽`;
  }

  return "—";
}

function getContactsLabel(item: CrmDealDetail): string {
  if (!item.contacts_visible) {
    return "Контакты скрыты";
  }

  const parts = [item.phone, item.email].filter(Boolean);
  return parts.length > 0 ? parts.join(" · ") : "—";
}

export default async function CrmDealPage({ params }: PageProps) {
  await requireCrmClientsAccess();
  const { linkId } = await params;
  const numericId = Number(linkId);

  if (!Number.isInteger(numericId) || numericId <= 0) {
    return (
      <>
        <CrmPageHeader title="Сделка" action={<BackToDealsLink />} />
        <CrmErrorState title="Сделка не найдена" description="Проверьте ссылку или вернитесь к списку сделок." />
      </>
    );
  }

  const dealResponse = await fetchCrmServer<CrmItemResponse<CrmDealDetail>>(`/api/v1/crm/deals/${numericId}`);
  const deal = dealResponse.item;
  const [commentsResult, tasksResult, clientResult] = await Promise.allSettled([
    fetchCrmServer<CrmDealActivityResponse<CrmDealCommentItem>>(`/api/v1/crm/deals/${numericId}/comments`),
    fetchCrmServer<CrmDealActivityResponse<CrmDealTaskItem>>(`/api/v1/crm/deals/${numericId}/tasks`),
    fetchCrmServer<CrmItemResponse<CrmClientDetail>>(`/api/v1/crm/clients/${deal.client_id}`),
  ]);
  const comments = commentsResult.status === "fulfilled" ? commentsResult.value.items : [];
  const tasks = tasksResult.status === "fulfilled" ? tasksResult.value.items : [];
  const client = clientResult.status === "fulfilled" ? clientResult.value.item : null;
  const activityWarning =
    commentsResult.status === "rejected" || tasksResult.status === "rejected"
      ? "Комментарии и задачи временно недоступны."
      : null;
  const proposalsWarning = clientResult.status === "rejected" ? "Подборка клиента временно недоступна." : null;

  return (
    <div className="crm-stack">
      <CrmPageHeader title={`Сделка #${deal.link_id}`} description={deal.client_name} action={<BackToDealsLink />} />

      <div className="crm-deal-page-grid">
        <CrmPanel>
          <div className="crm-stack">
            <section className="crm-deal-panel__section">
              <h2 className="crm-client-panel__section-title">Этап сделки</h2>
              <CrmDealStageControl linkId={deal.link_id} initialStatus={deal.status} />
            </section>
            <section className="crm-deal-panel__section">
              <h2 className="crm-client-panel__section-title">Основное</h2>
              <div className="crm-client-panel__info-list">
                <InfoRow label="Клиент" value={deal.client_name} />
                <InfoRow label="Контакты" value={getContactsLabel(deal)} />
                <InfoRow label="Объект" value={deal.estate_title} />
                <InfoRow label="Брокер" value={deal.broker_name} />
                <InfoRow label="Этап" value={getCrmPipelineLabel(deal.status)} />
                <InfoRow label="Цена" value={getDealPriceLabel(deal)} />
                <InfoRow label="Район" value={deal.district || "—"} />
                <InfoRow label="Метро" value={deal.metro_station || "—"} />
              </div>
            </section>

            <section className="crm-deal-panel__section">
              <h2 className="crm-client-panel__section-title">Этап сделки</h2>
              <CrmDealStageControl linkId={deal.link_id} initialStatus={deal.status} />
            </section>
            <section className="crm-deal-panel__section">
              <h2 className="crm-client-panel__section-title">Детали</h2>
              <div className="crm-client-panel__info-list">
                <InfoRow label="Источник" value={deal.source || "—"} />
                <InfoRow label="Комментарий клиента" value={deal.comment || "—"} />
                <InfoRow label="Создано" value={formatCrmDate(deal.created_at)} />
                <InfoRow label="Обновлено" value={formatCrmDate(deal.update_at)} />
              </div>
            </section>

            {proposalsWarning ? <div className="crm-action__feedback crm-action__feedback--error">{proposalsWarning}</div> : null}
            {client ? <CrmClientProposals title="Подборка клиента" items={client.estates} currentEstateId={deal.estate_id} /> : null}
          </div>
        </CrmPanel>

        <div className="crm-stack">
          {activityWarning ? <div className="crm-action__feedback crm-action__feedback--error">{activityWarning}</div> : null}
          <CrmDealActivity linkId={deal.link_id} initialComments={comments} initialTasks={tasks} />
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="crm-client-panel__info-row">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function BackToDealsLink() {
  return (
    <Link href={crmRoutes.deals} className="crm-button crm-button--ghost">
      К сделкам
    </Link>
  );
}
