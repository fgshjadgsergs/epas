import { CrmUserEditor } from "@/components/crm/users/crm-user-editor";
import { requireCrmUsersAccess } from "@/lib/crm-auth";

export default async function CrmUserCreatePage() {
  const viewer = await requireCrmUsersAccess();

  return <CrmUserEditor mode="create" viewer={viewer} />;
}
