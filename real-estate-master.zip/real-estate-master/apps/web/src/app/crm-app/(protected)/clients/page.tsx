import { CrmClientsWorkspace } from "@/components/crm/clients/crm-clients-workspace";
import { CrmClientBrokerItem, CrmClientListItem, CrmListResponse, CrmMetaResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmClientsAccess } from "@/lib/crm-auth";
import { SearchParamsRecord, getSingleValue, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function CrmClientsPage({ searchParams }: PageProps) {
  const user = await requireCrmClientsAccess();
  const resolvedSearchParams = (await searchParams) ?? {};
  const query = toUrlSearchParams(resolvedSearchParams).toString();
  const [meta, list, brokers] = await Promise.all([
    fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta"),
    fetchCrmServer<CrmListResponse<CrmClientListItem>>(`/api/v1/crm/clients${query ? `?${query}` : ""}`),
    fetchCrmServer<{ items: CrmClientBrokerItem[] }>("/api/v1/crm/clients/brokers"),
  ]);
  const limit = Number(getSingleValue(resolvedSearchParams.limit) ?? meta.clients.list.default_limit);
  const skip = Number(getSingleValue(resolvedSearchParams.skip) ?? 0);

  return (
    <CrmClientsWorkspace
      items={list.items}
      total={list.total}
      skip={skip}
      limit={limit}
      searchParams={resolvedSearchParams}
      viewer={user}
      brokerOptions={brokers.items}
      dealTypeOptions={meta.estate.form.choice_fields.deal_type}
    />
  );
}