import { ReactNode } from "react";
import { CrmShell } from "@/components/crm/layout/crm-shell";
import { requireCrmUser } from "@/lib/crm-auth";

export default async function CrmProtectedLayout({ children }: { children: ReactNode }) {
  const user = await requireCrmUser();

  return <CrmShell user={user}>{children}</CrmShell>;
}
