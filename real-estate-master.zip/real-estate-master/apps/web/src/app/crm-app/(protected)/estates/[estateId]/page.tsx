import { notFound } from "next/navigation";
import { CrmEstateEditor } from "@/components/crm/estates/crm-estate-editor";
import { CrmApiError, CrmEstateDetail, CrmItemResponse, CrmListResponse, CrmMetaResponse, CrmUser } from "@/lib/crm-api";
import { fetchCrmServer, fetchCrmServerOptional } from "@/lib/crm-api-server";
import { requireCrmUser } from "@/lib/crm-auth";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord } from "@/lib/public-query";

interface PageProps {
  params: Promise<{ estateId: string }>;
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function CrmEstateDetailPage({ params, searchParams }: PageProps) {
  const user = await requireCrmUser();
  const { estateId } = await params;
  const resolvedSearchParams = (await searchParams) ?? {};
  const numericId = Number.parseInt(estateId, 10);
  const archived = resolvedSearchParams.archived === "1" || resolvedSearchParams.archived === "true";
  const returnTo = Array.isArray(resolvedSearchParams.returnTo) ? resolvedSearchParams.returnTo[0] : resolvedSearchParams.returnTo;
  const backHref =
    returnTo === "my-archive"
      ? crmRoutes.myEstatesArchive
      : returnTo === "archive"
        ? crmRoutes.estatesArchive
        : archived
          ? user.role === "OWNER" || user.role === "ADMIN" || user.role === "ROP"
            ? crmRoutes.estatesArchive
            : crmRoutes.myEstatesArchive
          : undefined;

  if (!Number.isInteger(numericId) || numericId <= 0) {
    notFound();
  }

  try {
    const [meta, estate, brokerList] = await Promise.all([
      fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta"),
      fetchCrmServer<CrmItemResponse<CrmEstateDetail>>(`/api/v1/crm/estates/${numericId}${archived ? "?archived=1" : ""}`),
      fetchCrmServerOptional<CrmListResponse<CrmUser>>("/api/v1/crm/users?limit=100"),
    ]);
    const canManageAssignments = user.role === "OWNER" || user.role === "ADMIN";
    const assignableUsers =
      canManageAssignments
        ? brokerList?.items.filter((candidate) => candidate.role === "BROKER" || candidate.role === "ADMIN") ?? []
        : [];

    return (
      <CrmEstateEditor
        mode="edit"
        viewer={user}
        meta={meta}
        item={estate.item}
        assignableUsers={assignableUsers}
        archivedView={archived}
        backHref={backHref}
      />
    );
  } catch (error) {
    if (error instanceof CrmApiError && error.status === 404) {
      notFound();
    }

    throw error;
  }
}
