import { CrmDealsWorkspace } from "@/components/crm/deals/crm-deals-workspace";
import { CrmDealBrokerItem, CrmDealListItem, CrmListResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmClientsAccess } from "@/lib/crm-auth";
import { SearchParamsRecord, getSingleValue, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function CrmDealsPage({ searchParams }: PageProps) {
  const user = await requireCrmClientsAccess();
  const resolvedSearchParams = (await searchParams) ?? {};
  const query = toUrlSearchParams(resolvedSearchParams).toString();

  const [list, brokersResponse] = await Promise.all([
    fetchCrmServer<CrmListResponse<CrmDealListItem>>(`/api/v1/crm/deals${query ? `?${query}` : ""}`),
    fetchCrmServer<{ items: CrmDealBrokerItem[] }>("/api/v1/crm/deals/brokers"),
  ]);

  return (
    <CrmDealsWorkspace
      items={list.items}
      total={list.total}
      skip={list.skip ?? 0}
      limit={list.limit ?? list.items.length}
      searchParams={resolvedSearchParams}
      selectedBrokerId={getSingleValue(resolvedSearchParams.broker_id) ?? ""}
      brokerOptions={brokersResponse.items}
      viewer={user}
    />
  );
}
