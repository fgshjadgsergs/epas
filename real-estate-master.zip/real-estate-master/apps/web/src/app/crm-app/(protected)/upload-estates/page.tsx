import Link from "next/link";
import { CrmAvitoFeedTable } from "@/components/crm/estates/crm-avito-feed-table";
import { CrmEstateFilters } from "@/components/crm/estates/crm-estate-filters";
import { CrmEstateTable } from "@/components/crm/estates/crm-estate-table";
import { CrmActionButton } from "@/components/crm/shared/crm-action-button";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPagination } from "@/components/crm/shared/crm-pagination";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import { AvitoFeedListItem, CrmEstateListItem, CrmListResponse, CrmMetaResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmQueueAccess } from "@/lib/crm-auth";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord, getSingleValue, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function CrmUploadPage({ searchParams }: PageProps) {
  const user = await requireCrmQueueAccess();
  const resolvedSearchParams = (await searchParams) ?? {};
  const activeTab = getSingleValue(resolvedSearchParams.tab) === "avito" ? "avito" : "cian";
  const query = toUrlSearchParams(resolvedSearchParams).toString();
  const meta = await fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta");
  const list =
    activeTab === "avito"
      ? await fetchCrmServer<CrmListResponse<AvitoFeedListItem>>("/api/v1/crm/avito/feed/items")
      : await fetchCrmServer<CrmListResponse<CrmEstateListItem>>(`/api/v1/crm/estates/upload${query ? `?${query}` : ""}`);

  return (
    <>
      <CrmPageHeader
        title={activeTab === "avito" ? "Выгрузка Авито" : "Очередь выгрузки CIAN"}
        description={
          activeTab === "avito"
            ? "Объекты, которые уже одобрены и попадают в XML-фид Авито."
            : "Объекты, уже подтверждённые для CIAN. XML формируется вручную."
        }
        action={
          activeTab === "cian" ? (
            <CrmActionButton path="/api/v1/crm/cian/actions/create-xml" successMessage="XML сформирован.">
              Сформировать XML
            </CrmActionButton>
          ) : null
        }
      />

      <div className="crm-stack">
        <CrmPanel>
          <div className="crm-inline-filters">
            <Link
              href={crmRoutes.uploadEstates}
              className={`crm-button ${activeTab === "cian" ? "crm-button--secondary" : "crm-button--ghost"}`}
              prefetch={false}
            >
              CIAN
            </Link>
            <Link
              href={`${crmRoutes.uploadEstates}?tab=avito`}
              className={`crm-button ${activeTab === "avito" ? "crm-button--secondary" : "crm-button--ghost"}`}
              prefetch={false}
            >
              Авито
            </Link>
          </div>
        </CrmPanel>

        {activeTab === "cian" ? (
          <>
            <CrmPanel>
              <CrmEstateFilters
                searchParams={resolvedSearchParams}
                dealTypes={meta.estate.form.choice_fields.deal_type}
                regions={meta.estate.form.choice_fields.region}
                districts={meta.estate.form.choice_fields.district}
              />
            </CrmPanel>

            <CrmPanel>
              {list.items.length > 0 ? (
                <>
                  <CrmEstateTable items={list.items as CrmEstateListItem[]} viewer={user} mode="upload" />
                  <CrmPagination
                    pathname={crmRoutes.uploadEstates}
                    searchParams={resolvedSearchParams}
                    skip={list.skip ?? 0}
                    limit={list.limit ?? meta.estate.list.default_limit}
                    total={list.total}
                  />
                </>
              ) : (
                <CrmEmptyState title="Очередь выгрузки пуста" description="Сначала подтвердите объекты из модерации." />
              )}
            </CrmPanel>
          </>
        ) : (
          <CrmPanel>
            {list.items.length > 0 ? (
              <CrmAvitoFeedTable items={list.items as AvitoFeedListItem[]} />
            ) : (
              <CrmEmptyState
                title="Выгрузка Авито пуста"
                description="После внутреннего одобрения валидные объекты появятся здесь и в XML-фиде."
              />
            )}
          </CrmPanel>
        )}
      </div>
    </>
  );
}
