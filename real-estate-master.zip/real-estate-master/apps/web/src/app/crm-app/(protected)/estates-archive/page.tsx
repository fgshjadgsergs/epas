import { CrmEstateFilters } from "@/components/crm/estates/crm-estate-filters";
import { CrmEstateTable } from "@/components/crm/estates/crm-estate-table";
import { CrmHeaderLink, CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPagination } from "@/components/crm/shared/crm-pagination";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import { CrmEstateListItem, CrmListResponse, CrmMetaResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmEstatesAccess } from "@/lib/crm-auth";
import { getCrmRoleLabel } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

function withArchiveDefaults(searchParams: SearchParamsRecord): SearchParamsRecord {
  return {
    ...searchParams,
    archivedOnly: "true",
  };
}

export default async function CrmEstatesArchivePage({ searchParams }: PageProps) {
  const user = await requireCrmEstatesAccess();
  const resolvedSearchParams = withArchiveDefaults((await searchParams) ?? {});
  const query = toUrlSearchParams(resolvedSearchParams).toString();
  const [meta, list] = await Promise.all([
    fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta"),
    fetchCrmServer<CrmListResponse<CrmEstateListItem>>(`/api/v1/crm/estates${query ? `?${query}` : ""}`),
  ]);

  return (
    <>
      <CrmPageHeader
        title="Архив объектов"
        description={`Отдельный список soft-deleted объектов CRM. Доступ в соответствии с ролью: ${getCrmRoleLabel(user)}.`}
        action={<CrmHeaderLink href={crmRoutes.estates}>Активные объекты</CrmHeaderLink>}
      />

      <div className="crm-stack">
        <CrmPanel>
          <CrmEstateFilters
            searchParams={resolvedSearchParams}
            dealTypes={meta.estate.form.choice_fields.deal_type}
            regions={meta.estate.form.choice_fields.region}
            districts={meta.estate.form.choice_fields.district}
            archivedOnly
            defaultActive=""
          />
        </CrmPanel>

        <CrmPanel>
          {list.items.length > 0 ? (
            <>
              <CrmEstateTable items={list.items} viewer={user} mode="default" archivedOnly />
              <CrmPagination
                pathname={crmRoutes.estatesArchive}
                searchParams={resolvedSearchParams}
                skip={list.skip ?? 0}
                limit={list.limit ?? meta.estate.list.default_limit}
                total={list.total}
              />
            </>
          ) : (
            <CrmEmptyState title="Архив пуст" description="Soft-deleted объектов по текущим фильтрам не найдено." />
          )}
        </CrmPanel>
      </div>
    </>
  );
}
