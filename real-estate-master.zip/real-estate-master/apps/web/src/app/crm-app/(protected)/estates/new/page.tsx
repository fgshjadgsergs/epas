import { CrmEstateEditor } from "@/components/crm/estates/crm-estate-editor";
import { CrmListResponse, CrmMetaResponse, CrmUser } from "@/lib/crm-api";
import { fetchCrmServer, fetchCrmServerOptional } from "@/lib/crm-api-server";
import { requireCrmEstatesAccess } from "@/lib/crm-auth";

export default async function CrmEstateCreatePage() {
  const user = await requireCrmEstatesAccess();
  const canManageAssignments = user.role === "OWNER" || user.role === "ADMIN";
  const [meta, brokerList] = await Promise.all([
    fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta"),
    fetchCrmServerOptional<CrmListResponse<CrmUser>>("/api/v1/crm/users?limit=100"),
  ]);
  const assignableUsers =
    canManageAssignments
      ? brokerList?.items.filter((candidate) => candidate.role === "BROKER" || candidate.role === "ADMIN") ?? []
      : [];

  return <CrmEstateEditor mode="create" viewer={user} meta={meta} assignableUsers={assignableUsers} />;
}
