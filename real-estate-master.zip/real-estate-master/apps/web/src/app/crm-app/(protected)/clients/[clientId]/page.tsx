import Link from "next/link";
import { CrmClientStandalone } from "@/components/crm/clients/crm-client-standalone";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmErrorState } from "@/components/crm/shared/crm-state";
import { CrmMetaResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmClientsAccess } from "@/lib/crm-auth";

const CLIENT_LIST_HREF = "/crm/clients";

interface PageProps {
  params: Promise<{
    clientId: string;
  }>;
}

export default async function CrmClientPage({ params }: PageProps) {
  const user = await requireCrmClientsAccess();
  const { clientId } = await params;
  const numericId = Number(clientId);

  if (!Number.isInteger(numericId) || numericId <= 0) {
    return (
      <>
        <CrmPageHeader title="Клиент" action={<BackToClientsLink />} />
        <CrmErrorState title="Клиент не найден" description="Проверьте ссылку или вернитесь к списку клиентов." />
      </>
    );
  }

  const meta = await fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta");

  return (
    <>
      <CrmPageHeader title="Клиент" action={<BackToClientsLink />} />
      <CrmClientStandalone clientId={numericId} viewer={user} dealTypeOptions={meta.estate.form.choice_fields.deal_type} />
    </>
  );
}

function BackToClientsLink() {
  return (
    <Link href={CLIENT_LIST_HREF} className="crm-button crm-button--ghost">
      К списку
    </Link>
  );
}
