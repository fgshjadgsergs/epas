﻿import Link from "next/link";
import { CrmAvitoModerationTable } from "@/components/crm/estates/crm-avito-moderation-table";
import { CrmEstateFilters } from "@/components/crm/estates/crm-estate-filters";
import { CrmEstateTable } from "@/components/crm/estates/crm-estate-table";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPagination } from "@/components/crm/shared/crm-pagination";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import { AvitoModerationListItem, CrmEstateListItem, CrmListResponse, CrmMetaResponse } from "@/lib/crm-api";
import { fetchCrmServer } from "@/lib/crm-api-server";
import { requireCrmQueueAccess } from "@/lib/crm-auth";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord, toUrlSearchParams } from "@/lib/public-query";

interface PageProps {
  searchParams?: Promise<SearchParamsRecord>;
}

export default async function CrmModerationPage({ searchParams }: PageProps) {
  const user = await requireCrmQueueAccess();
  const resolvedSearchParams = (await searchParams) ?? {};
  const activeTab = resolvedSearchParams.tab === "avito" ? "avito" : "objects";
  const query = toUrlSearchParams(resolvedSearchParams).toString();
  const meta = await fetchCrmServer<CrmMetaResponse>("/api/v1/crm/meta");
  const list =
    activeTab === "avito"
      ? await fetchCrmServer<CrmListResponse<AvitoModerationListItem>>(
          `/api/v1/crm/avito/moderation${query ? `?${query}` : ""}`,
        )
      : await fetchCrmServer<CrmListResponse<CrmEstateListItem>>(`/api/v1/crm/estates/moderation${query ? `?${query}` : ""}`);

  return (
    <>
      <CrmPageHeader
        title={activeTab === "avito" ? "Модерация Авито" : "Модерация CIAN"}
        description={
          activeTab === "avito"
            ? "Очередь объектов, ожидающих внутреннего одобрения перед выгрузкой в Авито."
            : "Очередь объектов, ожидающих подтверждения перед выгрузкой."
        }
      />

      <div className="crm-stack">
        <CrmPanel>
          <div className="crm-inline-filters">
            <Link
              href={crmRoutes.moderationEstates}
              className={`crm-button ${activeTab === "objects" ? "crm-button--secondary" : "crm-button--ghost"}`}
              prefetch={false}
            >
              Объекты
            </Link>
            <Link
              href={`${crmRoutes.moderationEstates}?tab=avito&status=PENDING_REVIEW`}
              className={`crm-button ${activeTab === "avito" ? "crm-button--secondary" : "crm-button--ghost"}`}
              prefetch={false}
            >
              Авито
            </Link>
          </div>
        </CrmPanel>

        {activeTab === "objects" ? (
          <>
            <CrmPanel>
              <CrmEstateFilters
                searchParams={resolvedSearchParams}
                dealTypes={meta.estate.form.choice_fields.deal_type}
                regions={meta.estate.form.choice_fields.region}
                districts={meta.estate.form.choice_fields.district}
              />
            </CrmPanel>

            <CrmPanel>
              {list.items.length > 0 ? (
                <>
                  <CrmEstateTable items={list.items as CrmEstateListItem[]} viewer={user} mode="moderation" />
                  <CrmPagination
                    pathname={crmRoutes.moderationEstates}
                    searchParams={resolvedSearchParams}
                    skip={list.skip ?? 0}
                    limit={list.limit ?? meta.estate.list.default_limit}
                    total={list.total}
                  />
                </>
              ) : (
                <CrmEmptyState title="Очередь пуста" description="Сейчас нет объектов, ожидающих модерации." />
              )}
            </CrmPanel>
          </>
        ) : (
          <CrmPanel>
            {list.items.length > 0 ? (
              <>
                <CrmAvitoModerationTable items={list.items as AvitoModerationListItem[]} viewer={user} />
                <CrmPagination
                  pathname={crmRoutes.moderationEstates}
                  searchParams={resolvedSearchParams}
                  skip={list.skip ?? 0}
                  limit={list.limit ?? meta.estate.list.default_limit}
                  total={list.total}
                />
              </>
            ) : (
              <CrmEmptyState
                title="Очередь Авито пуста"
                description="Сейчас нет объектов, ожидающих внутренней модерации Авито."
              />
            )}
          </CrmPanel>
        )}
      </div>
    </>
  );
}

