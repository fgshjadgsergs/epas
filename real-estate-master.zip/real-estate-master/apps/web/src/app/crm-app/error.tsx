"use client";

import { useEffect } from "react";

export default function CrmAppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("[CRM APP ERROR]", error);
  }, [error]);

  return (
    <main className="crm-login">
      <section className="crm-login__panel">
        <div className="crm-login__brand">EPAS CRM</div>
        <h1 className="crm-login__title">Не удалось открыть CRM</h1>
        <p className="crm-login__subtitle">Не удалось проверить сессию. Обновите страницу или очистите данные сайта.</p>
        <button type="button" className="crm-button crm-button--wide" onClick={reset}>
          Повторить
        </button>
      </section>
    </main>
  );
}
