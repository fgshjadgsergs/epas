﻿import type { Metadata } from "next";
import Script from "next/script";
import { ReactNode } from "react";
import { QueryProvider } from "@/components/providers/query-provider";
import "./globals.css";


export const metadata: Metadata = {
  title: {
    default: "EPAS Development",
    template: "%s - EPAS Development",
  },
  description: "Аренда и продажа коммерческой недвижимости в Москве",
  icons: {
    icon: "/static/img/site-favicon.png",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=DM+Serif+Display&display=swap"
          rel="stylesheet"
        />
        <link rel="stylesheet" href="/static/fonts/flaticon/flaticon.css" />
        <link rel="stylesheet" href="/static/css/swiper-bundle.min.css" />
        <link rel="stylesheet" href="/static/css/discoverize-default.css" />
        <link rel="stylesheet" href="/static/css/cards.css" />
      </head>
      <body>
        <QueryProvider>{children}</QueryProvider>
        <Script src="/static/js/bootstrap.bundle.min.js" strategy="afterInteractive" />
      </body>
    </html>
  );
}

