"use client";

import { useRouter } from "next/navigation";
import { startTransition, useState } from "react";
import { CrmApiError, CrmUser, crmClientFetch } from "@/lib/crm-api";
import { crmRoutes } from "@/lib/crm-routes";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPanel } from "@/components/crm/shared/crm-state";

function readFieldMessage(payload: unknown, field: string): string | null {
  if (!payload || typeof payload !== "object") {
    return null;
  }

  const data = payload as { errors?: Record<string, string>; message?: string };
  return data.errors?.[field] ?? data.message ?? null;
}

export function CrmProfileScreen({
  viewer,
  profile,
}: {
  viewer: CrmUser;
  profile: Record<string, unknown>;
}) {
  const router = useRouter();
  const [profileError, setProfileError] = useState<string | null>(null);
  const [profileMessage, setProfileMessage] = useState<string | null>(null);
  const [profilePending, setProfilePending] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);
  const [passwordPending, setPasswordPending] = useState(false);

  return (
    <div className="crm-stack">
      <CrmPageHeader title="Профиль" description="Быстрое редактирование профиля и смена пароля без лишних переходов." />

      <div className="crm-form-grid">
        <CrmPanel>
          <h2 className="crm-section-title">Личные данные</h2>
          <form
            className="crm-form"
            onSubmit={(event) => {
              event.preventDefault();
              setProfileError(null);
              setProfileMessage(null);
              const formData = new FormData(event.currentTarget);
              setProfilePending(true);

              startTransition(async () => {
                try {
                  await crmClientFetch("/api/v1/crm/profile", {
                    method: "PUT",
                    headers: {
                      "content-type": "application/json",
                    },
                    body: JSON.stringify({
                      email: formData.get("email"),
                      first_name: formData.get("first_name"),
                      last_name: formData.get("last_name"),
                      phone_number: formData.get("phone_number"),
                    }),
                  });

                  setProfileMessage("Профиль обновлен.");
                  router.refresh();
                } catch (requestError) {
                  if (requestError instanceof CrmApiError) {
                    setProfileError(
                      readFieldMessage(requestError.payload, "email") ??
                        readFieldMessage(requestError.payload, "first_name") ??
                        readFieldMessage(requestError.payload, "last_name") ??
                        readFieldMessage(requestError.payload, "phone_number") ??
                        "Не удалось обновить профиль.",
                    );
                  } else {
                    setProfileError("Не удалось обновить профиль.");
                  }
                } finally {
                  setProfilePending(false);
                }
              });
            }}
          >
            <label className="crm-field">
              <span className="crm-field__label">Email</span>
              <input className="crm-input" name="email" defaultValue={String(profile.email ?? viewer.email)} />
            </label>

            <label className="crm-field">
              <span className="crm-field__label">Имя</span>
              <input className="crm-input" name="first_name" defaultValue={String(profile.first_name ?? viewer.first_name)} />
            </label>

            <label className="crm-field">
              <span className="crm-field__label">Фамилия</span>
              <input className="crm-input" name="last_name" defaultValue={String(profile.last_name ?? viewer.last_name)} />
            </label>

            <label className="crm-field">
              <span className="crm-field__label">Телефон</span>
              <input className="crm-input" name="phone_number" defaultValue={String(profile.phone_number ?? viewer.phone_number)} />
            </label>

            {profileError ? <div className="crm-form__error">{profileError}</div> : null}
            {profileMessage ? <div className="crm-form__success">{profileMessage}</div> : null}

            <div className="crm-form-actions crm-form-actions--sticky">
              <button type="submit" className="crm-button" disabled={profilePending}>
                {profilePending ? "Сохранение..." : "Сохранить профиль"}
              </button>
            </div>
          </form>
        </CrmPanel>

        <CrmPanel>
          <h2 className="crm-section-title">Смена пароля</h2>
          <form
            className="crm-form"
            onSubmit={(event) => {
              event.preventDefault();
              setPasswordError(null);
              setPasswordMessage(null);
              const formData = new FormData(event.currentTarget);
              setPasswordPending(true);

              startTransition(async () => {
                try {
                  const result = await crmClientFetch<{ message: string }>("/api/v1/crm/profile/change-password", {
                    method: "POST",
                    headers: {
                      "content-type": "application/json",
                    },
                    body: JSON.stringify({
                      password: formData.get("password"),
                      repeat_password: formData.get("repeat_password"),
                    }),
                  });

                  setPasswordMessage(result.message ?? "Пароль изменен.");
                  router.replace(crmRoutes.login);
                  router.refresh();
                } catch (requestError) {
                  if (requestError instanceof CrmApiError) {
                    setPasswordError(
                      readFieldMessage(requestError.payload, "password") ??
                        readFieldMessage(requestError.payload, "repeat_password") ??
                        "Не удалось изменить пароль.",
                    );
                  } else {
                    setPasswordError("Не удалось изменить пароль.");
                  }
                } finally {
                  setPasswordPending(false);
                }
              });
            }}
          >
            <label className="crm-field">
              <span className="crm-field__label">Новый пароль</span>
              <input className="crm-input" type="password" name="password" minLength={9} />
            </label>

            <label className="crm-field">
              <span className="crm-field__label">Повтор пароля</span>
              <input className="crm-input" type="password" name="repeat_password" minLength={9} />
            </label>

            {passwordError ? <div className="crm-form__error">{passwordError}</div> : null}
            {passwordMessage ? <div className="crm-form__success">{passwordMessage}</div> : null}

            <div className="crm-form-actions crm-form-actions--sticky">
              <button type="submit" className="crm-button" disabled={passwordPending}>
                {passwordPending ? "Смена..." : "Изменить пароль"}
              </button>
            </div>
          </form>
        </CrmPanel>
      </div>
    </div>
  );
}
