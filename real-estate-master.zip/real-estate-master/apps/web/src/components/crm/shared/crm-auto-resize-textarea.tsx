"use client";

import { TextareaHTMLAttributes, useCallback, useLayoutEffect, useRef } from "react";

type CrmAutoResizeTextareaProps = TextareaHTMLAttributes<HTMLTextAreaElement>;

export function CrmAutoResizeTextarea({
  className,
  onInput,
  onChange,
  ...props
}: CrmAutoResizeTextareaProps) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const resize = useCallback(() => {
    const element = textareaRef.current;
    if (!element) {
      return;
    }

    element.style.height = "0px";
    element.style.height = `${element.scrollHeight}px`;
  }, []);

  useLayoutEffect(() => {
    resize();
  }, [resize, props.defaultValue, props.value]);

  return (
    <textarea
      {...props}
      ref={textareaRef}
      className={className ? `crm-textarea crm-textarea--auto ${className}` : "crm-textarea crm-textarea--auto"}
      onInput={(event) => {
        resize();
        onInput?.(event);
      }}
      onChange={(event) => {
        onChange?.(event);
      }}
    />
  );
}
