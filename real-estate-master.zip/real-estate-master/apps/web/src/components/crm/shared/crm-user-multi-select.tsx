"use client";

import { useEffect, useMemo, useRef, useState } from "react";

export interface CrmUserMultiSelectOption {
  id: number;
  label: string;
  description?: string;
  searchText?: string;
}

export function CrmUserMultiSelect({
  name,
  options,
  selectedIds,
  onChange,
  disabled = false,
  maxSelected = 3,
  helperText,
  emptyText = "Нет доступных пользователей для назначения.",
  searchPlaceholder = "Поиск по имени, email или ID",
  noResultsText = "Ничего не найдено.",
  limitMessage = "Можно назначить не больше 3 пользователей.",
  onErrorChange,
  filterOptions,
}: {
  name?: string;
  options: CrmUserMultiSelectOption[];
  selectedIds: number[];
  onChange: (nextIds: number[]) => void;
  disabled?: boolean;
  maxSelected?: number;
  helperText?: string;
  emptyText?: string;
  searchPlaceholder?: string;
  noResultsText?: string;
  limitMessage?: string;
  onErrorChange?: (message: string | null) => void;
  filterOptions?: (options: CrmUserMultiSelectOption[], query: string) => CrmUserMultiSelectOption[];
}) {
  const rootRef = useRef<HTMLDivElement | null>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [localError, setLocalError] = useState<string | null>(null);

  const selectedOptions = useMemo(
    () => options.filter((option) => selectedIds.includes(option.id)),
    [options, selectedIds],
  );

  const filteredOptions = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    if (!normalizedQuery) {
      return options;
    }

    if (filterOptions) {
      return filterOptions(options, normalizedQuery);
    }

    return options.filter((option) => {
      const haystack = [option.id, option.label, option.description, option.searchText]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(normalizedQuery);
    });
  }, [filterOptions, options, query]);

  useEffect(() => {
    function handlePointerDown(event: MouseEvent) {
      if (!rootRef.current || rootRef.current.contains(event.target as Node)) {
        return;
      }

      setOpen(false);
    }

    document.addEventListener("mousedown", handlePointerDown);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
    };
  }, []);

  function updateError(message: string | null) {
    setLocalError(message);
    onErrorChange?.(message);
  }

  function toggleOption(optionId: number) {
    if (selectedIds.includes(optionId)) {
      updateError(null);
      onChange(selectedIds.filter((selectedId) => selectedId !== optionId));
      return;
    }

    if (selectedIds.length >= maxSelected) {
      updateError(limitMessage);
      return;
    }

    updateError(null);
    onChange([...selectedIds, optionId]);
  }

  return (
    <div className="crm-user-multi-select" ref={rootRef}>
      {name
        ? selectedIds.map((selectedId) => (
            <input key={selectedId} type="hidden" name={name} value={String(selectedId)} />
          ))
        : null}

      <button
        type="button"
        className="crm-user-multi-select__trigger crm-control-surface"
        onClick={() => {
          if (disabled) {
            return;
          }

          setOpen((current) => !current);
        }}
        disabled={disabled}
        aria-expanded={open}
      >
        <span className="crm-user-multi-select__summary">
          {selectedOptions.length > 0 ? `${selectedOptions.length} выбрано` : <span className="crm-user-multi-select__placeholder">Пользователи не выбраны</span>}
        </span>
        <span className="crm-user-multi-select__meta">
          {selectedIds.length}/{maxSelected}
        </span>
      </button>

      {helperText ? <p className="crm-subsection__note">{helperText}</p> : null}
      {selectedOptions.length > 0 ? (
        <div className="crm-user-multi-select__selected">
          {selectedOptions.map((option) => (
            <span className="crm-chip" key={option.id}>
              <span className="crm-chip__text">{option.label}</span>
              {!disabled ? (
                <button
                  type="button"
                  className="crm-chip__remove"
                  onClick={() => {
                    toggleOption(option.id);
                  }}
                  aria-label={`Удалить ${option.label}`}
                >
                  ×
                </button>
              ) : null}
            </span>
          ))}
        </div>
      ) : null}
      {localError ? <div className="crm-form__error crm-form__error--compact">{localError}</div> : null}

      {open ? (
        <div className="crm-user-multi-select__panel crm-control-surface">
          <input
            className="crm-input"
            type="search"
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
            }}
            placeholder={searchPlaceholder}
          />

          <div className="crm-user-multi-select__options">
            {options.length === 0 ? (
              <div className="crm-note">{emptyText}</div>
            ) : filteredOptions.length === 0 ? (
              <div className="crm-note">{noResultsText}</div>
            ) : (
              filteredOptions.map((option) => {
                const checked = selectedIds.includes(option.id);
                return (
                  <label className="crm-checkbox" key={option.id}>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => {
                        toggleOption(option.id);
                      }}
                    />
                    <span>
                      {option.label}
                      {option.description ? <span className="crm-user-multi-select__option-description"> · {option.description}</span> : null}
                    </span>
                  </label>
                );
              })
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
