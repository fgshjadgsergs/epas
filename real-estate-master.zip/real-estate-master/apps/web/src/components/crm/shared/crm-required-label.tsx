import { ReactNode } from "react";

export function CrmRequiredLabel({
  children,
  required = false,
}: {
  children: ReactNode;
  required?: boolean;
}) {
  return (
    <span className="crm-field__label">
      {children}
      {required ? <span className="crm-required-mark" aria-hidden="true"> *</span> : null}
    </span>
  );
}
