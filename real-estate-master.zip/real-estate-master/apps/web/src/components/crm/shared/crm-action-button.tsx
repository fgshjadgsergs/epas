"use client";

import { ReactNode, useState } from "react";
import { useRouter } from "next/navigation";
import { CrmApiError, crmClientFetch } from "@/lib/crm-api";
import { cn } from "@/lib/utils";

export function CrmActionButton({
  path,
  method = "POST",
  body,
  confirmText,
  successMessage,
  refreshOnSuccess = true,
  className,
  onSuccess,
  children,
}: {
  path: string;
  method?: "POST" | "PUT" | "DELETE";
  body?: unknown;
  confirmText?: string;
  successMessage?: string;
  refreshOnSuccess?: boolean;
  className?: string;
  onSuccess?: () => void;
  children: ReactNode;
}) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  return (
    <div className="crm-action">
      <button
        type="button"
        className={cn("crm-button crm-button--secondary", className)}
        disabled={pending}
        onClick={async (event) => {
          event.stopPropagation();

          if (confirmText && !window.confirm(confirmText)) {
            return;
          }

          setPending(true);
          setError(null);
          setMessage(null);

          try {
            await crmClientFetch(path, {
              method,
              headers: body ? { "content-type": "application/json" } : undefined,
              body: body ? JSON.stringify(body) : undefined,
            });

            setMessage(successMessage ?? "Действие выполнено.");
            onSuccess?.();

            if (refreshOnSuccess) {
              router.refresh();
            }
          } catch (requestError) {
            if (requestError instanceof CrmApiError && requestError.payload && typeof requestError.payload === "object") {
              const payload = requestError.payload as { message?: string };
              setError(payload.message ?? "Не удалось выполнить действие.");
            } else {
              setError("Не удалось выполнить действие.");
            }
          } finally {
            setPending(false);
          }
        }}
      >
        {pending ? "..." : children}
      </button>
      {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}
      {!error && message ? <div className="crm-action__feedback">{message}</div> : null}
    </div>
  );
}
