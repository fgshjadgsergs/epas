import Link from "next/link";
import { ReactNode } from "react";

export function CrmPageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="crm-page-header">
      <div>
        <h1 className="crm-page-header__title">{title}</h1>
        {description ? <p className="crm-page-header__description">{description}</p> : null}
      </div>
      {action ? <div className="crm-page-header__action">{action}</div> : null}
    </div>
  );
}

export function CrmHeaderLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link href={href} className="crm-button">
      {children}
    </Link>
  );
}

