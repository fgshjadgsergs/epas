import Link from "next/link";
import { buildPathWithSearchParams, SearchParamsRecord } from "@/lib/public-query";

export function CrmPagination({
  pathname,
  searchParams,
  skip,
  limit,
  total,
}: {
  pathname: string;
  searchParams: SearchParamsRecord;
  skip: number;
  limit: number;
  total: number;
}) {
  const previousSkip = Math.max(0, skip - limit);
  const nextSkip = skip + limit;
  const from = total === 0 ? 0 : skip + 1;
  const to = Math.min(skip + limit, total);

  return (
    <div className="crm-pagination">
      <div className="crm-pagination__summary">Показано {from}-{to} из {total}</div>

      <div className="crm-pagination__actions">
        <Link
          href={buildPathWithSearchParams(pathname, searchParams, { skip: previousSkip })}
          className={`crm-button crm-button--ghost${skip <= 0 ? " is-disabled" : ""}`}
          aria-disabled={skip <= 0}
          tabIndex={skip <= 0 ? -1 : undefined}
        >
          Назад
        </Link>

        <Link
          href={buildPathWithSearchParams(pathname, searchParams, { skip: nextSkip })}
          className={`crm-button crm-button--ghost${nextSkip >= total ? " is-disabled" : ""}`}
          aria-disabled={nextSkip >= total}
          tabIndex={nextSkip >= total ? -1 : undefined}
        >
          Дальше
        </Link>
      </div>
    </div>
  );
}
