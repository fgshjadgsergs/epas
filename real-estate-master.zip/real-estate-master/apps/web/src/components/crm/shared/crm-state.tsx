import { ReactNode } from "react";

export function CrmPanel({ children }: { children: ReactNode }) {
  return <section className="crm-panel">{children}</section>;
}

export function CrmEmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="crm-state">
      <h2 className="crm-state__title">{title}</h2>
      <p className="crm-state__description">{description}</p>
    </div>
  );
}

export function CrmErrorState({ title, description }: { title: string; description: string }) {
  return (
    <div className="crm-state crm-state--error">
      <h2 className="crm-state__title">{title}</h2>
      <p className="crm-state__description">{description}</p>
    </div>
  );
}

