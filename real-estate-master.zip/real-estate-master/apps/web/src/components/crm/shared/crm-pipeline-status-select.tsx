"use client";

import { useRouter } from "next/navigation";
import { startTransition, useState } from "react";
import { CrmApiError, CrmPipelineStatus, updateCrmDealStage } from "@/lib/crm-api";
import { CRM_PIPELINE_OPTIONS, getCrmPipelineClassName, getCrmPipelineLabel } from "@/lib/crm-pipeline";
import { cn } from "@/lib/utils";

export function CrmPipelineStatusSelect({
  linkId,
  status,
  disabled,
  onSuccess,
}: {
  linkId: number;
  status: CrmPipelineStatus;
  disabled?: boolean;
  onSuccess?: () => void;
}) {
  const router = useRouter();
  const [value, setValue] = useState<CrmPipelineStatus>(status);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (disabled) {
    return (
      <span className={cn("crm-pipeline-badge", getCrmPipelineClassName(value))} title={getCrmPipelineLabel(value)}>
        {getCrmPipelineLabel(value)}
      </span>
    );
  }

  return (
    <div className="crm-pipeline-select">
      <select
        className={cn("crm-select crm-select--pipeline", getCrmPipelineClassName(value))}
        value={value}
        disabled={pending}
        onClick={(event) => event.stopPropagation()}
        onChange={(event) => {
          const nextValue = event.target.value as CrmPipelineStatus;
          setValue(nextValue);
          setPending(true);
          setError(null);

          startTransition(async () => {
            try {
              await updateCrmDealStage(linkId, nextValue);
              onSuccess?.();
              router.refresh();
            } catch (requestError) {
              setValue(status);
              if (requestError instanceof CrmApiError && requestError.payload && typeof requestError.payload === "object") {
                const payload = requestError.payload as { message?: string };
                setError(payload.message ?? "Не удалось изменить статус.");
              } else {
                setError("Не удалось изменить статус.");
              }
            } finally {
              setPending(false);
            }
          });
        }}
      >
        {CRM_PIPELINE_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}
    </div>
  );
}
