"use client";

import { useRouter } from "next/navigation";
import { startTransition, useState } from "react";
import { CrmApiError, CrmAuthMeResponse, crmClientFetch } from "@/lib/crm-api";
import { getCrmLandingPathForUser } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

function readFieldError(payload: unknown): string | null {
  if (!payload || typeof payload !== "object") {
    return null;
  }

  const body = payload as { errors?: Record<string, string>; message?: string };
  if (body.errors?.username) {
    return body.errors.username;
  }
  if (body.errors?.password) {
    return body.errors.password;
  }

  return body.message ?? null;
}

export function CrmLoginForm() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  return (
    <main className="crm-login">
      <section className="crm-login__panel">
        <div className="crm-login__brand">EPAS CRM</div>
        <h1 className="crm-login__title">Вход в CRM</h1>
        <p className="crm-login__subtitle">Session-based вход поверх текущего Node API.</p>

        <form
          className="crm-form"
          onSubmit={(event) => {
            event.preventDefault();
            setError(null);
            setPending(true);

            startTransition(async () => {
              try {
                const response = await crmClientFetch<CrmAuthMeResponse>("/api/v1/crm/auth/login", {
                  method: "POST",
                  headers: {
                    "content-type": "application/json",
                  },
                  body: JSON.stringify({
                    username,
                    password,
                  }),
                });

                const pathname = getCrmLandingPathForUser(response.user);
                router.replace(pathname === "/profile" ? crmRoutes.profile : pathname === "/my-estates" ? crmRoutes.myEstates : crmRoutes.estates);
                router.refresh();
              } catch (requestError) {
                if (requestError instanceof CrmApiError) {
                  setError(readFieldError(requestError.payload) ?? "Не удалось выполнить вход.");
                } else {
                  setError("Не удалось выполнить вход.");
                }
              } finally {
                setPending(false);
              }
            });
          }}
        >
          <label className="crm-field">
            <span className="crm-field__label">Email</span>
            <input className="crm-input" value={username} onChange={(event) => setUsername(event.target.value)} required />
          </label>

          <label className="crm-field">
            <span className="crm-field__label">Пароль</span>
            <input className="crm-input" type="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </label>

          {error ? <div className="crm-form__error">{error}</div> : null}

          <button type="submit" className="crm-button crm-button--wide" disabled={pending}>
            {pending ? "Вход..." : "Войти"}
          </button>
        </form>
      </section>
    </main>
  );
}
