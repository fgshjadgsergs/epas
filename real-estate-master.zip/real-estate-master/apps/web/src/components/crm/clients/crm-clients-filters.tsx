"use client";

import { usePathname, useRouter } from "next/navigation";
import { startTransition, useEffect, useRef, useState } from "react";
import { CrmClientBrokerItem, CrmUser } from "@/lib/crm-api";
import { getCrmRole } from "@/lib/crm-role";
import { buildPathWithSearchParams, SearchParamsRecord } from "@/lib/public-query";

function getValue(searchParams: SearchParamsRecord, key: string): string {
  const value = searchParams[key];
  return Array.isArray(value) ? value[0] ?? "" : value ?? "";
}

type FilterState = {
  search: string;
  status: string;
  brokerId: string;
  limit: string;
};

function getInitialState(searchParams: SearchParamsRecord): FilterState {
  return {
    search: getValue(searchParams, "search"),
    status: getValue(searchParams, "status"),
    brokerId: getValue(searchParams, "brokerId") || getValue(searchParams, "broker_id"),
    limit: getValue(searchParams, "limit") || "50",
  };
}

const emptyFilters: FilterState = {
  search: "",
  status: "",
  brokerId: "",
  limit: "50",
};

export function CrmClientsFilters({
  searchParams,
  brokers,
  viewer,
}: {
  searchParams: SearchParamsRecord;
  brokers: CrmClientBrokerItem[];
  viewer: CrmUser;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const initialState = getInitialState(searchParams);
  const [filters, setFilters] = useState<FilterState>(initialState);
  const initialRenderRef = useRef(true);
  const showBrokerFilter = getCrmRole(viewer) !== "BROKER";

  useEffect(() => {
    setFilters(initialState);
    initialRenderRef.current = true;
  }, [searchParams]);

  useEffect(() => {
    if (initialRenderRef.current) {
      initialRenderRef.current = false;
      return;
    }

    const timeoutId = window.setTimeout(() => {
      startTransition(() => {
        router.replace(
          buildPathWithSearchParams(pathname, {}, {
            broker_id: null,
            ...filters,
            skip: 0,
          }),
        );
      });
    }, 200);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [filters, pathname, router]);

  const replaceFilter = (patch: Partial<FilterState>) => {
    setFilters((current) => ({ ...current, ...patch }));
  };

  return (
    <form
      className="crm-inline-filters"
      onSubmit={(event) => {
        event.preventDefault();
        router.replace(
          buildPathWithSearchParams(pathname, {}, {
            broker_id: null,
            ...filters,
            skip: 0,
          }),
        );
      }}
    >
      <label className="crm-field">
        <span className="crm-field__label">Поиск</span>
        <input className="crm-input" type="search" value={filters.search} onChange={(event) => replaceFilter({ search: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Статус</span>
        <select className="crm-select" value={filters.status} onChange={(event) => replaceFilter({ status: event.target.value })}>
          <option value="">Все</option>
          <option value="new">Новый</option>
          <option value="in_progress">В работе</option>
          <option value="showing">Показ</option>
          <option value="negotiation">Переговоры</option>
          <option value="closed">Закрыт</option>
          <option value="rejected">Отказ</option>
        </select>
      </label>

      {showBrokerFilter ? (
        <label className="crm-field">
          <span className="crm-field__label">Брокер</span>
          <select className="crm-select" value={filters.brokerId} onChange={(event) => replaceFilter({ brokerId: event.target.value })}>
            <option value="">Все доступные</option>
            {brokers.map((broker) => (
              <option key={broker.id} value={broker.id}>
                {`${broker.first_name} ${broker.last_name}`.trim() || broker.email} ({broker.email})
              </option>
            ))}
          </select>
        </label>
      ) : null}

      <label className="crm-field">
        <span className="crm-field__label">Лимит</span>
        <select className="crm-select" value={filters.limit} onChange={(event) => replaceFilter({ limit: event.target.value })}>
          {[10, 20, 50, 100].map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        </select>
      </label>

      <div className="crm-filters__actions">
        <button className="crm-button crm-button--xs" type="submit">
          Обновить
        </button>
        <button className="crm-button crm-button--ghost crm-button--xs" type="button" onClick={() => setFilters(emptyFilters)}>
          Сбросить
        </button>
      </div>
    </form>
  );
}