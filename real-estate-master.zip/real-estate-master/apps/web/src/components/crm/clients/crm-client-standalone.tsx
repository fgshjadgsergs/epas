"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CrmClientDetailPanel, CrmClientPanelMode } from "@/components/crm/clients/crm-client-detail-panel";
import { CrmUser } from "@/lib/crm-api";
import { crmRoutes } from "@/lib/crm-routes";

const CLIENT_LIST_HREF = "/crm/clients";

export function CrmClientStandalone({
  clientId,
  viewer,
  dealTypeOptions,
}: {
  clientId: number;
  viewer: CrmUser;
  dealTypeOptions: string[];
}) {
  const router = useRouter();
  const [mode, setMode] = useState<Exclude<CrmClientPanelMode, "closed" | "create">>("detail");

  const goToList = () => {
    router.push(CLIENT_LIST_HREF);
  };

  return (
    <CrmClientDetailPanel
      clientId={clientId}
      mode={mode}
      viewer={viewer}
      dealTypeOptions={dealTypeOptions}
      standalone
      onClose={goToList}
      onEdit={() => setMode("edit")}
      onCancelEdit={() => setMode("detail")}
      onCreated={(nextClientId) => {
        router.replace(crmRoutes.client(nextClientId));
      }}
      onDeleted={goToList}
      onListRefresh={() => router.refresh()}
    />
  );
}
