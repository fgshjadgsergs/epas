"use client";

import NextImage from "next/image";
import Link from "next/link";
import { useState } from "react";
import { ImageIcon } from "lucide-react";
import { ClientEstateSection } from "@/components/crm/clients/client-estate-section";
import { CrmPipelineStatusSelect } from "@/components/crm/shared/crm-pipeline-status-select";
import { CrmClientEstateItem } from "@/lib/crm-api";
import { formatCrmCurrency, formatCrmDate } from "@/lib/crm-format";
import { getCrmPipelineLabel } from "@/lib/crm-pipeline";
import { crmRoutes, getPublicSiteUrl } from "@/lib/crm-routes";
import { cn } from "@/lib/utils";

function getBrokerName(item: CrmClientEstateItem): string {
  const name = `${item.broker.first_name} ${item.broker.last_name}`.trim();
  return name || item.broker.email;
}

function getPriceLabel(value: number | null): string {
  return value === null ? "Цена не указана" : `${formatCrmCurrency(value)} ₽`;
}

export function CrmClientProposals({
  items,
  title = "Предложенные объекты",
  currentEstateId,
  canManageStatus = false,
  onStatusUpdated,
}: {
  items: CrmClientEstateItem[];
  title?: string;
  currentEstateId?: number;
  canManageStatus?: boolean;
  onStatusUpdated?: () => void;
}) {
  const [failedImages, setFailedImages] = useState<Set<number>>(new Set());

  return (
    <ClientEstateSection title={title} count={items.length}>
      {items.length > 0 ? (
        <div className="crm-matching-list">
          {items.map((item) => {
            const isCurrent = item.id === currentEstateId;
            return (
              <article key={item.link_id} className={cn("crm-matching-card crm-matching-card--estate", isCurrent && "crm-deal-card--active")}>
                <Link
                  href={crmRoutes.estate(item.id)}
                  target="_blank"
                  rel="noopener noreferrer"
                  prefetch={false}
                  className="crm-matching-card__thumb"
                  aria-label={`Открыть объект ${item.title} в CRM`}
                >
                  {(item.thumbnail_url || item.image_url) && !failedImages.has(item.id) ? (
                    <NextImage
                      src={item.thumbnail_url || item.image_url || ""}
                      alt=""
                      fill
                      sizes="64px"
                      unoptimized
                      onError={() => {
                        setFailedImages((current) => new Set(current).add(item.id));
                      }}
                    />
                  ) : (
                    <span className="crm-matching-card__thumb-placeholder" aria-hidden="true">
                      <ImageIcon size={22} strokeWidth={1.8} />
                    </span>
                  )}
                </Link>

                <div className="crm-matching-card__body">
                  <Link
                    href={crmRoutes.estate(item.id)}
                    target="_blank"
                    rel="noopener noreferrer"
                    prefetch={false}
                    className="crm-table__title"
                  >
                    {item.title}
                  </Link>
                  {isCurrent ? <strong className="crm-table__meta">Текущий объект сделки</strong> : null}
                  <div className="crm-matching-card__meta">
                    <span>{item.deal_type}</span>
                    <span>{getPriceLabel(item.price)}</span>
                    <span>{item.area === null ? "Площадь не указана" : `${item.area} м²`}</span>
                  </div>
                  <div className="crm-table__meta">
                    {getCrmPipelineLabel(item.status)} · {getBrokerName(item)} · {formatCrmDate(item.created_at)}
                  </div>
                  <div className="crm-filters__actions">
                    <Link
                      href={crmRoutes.estate(item.id)}
                      target="_blank"
                      rel="noopener noreferrer"
                      prefetch={false}
                      className="crm-button crm-button--ghost crm-button--xs"
                    >
                      CRM
                    </Link>
                    {item.public_page_url ? (
                      <a
                        href={getPublicSiteUrl(item.public_page_url)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="crm-button crm-button--ghost crm-button--xs"
                      >
                        На сайте
                      </a>
                    ) : null}
                  </div>
                </div>

                {canManageStatus ? (
                  <CrmPipelineStatusSelect
                    linkId={item.link_id}
                    status={item.status}
                    onSuccess={onStatusUpdated}
                  />
                ) : null}
              </article>
            );
          })}
        </div>
      ) : (
        <div className="crm-note">Предложенных объектов пока нет.</div>
      )}
    </ClientEstateSection>
  );
}
