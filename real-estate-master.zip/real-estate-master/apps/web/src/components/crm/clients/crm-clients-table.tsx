"use client";

import Link from "next/link";
import { CrmPipelineStatusSelect } from "@/components/crm/shared/crm-pipeline-status-select";
import { CrmClientListItem, CrmUser } from "@/lib/crm-api";
import { formatCrmDate } from "@/lib/crm-format";
import { canManageCrmClient } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

export function CrmClientsTable({
  items,
  viewer,
  selectedClientId,
  onQuickView,
}: {
  items: CrmClientListItem[];
  viewer: CrmUser;
  selectedClientId: number | null;
  onQuickView: (clientId: number) => void;
}) {
  const openClient = (clientId: number) => {
    window.open(crmRoutes.client(clientId), "_blank", "noopener,noreferrer");
  };

  return (
    <div className="crm-table-wrap">
      <table className="crm-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Клиент</th>
            <th>Контакты</th>
            <th>Статус</th>
            <th>Объекты</th>
            <th>Брокер</th>
            <th>Обновлен</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const canManageItem = canManageCrmClient(viewer, {
              id: item.broker_id,
              rop_id: item.broker.rop_id ?? null,
            });
            const isSelected = item.id === selectedClientId;

            return (
              <tr
                key={item.id}
                className={isSelected ? "crm-table__row--active" : undefined}
                tabIndex={0}
                onClick={(event) => {
                  if ((event.target as HTMLElement).closest("a, button, select, input")) {
                    return;
                  }
                  openClient(item.id);
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    openClient(item.id);
                  }
                }}
              >
                <td>{item.id}</td>
                <td>
                  <Link
                    href={crmRoutes.client(item.id)}
                    target="_blank"
                    rel="noopener noreferrer"
                    prefetch={false}
                    className="crm-table__title"
                  >
                    {item.name}
                  </Link>
                  <div className="crm-table__meta">{item.source || "Без источника"}</div>
                </td>
                <td>
                  <div>{item.phone || "-"}</div>
                  <div className="crm-table__meta">{item.email || "-"}</div>
                </td>
                <td>
                  <div className="crm-pipeline-list">
                    {item.estates.length > 0 ? (
                      item.estates.map((estate) => (
                        <div key={estate.link_id} className="crm-pipeline-row">
                          <span className="crm-pipeline-row__label" title={estate.title}>
                            #{estate.id}
                          </span>
                          <CrmPipelineStatusSelect linkId={estate.link_id} status={estate.status} disabled={!canManageItem} />
                        </div>
                      ))
                    ) : (
                      <span className="crm-table__meta">Без связи</span>
                    )}
                  </div>
                </td>
                <td>
                  <div className="crm-pipeline-list">
                    {item.estates.length > 0 ? (
                      item.estates.map((estate) => (
                        <div key={`estate-${estate.link_id}`} className="crm-pipeline-row">
                          <span className="crm-pipeline-row__label" title={estate.title}>
                            {estate.title}
                          </span>
                        </div>
                      ))
                    ) : (
                      <span className="crm-table__meta">Не привязан</span>
                    )}
                  </div>
                </td>
                <td>
                  <div className="crm-table__title">{`${item.broker.first_name} ${item.broker.last_name}`.trim() || item.broker.email}</div>
                  <div className="crm-table__meta">{item.broker.email}</div>
                </td>
                <td>{formatCrmDate(item.update_at)}</td>
                <td>
                  <button
                    type="button"
                    className="crm-button crm-button--ghost crm-button--xs"
                    onClick={(event) => {
                      event.stopPropagation();
                      onQuickView(item.id);
                    }}
                  >
                    Быстрый просмотр
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}