"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { CrmClientMatchingFields } from "@/components/crm/matching/crm-client-matching-fields";
import {
  CrmApiError,
  CrmClientDetail,
  CrmClientMatchingProfile,
  CrmClientMatchingProfileWritePayload,
  CrmClientWritePayload,
  CrmEstateListItem,
  CrmItemResponse,
  CrmListResponse,
  CrmPipelineStatus,
  CrmUser,
  crmClientFetch,
} from "@/lib/crm-api";
import { CRM_PIPELINE_OPTIONS } from "@/lib/crm-pipeline";
import { getCrmRole } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

interface ClientEstateDraft {
  key: string;
  estateId: number;
  title: string;
  subtitle: string | null;
  status: CrmPipelineStatus;
}

interface BrokerOption {
  id: number;
  label: string;
  meta: string;
}

interface EstateOption {
  id: number;
  title: string;
  subtitle: string | null;
}

interface ExistingClientConflict {
  clientId: number;
  name: string;
  phone: string | null;
  href: string;
  broker: { name: string; email: string };
}

interface MatchingDraft {
  deal_type: string;
  price_from: string;
  price_to: string;
  area_from: string;
  area_to: string;
}

export interface CrmClientFormSuccessResult {
  client: CrmClientDetail;
  matchingProfile: CrmClientMatchingProfile | null;
  profileSaveError: string | null;
}

function normalizeOptionalText(value: string): string | null {
  const normalized = value.trim();
  return normalized ? normalized : null;
}

function formatNullableNumber(value: number | null | undefined): string {
  return value === null || value === undefined ? "" : String(value);
}

function buildInitialMatchingDraft(profile?: CrmClientMatchingProfile | null): MatchingDraft {
  return {
    deal_type: profile?.deal_type ?? "",
    price_from: formatNullableNumber(profile?.price_from),
    price_to: formatNullableNumber(profile?.price_to),
    area_from: formatNullableNumber(profile?.area_from),
    area_to: formatNullableNumber(profile?.area_to),
  };
}

function hasMatchingDraftValues(draft: MatchingDraft): boolean {
  return Boolean(
    draft.deal_type.trim() ||
      draft.price_from.trim() ||
      draft.price_to.trim() ||
      draft.area_from.trim() ||
      draft.area_to.trim(),
  );
}

function parseNullableNumberInput(value: string): number | null {
  const normalized = value.trim().replace(/\s+/g, "").replace(",", ".");
  if (!normalized) {
    return null;
  }

  const parsed = Number(normalized);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

function extractApiPayload(error: unknown): {
  message?: string;
  errors?: Record<string, string>;
  existingClient?: ExistingClientConflict;
} | null {
  if (!(error instanceof CrmApiError) || !error.payload || typeof error.payload !== "object") {
    return null;
  }

  const payload = error.payload as {
    message?: string;
    errors?: Record<string, string>;
    existingClient?: ExistingClientConflict;
  };
  return payload;
}

function buildInitialEstateLinks(client?: CrmClientDetail | null): ClientEstateDraft[] {
  return (client?.estates ?? []).map((estate) => ({
    key: `existing-${estate.link_id}`,
    estateId: estate.id,
    title: estate.title,
    subtitle: null,
    status: estate.status,
  }));
}

function getEstateSubtitle(estate: Pick<CrmEstateListItem, "deal_type" | "district" | "metro_station">): string | null {
  const parts = [estate.deal_type, estate.district, estate.metro_station].filter(Boolean);
  return parts.length > 0 ? parts.join(" · ") : null;
}

function getBrokerDisplayName(user: Pick<CrmUser, "first_name" | "last_name" | "email">): string {
  const fullName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return fullName || user.email;
}

function buildInitialBrokerOptions(client?: CrmClientDetail | null): BrokerOption[] {
  if (!client) {
    return [];
  }

  return [
    {
      id: client.broker.id,
      label: getBrokerDisplayName(client.broker),
      meta: client.broker.email,
    },
  ];
}

function validateMatchingDraft(draft: MatchingDraft, hasExistingProfile: boolean): Record<string, string> {
  const errors: Record<string, string> = {};
  const shouldSave = hasMatchingDraftValues(draft) || hasExistingProfile;
  if (!shouldSave) {
    return errors;
  }

  if (!draft.deal_type.trim()) {
    errors.deal_type = "Укажите тип сделки для профиля подбора.";
  }

  const priceFrom = parseNullableNumberInput(draft.price_from);
  const priceTo = parseNullableNumberInput(draft.price_to);
  const areaFrom = parseNullableNumberInput(draft.area_from);
  const areaTo = parseNullableNumberInput(draft.area_to);

  if (draft.price_from.trim() && priceFrom === null) {
    errors.price_from = "Укажите корректное значение цены.";
  }

  if (draft.price_to.trim() && priceTo === null) {
    errors.price_to = "Укажите корректное значение цены.";
  }

  if (draft.area_from.trim() && areaFrom === null) {
    errors.area_from = "Укажите корректное значение площади.";
  }

  if (draft.area_to.trim() && areaTo === null) {
    errors.area_to = "Укажите корректное значение площади.";
  }

  if (priceFrom !== null && priceTo !== null && priceFrom > priceTo) {
    errors.price_range = "Диапазон цены заполнен некорректно.";
  }

  if (areaFrom !== null && areaTo !== null && areaFrom > areaTo) {
    errors.area_range = "Диапазон площади заполнен некорректно.";
  }

  return errors;
}

function buildMatchingPayload(draft: MatchingDraft): CrmClientMatchingProfileWritePayload {
  return {
    deal_type: draft.deal_type.trim(),
    price_from: parseNullableNumberInput(draft.price_from),
    price_to: parseNullableNumberInput(draft.price_to),
    area_from: parseNullableNumberInput(draft.area_from),
    area_to: parseNullableNumberInput(draft.area_to),
  };
}

export function CrmClientForm({
  mode,
  viewer,
  dealTypeOptions,
  initialClient,
  initialMatchingProfile,
  onCancel,
  onSuccess,
}: {
  mode: "create" | "edit";
  viewer: CrmUser;
  dealTypeOptions: string[];
  initialClient?: CrmClientDetail | null;
  initialMatchingProfile?: CrmClientMatchingProfile | null;
  onCancel: () => void;
  onSuccess: (result: CrmClientFormSuccessResult) => void;
}) {
  const isBrokerViewer = getCrmRole(viewer) === "BROKER";
  const [name, setName] = useState(initialClient?.name ?? "");
  const [phone, setPhone] = useState(initialClient?.phone ?? "");
  const [email, setEmail] = useState(initialClient?.email ?? "");
  const [source, setSource] = useState(initialClient?.source ?? "");
  const [comment, setComment] = useState(initialClient?.comment ?? "");
  const [brokerId, setBrokerId] = useState(isBrokerViewer ? String(viewer.id) : initialClient ? String(initialClient.broker_id) : "");
  const [brokerSearch, setBrokerSearch] = useState("");
  const [brokerOptions, setBrokerOptions] = useState<BrokerOption[]>(buildInitialBrokerOptions(initialClient));
  const [brokerLoading, setBrokerLoading] = useState(false);
  const [estateQuery, setEstateQuery] = useState("");
  const [estateOptions, setEstateOptions] = useState<EstateOption[]>([]);
  const [estateLoading, setEstateLoading] = useState(false);
  const [estateSearchError, setEstateSearchError] = useState<string | null>(null);
  const [estateLinks, setEstateLinks] = useState<ClientEstateDraft[]>(buildInitialEstateLinks(initialClient));
  const [matchingDraft, setMatchingDraft] = useState<MatchingDraft>(buildInitialMatchingDraft(initialMatchingProfile));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [existingClientConflict, setExistingClientConflict] = useState<ExistingClientConflict | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    setName(initialClient?.name ?? "");
    setPhone(initialClient?.phone ?? "");
    setEmail(initialClient?.email ?? "");
    setSource(initialClient?.source ?? "");
    setComment(initialClient?.comment ?? "");
    setBrokerId(isBrokerViewer ? String(viewer.id) : initialClient ? String(initialClient.broker_id) : "");
    setBrokerSearch("");
    setBrokerOptions(buildInitialBrokerOptions(initialClient));
    setEstateQuery("");
    setEstateOptions([]);
    setEstateLinks(buildInitialEstateLinks(initialClient));
    setMatchingDraft(buildInitialMatchingDraft(initialMatchingProfile));
    setErrors({});
    setSubmitError(null);
    setExistingClientConflict(null);
  }, [initialClient?.id, initialMatchingProfile?.update_at, isBrokerViewer, mode, viewer.id]);

  useEffect(() => {
    if (isBrokerViewer) {
      return;
    }

    const timeoutId = window.setTimeout(async () => {
      setBrokerLoading(true);

      try {
        const query = brokerSearch.trim();
        const response = await crmClientFetch<CrmListResponse<CrmUser>>(
          `/api/v1/crm/users?limit=100${query ? `&search=${encodeURIComponent(query)}` : ""}`,
        );
        const nextOptions = response.items
          .filter((user) => getCrmRole(user) === "BROKER")
          .map((user) => ({
            id: user.id,
            label: getBrokerDisplayName(user),
            meta: user.email,
          }));

        setBrokerOptions(nextOptions);
      } catch {
        setBrokerOptions([]);
      } finally {
        setBrokerLoading(false);
      }
    }, 250);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [brokerSearch, isBrokerViewer]);

  useEffect(() => {
    const query = estateQuery.trim();
    if (query.length < 2) {
      setEstateOptions([]);
      setEstateSearchError(null);
      return;
    }

    const timeoutId = window.setTimeout(async () => {
      setEstateLoading(true);
      setEstateSearchError(null);

      try {
        const response = await crmClientFetch<CrmListResponse<CrmEstateListItem>>(
          `/api/v1/crm/estates?limit=20&search=${encodeURIComponent(query)}`,
        );
        setEstateOptions(
          response.items.map((estate) => ({
            id: estate.id,
            title: estate.title,
            subtitle: getEstateSubtitle(estate),
          })),
        );
      } catch {
        setEstateSearchError("Не удалось загрузить объекты.");
        setEstateOptions([]);
      } finally {
        setEstateLoading(false);
      }
    }, 250);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [estateQuery]);

  const selectedBrokerMeta = useMemo(() => {
    if (isBrokerViewer) {
      return getBrokerDisplayName(viewer);
    }

    return brokerOptions.find((option) => String(option.id) === brokerId)?.meta ?? null;
  }, [brokerId, brokerOptions, isBrokerViewer, viewer]);

  const addEstateLink = (option: EstateOption) => {
    setEstateLinks((currentLinks) => {
      if (currentLinks.some((link) => link.estateId === option.id)) {
        return currentLinks;
      }

      return [
        ...currentLinks,
        {
          key: `draft-${option.id}`,
          estateId: option.id,
          title: option.title,
          subtitle: option.subtitle,
          status: "new",
        },
      ];
    });
    setEstateQuery("");
    setEstateOptions([]);
  };

  const submit = async () => {
    const nextErrors: Record<string, string> = {};

    if (!name.trim()) {
      nextErrors.name = "Поле обязательно.";
    }

    if (!isBrokerViewer && !brokerId) {
      nextErrors.broker_id = "Выберите брокера.";
    }

    Object.assign(nextErrors, validateMatchingDraft(matchingDraft, Boolean(initialMatchingProfile)));

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    const payload: CrmClientWritePayload = {
      name: name.trim(),
      phone: normalizeOptionalText(phone),
      email: normalizeOptionalText(email),
      source: normalizeOptionalText(source),
      comment: normalizeOptionalText(comment),
      estate_links: estateLinks.map((link) => ({
        estate_id: link.estateId,
        status: link.status,
      })),
    };

    if (!isBrokerViewer) {
      payload.broker_id = Number(brokerId);
    }

    setPending(true);
    setErrors({});
    setSubmitError(null);
    setExistingClientConflict(null);

    try {
      const clientResponse =
        mode === "create"
          ? await crmClientFetch<CrmItemResponse<CrmClientDetail>>("/api/v1/crm/clients", {
              method: "POST",
              headers: {
                "content-type": "application/json",
              },
              body: JSON.stringify(payload),
            })
          : await crmClientFetch<CrmItemResponse<CrmClientDetail>>(`/api/v1/crm/clients/${initialClient?.id}`, {
              method: "PUT",
              headers: {
                "content-type": "application/json",
              },
              body: JSON.stringify(payload),
            });

      let matchingProfile: CrmClientMatchingProfile | null = initialMatchingProfile ?? null;
      let profileSaveError: string | null = null;
      const shouldSaveMatchingProfile = hasMatchingDraftValues(matchingDraft) || Boolean(initialMatchingProfile);

      if (shouldSaveMatchingProfile) {
        try {
          const matchingResponse = await crmClientFetch<CrmItemResponse<CrmClientMatchingProfile>>(
            `/api/v1/crm/clients/${clientResponse.item.id}/matching-profile`,
            {
              method: "PUT",
              headers: {
                "content-type": "application/json",
              },
              body: JSON.stringify(buildMatchingPayload(matchingDraft)),
            },
          );
          matchingProfile = matchingResponse.item;
        } catch (matchingError) {
          const apiPayload = extractApiPayload(matchingError);
          profileSaveError =
            apiPayload?.message ?? (mode === "create" ? "Клиент создан, но критерии поиска не сохранены." : "Клиент обновлён, но критерии поиска не сохранены.");
          matchingProfile = initialMatchingProfile ?? null;
        }
      } else {
        matchingProfile = null;
      }

      onSuccess({
        client: clientResponse.item,
        matchingProfile,
        profileSaveError,
      });
    } catch (requestError) {
      const payload = extractApiPayload(requestError);
      if (payload) {
        setErrors(payload.errors ?? {});
        setSubmitError(payload.message ?? null);
        setExistingClientConflict(requestError instanceof CrmApiError && requestError.status === 409 ? payload.existingClient ?? null : null);
      } else {
        setSubmitError("Не удалось сохранить клиента.");
      }
    } finally {
      setPending(false);
    }
  };

  return (
    <form
      className="crm-form crm-client-form"
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
    >
      <label className="crm-field">
        <span className="crm-field__label">
          Имя клиента <span className="crm-required-mark">*</span>
        </span>
        <input className="crm-input" value={name} onChange={(event) => setName(event.target.value)} />
        {errors.name ? <div className="crm-action__feedback crm-action__feedback--error">{errors.name}</div> : null}
      </label>

      {isBrokerViewer ? (
        <div className="crm-field">
          <span className="crm-field__label">Ответственный брокер</span>
          <div className="crm-client-form__readonly">{getBrokerDisplayName(viewer)}</div>
        </div>
      ) : (
        <div className="crm-field">
          <span className="crm-field__label">
            Ответственный брокер <span className="crm-required-mark">*</span>
          </span>
          <input
            className="crm-input"
            type="search"
            placeholder="Поиск брокера"
            value={brokerSearch}
            onChange={(event) => setBrokerSearch(event.target.value)}
          />
          <select className="crm-select" value={brokerId} onChange={(event) => setBrokerId(event.target.value)}>
            <option value="">{brokerLoading ? "Загрузка..." : "Выберите брокера"}</option>
            {brokerOptions.map((option) => (
              <option key={option.id} value={option.id}>
                {option.label} ({option.meta})
              </option>
            ))}
          </select>
          {selectedBrokerMeta ? <div className="crm-table__meta">{selectedBrokerMeta}</div> : null}
          {errors.broker_id ? <div className="crm-action__feedback crm-action__feedback--error">{errors.broker_id}</div> : null}
        </div>
      )}

      <div className="crm-client-form__grid">
        <label className="crm-field">
          <span className="crm-field__label">Телефон</span>
          <input className="crm-input" value={phone} onChange={(event) => setPhone(event.target.value)} />
          {errors.phone ? <div className="crm-action__feedback crm-action__feedback--error">{errors.phone}</div> : null}
        </label>

        <label className="crm-field">
          <span className="crm-field__label">Email</span>
          <input className="crm-input" type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
          {errors.email ? <div className="crm-action__feedback crm-action__feedback--error">{errors.email}</div> : null}
        </label>
      </div>

      <label className="crm-field">
        <span className="crm-field__label">Источник</span>
        <input className="crm-input" value={source} onChange={(event) => setSource(event.target.value)} />
        {errors.source ? <div className="crm-action__feedback crm-action__feedback--error">{errors.source}</div> : null}
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Комментарий</span>
        <textarea className="crm-textarea" rows={4} value={comment} onChange={(event) => setComment(event.target.value)} />
        {errors.comment ? <div className="crm-action__feedback crm-action__feedback--error">{errors.comment}</div> : null}
      </label>

      <CrmClientMatchingFields
        dealTypeOptions={dealTypeOptions}
        value={matchingDraft}
        errors={errors}
        disabled={pending}
        hasExistingProfile={Boolean(initialMatchingProfile)}
        onChange={(field, nextValue) => {
          setMatchingDraft((currentDraft) => ({
            ...currentDraft,
            [field]: nextValue,
          }));
        }}
      />

      <div className="crm-field">
        <span className="crm-field__label">Связанные объекты</span>
        <div className="crm-client-form__estate-search">
          <input
            className="crm-input"
            type="search"
            placeholder="Поиск объекта по названию"
            value={estateQuery}
            onChange={(event) => setEstateQuery(event.target.value)}
          />

          {estateQuery.trim().length > 0 ? (
            <div className="crm-client-form__search-hint">
              {estateQuery.trim().length < 2 ? "Введите минимум 2 символа для поиска." : estateLoading ? "Загрузка..." : null}
            </div>
          ) : null}

          {estateSearchError ? <div className="crm-action__feedback crm-action__feedback--error">{estateSearchError}</div> : null}

          {estateOptions.length > 0 ? (
            <div className="crm-client-form__search-results">
              {estateOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  className="crm-client-form__search-result"
                  onClick={() => addEstateLink(option)}
                >
                  <span className="crm-client-form__search-result-title">{option.title}</span>
                  {option.subtitle ? <span className="crm-client-form__search-result-meta">{option.subtitle}</span> : null}
                </button>
              ))}
            </div>
          ) : null}
        </div>

        <div className="crm-client-form__estate-links">
          {estateLinks.length > 0 ? (
            estateLinks.map((link) => (
              <div key={link.key} className="crm-client-form__estate-link">
                <div className="crm-client-form__estate-link-main">
                  <div className="crm-table__title">{link.title}</div>
                  {link.subtitle ? <div className="crm-table__meta">{link.subtitle}</div> : null}
                </div>

                <select
                  className="crm-select"
                  value={link.status}
                  onChange={(event) => {
                    const nextStatus = event.target.value as CrmPipelineStatus;
                    setEstateLinks((currentLinks) =>
                      currentLinks.map((currentLink) =>
                        currentLink.key === link.key
                          ? {
                              ...currentLink,
                              status: nextStatus,
                            }
                          : currentLink,
                      ),
                    );
                  }}
                >
                  {CRM_PIPELINE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  className="crm-button crm-button--ghost crm-button--xs"
                  onClick={() => {
                    setEstateLinks((currentLinks) => currentLinks.filter((currentLink) => currentLink.key !== link.key));
                  }}
                >
                  Убрать
                </button>
              </div>
            ))
          ) : (
            <div className="crm-state">
              <h2 className="crm-state__title">Объекты не привязаны</h2>
              <p className="crm-state__description">Добавьте один или несколько объектов через поиск выше.</p>
            </div>
          )}
        </div>
        {errors.estate_links ? <div className="crm-action__feedback crm-action__feedback--error">{errors.estate_links}</div> : null}
      </div>

      {existingClientConflict ? (
        <div className="crm-action__feedback crm-action__feedback--error">
          <strong>Клиент с таким номером уже существует: {existingClientConflict.name}</strong>
          <div>{existingClientConflict.phone || "Телефон скрыт"} · {existingClientConflict.broker.name}</div>
          <Link
            href={existingClientConflict.href || crmRoutes.client(existingClientConflict.clientId)}
            target="_blank"
            rel="noopener noreferrer"
            prefetch={false}
            className="crm-button crm-button--ghost crm-button--xs"
          >
            Открыть существующего клиента
          </Link>
        </div>
      ) : null}

      {submitError && !existingClientConflict ? <div className="crm-action__feedback crm-action__feedback--error">{submitError}</div> : null}

      <div className="crm-client-panel__footer">
        <button type="submit" className="crm-button" disabled={pending}>
          {pending ? "Сохранение..." : mode === "create" ? "Создать клиента" : "Сохранить изменения"}
        </button>
        <button type="button" className="crm-button crm-button--ghost" onClick={onCancel} disabled={pending}>
          Отмена
        </button>
      </div>
    </form>
  );
}
