"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CrmClientForm, CrmClientFormSuccessResult } from "@/components/crm/clients/crm-client-form";
import { CrmClientProposals } from "@/components/crm/clients/crm-client-proposals";
import { CrmClientMatches } from "@/components/crm/matching/crm-client-matches";
import { CrmErrorState } from "@/components/crm/shared/crm-state";
import { CrmPipelineStatusSelect } from "@/components/crm/shared/crm-pipeline-status-select";
import {
  CrmApiError,
  CrmClientDetail,
  CrmClientMatchingProfile,
  CrmItemResponse,
  CrmMatchedEstateItem,
  CrmUser,
  CrmClientMatchesResponse,
  crmClientFetch,
} from "@/lib/crm-api";
import { formatCrmDate } from "@/lib/crm-format";
import { canManageCrmClient } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

export type CrmClientPanelMode = "closed" | "detail" | "create" | "edit";

function getBrokerDisplayName(user: Pick<CrmUser, "first_name" | "last_name" | "email">): string {
  const fullName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return fullName || user.email;
}

function getErrorMessage(error: unknown): string {
  if (error instanceof CrmApiError && error.payload && typeof error.payload === "object") {
    const payload = error.payload as { message?: string };
    if (payload.message) {
      return payload.message;
    }
  }

  return "Не удалось загрузить клиента.";
}

function formatMatchingRange(from: number | null, to: number | null, suffix: string): string {
  if (from !== null && to !== null) {
    return `${from}–${to} ${suffix}`;
  }

  if (from !== null) {
    return `от ${from} ${suffix}`;
  }

  if (to !== null) {
    return `до ${to} ${suffix}`;
  }

  return "не задан";
}

export function CrmClientDetailPanel({
  clientId,
  mode,
  viewer,
  dealTypeOptions,
  onClose,
  onEdit,
  onCancelEdit,
  onCreated,
  onDeleted,
  onListRefresh,
  standalone = false,
}: {
  clientId: number | null;
  mode: Exclude<CrmClientPanelMode, "closed">;
  viewer: CrmUser;
  dealTypeOptions: string[];
  onClose: () => void;
  onEdit: (clientId: number) => void;
  onCancelEdit: () => void;
  onCreated: (clientId: number) => void;
  onDeleted: () => void;
  onListRefresh: () => void;
  standalone?: boolean;
}) {
  const requestIdRef = useRef(0);
  const matchingRequestIdRef = useRef(0);
  const [detail, setDetail] = useState<CrmClientDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deletePending, setDeletePending] = useState(false);
  const [matchingProfile, setMatchingProfile] = useState<CrmClientMatchingProfile | null>(null);
  const [matchingItems, setMatchingItems] = useState<CrmMatchedEstateItem[]>([]);
  const [matchingTotal, setMatchingTotal] = useState(0);
  const [matchingLoading, setMatchingLoading] = useState(false);
  const [matchingRefreshing, setMatchingRefreshing] = useState(false);
  const [matchingError, setMatchingError] = useState<string | null>(null);
  const [matchingFeedback, setMatchingFeedback] = useState<string | null>(null);
  const detailClientId = detail?.id ?? null;
  const canManage = useMemo(
    () =>
      detail
        ? canManageCrmClient(viewer, {
            id: detail.broker_id,
            rop_id: detail.broker.rop_id ?? null,
          })
        : false,
    [detail, viewer],
  );

  const fetchDetail = useCallback(
    async (options?: { preserveExisting?: boolean }) => {
      if (clientId === null) {
        return;
      }

      const requestId = ++requestIdRef.current;
      const preserveExisting = options?.preserveExisting && detailClientId === clientId;

      setError(null);
      if (preserveExisting) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      try {
        const response = await crmClientFetch<CrmItemResponse<CrmClientDetail>>(`/api/v1/crm/clients/${clientId}`);
        if (requestId !== requestIdRef.current) {
          return;
        }

        setDetail(response.item);
      } catch (requestError) {
        if (requestId !== requestIdRef.current) {
          return;
        }

        setError(getErrorMessage(requestError));
        if (!preserveExisting) {
          setDetail(null);
        }
      } finally {
        if (requestId === requestIdRef.current) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    },
    [clientId, detailClientId],
  );

  const fetchMatchingData = useCallback(
    async (targetClientId: number, options?: { preserveExisting?: boolean }) => {
      const requestId = ++matchingRequestIdRef.current;
      const preserveExisting = Boolean(options?.preserveExisting);

      setMatchingError(null);
      if (preserveExisting) {
        setMatchingRefreshing(true);
      } else {
        setMatchingLoading(true);
      }

      try {
        const [profileResponse, matchesResponse] = await Promise.all([
          crmClientFetch<CrmItemResponse<CrmClientMatchingProfile | null>>(`/api/v1/crm/clients/${targetClientId}/matching-profile`),
          crmClientFetch<CrmClientMatchesResponse>(`/api/v1/crm/clients/${targetClientId}/matches`),
        ]);

        if (requestId !== matchingRequestIdRef.current) {
          return;
        }

        setMatchingProfile(profileResponse.item ?? matchesResponse.profile ?? null);
        setMatchingItems(matchesResponse.items);
        setMatchingTotal(matchesResponse.total);
      } catch (requestError) {
        if (requestId !== matchingRequestIdRef.current) {
          return;
        }

        setMatchingError(getErrorMessage(requestError));
        if (!preserveExisting) {
          setMatchingProfile(null);
          setMatchingItems([]);
          setMatchingTotal(0);
        }
      } finally {
        if (requestId === matchingRequestIdRef.current) {
          setMatchingLoading(false);
          setMatchingRefreshing(false);
        }
      }
    },
    [],
  );

  useEffect(() => {
    if (mode === "create") {
      setDetail(null);
      setLoading(false);
      setRefreshing(false);
      setError(null);
      setMatchingProfile(null);
      setMatchingItems([]);
      setMatchingTotal(0);
      setMatchingLoading(false);
      setMatchingRefreshing(false);
      setMatchingError(null);
      setMatchingFeedback(null);
      return;
    }

    if (clientId === null) {
      return;
    }

    if (detailClientId === clientId && (mode === "detail" || mode === "edit")) {
      return;
    }

    setMatchingFeedback(null);
    void fetchDetail();
    void fetchMatchingData(clientId);
  }, [clientId, detailClientId, fetchDetail, fetchMatchingData, mode]);

  const handleDelete = async () => {
    if (!detail || !canManage || deletePending) {
      return;
    }

    if (!window.confirm("Удалить клиента?")) {
      return;
    }

    setDeletePending(true);
    setError(null);

    try {
      await crmClientFetch(`/api/v1/crm/clients/${detail.id}`, {
        method: "DELETE",
      });
      onDeleted();
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setDeletePending(false);
    }
  };

  const handleFormSuccess = (result: CrmClientFormSuccessResult) => {
    setDetail(result.client);
    setMatchingProfile(result.matchingProfile);
    setMatchingError(null);
    setMatchingFeedback(result.profileSaveError);

    if (mode === "create") {
      onCreated(result.client.id);
    } else {
      onCancelEdit();
      onListRefresh();
    }

    void fetchDetail({ preserveExisting: true });
    void fetchMatchingData(result.client.id, { preserveExisting: true });
  };

  const renderLoading = () => (
    <div className="crm-client-panel__skeleton">
      <div className="crm-client-panel__skeleton-line crm-client-panel__skeleton-line--title" />
      <div className="crm-client-panel__skeleton-line" />
      <div className="crm-client-panel__skeleton-line" />
      <div className="crm-client-panel__skeleton-block" />
      <div className="crm-client-panel__skeleton-block" />
    </div>
  );

  return (
    <aside className={`crm-panel crm-client-panel${standalone ? " crm-client-panel--standalone" : ""}`}>
      <div className="crm-client-panel__header">
        <div>
          <h2 className="crm-client-panel__title">
            {mode === "create" ? "Новый клиент" : mode === "edit" ? "Редактирование клиента" : detail?.name ?? "Клиент"}
          </h2>
          {mode !== "create" && detail ? (
            <div className="crm-client-panel__subtitle">{getBrokerDisplayName(detail.broker)}</div>
          ) : (
            <div className="crm-client-panel__subtitle">Детали открываются справа без перехода на отдельную страницу.</div>
          )}
        </div>

        <div className="crm-client-panel__header-actions">
          {!standalone && mode !== "create" && detail ? (
            <Link
              href={crmRoutes.client(detail.id)}
              className="crm-button crm-button--ghost crm-button--xs"
              target="_blank"
              rel="noopener noreferrer"
            >
              Открыть в новой вкладке
            </Link>
          ) : null}

          {!standalone ? (
            <button type="button" className="crm-client-panel__close" onClick={onClose} aria-label="Закрыть">
              ×
            </button>
          ) : null}
        </div>
      </div>

      {mode === "create" ? (
        <CrmClientForm
          mode="create"
          viewer={viewer}
          dealTypeOptions={dealTypeOptions}
          initialMatchingProfile={null}
          onCancel={onClose}
          onSuccess={handleFormSuccess}
        />
      ) : loading && detailClientId !== clientId ? (
        renderLoading()
      ) : error && !detail ? (
        <CrmErrorState title="Не удалось загрузить клиента" description={error} />
      ) : detail ? (
        <>
          {refreshing ? <div className="crm-client-panel__refreshing">Обновляем данные…</div> : null}
          {mode === "edit" ? (
            <CrmClientForm
              mode="edit"
              viewer={viewer}
              dealTypeOptions={dealTypeOptions}
              initialClient={detail}
              initialMatchingProfile={matchingProfile}
              onCancel={onCancelEdit}
              onSuccess={handleFormSuccess}
            />
          ) : (
            <div className="crm-stack">
              {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}
              {matchingFeedback ? <div className="crm-action__feedback crm-action__feedback--error">{matchingFeedback}</div> : null}
              {matchingRefreshing ? <div className="crm-note">Обновляем подбор…</div> : null}

              <section className="crm-client-panel__section">
                <h3 className="crm-client-panel__section-title">Основная информация</h3>
                <div className="crm-client-panel__info-list">
                  <div className="crm-client-panel__info-row">
                    <span>Имя</span>
                    <strong>{detail.name}</strong>
                  </div>
                  <div className="crm-client-panel__info-row">
                    <span>Телефон</span>
                    <strong>{detail.phone || "—"}</strong>
                  </div>
                  <div className="crm-client-panel__info-row">
                    <span>Email</span>
                    <strong>{detail.email || "—"}</strong>
                  </div>
                  <div className="crm-client-panel__info-row">
                    <span>Источник</span>
                    <strong>{detail.source || "—"}</strong>
                  </div>
                  <div className="crm-client-panel__info-row">
                    <span>Брокер</span>
                    <strong>{getBrokerDisplayName(detail.broker)}</strong>
                  </div>
                  <div className="crm-client-panel__info-row">
                    <span>Обновлён</span>
                    <strong>{formatCrmDate(detail.update_at)}</strong>
                  </div>
                </div>

                {detail.comment ? <div className="crm-client-panel__comment">{detail.comment}</div> : null}
              </section>

              <section className="crm-client-panel__section">
                <h3 className="crm-client-panel__section-title">Критерии поиска</h3>
                {matchingLoading ? (
                  <div className="crm-note">Загружаем профиль подбора…</div>
                ) : matchingError ? (
                  <div className="crm-action__feedback crm-action__feedback--error">{matchingError}</div>
                ) : matchingProfile ? (
                  <div className="crm-client-panel__info-list">
                    <div className="crm-client-panel__info-row">
                      <span>Тип сделки</span>
                      <strong>{matchingProfile.deal_type}</strong>
                    </div>
                    <div className="crm-client-panel__info-row">
                      <span>Цена</span>
                      <strong>{formatMatchingRange(matchingProfile.price_from, matchingProfile.price_to, "₽")}</strong>
                    </div>
                    <div className="crm-client-panel__info-row">
                      <span>Площадь</span>
                      <strong>{formatMatchingRange(matchingProfile.area_from, matchingProfile.area_to, "м²")}</strong>
                    </div>
                  </div>
                ) : (
                  <div className="crm-note">Критерии поиска ещё не заполнены.</div>
                )}
              </section>

              <CrmClientMatches
                items={matchingItems}
                total={matchingTotal}
                loading={matchingLoading}
                error={matchingError}
              />

              <CrmClientProposals
                items={detail.estates}
                canManageStatus={canManage}
                onStatusUpdated={() => {
                  void fetchDetail({ preserveExisting: true });
                }}
              />

              {canManage ? (
                <div className="crm-client-panel__footer">
                  <button type="button" className="crm-button" onClick={() => onEdit(detail.id)}>
                    Редактировать клиента
                  </button>
                  <button type="button" className="crm-button crm-button--danger" onClick={handleDelete} disabled={deletePending}>
                    {deletePending ? "Удаление..." : "Удалить"}
                  </button>
                </div>
              ) : null}
            </div>
          )}
        </>
      ) : null}
    </aside>
  );
}
