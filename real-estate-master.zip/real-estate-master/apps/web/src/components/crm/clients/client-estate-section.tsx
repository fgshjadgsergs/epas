import type { ReactNode } from "react";

export function ClientEstateSection({
  title,
  count,
  children,
}: {
  title: string;
  count: number;
  children: ReactNode;
}) {
  return (
    <details className="crm-subsection crm-subsection--dense">
      <summary className="crm-section-title">
        {title} — {count}
      </summary>
      {children}
    </details>
  );
}
