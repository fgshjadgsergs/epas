"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CrmClientDetailPanel, CrmClientPanelMode } from "@/components/crm/clients/crm-client-detail-panel";
import { CrmClientsFilters } from "@/components/crm/clients/crm-clients-filters";
import { CrmClientsTable } from "@/components/crm/clients/crm-clients-table";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPagination } from "@/components/crm/shared/crm-pagination";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import { CrmClientBrokerItem, CrmClientListItem, CrmUser } from "@/lib/crm-api";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord } from "@/lib/public-query";

export function CrmClientsWorkspace({
  items,
  total,
  skip,
  limit,
  searchParams,
  viewer,
  brokerOptions,
  dealTypeOptions,
}: {
  items: CrmClientListItem[];
  total: number;
  skip: number;
  limit: number;
  searchParams: SearchParamsRecord;
  viewer: CrmUser;
  brokerOptions: CrmClientBrokerItem[];
  dealTypeOptions: string[];
}) {
  const router = useRouter();
  const [panelState, setPanelState] = useState<{
    selectedClientId: number | null;
    mode: CrmClientPanelMode;
  }>({
    selectedClientId: null,
    mode: "closed",
  });
  const selectedClientId = panelState.selectedClientId;
  const panelMode = panelState.mode;

  const closePanel = () => {
    setPanelState({
      selectedClientId: null,
      mode: "closed",
    });
  };

  const openClient = (clientId: number) => {
    setPanelState({
      selectedClientId: clientId,
      mode: "detail",
    });
  };

  const openCreate = () => {
    setPanelState({
      selectedClientId: null,
      mode: "create",
    });
  };

  const refreshList = () => {
    router.refresh();
  };

  return (
    <>
      <CrmPageHeader
        title="Клиенты"
        description="Список клиентов с правой detail panel, связанными объектами и базой для matching."
        action={
          <button type="button" className="crm-button" onClick={openCreate}>
            Новый клиент
          </button>
        }
      />

      <div className={`crm-clients-layout${panelMode !== "closed" ? " crm-clients-layout--with-panel" : ""}`}>
        <div className="crm-clients-layout__main">
          <div className="crm-stack">
            <CrmPanel>
              <CrmClientsFilters searchParams={searchParams} brokers={brokerOptions} viewer={viewer} />
            </CrmPanel>

            <CrmPanel>
              {items.length > 0 ? (
                <>
                  <CrmClientsTable
                    items={items}
                    viewer={viewer}
                    selectedClientId={panelMode === "closed" ? null : selectedClientId}
                    onQuickView={openClient}
                  />
                  <CrmPagination pathname={crmRoutes.clients} searchParams={searchParams} skip={skip} limit={limit} total={total} />
                </>
              ) : (
                <CrmEmptyState title="Клиенты не найдены" description="Попробуйте ослабить фильтр по статусу или поиску." />
              )}
            </CrmPanel>
          </div>
        </div>

        {panelMode !== "closed" ? (
          <CrmClientDetailPanel
            clientId={selectedClientId}
            mode={panelMode}
            viewer={viewer}
            dealTypeOptions={dealTypeOptions}
            onClose={closePanel}
            onEdit={(clientId) => {
              setPanelState({
                selectedClientId: clientId,
                mode: "edit",
              });
            }}
            onCancelEdit={() => {
              if (selectedClientId !== null) {
                setPanelState({
                  selectedClientId,
                  mode: "detail",
                });
              } else {
                setPanelState({
                  selectedClientId: null,
                  mode: "closed",
                });
              }
            }}
            onCreated={(nextClientId) => {
              setPanelState({
                selectedClientId: nextClientId,
                mode: "detail",
              });
              refreshList();
            }}
            onDeleted={() => {
              closePanel();
              refreshList();
            }}
            onListRefresh={refreshList}
          />
        ) : null}
      </div>
    </>
  );
}
