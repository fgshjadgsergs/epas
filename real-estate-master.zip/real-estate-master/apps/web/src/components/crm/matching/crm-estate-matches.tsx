"use client";

import Link from "next/link";
import { CrmMatchedClientItem } from "@/lib/crm-api";
import { formatCrmCurrency } from "@/lib/crm-format";
import { crmRoutes } from "@/lib/crm-routes";

function formatRangeLabel(from: number | null, to: number | null, suffix: string): string {
  if (from !== null && to !== null) {
    return `${from}–${to} ${suffix}`;
  }

  if (from !== null) {
    return `от ${from} ${suffix}`;
  }

  if (to !== null) {
    return `до ${to} ${suffix}`;
  }

  return "не задано";
}

function formatClientContacts(item: CrmMatchedClientItem): string {
  if (!item.contacts_visible) {
    return "Контакты скрыты";
  }

  const parts = [item.phone, item.email].filter(Boolean);
  return parts.length > 0 ? parts.join(" · ") : "Контакты не указаны";
}

function buildClientSearchHref(name: string): string {
  return `${crmRoutes.clients}?search=${encodeURIComponent(name)}`;
}

export function CrmEstateMatches({
  items,
  total,
  loading,
  error,
}: {
  items: CrmMatchedClientItem[];
  total: number;
  loading?: boolean;
  error?: string | null;
}) {
  return (
    <section className="crm-subsection crm-subsection--dense">
      <h2 className="crm-section-title">Подходящие клиенты</h2>
      <p className="crm-subsection__note">Найдено: {total}</p>

      {loading ? <div className="crm-note">Подбираем клиентов…</div> : null}
      {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}

      {!loading && !error ? (
        items.length > 0 ? (
          <div className="crm-matching-list">
            {items.map((item) => (
              <Link key={item.client_id} href={buildClientSearchHref(item.name)} className="crm-matching-card">
                <div className="crm-table__title">{item.name}</div>
                <div className="crm-table__meta">{formatClientContacts(item)}</div>
                <div className="crm-matching-card__meta">
                  <span>{item.profile.deal_type}</span>
                  <span>{item.broker_name}</span>
                </div>
                <div className="crm-table__meta">
                  Бюджет: {formatRangeLabel(item.profile.price_from, item.profile.price_to, "₽")}
                </div>
                <div className="crm-table__meta">
                  Площадь: {formatRangeLabel(item.profile.area_from, item.profile.area_to, "м²")}
                </div>
                {item.source ? <div className="crm-table__meta">Источник: {item.source}</div> : null}
                {item.comment ? <div className="crm-table__meta">{item.comment}</div> : null}
              </Link>
            ))}
          </div>
        ) : (
          <div className="crm-note">Для этого объекта подходящих клиентов пока нет.</div>
        )
      ) : null}
    </section>
  );
}
