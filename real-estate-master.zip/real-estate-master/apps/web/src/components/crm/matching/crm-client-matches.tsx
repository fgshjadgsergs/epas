"use client";

import NextImage from "next/image";
import Link from "next/link";
import { ImageIcon } from "lucide-react";
import { ClientEstateSection } from "@/components/crm/clients/client-estate-section";
import { CrmMatchedEstateItem } from "@/lib/crm-api";
import { formatCrmCurrency } from "@/lib/crm-format";
import { getPublicSiteUrl } from "@/lib/crm-routes";

function formatEstateLocation(item: CrmMatchedEstateItem): string {
  const parts = [item.district, item.metro_station].filter(Boolean);
  return parts.length > 0 ? parts.join(" · ") : "Локация не указана";
}

function formatEstatePrice(item: CrmMatchedEstateItem): string {
  if (item.presentation_price) {
    return `${item.presentation_price} ₽`;
  }

  if (item.price !== null && item.price !== undefined) {
    return `${formatCrmCurrency(item.price)} ₽`;
  }

  return "Цена не указана";
}

export function CrmClientMatches({
  items,
  total,
  loading,
  error,
}: {
  items: CrmMatchedEstateItem[];
  total: number;
  loading?: boolean;
  error?: string | null;
}) {
  return (
    <ClientEstateSection title="Подходящие объекты" count={total}>
      {loading ? <div className="crm-note">Подбираем объекты…</div> : null}
      {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}

      {!loading && !error ? (
        items.length > 0 ? (
          <div className="crm-matching-list">
            {items.map((item) => (
              <Link
                key={item.estate_id}
                href={getPublicSiteUrl(`/detail/${item.estate_id}`)}
                className="crm-matching-card crm-matching-card--estate"
                target="_blank"
                rel="noopener noreferrer"
              >
                <div className="crm-matching-card__thumb">
                  {item.image_url ? (
                    <NextImage src={item.image_url} alt="" fill sizes="64px" unoptimized />
                  ) : (
                    <span className="crm-matching-card__thumb-placeholder" aria-hidden="true">
                      <ImageIcon size={22} strokeWidth={1.8} />
                    </span>
                  )}
                </div>

                <div className="crm-matching-card__body">
                  <div className="crm-table__title">{item.title}</div>
                  <div className="crm-table__meta">{formatEstateLocation(item)}</div>
                  <div className="crm-matching-card__meta">
                    <span>{item.deal_type}</span>
                    <span>{formatEstatePrice(item)}</span>
                  </div>
                  <div className="crm-table__meta">
                    {item.area !== null ? `${item.area} м²` : "Площадь не указана"}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="crm-note">По текущим критериям подходящих объектов пока нет.</div>
        )
      ) : null}
    </ClientEstateSection>
  );
}
