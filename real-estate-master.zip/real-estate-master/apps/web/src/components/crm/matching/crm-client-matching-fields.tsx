"use client";

interface MatchingFormValue {
  deal_type: string;
  price_from: string;
  price_to: string;
  area_from: string;
  area_to: string;
}

export function CrmClientMatchingFields({
  dealTypeOptions,
  value,
  errors,
  disabled,
  hasExistingProfile,
  onChange,
}: {
  dealTypeOptions: string[];
  value: MatchingFormValue;
  errors?: Record<string, string>;
  disabled?: boolean;
  hasExistingProfile?: boolean;
  onChange: (field: keyof MatchingFormValue, nextValue: string) => void;
}) {
  return (
    <div className="crm-subsection crm-subsection--dense">
      <h2 className="crm-section-title">Критерии поиска</h2>
      <p className="crm-subsection__note">
        {hasExistingProfile
          ? "Профиль подбора уже сохранён и будет обновлён отдельно от карточки клиента."
          : "Заполните критерии, если хотите сразу видеть подходящие объекты для клиента."}
      </p>

      <div className="crm-form-columns">
        <label className="crm-field">
          <span className="crm-field__label">Тип сделки</span>
          <select
            className="crm-select"
            value={value.deal_type}
            disabled={disabled}
            onChange={(event) => onChange("deal_type", event.target.value)}
          >
            <option value="">Не выбран</option>
            {dealTypeOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
          {errors?.deal_type ? <div className="crm-action__feedback crm-action__feedback--error">{errors.deal_type}</div> : null}
        </label>

        <label className="crm-field">
          <span className="crm-field__label">Цена от</span>
          <input
            className="crm-input"
            inputMode="decimal"
            value={value.price_from}
            disabled={disabled}
            onChange={(event) => onChange("price_from", event.target.value)}
          />
          {errors?.price_from ? <div className="crm-action__feedback crm-action__feedback--error">{errors.price_from}</div> : null}
        </label>

        <label className="crm-field">
          <span className="crm-field__label">Цена до</span>
          <input
            className="crm-input"
            inputMode="decimal"
            value={value.price_to}
            disabled={disabled}
            onChange={(event) => onChange("price_to", event.target.value)}
          />
          {errors?.price_to ? <div className="crm-action__feedback crm-action__feedback--error">{errors.price_to}</div> : null}
        </label>

        <label className="crm-field">
          <span className="crm-field__label">Площадь от</span>
          <input
            className="crm-input"
            inputMode="decimal"
            value={value.area_from}
            disabled={disabled}
            onChange={(event) => onChange("area_from", event.target.value)}
          />
          {errors?.area_from ? <div className="crm-action__feedback crm-action__feedback--error">{errors.area_from}</div> : null}
        </label>

        <label className="crm-field">
          <span className="crm-field__label">Площадь до</span>
          <input
            className="crm-input"
            inputMode="decimal"
            value={value.area_to}
            disabled={disabled}
            onChange={(event) => onChange("area_to", event.target.value)}
          />
          {errors?.area_to ? <div className="crm-action__feedback crm-action__feedback--error">{errors.area_to}</div> : null}
        </label>
      </div>

      {errors?.price_range ? <div className="crm-action__feedback crm-action__feedback--error">{errors.price_range}</div> : null}
      {errors?.area_range ? <div className="crm-action__feedback crm-action__feedback--error">{errors.area_range}</div> : null}
    </div>
  );
}
