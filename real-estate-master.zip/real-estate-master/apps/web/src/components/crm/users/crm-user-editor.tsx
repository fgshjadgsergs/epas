"use client";

import { useRouter } from "next/navigation";
import { startTransition, useState } from "react";
import { CrmApiError, CrmMessageResponse, CrmUser, crmClientFetch } from "@/lib/crm-api";
import {
  canDeleteCrmUser,
  canManageCrmUser,
  canResetCrmUserPassword,
  CRM_ROLE_OPTIONS,
  getAssignableCrmRoles,
  getCrmRole,
  getCrmRoleLabel,
  requiresRopAssignment,
} from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";
import { CrmActionButton } from "@/components/crm/shared/crm-action-button";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmPanel } from "@/components/crm/shared/crm-state";

function readUserError(payload: unknown): string | null {
  if (!payload || typeof payload !== "object") {
    return null;
  }

  const data = payload as { errors?: Record<string, string>; message?: string };
  return data.errors?.email ?? data.errors?.password ?? data.errors?.role ?? data.errors?.rop_id ?? data.message ?? null;
}

export function CrmUserEditor({
  mode,
  viewer,
  user,
}: {
  mode: "create" | "edit";
  viewer: CrmUser;
  user?: CrmUser;
}) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);
  const [passwordPending, setPasswordPending] = useState(false);

  const baseAssignableRoles = getAssignableCrmRoles(viewer);
  const selectedCurrentRole = user ? getCrmRole(user) : baseAssignableRoles[0] ?? "BROKER";
  const [selectedRole, setSelectedRole] = useState(selectedCurrentRole);
  const canManageCurrentUser = mode === "create" ? baseAssignableRoles.length > 0 : Boolean(user && canManageCrmUser(viewer, user));
  const canResetPassword = mode === "edit" && user ? canResetCrmUserPassword(viewer) : false;
  const canDeleteUser = mode === "edit" && user ? canDeleteCrmUser(viewer, user) : false;
  const roleOptions = user && !baseAssignableRoles.includes(selectedCurrentRole)
    ? [...baseAssignableRoles, selectedCurrentRole]
    : baseAssignableRoles;
  const showRopField = requiresRopAssignment(selectedRole) && getCrmRole(viewer) !== "ROP";

  return (
    <div className="crm-stack">
      <CrmPageHeader
        title={mode === "create" ? "Новый пользователь" : `Пользователь #${user?.id ?? ""}`}
        description={mode === "create" ? "Создание учетной записи CRM с ролью и временным паролем." : "Редактирование пользователя и безопасный сброс пароля."}
      />

      <div className="crm-form-grid">
        <CrmPanel>
          {!canManageCurrentUser && mode === "edit" ? <div className="crm-note">Редактирование этой учетной записи вам недоступно.</div> : null}

          <h2 className="crm-section-title">{mode === "create" ? "Создание" : "Редактирование"}</h2>
          <form
            className="crm-form"
            onSubmit={(event) => {
              event.preventDefault();
              if (!canManageCurrentUser) {
                return;
              }

              setError(null);
              setMessage(null);
              const formData = new FormData(event.currentTarget);
              setPending(true);

              startTransition(async () => {
                try {
                  const payload: Record<string, unknown> = {
                    email: formData.get("email"),
                    first_name: formData.get("first_name"),
                    last_name: formData.get("last_name"),
                    phone_number: formData.get("phone_number"),
                    role: formData.get("role"),
                  };

                  if (showRopField) {
                    payload.rop_id = formData.get("rop_id");
                  }

                  if (mode === "create") {
                    payload.password = formData.get("password");
                  }

                  const result = await crmClientFetch<{ item: CrmUser }>(
                    mode === "create" ? "/api/v1/crm/users" : `/api/v1/crm/users/${user?.id}`,
                    {
                      method: mode === "create" ? "POST" : "PUT",
                      headers: {
                        "content-type": "application/json",
                      },
                      body: JSON.stringify(payload),
                    },
                  );

                  setMessage(mode === "create" ? "Пользователь создан." : "Пользователь обновлен.");
                  router.replace(crmRoutes.user(result.item.id));
                  router.refresh();
                } catch (requestError) {
                  if (requestError instanceof CrmApiError) {
                    setError(readUserError(requestError.payload) ?? "Не удалось сохранить пользователя.");
                  } else {
                    setError("Не удалось сохранить пользователя.");
                  }
                } finally {
                  setPending(false);
                }
              });
            }}
          >
            <fieldset className="crm-form__fieldset" disabled={pending || !canManageCurrentUser}>
              <label className="crm-field">
                <span className="crm-field__label">Email</span>
                <input className="crm-input" name="email" defaultValue={user?.email ?? ""} />
              </label>

              <label className="crm-field">
                <span className="crm-field__label">Имя</span>
                <input className="crm-input" name="first_name" defaultValue={user?.first_name ?? ""} />
              </label>

              <label className="crm-field">
                <span className="crm-field__label">Фамилия</span>
                <input className="crm-input" name="last_name" defaultValue={user?.last_name ?? ""} />
              </label>

              <label className="crm-field">
                <span className="crm-field__label">Телефон</span>
                <input className="crm-input" name="phone_number" defaultValue={user?.phone_number ?? ""} />
              </label>

              <label className="crm-field">
                <span className="crm-field__label">Роль</span>
                <select className="crm-select" name="role" value={selectedRole} onChange={(event) => setSelectedRole(event.target.value as typeof selectedRole)}>
                  {roleOptions.map((role) => (
                    <option key={role} value={role}>
                      {getCrmRoleLabel(role)}
                    </option>
                  ))}
                </select>
              </label>

              {showRopField ? (
                <label className="crm-field">
                  <span className="crm-field__label">ROP ID</span>
                  <input className="crm-input" name="rop_id" type="number" defaultValue={user?.rop_id ?? ""} />
                </label>
              ) : null}

              {mode === "create" ? (
                <label className="crm-field">
                  <span className="crm-field__label">Временный пароль</span>
                  <input className="crm-input" type="password" name="password" minLength={9} />
                </label>
              ) : null}
            </fieldset>

            {error ? <div className="crm-form__error">{error}</div> : null}
            {message ? <div className="crm-form__success">{message}</div> : null}

            <div className="crm-form-actions crm-form-actions--sticky">
              {canManageCurrentUser ? (
                <button type="submit" className="crm-button" disabled={pending}>
                  {pending ? "Сохранение..." : mode === "create" ? "Создать пользователя" : "Сохранить изменения"}
                </button>
              ) : null}
              <div className="crm-note">Текущий пароль недоступен для просмотра. Допустим только безопасный reset.</div>
            </div>
          </form>
        </CrmPanel>

        {mode === "edit" && user ? (
          <CrmPanel>
            <h2 className="crm-section-title">Действия</h2>

            <div className="crm-detail-card">
              <div>
                <strong>Роль:</strong> {getCrmRoleLabel(user)}
              </div>
              <div>
                <strong>ROP ID:</strong> {user.rop_id ?? "-"}
              </div>
            </div>

            {canResetPassword ? (
              <form
                className="crm-form"
                onSubmit={(event) => {
                  event.preventDefault();
                  setPasswordError(null);
                  setPasswordMessage(null);
                  const formData = new FormData(event.currentTarget);
                  setPasswordPending(true);

                  startTransition(async () => {
                    try {
                      const result = await crmClientFetch<CrmMessageResponse>(`/api/v1/crm/users/${user.id}/change-password`, {
                        method: "POST",
                        headers: {
                          "content-type": "application/json",
                        },
                        body: JSON.stringify({
                          password: formData.get("password"),
                          repeat_password: formData.get("repeat_password"),
                        }),
                      });

                      setPasswordMessage(result.message ?? "Временный пароль установлен.");
                      router.refresh();
                    } catch (requestError) {
                      if (requestError instanceof CrmApiError) {
                        setPasswordError(readUserError(requestError.payload) ?? "Не удалось сбросить пароль.");
                      } else {
                        setPasswordError("Не удалось сбросить пароль.");
                      }
                    } finally {
                      setPasswordPending(false);
                    }
                  });
                }}
              >
                <div className="crm-note">Текущий пароль не раскрывается. Администратор может только задать новый временный пароль.</div>

                <label className="crm-field">
                  <span className="crm-field__label">Новый временный пароль</span>
                  <input className="crm-input" type="password" name="password" minLength={9} />
                </label>

                <label className="crm-field">
                  <span className="crm-field__label">Повтор пароля</span>
                  <input className="crm-input" type="password" name="repeat_password" minLength={9} />
                </label>

                {passwordError ? <div className="crm-form__error">{passwordError}</div> : null}
                {passwordMessage ? <div className="crm-form__success">{passwordMessage}</div> : null}

                <div className="crm-form-actions crm-form-actions--sticky">
                  <button type="submit" className="crm-button" disabled={passwordPending}>
                    {passwordPending ? "Сброс..." : "Задать временный пароль"}
                  </button>
                </div>
              </form>
            ) : null}

            {canDeleteUser ? (
              <div className="crm-danger-zone">
                <CrmActionButton
                  path={`/api/v1/crm/users/${user.id}`}
                  method="DELETE"
                  className="crm-button--danger"
                  refreshOnSuccess={false}
                  confirmText="Удалить пользователя? Его объекты будут переведены на buffer user."
                  successMessage="Пользователь удален."
                  onSuccess={() => {
                    router.replace(crmRoutes.users);
                  }}
                >
                  Удалить пользователя
                </CrmActionButton>
              </div>
            ) : null}
          </CrmPanel>
        ) : null}
      </div>
    </div>
  );
}
