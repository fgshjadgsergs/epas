"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { KeyboardEvent } from "react";
import { CrmUser } from "@/lib/crm-api";
import { formatCrmDate } from "@/lib/crm-format";
import { getCrmRole, getCrmRoleLabel, isCrmAdminLike } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

export function CrmUsersTable({ items }: { items: CrmUser[] }) {
  const router = useRouter();

  const openUser = (id: number) => {
    router.push(crmRoutes.user(id));
  };

  const handleRowKeyDown = (event: KeyboardEvent<HTMLTableRowElement>, id: number) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openUser(id);
    }
  };

  return (
    <div className="crm-table-wrap">
      <table className="crm-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Имя</th>
            <th>Телефон</th>
            <th>Роль</th>
            <th>Создан</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const role = getCrmRole(item);

            return (
              <tr key={item.id} tabIndex={0} onClick={() => openUser(item.id)} onKeyDown={(event) => handleRowKeyDown(event, item.id)}>
                <td>{item.id}</td>
                <td>{item.email}</td>
                <td>
                  <div className="crm-table__title">{`${item.first_name} ${item.last_name}`.trim() || "-"}</div>
                  <div className="crm-table__meta">{getCrmRoleLabel(role)}</div>
                </td>
                <td>{item.phone_number || "-"}</td>
                <td>
                  <span className={`crm-table__status ${isCrmAdminLike(item) ? "crm-table__status--priority" : ""}`}>{getCrmRoleLabel(role)}</span>
                </td>
                <td>{formatCrmDate(item.created_at)}</td>
                <td className="crm-table__cell-actions" onClick={(event) => event.stopPropagation()}>
                  <Link href={crmRoutes.user(item.id)} className="crm-button crm-button--ghost crm-button--xs">
                    Открыть
                  </Link>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
