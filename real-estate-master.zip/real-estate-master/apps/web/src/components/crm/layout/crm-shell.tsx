import { ReactNode } from "react";
import { CrmUser } from "@/lib/crm-api";
import { getCrmRoleLabel } from "@/lib/crm-role";
import { CrmLogoutButton } from "./crm-logout-button";
import { CrmNav } from "./crm-nav";

export function CrmShell({ user, children }: { user: CrmUser; children: ReactNode }) {
  const displayName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim() || user.email;

  return (
    <div className="crm-shell">
      <aside className="crm-shell__sidebar">
        <div className="crm-brand">
          <div className="crm-brand__eyebrow">EPAS CRM</div>
          <div className="crm-brand__title">Панель оператора</div>
          <div className="crm-brand__subtitle">{getCrmRoleLabel(user)}</div>
        </div>

        <CrmNav user={user} />

        <div className="crm-shell__sidebar-footer">
          <CrmLogoutButton />
        </div>
      </aside>

      <div className="crm-shell__content">
        <header className="crm-shell__header">
          <div>
            <div className="crm-shell__user">{displayName}</div>
            <div className="crm-shell__role">{user.email}</div>
          </div>
        </header>

        <main className="crm-shell__main">{children}</main>
      </div>
    </div>
  );
}
