"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CrmUser } from "@/lib/crm-api";
import {
  canAccessCrmAllEstates,
  canAccessCrmClients,
  canAccessCrmQueues,
  canAccessCrmUsers,
  canCreateCrmEstate,
} from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";
import { cn } from "@/lib/utils";

export function CrmNav({ user }: { user: CrmUser }) {
  const pathname = usePathname();
  const links = [
    { href: crmRoutes.profile, label: "Профиль" },
    ...(canCreateCrmEstate(user) ? [{ href: crmRoutes.myEstates, label: "Мои объекты" }] : []),
    ...(canCreateCrmEstate(user) ? [{ href: crmRoutes.myEstatesArchive, label: "Архив моих" }] : []),
    ...(canAccessCrmAllEstates(user) ? [{ href: crmRoutes.estates, label: "Все объекты" }] : []),
    ...(canAccessCrmAllEstates(user) ? [{ href: crmRoutes.estatesArchive, label: "Архив всех" }] : []),
    ...(canAccessCrmClients(user) ? [{ href: crmRoutes.clients, label: "Клиенты" }] : []),
    ...(canAccessCrmClients(user) ? [{ href: crmRoutes.deals, label: "Сделки" }] : []),
    ...(canAccessCrmUsers(user) ? [{ href: crmRoutes.users, label: "Пользователи" }] : []),
    ...(canAccessCrmQueues(user) ? [{ href: crmRoutes.moderationEstates, label: "Модерация" }] : []),
    ...(canAccessCrmQueues(user) ? [{ href: crmRoutes.uploadEstates, label: "Выгрузка" }] : []),
  ] as const;

  return (
    <nav className="crm-nav">
      {links.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className={cn("crm-nav__link", pathname === link.href || pathname.startsWith(`${link.href}/`) ? "is-active" : "")}
        >
          {link.label}
        </Link>
      ))}
    </nav>
  );
}
