"use client";

import { useRouter } from "next/navigation";
import { startTransition, useState } from "react";
import { crmClientFetch } from "@/lib/crm-api";
import { crmRoutes } from "@/lib/crm-routes";

export function CrmLogoutButton() {
  const router = useRouter();
  const [pending, setPending] = useState(false);

  return (
    <button
      type="button"
      className="crm-button crm-button--ghost"
      disabled={pending}
      onClick={() => {
        setPending(true);
        startTransition(async () => {
          try {
            await crmClientFetch("/api/v1/crm/auth/logout", {
              method: "POST",
            });
            router.replace(crmRoutes.login);
            router.refresh();
          } finally {
            setPending(false);
          }
        });
      }}
    >
      {pending ? "Выход..." : "Выйти"}
    </button>
  );
}
