﻿"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChangeEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";
import {
  CrmApiError,
  CrmEstateDetail,
  CrmEstateMatchesResponse,
  CrmItemResponse,
  CrmMatchedClientItem,
  CrmMetaResponse,
  CrmUser,
  crmClientFetch,
} from "@/lib/crm-api";
import { getCrmDictionaryLabel } from "@/lib/crm-dictionaries";
import { canAccessCrmAllEstates, canManageEstate, getCrmRole, hasEstateOwnerContacts } from "@/lib/crm-role";
import { crmRoutes, getPublicSiteUrl } from "@/lib/crm-routes";
import { CrmEstateMatches } from "@/components/crm/matching/crm-estate-matches";
import { CrmEstateAvitoPanel } from "@/components/crm/estates/crm-estate-avito-panel";
import { CrmActionButton } from "@/components/crm/shared/crm-action-button";
import { CrmAutoResizeTextarea } from "@/components/crm/shared/crm-auto-resize-textarea";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmRequiredLabel } from "@/components/crm/shared/crm-required-label";
import { CrmPanel } from "@/components/crm/shared/crm-state";
import { CrmUserMultiSelect, CrmUserMultiSelectOption } from "@/components/crm/shared/crm-user-multi-select";

const ALLOWED_IMAGE_MIME_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"] as const;
const ALLOWED_IMAGE_EXTENSIONS = ["jpg", "jpeg", "png", "webp", "gif", "avif"] as const;
const IMAGE_UPLOAD_ERROR_MESSAGE = "Можно загружать только изображения JPG, JPEG, PNG, WEBP, GIF или AVIF.";
const RENT_BUSINESS_LABEL = "Арендный бизнес";

interface ExistingEditorImage {
  kind: "existing";
  id: number;
  url: string;
  publicUrl: string;
  isMain: boolean;
  isPlan: boolean;
  markedForDelete: boolean;
}

interface NewEditorImage {
  kind: "new";
  clientId: string;
  file: File;
  previewUrl: string;
}

type SelectedPlanImage =
  | { kind: "existing"; id: number }
  | { kind: "new"; clientId: string }
  | null;

function parseOwnerContacts(value: FormDataEntryValue | null): Array<{ owner_phone: string; owner_name: string }> {
  return String(value ?? "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [owner_phone, owner_name] = line.split("|").map((item) => item.trim());
      return {
        owner_phone: owner_phone ?? "",
        owner_name: owner_name ?? "",
      };
    });
}

function parseCianContacts(value: FormDataEntryValue | null): Array<{ code: string; number: string }> {
  return String(value ?? "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => line.replace(/[^\d+]/g, ""))
    .map((phone) => {
      const digits = phone.startsWith("+") ? phone.slice(1) : phone;
      const normalized = digits.length === 11 && digits.startsWith("7") ? digits.slice(1) : digits;
      return {
        code: "+7",
        number: normalized,
      };
    });
}

function humanizeEstateErrorMessage(message: string): string {
  const normalized = message.toLowerCase();

  if (normalized.includes("user_id is required for rop")) {
    return "Выберите брокера для объекта.";
  }

  if (normalized.includes("user_id must reference broker")) {
    return "Нужно выбрать брокера для объекта.";
  }

  if (normalized.includes("можно назначить не больше 3 пользователей")) {
    return "Можно назначить не больше 3 пользователей.";
  }

  if (normalized.includes("можно назначать только брокеров и администраторов")) {
    return "Можно назначать только брокеров и администраторов.";
  }

  return message;
}

function readErrorMessage(payload: unknown): string {
  if (!payload || typeof payload !== "object") {
    return "Не удалось сохранить объект.";
  }

  const data = payload as { errors?: Record<string, unknown>; message?: string };
  if (data.message) {
    return humanizeEstateErrorMessage(data.message);
  }

  if (data.errors) {
    for (const value of Object.values(data.errors)) {
      if (typeof value === "string") {
        return humanizeEstateErrorMessage(value);
      }

      if (value && typeof value === "object") {
        for (const nestedValue of Object.values(value)) {
          if (typeof nestedValue === "string") {
            return humanizeEstateErrorMessage(nestedValue);
          }
        }
      }
    }
  }

  return "Не удалось сохранить объект.";
}

function Section({
  title,
  note,
  children,
}: {
  title: string;
  note?: string;
  children: ReactNode;
}) {
  return (
    <div className="crm-subsection crm-subsection--dense">
      <h2 className="crm-section-title">{title}</h2>
      {note ? <p className="crm-subsection__note">{note}</p> : null}
      {children}
    </div>
  );
}

function getAssignableUserLabel(user: CrmUser): string {
  const displayName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return displayName ? `${displayName} (${user.email})` : user.email;
}

function formatDecimalInput(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") {
    return "";
  }

  const normalized = String(value).trim().replace(/\s+/g, "").replace(/,/g, ".");
  if (!normalized) {
    return "";
  }

  const hasTrailingDot = normalized.endsWith(".");
  const sign = normalized.startsWith("-") ? "-" : "";
  const unsigned = sign ? normalized.slice(1) : normalized;
  const [integerPartRaw, fractionPart] = unsigned.split(".");
  const integerPart = (integerPartRaw || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");

  if (hasTrailingDot) {
    return `${sign}${integerPart}.`;
  }

  return fractionPart !== undefined ? `${sign}${integerPart}.${fractionPart}` : `${sign}${integerPart}`;
}

function normalizeFormattedDecimalInput(value: FormDataEntryValue | null): string {
  return String(value ?? "").trim().replace(/\s+/g, "").replace(/,/g, ".");
}

function getEstateRequiredFieldNames(
  meta: CrmMetaResponse | undefined,
  mode: "create" | "edit",
  dealType: string,
): Set<string> {
  const requiredFields = meta?.estate?.form?.required_fields;
  const fieldNames = new Set<string>(requiredFields?.always ?? []);

  if (mode === "create") {
    for (const field of requiredFields?.create_only ?? []) {
      fieldNames.add(field);
    }
  }

  if (dealType === RENT_BUSINESS_LABEL) {
    for (const field of requiredFields?.conditional?.rent_business ?? []) {
      fieldNames.add(field);
    }
  }

  return fieldNames;
}

function isAllowedImageFile(file: File): boolean {
  const normalizedType = String(file.type ?? "").trim().toLowerCase();
  const normalizedExtension = file.name.split(".").pop()?.trim().toLowerCase() ?? "";
  const hasAllowedType = normalizedType ? ALLOWED_IMAGE_MIME_TYPES.includes(normalizedType as (typeof ALLOWED_IMAGE_MIME_TYPES)[number]) : false;
  const hasAllowedExtension = normalizedExtension
    ? ALLOWED_IMAGE_EXTENSIONS.includes(normalizedExtension as (typeof ALLOWED_IMAGE_EXTENSIONS)[number])
    : false;

  if (normalizedType && normalizedExtension) {
    return hasAllowedType && hasAllowedExtension;
  }

  return hasAllowedType || hasAllowedExtension;
}

function buildExistingEditorImages(images: CrmEstateDetail["images"] | undefined): ExistingEditorImage[] {
  return (images ?? []).map((image) => ({
    kind: "existing",
    id: image.id,
    url: image.url,
    publicUrl: image.public_url,
    isMain: image.is_main,
    isPlan: image.is_plan,
    markedForDelete: false,
  }));
}

function resolveMainExistingImageId(images: ExistingEditorImage[]): number | null {
  const activeImages = images.filter((image) => !image.markedForDelete);
  const explicitlyMain = activeImages.find((image) => image.isMain);

  return explicitlyMain?.id ?? activeImages[0]?.id ?? null;
}

function resolvePlanExistingImage(images: ExistingEditorImage[]): SelectedPlanImage {
  const planImage = images.find((image) => image.isPlan && !image.markedForDelete);
  return planImage ? { kind: "existing", id: planImage.id } : null;
}

export function CrmEstateEditor({
  mode,
  viewer,
  meta,
  item,
  assignableUsers = [],
  archivedView = false,
  backHref: backHrefProp,
}: {
  mode: "create" | "edit";
  viewer: CrmUser;
  meta: CrmMetaResponse;
  item?: CrmEstateDetail;
  assignableUsers?: CrmUser[];
  archivedView?: boolean;
  backHref?: string;
}) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [presentationPending, setPresentationPending] = useState(false);
  const [duplicatePending, setDuplicatePending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [matchedClients, setMatchedClients] = useState<CrmMatchedClientItem[]>([]);
  const [matchedClientsTotal, setMatchedClientsTotal] = useState(0);
  const [matchedClientsLoading, setMatchedClientsLoading] = useState(false);
  const [matchedClientsError, setMatchedClientsError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const viewerRole = getCrmRole(viewer);
  const canManageAssignments = viewerRole === "OWNER" || viewerRole === "ADMIN";
  const canManageCurrentEstate = mode === "create" ? canAccessCrmAllEstates(viewer) : item ? canManageEstate(viewer, item) : false;
  const isReadOnly = mode === "edit" && !canManageCurrentEstate;
  const ownerContactsVisible = mode === "create" || Boolean(item && hasEstateOwnerContacts(item));
  const defaultOwnerContacts = item?.owner_contacts?.map((contact) => `${contact.owner_phone} | ${contact.owner_name}`).join("\n") ?? "";
  const defaultCianPhones = item?.cian.owner_contacts?.map((contact) => `${contact.code}${contact.number}`).join("\n") ?? "";
  const isArchivedItem = mode === "edit" && archivedView;
  const backHref = backHrefProp ?? (canAccessCrmAllEstates(viewer) ? crmRoutes.estates : crmRoutes.myEstates);
  const restoreTargetHref = backHref === crmRoutes.myEstatesArchive ? crmRoutes.myEstates : crmRoutes.estates;
  const archivedReturnTo = backHref === crmRoutes.myEstatesArchive ? "my-archive" : "archive";
  const initialDealType = item?.deal_type ?? meta.estate.form.choice_fields.deal_type[0] ?? "";
  const [currentDealType, setCurrentDealType] = useState(initialDealType);
  const defaultAssignedUserIds =
    mode === "edit"
      ? item?.assigned_user_ids ?? []
      : viewerRole === "BROKER"
        ? [viewer.id]
        : [];
  const [selectedAssignedUserIds, setSelectedAssignedUserIds] = useState<number[]>(defaultAssignedUserIds);
  const [assignmentError, setAssignmentError] = useState<string | null>(null);
  const [gapDisplayValue, setGapDisplayValue] = useState(formatDecimalInput(item?.gap ?? ""));
  const [existingEditorImages, setExistingEditorImages] = useState<ExistingEditorImage[]>(() => buildExistingEditorImages(item?.images));
  const [newEditorImages, setNewEditorImages] = useState<NewEditorImage[]>([]);
  const [selectedMainExistingImageId, setSelectedMainExistingImageId] = useState<number | null>(() =>
    resolveMainExistingImageId(buildExistingEditorImages(item?.images)),
  );
  const [selectedPlanImage, setSelectedPlanImage] = useState<SelectedPlanImage>(() =>
    resolvePlanExistingImage(buildExistingEditorImages(item?.images)),
  );
  const requiredFieldNames = useMemo(
    () => getEstateRequiredFieldNames(meta, mode, currentDealType),
    [currentDealType, meta, mode],
  );
  const availableAssignableUsers = assignableUsers
    .filter((candidate) => {
      const role = getCrmRole(candidate);
      return role === "BROKER" || role === "ADMIN";
    })
    .sort((left, right) => getAssignableUserLabel(left).localeCompare(getAssignableUserLabel(right), "ru"));
  const availableAssignableUserOptions = useMemo<CrmUserMultiSelectOption[]>(
    () =>
      availableAssignableUsers.map((user) => {
        const displayName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
        return {
          id: user.id,
          label: displayName || user.email,
          description: `${user.email} · ${getCrmRole(user)} · ID ${user.id}`,
          searchText: `${displayName} ${user.email} ${user.id}`,
        };
      }),
    [availableAssignableUsers],
  );
  const assignmentsNote =
    availableAssignableUsers.length > 0
      ? "Можно оставить объект без назначений или выбрать до 3 пользователей."
      : "Нет доступных пользователей для назначения.";
  const presentationHref = item
    ? `/api/v1/crm/estates/${item.id}/presentation.pdf${isArchivedItem ? "?archived=1" : ""}`
    : null;
  const newEditorImagesRef = useRef<NewEditorImage[]>([]);

  useEffect(() => {
    setNewEditorImages((currentImages) => {
      for (const image of currentImages) {
        URL.revokeObjectURL(image.previewUrl);
      }

      return [];
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    if (mode === "edit") {
      const nextExistingImages = buildExistingEditorImages(item?.images);
      setExistingEditorImages(nextExistingImages);
      setSelectedMainExistingImageId(resolveMainExistingImageId(nextExistingImages));
      setSelectedPlanImage(resolvePlanExistingImage(nextExistingImages));
    } else {
      setExistingEditorImages([]);
      setSelectedMainExistingImageId(null);
      setSelectedPlanImage(null);
    }
  }, [item?.id, mode]);

  useEffect(() => {
    newEditorImagesRef.current = newEditorImages;
  }, [newEditorImages]);

  useEffect(() => {
    return () => {
      for (const image of newEditorImagesRef.current) {
        URL.revokeObjectURL(image.previewUrl);
      }
    };
  }, []);

  useEffect(() => {
    if (mode !== "edit" || !item || archivedView) {
      setMatchedClients([]);
      setMatchedClientsTotal(0);
      setMatchedClientsLoading(false);
      setMatchedClientsError(null);
      return;
    }

    let cancelled = false;
    setMatchedClientsLoading(true);
    setMatchedClientsError(null);

    void crmClientFetch<CrmEstateMatchesResponse>(`/api/v1/crm/estates/${item.id}/matches`)
      .then((response) => {
        if (cancelled) {
          return;
        }

        setMatchedClients(response.items);
        setMatchedClientsTotal(response.total);
      })
      .catch((requestError) => {
        if (cancelled) {
          return;
        }

        if (requestError instanceof CrmApiError && requestError.payload && typeof requestError.payload === "object") {
          const payload = requestError.payload as { message?: string };
          setMatchedClientsError(payload.message ?? "Не удалось загрузить подходящих клиентов.");
        } else {
          setMatchedClientsError("Не удалось загрузить подходящих клиентов.");
        }
        setMatchedClients([]);
        setMatchedClientsTotal(0);
      })
      .finally(() => {
        if (!cancelled) {
          setMatchedClientsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [archivedView, item?.id, mode]);

  function clearNewEditorImages(): void {
    setNewEditorImages((currentImages) => {
      for (const image of currentImages) {
        URL.revokeObjectURL(image.previewUrl);
      }

      return [];
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }

  function handleNewImagesChange(event: ChangeEvent<HTMLInputElement>): void {
    const files = Array.from(event.target.files ?? []);
    if (files.length === 0) {
      return;
    }

    if (files.some((file) => !isAllowedImageFile(file))) {
      setError(IMAGE_UPLOAD_ERROR_MESSAGE);
      event.target.value = "";
      return;
    }

    setError(null);
    setNewEditorImages((currentImages) => [
      ...currentImages,
      ...files.map((file, index) => ({
        kind: "new" as const,
        clientId: `${Date.now()}-${index}-${file.name}-${file.size}-${file.lastModified}`,
        file,
        previewUrl: URL.createObjectURL(file),
      })),
    ]);
    event.target.value = "";
  }

  function handleRemoveNewImage(clientId: string): void {
    setNewEditorImages((currentImages) => {
      const imageToRemove = currentImages.find((image) => image.clientId === clientId);
      if (imageToRemove) {
        URL.revokeObjectURL(imageToRemove.previewUrl);
      }

      if (selectedPlanImage?.kind === "new" && selectedPlanImage.clientId === clientId) {
        setSelectedPlanImage(null);
      }

      return currentImages.filter((image) => image.clientId !== clientId);
    });
  }

  function handleExistingImageDeleteToggle(imageId: number, shouldDelete: boolean): void {
    setExistingEditorImages((currentImages) => {
      const nextImages = currentImages.map((image) => (image.id === imageId ? { ...image, markedForDelete: shouldDelete } : image));
      const nextMainImageId = resolveMainExistingImageId(
        nextImages.map((image) =>
          image.id === imageId && shouldDelete && image.id === selectedMainExistingImageId ? { ...image, isMain: false } : image,
        ),
      );

      setSelectedMainExistingImageId(nextMainImageId);
      if (shouldDelete && selectedPlanImage?.kind === "existing" && selectedPlanImage.id === imageId) {
        setSelectedPlanImage(null);
      }

      return nextImages.map((image) => ({
        ...image,
        isMain: image.id === nextMainImageId,
        isPlan: shouldDelete && image.id === imageId ? false : image.isPlan,
      }));
    });
  }

  function handleMainExistingImageChange(imageId: number): void {
    setSelectedMainExistingImageId(imageId);
    setExistingEditorImages((currentImages) =>
      currentImages.map((image) => ({
        ...image,
        isMain: image.id === imageId,
      })),
    );
  }

  function handlePlanExistingImageChange(imageId: number): void {
    setSelectedPlanImage({ kind: "existing", id: imageId });
    setExistingEditorImages((currentImages) =>
      currentImages.map((image) => ({
        ...image,
        isPlan: image.id === imageId,
      })),
    );
  }

  function handlePlanNewImageChange(clientId: string): void {
    setSelectedPlanImage({ kind: "new", clientId });
    setExistingEditorImages((currentImages) =>
      currentImages.map((image) => ({
        ...image,
        isPlan: false,
      })),
    );
  }

  async function handlePresentationDownload(): Promise<void> {
    if (!presentationHref || presentationPending || !item) {
      return;
    }

    setPresentationPending(true);
    setError(null);

    try {
      const response = await fetch(presentationHref, {
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error(`PDF request failed with status ${response.status}`);
      }

      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const filenameMatch = response.headers.get("content-disposition")?.match(/filename=\"([^\"]+)\"/i);

      link.href = objectUrl;
      link.download = filenameMatch?.[1] ?? `estate-${item.id}-presentation.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(objectUrl);
    } catch (downloadError) {
      setError(downloadError instanceof Error ? downloadError.message : "Не удалось скачать PDF.");
    } finally {
      setPresentationPending(false);
    }
  }

  async function handleDuplicate(): Promise<void> {
    if (!item || duplicatePending || isArchivedItem || !canManageCurrentEstate) {
      return;
    }

    if (!window.confirm("Дублировать объект?")) {
      return;
    }

    setDuplicatePending(true);
    setError(null);
    setMessage(null);

    try {
      const result = await crmClientFetch<CrmItemResponse<CrmEstateDetail>>(`/api/v1/crm/estates/${item.id}/actions/duplicate`, {
        method: "POST",
      });

      setMessage("Копия объекта создана.");
      router.replace(crmRoutes.estate(result.item.id));
      router.refresh();
    } catch (requestError) {
      if (requestError instanceof CrmApiError) {
        setError(readErrorMessage(requestError.payload));
      } else {
        setError("Не удалось продублировать объект.");
      }
    } finally {
      setDuplicatePending(false);
    }
  }

  return (
    <div className="crm-stack">
      <CrmPageHeader
        title={mode === "create" ? "Новый объект" : `Объект #${item?.id ?? ""}`}
        description={
          mode === "create"
            ? "Быстрое создание объекта с обязательным базовым набором данных."
            : isReadOnly
              ? "Объект доступен только для просмотра. Контакты собственника скрываются правилами доступа."
              : "Компактное редактирование объекта с быстрыми действиями и отдельным блоком CIAN."
        }
      />

      <div className="crm-form-grid crm-form-grid--wide">
        <CrmPanel>
          {isReadOnly ? <div className="crm-note">Редактирование недоступно. У вас есть только просмотр карточки объекта.</div> : null}

          <form
            className="crm-form"
            onSubmit={(event) => {
              event.preventDefault();
              if (isReadOnly) {
                return;
              }

              setError(null);
              setMessage(null);
              setAssignmentError(null);

              const formData = new FormData(event.currentTarget);
              const requestFormData = new FormData();
              const newImages = newEditorImages.map((image) => image.file);

              if (newImages.some((image) => !isAllowedImageFile(image))) {
                setError(IMAGE_UPLOAD_ERROR_MESSAGE);
                return;
              }

              if (mode === "create" && newImages.length === 0) {
                setError("Обязательно нужно указать фото.");
                return;
              }

              const existingImages = existingEditorImages.map((image) => ({
                id: image.id,
                delete: image.markedForDelete,
                is_main: !image.markedForDelete && image.id === selectedMainExistingImageId,
                is_plan:
                  !image.markedForDelete &&
                  selectedPlanImage?.kind === "existing" &&
                  image.id === selectedPlanImage.id,
              }));
              const planImageNewIndex =
                selectedPlanImage?.kind === "new"
                  ? newEditorImages.findIndex((image) => image.clientId === selectedPlanImage.clientId)
                  : null;

              const payload: Record<string, unknown> = {
                title: formData.get("title"),
                description: formData.get("description"),
                area_description: formData.get("area_description"),
                internal_info: formData.get("internal_info"),
                status: formData.get("status"),
                tags: formData.get("tags"),
                estate_type: formData.get("estate_type"),
                deal_type: formData.get("deal_type"),
                area: formData.get("area"),
                floor: formData.get("floor"),
                all_floors: formData.get("all_floors"),
                levels_count: formData.get("levels_count"),
                occupied_floors_text: formData.get("occupied_floors_text"),
                price: formData.get("price"),
                region: formData.get("region"),
                district: formData.get("district"),
                metro_station: formData.get("metro_station"),
                priority: formData.get("priority") === "on",
                is_private_sale: formData.get("is_private_sale") === "on",
                owner_type: ownerContactsVisible ? formData.get("owner_type") : undefined,
                owner_contacts: ownerContactsVisible ? parseOwnerContacts(formData.get("owner_contacts")) : undefined,
                required_owner_phone: formData.get("required_owner_phone"),
                required_owner_name: formData.get("required_owner_name"),
                tenant_type: formData.get("tenant_type"),
                map_: formData.get("map_"),
                contract_term: formData.get("contract_term"),
                indexing: formData.get("indexing"),
                gap: normalizeFormattedDecimalInput(formData.get("gap")),
                power_kw: formData.get("power_kw"),
                ceiling_height_m: formData.get("ceiling_height_m"),
                existing_images: existingImages,
                plan_image_new_index: planImageNewIndex !== null && planImageNewIndex >= 0 ? planImageNewIndex : null,
              };

              if (canManageAssignments) {
                const selectedAssignedUserIds = formData
                  .getAll("assigned_user_ids")
                  .map((value) => Number(value))
                  .filter((value) => Number.isInteger(value) && value > 0);

                if (selectedAssignedUserIds.length > 3) {
                  setAssignmentError("Можно назначить не больше 3 пользователей.");
                  return;
                }

                const availableAssignableUserIds = new Set(availableAssignableUsers.map((user) => user.id));
                if (selectedAssignedUserIds.some((userId) => !availableAssignableUserIds.has(userId))) {
                  setAssignmentError("Можно назначать только брокеров и администраторов.");
                  return;
                }

                payload.assigned_user_ids = selectedAssignedUserIds;
              }

              if (mode === "edit") {
                payload.cian = {
                  include: formData.get("cian_include") === "on",
                  type: formData.get("cian_type"),
                  owner_contacts: parseCianContacts(formData.get("cian_owner_contacts")),
                  vat_type: formData.get("cian_vat_type"),
                  ready_business_type: formData.get("cian_ready_business_type"),
                  specialty: formData.get("cian_specialty"),
                  garage_type: formData.get("cian_garage_type"),
                  land_area: formData.get("cian_land_area"),
                  land_area_unit: formData.get("cian_land_area_unit"),
                  building_area: formData.get("cian_building_area"),
                };
              }

              requestFormData.set("data", JSON.stringify(payload));
              for (const image of newImages) {
                requestFormData.append("new_images", image);
              }

              setPending(true);

              void (async () => {
                try {
                  const result = await crmClientFetch<{ item: CrmEstateDetail }>(
                    mode === "create" ? "/api/v1/crm/estates" : `/api/v1/crm/estates/${item?.id}`,
                    {
                      method: mode === "create" ? "POST" : "PUT",
                      body: requestFormData,
                    },
                  );

                  setMessage(mode === "create" ? "Объект создан." : "Объект обновлен.");
                  clearNewEditorImages();
                  router.replace(
                    mode === "edit" && isArchivedItem
                      ? `${crmRoutes.estate(result.item.id)}?archived=1&returnTo=${archivedReturnTo}`
                      : crmRoutes.estate(result.item.id),
                  );
                  router.refresh();
                } catch (requestError) {
                  if (requestError instanceof CrmApiError) {
                    setError(readErrorMessage(requestError.payload));
                  } else {
                    setError("Не удалось сохранить объект.");
                  }
                } finally {
                  setPending(false);
                }
              })();
            }}
          >
            <fieldset className="crm-form__fieldset" disabled={pending || isReadOnly}>
              <Section title="Основное">
                <div className="crm-form-columns">
                  <label className="crm-field crm-field--wide">
                    <CrmRequiredLabel required={requiredFieldNames.has("title")}>Название объекта</CrmRequiredLabel>
                    <input className="crm-input" name="title" defaultValue={item?.title ?? ""} />
                  </label>

                  <label className="crm-field crm-field--wide">
                    <CrmRequiredLabel required={requiredFieldNames.has("description")}>Описание</CrmRequiredLabel>
                    <CrmAutoResizeTextarea name="description" defaultValue={item?.description ?? ""} />
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("deal_type")}>Сделка</CrmRequiredLabel>
                    <select
                      className="crm-select"
                      name="deal_type"
                      defaultValue={item?.deal_type ?? meta.estate.form.choice_fields.deal_type[0] ?? ""}
                      onChange={(event) => {
                        setCurrentDealType(event.target.value);
                      }}
                    >
                      {meta.estate.form.choice_fields.deal_type.map((value) => (
                        <option key={value} value={value}>
                          {value}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Статус</span>
                    <input className="crm-input" name="status" defaultValue={item?.status ?? ""} />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Теги</span>
                    <input className="crm-input" name="tags" defaultValue={item?.tags ?? ""} />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Тип объекта</span>
                    <input className="crm-input" name="estate_type" defaultValue={item?.estate_type ?? ""} />
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("tenant_type")}>Арендатор</CrmRequiredLabel>
                    <input className="crm-input" name="tenant_type" defaultValue={item?.tenant_type ?? ""} />
                  </label>

                  {ownerContactsVisible ? (
                    <label className="crm-field">
                      <span className="crm-field__label">Тип собственника</span>
                      <select className="crm-select" name="owner_type" defaultValue={item?.owner_type ?? meta.estate.form.choice_fields.owner_type[0] ?? ""}>
                        <option value="">Не указан</option>
                        {meta.estate.form.choice_fields.owner_type.map((value) => (
                          <option key={value} value={value}>
                            {value}
                          </option>
                        ))}
                      </select>
                    </label>
                  ) : null}

                  {canManageAssignments ? (
                    <div className="crm-field crm-field--wide">
                      <span className="crm-field__label">Назначенные пользователи</span>
                      <CrmUserMultiSelect
                        name="assigned_user_ids"
                        options={availableAssignableUserOptions}
                        selectedIds={selectedAssignedUserIds}
                        onChange={(nextIds) => {
                          setAssignmentError(null);
                          setSelectedAssignedUserIds(nextIds);
                        }}
                        disabled={isReadOnly}
                        helperText={assignmentsNote}
                      />
                      {assignmentError ? <div className="crm-form__error crm-form__error--compact">{assignmentError}</div> : null}
                    </div>
                  ) : null}
                </div>
              </Section>

              <Section title="Цена и параметры">
                <div className="crm-form-columns">
                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("price")}>Цена</CrmRequiredLabel>
                    <input className="crm-input" type="number" name="price" defaultValue={item?.price ?? ""} />
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("area")}>Площадь</CrmRequiredLabel>
                    <input className="crm-input" type="number" step="0.1" name="area" defaultValue={item?.area ?? ""} />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Этаж</span>
                    <input className="crm-input" type="number" name="floor" defaultValue={item?.floor ?? ""} />
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("all_floors")}>Всего этажей</CrmRequiredLabel>
                    <input className="crm-input" type="number" name="all_floors" defaultValue={item?.all_floors ?? ""} />
                  </label>
                  <label className="crm-field">
                    <span className="crm-field__label">Количество уровней</span>
                    <input
                      className="crm-input"
                      type="number"
                      min="1"
                      step="1"
                      name="levels_count"
                      defaultValue={item?.levels_count ?? ""}
                    />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Занимаемые этажи / уровни</span>
                    <input
                      className="crm-input"
                      name="occupied_floors_text"
                      maxLength={255}
                      placeholder="Например: цоколь и 1 этаж или 1–3 этажи"
                      defaultValue={item?.occupied_floors_text ?? ""}
                    />
                    <span className="crm-field__hint">Для многоуровневого объекта укажите все занимаемые этажи или уровни.</span>
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("map_")}>MAP</CrmRequiredLabel>
                    <input className="crm-input" name="map_" type="number" defaultValue={item?.map_ ?? ""} />
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("contract_term")}>Срок договора</CrmRequiredLabel>
                    <input className="crm-input" name="contract_term" defaultValue={item?.contract_term ?? ""} />
                  </label>

                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("indexing")}>Индексация</CrmRequiredLabel>
                    <input className="crm-input" name="indexing" defaultValue={item?.indexing ?? ""} />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">ГАП (руб/год)</span>
                    <input
                      className="crm-input"
                      type="text"
                      inputMode="decimal"
                      name="gap"
                      value={gapDisplayValue}
                      onChange={(event) => {
                        setGapDisplayValue(formatDecimalInput(event.target.value));
                      }}
                    />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Мощность (кВт)</span>
                    <input className="crm-input" type="number" step="0.01" name="power_kw" defaultValue={item?.power_kw ?? ""} />
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Высота потолков (м)</span>
                    <input
                      className="crm-input"
                      type="number"
                      step="0.01"
                      name="ceiling_height_m"
                      defaultValue={item?.ceiling_height_m ?? ""}
                    />
                  </label>

                  <div className="crm-inline-filters">
                    <label className="crm-checkbox">
                      <input type="checkbox" name="priority" defaultChecked={item?.priority ?? false} />
                      <span>Приоритет</span>
                    </label>
                    <label className="crm-checkbox">
                      <input type="checkbox" name="is_private_sale" defaultChecked={item?.is_private_sale ?? false} />
                      <span>Закрытая продажа</span>
                    </label>
                  </div>
                </div>
              </Section>

              <Section title="Локация и собственник">
                <div className="crm-form-columns">
                  <label className="crm-field">
                    <CrmRequiredLabel required={requiredFieldNames.has("region")}>Регион</CrmRequiredLabel>
                    <select className="crm-select" name="region" defaultValue={item?.region ?? meta.estate.form.choice_fields.region[0] ?? ""}>
                      {meta.estate.form.choice_fields.region.map((value) => (
                        <option key={value} value={value}>
                          {value}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Округ</span>
                    <select className="crm-select" name="district" defaultValue={item?.district ?? ""}>
                      <option value="">Не указан</option>
                      {meta.estate.form.choice_fields.district.map((value) => (
                        <option key={value} value={value}>
                          {value}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="crm-field">
                    <span className="crm-field__label">Метро</span>
                    <input className="crm-input" name="metro_station" defaultValue={item?.metro_station ?? ""} />
                  </label>

                  {ownerContactsVisible ? (
                    <label className="crm-field crm-field--wide">
                      <span className="crm-field__label">Дополнительные контакты</span>
                      <textarea className="crm-textarea" name="owner_contacts" defaultValue={defaultOwnerContacts} />
                    </label>
                  ) : (
                    <div className="crm-note">Контакты собственника скрыты правилами доступа.</div>
                  )}

                  {mode === "create" ? (
                    <>
                      <label className="crm-field">
                        <CrmRequiredLabel required={requiredFieldNames.has("required_owner_phone")}>Телефон собственника</CrmRequiredLabel>
                        <input className="crm-input" name="required_owner_phone" />
                      </label>

                      <label className="crm-field">
                        <CrmRequiredLabel required={requiredFieldNames.has("required_owner_name")}>Имя собственника</CrmRequiredLabel>
                        <input className="crm-input" name="required_owner_name" />
                      </label>
                    </>
                  ) : null}

                  <label className="crm-field crm-field--wide">
                    <span className="crm-field__label">Описание площади и района</span>
                    <CrmAutoResizeTextarea name="area_description" defaultValue={item?.area_description ?? ""} />
                  </label>

                  <label className="crm-field crm-field--wide">
                    <span className="crm-field__label">Внутренняя информация</span>
                    <CrmAutoResizeTextarea name="internal_info" defaultValue={item?.internal_info ?? ""} />
                  </label>
                </div>
              </Section>

              <Section title="Медиа">
                <div className="crm-form-columns">
                  <label className="crm-field crm-field--wide">
                    <CrmRequiredLabel required={mode === "create" && requiredFieldNames.has("new_images")}>
                      {mode === "create" ? "Фото" : "Новые фото"}
                    </CrmRequiredLabel>
                    <input
                      ref={fileInputRef}
                      className="crm-input"
                      type="file"
                      name="new_images"
                      accept=".jpg,.jpeg,.png,.webp,.gif,.avif,image/jpeg,image/png,image/webp,image/gif,image/avif"
                      multiple={mode === "edit"}
                      onChange={handleNewImagesChange}
                    />
                    <span className="crm-field__hint">Допустимы только JPG, JPEG, PNG, WEBP, GIF и AVIF.</span>
                  </label>
                  {selectedPlanImage ? (
                    <button
                      type="button"
                      className="crm-button crm-button--ghost crm-button--xs"
                      onClick={() => {
                        setSelectedPlanImage(null);
                        setExistingEditorImages((currentImages) => currentImages.map((image) => ({ ...image, isPlan: false })));
                      }}
                    >
                      Сбросить планировку
                    </button>
                  ) : null}
                </div>
              </Section>

              {existingEditorImages.length > 0 || newEditorImages.length > 0 ? (
                <div className="crm-image-list">
                  {existingEditorImages.map((image) => (
                    <div className="crm-image-card" key={`existing-${image.id}`}>
                      <div className="crm-image-card__preview">
                        <Image src={image.publicUrl || image.url} alt="" fill sizes="120px" unoptimized />
                      </div>
                      <label className="crm-checkbox">
                        <input
                          type="radio"
                          name="main_image"
                          checked={image.id === selectedMainExistingImageId && !image.markedForDelete}
                          value={String(image.id)}
                          disabled={image.markedForDelete}
                          onChange={() => {
                            handleMainExistingImageChange(image.id);
                          }}
                        />
                        <span>Главное фото</span>
                      </label>
                      <label className="crm-checkbox">
                        <input
                          type="radio"
                          name="plan_image"
                          checked={selectedPlanImage?.kind === "existing" && selectedPlanImage.id === image.id && !image.markedForDelete}
                          value={`existing-${image.id}`}
                          disabled={image.markedForDelete}
                          onChange={() => {
                            handlePlanExistingImageChange(image.id);
                          }}
                        />
                        <span>Планировка</span>
                      </label>
                      <label className="crm-checkbox">
                        <input
                          type="checkbox"
                          checked={image.markedForDelete}
                          onChange={(event) => {
                            handleExistingImageDeleteToggle(image.id, event.target.checked);
                          }}
                        />
                        <span>Удалить</span>
                      </label>
                    </div>
                  ))}

                  {newEditorImages.map((image) => (
                    <div className="crm-image-card" key={`new-${image.clientId}`}>
                      <div className="crm-image-card__preview">
                        <Image src={image.previewUrl} alt={image.file.name} fill sizes="120px" unoptimized />
                      </div>
                      <div className="crm-note">Новое фото будет добавлено после сохранения.</div>
                      <label className="crm-checkbox">
                        <input
                          type="radio"
                          name="plan_image"
                          checked={selectedPlanImage?.kind === "new" && selectedPlanImage.clientId === image.clientId}
                          value={`new-${image.clientId}`}
                          onChange={() => {
                            handlePlanNewImageChange(image.clientId);
                          }}
                        />
                        <span>Планировка</span>
                      </label>
                      <button
                        type="button"
                        className="crm-button crm-button--ghost crm-button--xs"
                        onClick={() => {
                          handleRemoveNewImage(image.clientId);
                        }}
                      >
                        Удалить
                      </button>
                    </div>
                  ))}
                </div>
              ) : null}

              {mode === "edit" ? (
                <Section title="CIAN" note="Поля CIAN хранятся отдельно от основной карточки объекта.">
                  <div className="crm-form-columns">
                    <label className="crm-checkbox">
                      <input type="checkbox" name="cian_include" defaultChecked={Boolean(item?.cian.include)} />
                      <span>Включить в CIAN</span>
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Тип</span>
                      <select className="crm-select" name="cian_type" defaultValue={item?.cian.type ?? ""}>
                        <option value="">Не выбран</option>
                        {meta.cian.choice_fields.type.map((value) => (
                          <option key={value} value={value}>
                            {getCrmDictionaryLabel(value)}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="crm-field crm-field--wide">
                      <span className="crm-field__label">Телефоны CIAN, по одному в строке</span>
                      <textarea className="crm-textarea" name="cian_owner_contacts" defaultValue={defaultCianPhones} />
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">VAT</span>
                      <select className="crm-select" name="cian_vat_type" defaultValue={item?.cian.vat_type ?? ""}>
                        <option value="">Не выбран</option>
                        {meta.cian.choice_fields.vat_type.map((value) => (
                          <option key={value} value={value}>
                            {getCrmDictionaryLabel(value)}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Тип гаража</span>
                      <select className="crm-select" name="cian_garage_type" defaultValue={item?.cian.garage_type ?? ""}>
                        <option value="">Не выбран</option>
                        {meta.cian.choice_fields.garage_type.map((value) => (
                          <option key={value} value={value}>
                            {getCrmDictionaryLabel(value)}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Тип бизнеса</span>
                      <select className="crm-select" name="cian_ready_business_type" defaultValue={item?.cian.ready_business_type ?? ""}>
                        <option value="">Не выбран</option>
                        {meta.cian.choice_fields.ready_business_type.map((value) => (
                          <option key={value} value={value}>
                            {getCrmDictionaryLabel(value)}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Назначение</span>
                      <select className="crm-select" name="cian_specialty" defaultValue={item?.cian.specialty ?? ""}>
                        <option value="">Не выбрано</option>
                        {meta.cian.choice_fields.specialty.map((value) => (
                          <option key={value} value={value}>
                            {getCrmDictionaryLabel(value)}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Площадь земли</span>
                      <input className="crm-input" name="cian_land_area" type="number" defaultValue={item?.cian.land_area ?? ""} />
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Единица земли</span>
                      <select className="crm-select" name="cian_land_area_unit" defaultValue={item?.cian.land_area_unit ?? ""}>
                        <option value="">Не выбрана</option>
                        {meta.cian.choice_fields.land_area_unit.map((value) => (
                          <option key={value} value={value}>
                            {getCrmDictionaryLabel(value)}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="crm-field">
                      <span className="crm-field__label">Площадь здания</span>
                      <input className="crm-input" name="cian_building_area" type="number" defaultValue={item?.cian.building_area ?? ""} />
                    </label>
                  </div>
                </Section>
              ) : (
                <div className="crm-note">CIAN недоступен при создании объекта.</div>
              )}
            </fieldset>

            {error ? <div className="crm-form__error">{error}</div> : null}
            {message ? <div className="crm-form__success">{message}</div> : null}

            <div className="crm-form-actions crm-form-actions--sticky">
              {canManageCurrentEstate ? (
                <button type="submit" className="crm-button" disabled={pending}>
                  {pending ? "Сохранение..." : mode === "create" ? "Создать объект" : "Сохранить объект"}
                </button>
              ) : null}
              <Link href={backHref} className="crm-button crm-button--ghost">
                Назад к списку
              </Link>
            </div>
          </form>
        </CrmPanel>

        {mode === "edit" && item ? (
          <CrmPanel>
            <CrmEstateAvitoPanel item={item} viewer={viewer} />

            <h2 className="crm-section-title">Быстрые действия</h2>
            <div className="crm-stack">
              {canManageCurrentEstate && !isArchivedItem ? (
                <>
                  <CrmActionButton
                    path={`/api/v1/crm/estates/${item.id}/actions/define-coordinates`}
                    successMessage="Координаты обновлены."
                  >
                    Обновить координаты
                  </CrmActionButton>
                  {!item.coordinates ? (
                    <p className="crm-note">Координаты не определены. Проверьте адрес и используйте кнопку «Обновить координаты».</p>
                  ) : null}
                </>
              ) : null}

              {!isArchivedItem ? (
                <Link href={getPublicSiteUrl(`/detail/${item.id}`)} className="crm-button crm-button--ghost">
                  Открыть публичную страницу
                </Link>
              ) : null}

              <button
                type="button"
                className="crm-button crm-button--ghost"
                onClick={() => {
                  void handlePresentationDownload();
                }}
                disabled={presentationPending}
              >
                {presentationPending ? "Готовим PDF..." : "Скачать PDF"}
              </button>

              {canManageCurrentEstate && !isArchivedItem ? (
                <button
                  type="button"
                  className="crm-button crm-button--secondary"
                  onClick={() => {
                    void handleDuplicate();
                  }}
                  disabled={duplicatePending}
                >
                  {duplicatePending ? "Дублируем..." : "Дублировать объект"}
                </button>
              ) : null}

              {canManageCurrentEstate && !isArchivedItem ? (
                <CrmActionButton
                  path={`/api/v1/crm/estates/${item.id}/actions/archive`}
                  className="crm-button--secondary"
                  refreshOnSuccess={false}
                  confirmText="Отправить объект в архив?"
                  successMessage="Объект перенесен в архив."
                  onSuccess={() => {
                    router.replace(backHref);
                  }}
                >
                  Отправить в архив
                </CrmActionButton>
              ) : null}

              {canManageCurrentEstate && isArchivedItem ? (
                <CrmActionButton
                  path={`/api/v1/crm/estates/${item.id}/actions/restore`}
                  className="crm-button--secondary"
                  refreshOnSuccess={false}
                  successMessage="Объект восстановлен."
                  onSuccess={() => {
                    router.replace(restoreTargetHref);
                  }}
                >
                  Восстановить объект
                </CrmActionButton>
              ) : null}

              {canManageCurrentEstate && !isArchivedItem ? (
                <CrmActionButton
                  path={`/api/v1/crm/estates/${item.id}`}
                  method="DELETE"
                  className="crm-button--danger"
                  refreshOnSuccess={false}
                  confirmText="Удалить объект?"
                  successMessage="Объект удален."
                  onSuccess={() => {
                    router.replace(backHref);
                  }}
                >
                  Удалить объект
                </CrmActionButton>
              ) : null}
            </div>

            <div className="crm-detail-card">
              <div>
                <strong>ID:</strong> {item.id}
              </div>
              <div>
                <strong>Координаты:</strong> {item.coordinates ?? "-"}
              </div>
              <div>
                <strong>Назначены:</strong>{" "}{item.assigned_users.length > 0 ? item.assigned_users.map((user) => getAssignableUserLabel(user)).join(", ") : "Не назначены"}
              </div>
              <div>
                <strong>Контакты:</strong>{" "}
                {hasEstateOwnerContacts(item)
                  ? item.owner_contacts?.map((contact) => `${contact.owner_phone} / ${contact.owner_name}`).join(", ") || "-"
                  : "Скрыты правилами доступа"}
              </div>
            </div>

            {!isArchivedItem ? (
              <CrmEstateMatches
                items={matchedClients}
                total={matchedClientsTotal}
                loading={matchedClientsLoading}
                error={matchedClientsError}
              />
            ) : null}
          </CrmPanel>
        ) : null}
      </div>
    </div>
  );
}
