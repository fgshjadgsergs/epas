"use client";

import { usePathname, useRouter } from "next/navigation";
import { startTransition, useEffect, useMemo, useRef, useState } from "react";
import { buildPathWithSearchParams, SearchParamsRecord } from "@/lib/public-query";

function getValue(searchParams: SearchParamsRecord, key: string): string {
  const value = searchParams[key];
  return Array.isArray(value) ? value[0] ?? "" : value ?? "";
}

type DraftFilterState = {
  search: string;
  metro_station: string;
  price_from: string;
  price_to: string;
  area_from: string;
  area_to: string;
};

type AppliedFilterState = {
  status: string;
  deal_type: string;
  region: string;
  district: string;
  active: string;
  archivedOnly: string;
  cian_included: string;
  limit: string;
};

function getInitialDrafts(searchParams: SearchParamsRecord): DraftFilterState {
  return {
    search: getValue(searchParams, "search"),
    metro_station: getValue(searchParams, "metro_station"),
    price_from: getValue(searchParams, "price_from"),
    price_to: getValue(searchParams, "price_to"),
    area_from: getValue(searchParams, "area_from"),
    area_to: getValue(searchParams, "area_to"),
  };
}

function getInitialAppliedFilters(
  searchParams: SearchParamsRecord,
  options: { defaultActive: string; archivedOnly: boolean },
): AppliedFilterState {
  return {
    status: getValue(searchParams, "status"),
    deal_type: getValue(searchParams, "deal_type"),
    region: getValue(searchParams, "region"),
    district: getValue(searchParams, "district"),
    active: getValue(searchParams, "active") || options.defaultActive,
    archivedOnly: options.archivedOnly ? "true" : "",
    cian_included: getValue(searchParams, "cian_included"),
    limit: getValue(searchParams, "limit") || "50",
  };
}

function createEmptyDrafts(): DraftFilterState {
  return {
    search: "",
    metro_station: "",
    price_from: "",
    price_to: "",
    area_from: "",
    area_to: "",
  };
}

function createEmptyAppliedFilters(defaultActive: string, archivedOnly: boolean): AppliedFilterState {
  return {
    status: "",
    deal_type: "",
    region: "",
    district: "",
    active: defaultActive,
    archivedOnly: archivedOnly ? "true" : "",
    cian_included: "",
    limit: "50",
  };
}

function hasDifference<T extends Record<string, string>>(left: T, right: T): boolean {
  return Object.keys(left).some((key) => {
    const typedKey = key as keyof T;
    return left[typedKey] !== right[typedKey];
  });
}

export function CrmEstateFilters({
  searchParams,
  dealTypes,
  regions,
  districts,
  archivedOnly = false,
  defaultActive = "true",
}: {
  searchParams: SearchParamsRecord;
  dealTypes: string[];
  regions: string[];
  districts: string[];
  archivedOnly?: boolean;
  defaultActive?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParamsKey = useMemo(() => JSON.stringify(searchParams), [searchParams]);
  const initialDrafts = useMemo(() => getInitialDrafts(searchParams), [searchParamsKey]);
  const initialAppliedFilters = useMemo(
    () => getInitialAppliedFilters(searchParams, { defaultActive, archivedOnly }),
    [archivedOnly, defaultActive, searchParamsKey],
  );
  const [drafts, setDrafts] = useState<DraftFilterState>(initialDrafts);
  const [appliedFilters, setAppliedFilters] = useState<AppliedFilterState>(initialAppliedFilters);
  const initialRenderRef = useRef(true);
  const draftsRef = useRef(initialDrafts);
  const appliedDraftsRef = useRef(initialDrafts);
  const appliedFiltersRef = useRef(initialAppliedFilters);

  useEffect(() => {
    draftsRef.current = drafts;
  }, [drafts]);

  useEffect(() => {
    appliedFiltersRef.current = appliedFilters;
  }, [appliedFilters]);

  useEffect(() => {
    if (!hasDifference(appliedFiltersRef.current, initialAppliedFilters)) {
      return;
    }

    setAppliedFilters(initialAppliedFilters);
    initialRenderRef.current = true;
  }, [initialAppliedFilters]);

  useEffect(() => {
    setDrafts((current) => {
      let changed = false;
      const next = { ...current };

      for (const key of Object.keys(initialDrafts) as Array<keyof DraftFilterState>) {
        const latestLocalValue = draftsRef.current[key];
        const lastAppliedValue = appliedDraftsRef.current[key];
        const incomingValue = initialDrafts[key];
        const hasPendingLocalValue = latestLocalValue !== lastAppliedValue;

        if (!hasPendingLocalValue || incomingValue === latestLocalValue) {
          if (next[key] !== incomingValue) {
            next[key] = incomingValue;
            changed = true;
          }
          appliedDraftsRef.current[key] = incomingValue;
        }
      }

      return changed ? next : current;
    });
  }, [initialDrafts]);

  const pushFilters = (nextAppliedFilters: AppliedFilterState, nextDrafts: DraftFilterState) => {
    appliedDraftsRef.current = { ...nextDrafts };
    startTransition(() => {
      router.replace(
        buildPathWithSearchParams(pathname, {}, {
          ...nextAppliedFilters,
          ...nextDrafts,
          skip: 0,
        }),
      );
    });
  };

  useEffect(() => {
    if (initialRenderRef.current) {
      initialRenderRef.current = false;
      return;
    }

    const timeoutId = window.setTimeout(() => {
      pushFilters(appliedFiltersRef.current, draftsRef.current);
    }, 200);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [appliedFilters, drafts, pathname, router]);

  const replaceAppliedFilter = (patch: Partial<AppliedFilterState>) => {
    setAppliedFilters((current) => ({ ...current, ...patch }));
  };

  const replaceDraft = (patch: Partial<DraftFilterState>) => {
    setDrafts((current) => ({ ...current, ...patch }));
  };

  return (
    <form
      className="crm-filters"
      onSubmit={(event) => {
        event.preventDefault();
        pushFilters(appliedFiltersRef.current, draftsRef.current);
      }}
    >
      <label className="crm-field crm-field--search">
        <span className="crm-field__label">Поиск</span>
        <input className="crm-input" type="search" value={drafts.search} onChange={(event) => replaceDraft({ search: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Статус</span>
        <select className="crm-select" value={appliedFilters.status} onChange={(event) => replaceAppliedFilter({ status: event.target.value })}>
          <option value="">Все</option>
          <option value="new">Новый</option>
          <option value="in_progress">В работе</option>
          <option value="showing">Показ</option>
          <option value="negotiation">Переговоры</option>
          <option value="closed">Закрыт</option>
          <option value="rejected">Отказ</option>
        </select>
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Сделка</span>
        <select className="crm-select" value={appliedFilters.deal_type} onChange={(event) => replaceAppliedFilter({ deal_type: event.target.value })}>
          <option value="">Все</option>
          {dealTypes.map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        </select>
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Регион</span>
        <select className="crm-select" value={appliedFilters.region} onChange={(event) => replaceAppliedFilter({ region: event.target.value })}>
          <option value="">Все</option>
          {regions.map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        </select>
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Округ</span>
        <select className="crm-select" value={appliedFilters.district} onChange={(event) => replaceAppliedFilter({ district: event.target.value })}>
          <option value="">Все</option>
          {districts.map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        </select>
      </label>

      <label className="crm-field crm-field--metro">
        <span className="crm-field__label">Метро</span>
        <input className="crm-input" value={drafts.metro_station} onChange={(event) => replaceDraft({ metro_station: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Цена от</span>
        <input className="crm-input" type="number" value={drafts.price_from} onChange={(event) => replaceDraft({ price_from: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Цена до</span>
        <input className="crm-input" type="number" value={drafts.price_to} onChange={(event) => replaceDraft({ price_to: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Площадь от</span>
        <input className="crm-input" type="number" value={drafts.area_from} onChange={(event) => replaceDraft({ area_from: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Площадь до</span>
        <input className="crm-input" type="number" value={drafts.area_to} onChange={(event) => replaceDraft({ area_to: event.target.value })} />
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Публикация</span>
        <select className="crm-select" value={appliedFilters.active} onChange={(event) => replaceAppliedFilter({ active: event.target.value })}>
          <option value="">Все</option>
          <option value="true">Активные</option>
          <option value="false">Неактивные</option>
        </select>
      </label>

      <label className="crm-field">
        <span className="crm-field__label">CIAN</span>
        <select className="crm-select" value={appliedFilters.cian_included} onChange={(event) => replaceAppliedFilter({ cian_included: event.target.value })}>
          <option value="">Все</option>
          <option value="true">Выгрузка</option>
          <option value="false">Без выгрузки</option>
        </select>
      </label>

      <label className="crm-field">
        <span className="crm-field__label">Лимит</span>
        <select className="crm-select" value={appliedFilters.limit} onChange={(event) => replaceAppliedFilter({ limit: event.target.value })}>
          {[10, 20, 50, 100].map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        </select>
      </label>

      <div className="crm-filters__actions">
        <button type="submit" className="crm-button crm-button--xs">
          Обновить
        </button>
        <button
          type="button"
          className="crm-button crm-button--ghost crm-button--xs"
          onClick={() => {
            setAppliedFilters(createEmptyAppliedFilters(defaultActive, archivedOnly));
            setDrafts(createEmptyDrafts());
          }}
        >
          Сбросить
        </button>
      </div>
    </form>
  );
}
