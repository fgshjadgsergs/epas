"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CrmActionButton } from "@/components/crm/shared/crm-action-button";
import {
  approveEstateForAvito,
  AvitoFeedData,
  AvitoValidationIssue,
  AvitoValidationResult,
  CrmApiError,
  CrmEstateAvitoBlock,
  CrmEstateDetail,
  CrmUser,
  getEstateAvitoValidation,
  requestEstateAvitoChanges,
  submitEstateToAvitoReview,
  updateEstateAvitoFeedSettings,
} from "@/lib/crm-api";
import {
  formatAvitoDate,
  getAvitoModerationStatusLabel,
  getAvitoPublicationStatusLabel,
  normalizeAvitoIssues,
} from "@/lib/crm-avito";
import { canManageEstate, getCrmRole } from "@/lib/crm-role";

const OBJECT_TYPES = [
  "Офисное помещение",
  "Помещение свободного назначения",
  "Торговое помещение",
  "Складское помещение",
  "Производственное помещение",
  "Помещение общественного питания",
  "Гостиница",
  "Автосервис",
  "Здание",
];
const PROPERTY_RIGHTS = ["Собственник", "Посредник"];
const OFFICE_TYPES = ["Помещение под офис", "Только юридический адрес"];
const ENTRANCES = ["С улицы", "Со двора"];
const LAYOUTS = ["Кабинетная", "Открытая"];
const DECORATIONS = ["Без отделки", "Чистовая", "Офисная"];
const BUILDING_TYPES = ["Бизнес-центр", "Торговый центр", "Административное здание", "Жилой дом", "Другой"];
const PARKING_TYPES = ["Нет", "На улице", "В здании"];
const RENTAL_TYPES = ["Прямая", "Субаренда"];
const TRANSACTION_TYPES = ["Продажа", "Переуступка права аренды"];
const AVITO_TITLE_MAX_LENGTH = 100;

function AvitoSelect({
  label,
  value,
  options,
  disabled,
  onChange,
}: {
  label: string;
  value?: string;
  options: string[];
  disabled: boolean;
  onChange: (value: string) => void;
}) {
  return (
    <label className="crm-field">
      <span className="crm-field__label">{label}</span>
      <select className="crm-select" value={value ?? ""} disabled={disabled} onChange={(event) => onChange(event.target.value)}>
        <option value="">Не выбрано</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}

function getRequestErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof CrmApiError && error.payload && typeof error.payload === "object") {
    const payload = error.payload as { message?: string; error?: string };
    return payload.message ?? payload.error ?? fallback;
  }

  return fallback;
}

function AvitoIssuesList({ issues }: { issues: AvitoValidationIssue[] }) {
  if (issues.length === 0) {
    return <div className="crm-form__success">Объект готов к отправке на внутреннюю модерацию.</div>;
  }

  return (
    <div className="crm-stack crm-stack--compact">
      {issues.map((issue) => (
        <div
          key={`${issue.code}-${issue.field}-${issue.message}`}
          className={issue.severity === "warning" ? "crm-note" : "crm-form__error crm-form__error--compact"}
        >
          <strong>{issue.severity === "warning" ? "Предупреждение" : "Ошибка"}:</strong> {issue.field} - {issue.message}
        </div>
      ))}
    </div>
  );
}

export function CrmEstateAvitoPanel({
  item,
  viewer,
}: {
  item: CrmEstateDetail;
  viewer: CrmUser;
}) {
  const router = useRouter();
  const [avito, setAvito] = useState<CrmEstateAvitoBlock>(item.avito);
  const [avitoTitleInput, setAvitoTitleInput] = useState(item.avito.avitoTitle ?? item.title);
  const [feedData, setFeedData] = useState<AvitoFeedData>(item.avito.feed_data ?? {});
  const [validation, setValidation] = useState<AvitoValidationResult | null>(null);
  const [pendingAction, setPendingAction] = useState<"settings" | "validate" | "submit" | "approve" | "changes" | null>(null);
  const [changesComment, setChangesComment] = useState("");
  const [showChangesForm, setShowChangesForm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const role = getCrmRole(viewer);
  const canManageCurrentEstate = canManageEstate(viewer, item);
  const canSubmitRole = role === "OWNER" || role === "ADMIN" || role === "ROP" || role === "BROKER";
  const canSubmit =
    canSubmitRole &&
    canManageCurrentEstate &&
    (avito.moderation_status === "DRAFT" || avito.moderation_status === "CHANGES_REQUESTED");
  const canModerate = (role === "OWNER" || role === "ADMIN" || role === "ROP") && avito.moderation_status === "PENDING_REVIEW";
  const canRestoreToFeed =
    (role === "OWNER" || role === "ADMIN") && canManageCurrentEstate && avito.moderation_status === "APPROVED" && !avito.included;
  const lastIssues = validation?.errors ?? normalizeAvitoIssues(avito.last_error);
  const normalizedDealType = item.deal_type.toLowerCase();
  const isRentBusiness = normalizedDealType.includes("арендный бизнес") || normalizedDealType.includes("rental business");
  const isRent = !isRentBusiness && (normalizedDealType.includes("аренд") || normalizedDealType.includes("rent"));
  const isOffice = feedData.object_type === "Офисное помещение";

  async function runValidation(): Promise<void> {
    setPendingAction("validate");
    setError(null);
    setMessage(null);

    try {
      const result = await getEstateAvitoValidation(item.id);
      setValidation(result);
      setMessage(result.ok ? "Проверка пройдена." : "Проверка завершена: есть ошибки.");
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось проверить объект для Авито."));
    } finally {
      setPendingAction(null);
    }
  }

  async function saveFeedSettings(): Promise<void> {
    setPendingAction("settings");
    setError(null);
    setMessage(null);

    try {
      const normalizedAvitoTitle = avitoTitleInput.trim();
      const fallbackTitle = item.title.trim();
      const avitoTitle = !normalizedAvitoTitle || normalizedAvitoTitle === fallbackTitle ? null : normalizedAvitoTitle;
      const result = await updateEstateAvitoFeedSettings(item.id, { ...feedData, avitoTitle });
      setAvito(result.item.avito);
      setAvitoTitleInput(result.item.avito.avitoTitle ?? item.title);
      setFeedData(result.item.avito.feed_data ?? {});
      if (result.validation) {
        setValidation(result.validation);
      }
      setMessage(result.validation?.ok ? "Параметры Авито сохранены, проверка пройдена." : "Параметры Авито сохранены: заполните отмеченные ошибки.");
      router.refresh();
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось сохранить параметры Авито."));
    } finally {
      setPendingAction(null);
    }
  }

  async function submitReview(): Promise<void> {
    setPendingAction("submit");
    setError(null);
    setMessage(null);

    try {
      const result = await submitEstateToAvitoReview(item.id);
      setAvito(result.item.avito);
      setMessage("Объект отправлен на внутреннюю модерацию.");
      router.refresh();
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось отправить объект на модерацию."));
    } finally {
      setPendingAction(null);
    }
  }

  async function approve(): Promise<void> {
    setPendingAction("approve");
    setError(null);
    setMessage(null);

    try {
      const result = await approveEstateForAvito(item.id);
      setAvito(result.item.avito);
      if (result.validation) {
        setValidation(result.validation);
      }
      setMessage(
        result.validation?.ok
          ? "Объект одобрен и готов к выгрузке в Авито."
          : "Объект одобрен внутренне, но пока не готов к Авито.",
      );
      router.refresh();
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось одобрить объект."));
    } finally {
      setPendingAction(null);
    }
  }

  async function requestChanges(): Promise<void> {
    const comment = changesComment.trim();
    if (!comment) {
      setError("Комментарий обязателен.");
      return;
    }

    setPendingAction("changes");
    setError(null);
    setMessage(null);

    try {
      const result = await requestEstateAvitoChanges(item.id, comment);
      setAvito(result.item.avito);
      setShowChangesForm(false);
      setChangesComment("");
      setMessage("Объект возвращён на доработку.");
      router.refresh();
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось вернуть объект на доработку."));
    } finally {
      setPendingAction(null);
    }
  }

  return (
    <div className="crm-stack">
      <h2 className="crm-section-title">Авито</h2>

      <div className="crm-detail-card">
        <div>
          <strong>Внутренняя модерация:</strong> {getAvitoModerationStatusLabel(avito.moderation_status)}
        </div>
        <div>
          <strong>Статус публикации:</strong> {getAvitoPublicationStatusLabel(avito.publication_status)}
        </div>
        <div>
          <strong>Включён в выгрузку:</strong> {avito.included ? "Да" : "Нет"}
        </div>
        <div>
          <strong>Отправлен на проверку:</strong> {formatAvitoDate(avito.review_requested_at)}
        </div>
        <div>
          <strong>Одобрен:</strong> {formatAvitoDate(avito.approved_at)}
        </div>
        <div>
          <strong>Кто одобрил:</strong> {avito.approved_by_id ?? "-"}
        </div>
        <div>
          <strong>Комментарий модератора:</strong> {avito.review_comment || "-"}
        </div>
        <div>
          <strong>Последняя валидация:</strong> {formatAvitoDate(avito.last_validated_at)}
        </div>
        <div>
          <strong>Последняя синхронизация:</strong> {formatAvitoDate(avito.last_synced_at)}
        </div>
        <div>
          <strong>Avito ID:</strong> {avito.avito_id ?? "-"}
        </div>
      </div>

      <form
        className="crm-stack crm-stack--compact"
        onSubmit={(event) => {
          event.preventDefault();
          void saveFeedSettings();
        }}
      >
        <h3 className="crm-section-title">Параметры XML-фида</h3>
        <label className="crm-field">
          <span className="crm-field__label">Название объявления Авито</span>
          <input
            className="crm-input"
            value={avitoTitleInput}
            maxLength={AVITO_TITLE_MAX_LENGTH}
            disabled={!canManageCurrentEstate || pendingAction !== null}
            onChange={(event) => setAvitoTitleInput(event.target.value)}
          />
          <span className="crm-field__hint">
            Если оставить поле пустым, будет использовано название объекта из CRM.
          </span>
        </label>
        {canManageCurrentEstate ? (
          <div className="crm-form-actions">
            <button
              type="button"
              className="crm-button crm-button--ghost"
              disabled={pendingAction !== null}
              onClick={() => setAvitoTitleInput(item.title)}
            >
              Вернуть название объекта
            </button>
          </div>
        ) : null}
        <div className="crm-form-grid">
          <AvitoSelect
            label="Вид объекта"
            value={feedData.object_type}
            options={OBJECT_TYPES}
            disabled={!canManageCurrentEstate || pendingAction !== null}
            onChange={(value) => setFeedData((current) => ({ ...current, object_type: value || undefined }))}
          />
          <AvitoSelect
            label="Право собственности"
            value={feedData.property_rights}
            options={PROPERTY_RIGHTS}
            disabled={!canManageCurrentEstate || pendingAction !== null}
            onChange={(value) => setFeedData((current) => ({ ...current, property_rights: value || undefined }))}
          />

          {isOffice && isRent ? (
            <AvitoSelect
              label="Что сдаётся"
              value={feedData.office_type}
              options={OFFICE_TYPES}
              disabled={!canManageCurrentEstate || pendingAction !== null}
              onChange={(value) => setFeedData((current) => ({ ...current, office_type: value || undefined }))}
            />
          ) : null}

          {!isOffice && feedData.object_type ? (
            <AvitoSelect
              label="Вход"
              value={feedData.entrance}
              options={ENTRANCES}
              disabled={!canManageCurrentEstate || pendingAction !== null}
              onChange={(value) => setFeedData((current) => ({ ...current, entrance: value || undefined }))}
            />
          ) : null}

          <AvitoSelect
            label="Отделка"
            value={feedData.decoration}
            options={DECORATIONS}
            disabled={!canManageCurrentEstate || pendingAction !== null}
            onChange={(value) => setFeedData((current) => ({ ...current, decoration: value || undefined }))}
          />
          <AvitoSelect
            label="Тип здания"
            value={feedData.building_type}
            options={BUILDING_TYPES}
            disabled={!canManageCurrentEstate || pendingAction !== null}
            onChange={(value) => setFeedData((current) => ({ ...current, building_type: value || undefined }))}
          />
          <AvitoSelect
            label="Парковка"
            value={feedData.parking_type}
            options={PARKING_TYPES}
            disabled={!canManageCurrentEstate || pendingAction !== null}
            onChange={(value) => setFeedData((current) => ({ ...current, parking_type: value || undefined }))}
          />

          {isRent ? (
            <AvitoSelect
              label="Тип аренды"
              value={feedData.rental_type}
              options={RENTAL_TYPES}
              disabled={!canManageCurrentEstate || pendingAction !== null}
              onChange={(value) => setFeedData((current) => ({ ...current, rental_type: value || undefined }))}
            />
          ) : (
            <AvitoSelect
              label="Тип сделки"
              value={feedData.transaction_type}
              options={TRANSACTION_TYPES}
              disabled={!canManageCurrentEstate || pendingAction !== null}
              onChange={(value) => setFeedData((current) => ({ ...current, transaction_type: value || undefined }))}
            />
          )}
        </div>

        {isOffice ? (
          <fieldset className="crm-fieldset" disabled={!canManageCurrentEstate || pendingAction !== null}>
            <legend className="crm-field__label">Планировка</legend>
            <div className="crm-form-actions">
              {LAYOUTS.map((layout) => (
                <label key={layout} className="crm-checkbox">
                  <input
                    type="checkbox"
                    checked={feedData.layout?.includes(layout) ?? false}
                    onChange={(event) => {
                      setFeedData((current) => {
                        const values = new Set(current.layout ?? []);
                        if (event.target.checked) {
                          values.add(layout);
                        } else {
                          values.delete(layout);
                        }
                        return { ...current, layout: [...values] };
                      });
                    }}
                  />
                  <span>{layout}</span>
                </label>
              ))}
            </div>
          </fieldset>
        ) : null}

        <div className="crm-note">Площадь, цена, этаж, высота потолков и мощность берутся из основной карточки объекта.</div>
        {canManageCurrentEstate ? (
          <button type="submit" className="crm-button crm-button--secondary" disabled={pendingAction !== null}>
            {pendingAction === "settings" ? "Сохраняем параметры..." : "Сохранить параметры Авито"}
          </button>
        ) : null}
      </form>

      {avito.moderation_status === "PENDING_REVIEW" && role === "BROKER" ? (
        <div className="crm-note">Объект находится на проверке.</div>
      ) : null}
      {avito.moderation_status === "APPROVED" && role === "BROKER" ? (
        <div className="crm-form__success">Объект одобрен для выгрузки в Авито.</div>
      ) : null}
      {avito.moderation_status === "CHANGES_REQUESTED" && avito.review_comment ? (
        <div className="crm-note">Комментарий модератора: {avito.review_comment}</div>
      ) : null}

      <div className="crm-form-actions">
        <button
          type="button"
          className="crm-button crm-button--ghost"
          disabled={pendingAction !== null}
          onClick={() => {
            void runValidation();
          }}
        >
          {pendingAction === "validate" ? "Проверяем объект..." : "Проверить готовность для Авито"}
        </button>

        {canSubmit ? (
          <button
            type="button"
            className="crm-button crm-button--secondary"
            disabled={pendingAction !== null}
            onClick={() => {
              void submitReview();
            }}
          >
            {pendingAction === "submit"
              ? "Отправляем на модерацию..."
              : avito.moderation_status === "CHANGES_REQUESTED"
                ? "Отправить повторно"
                : "Отправить на модерацию"}
          </button>
        ) : null}

        {canModerate ? (
          <>
            <button
              type="button"
              className="crm-button crm-button--secondary"
              disabled={pendingAction !== null}
              onClick={() => {
                void approve();
              }}
            >
              {pendingAction === "approve" ? "Одобряем..." : "Одобрить"}
            </button>
            <button
              type="button"
              className="crm-button crm-button--ghost"
              disabled={pendingAction !== null}
              onClick={() => {
                setShowChangesForm((current) => !current);
              }}
            >
              Вернуть на доработку
            </button>
          </>
        ) : null}

        {canRestoreToFeed ? (
          <CrmActionButton
            path={`/api/v1/crm/estates/${item.id}/avito/restore-to-feed`}
            className="crm-button--secondary"
            successMessage="Объект возвращён в выгрузку Авито."
          >
            Вернуть в выгрузку
          </CrmActionButton>
        ) : null}
      </div>

      {showChangesForm ? (
        <div className="crm-stack crm-stack--compact">
          <label className="crm-field">
            <span className="crm-field__label">Комментарий для брокера</span>
            <textarea
              className="crm-textarea"
              value={changesComment}
              onChange={(event) => {
                setChangesComment(event.target.value);
              }}
            />
          </label>
          <button
            type="button"
            className="crm-button crm-button--danger"
            disabled={pendingAction !== null}
            onClick={() => {
              void requestChanges();
            }}
          >
            {pendingAction === "changes" ? "Возвращаем на доработку..." : "Подтвердить доработку"}
          </button>
        </div>
      ) : null}

      {lastIssues.length > 0 || validation ? (
        <div className="crm-stack crm-stack--compact">
          <h3 className="crm-section-title">Проверка готовности</h3>
          <AvitoIssuesList issues={lastIssues} />
        </div>
      ) : null}

      {error ? <div className="crm-form__error">{error}</div> : null}
      {message ? <div className="crm-form__success">{message}</div> : null}
    </div>
  );
}

