"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { KeyboardEvent, ReactNode, useState } from "react";
import { CrmActionButton } from "@/components/crm/shared/crm-action-button";
import { CrmPipelineStatusSelect } from "@/components/crm/shared/crm-pipeline-status-select";
import type { CrmEstateListItem, CrmUser } from "@/lib/crm-api";
import { getAvitoListStatusPresentation } from "@/lib/crm-avito";
import type { AvitoListStatusVariant } from "@/lib/crm-avito";
import { getCrmEstateDealTypePresentation } from "@/lib/crm-estate-display";
import type { CrmEstateDealTypeVariant } from "@/lib/crm-estate-display";
import { formatCrmCurrency } from "@/lib/crm-format";
import { getCrmPipelineClassName } from "@/lib/crm-pipeline";
import { canAccessCrmQueues, canAccessCrmUsers, canManageCrmClient, canManageEstate, isCrmAdminLike } from "@/lib/crm-role";
import { crmRoutes, getPublicSiteUrl } from "@/lib/crm-routes";
import styles from "./crm-estate-table.module.css";

const DEAL_ROW_CLASSES: Record<CrmEstateDealTypeVariant, string> = {
  rent: styles.rowRent,
  sale: styles.rowSale,
  "rent-business": styles.rowRentBusiness,
  other: "",
};

const DEAL_BADGE_CLASSES: Record<CrmEstateDealTypeVariant, string> = {
  rent: styles.dealRent,
  sale: styles.dealSale,
  "rent-business": styles.dealRentBusiness,
  other: styles.dealOther,
};

const AVITO_BADGE_CLASSES: Record<AvitoListStatusVariant, string> = {
  neutral: styles.avitoNeutral,
  review: styles.avitoReview,
  ready: styles.avitoReady,
  progress: styles.avitoProgress,
  published: styles.avitoPublished,
  error: styles.avitoError,
};

function getDisplayName(user: CrmUser): string {
  const fullName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return fullName || user.email;
}

function normalizeCrmImageUrl(url: string | null | undefined): string {
  const value = (url ?? "").trim();
  if (!value) {
    return "";
  }

  try {
    const parsedUrl = new URL(value);
    if (parsedUrl.pathname.startsWith("/storage/")) {
      return `${parsedUrl.pathname}${parsedUrl.search}${parsedUrl.hash}`;
    }
  } catch {
    // Relative URL, normalize below.
  }

  if (/^(https?:|data:|blob:)/i.test(value)) {
    return value;
  }

  return value.startsWith("/") ? value : `/${value}`;
}

function CrmEstateThumbnail({ estateId, image }: { estateId: number; image: CrmEstateListItem["images"][number] | null }) {
  const [failed, setFailed] = useState(false);
  const src = normalizeCrmImageUrl(image?.thumbnail_url || image?.public_url || image?.url);

  console.log({
    estateId,
    imageSrc: src,
    thumbnailUrl: image?.thumbnail_url ?? null,
    publicUrl: image?.public_url ?? null,
    url: image?.url ?? null,
  });

  if (!src || failed) {
    return <span className="crm-table__thumb-placeholder">Нет фото</span>;
  }

  return (
    <Image
      src={src}
      alt=""
      fill
      sizes="48px"
      unoptimized
      onError={() => {
        console.warn({ estateId, imageSrc: src, imageLoadError: true });
        setFailed(true);
      }}
    />
  );
}

export function CrmEstateTable({
  items,
  viewer,
  mode,
  archivedOnly = false,
}: {
  items: CrmEstateListItem[];
  viewer: CrmUser;
  mode: "default" | "moderation" | "upload";
  archivedOnly?: boolean;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const showAssigneeColumn = canAccessCrmUsers(viewer);
  const canUseQueues = canAccessCrmQueues(viewer);
  const currentListHref = (() => {
    const query = searchParams.toString();
    return query ? `${pathname}?${query}` : pathname;
  })();
  const activeListHref = pathname === crmRoutes.myEstatesArchive ? crmRoutes.myEstates : crmRoutes.estates;
  const archivedReturnTo = pathname === crmRoutes.myEstatesArchive ? "my-archive" : "archive";

  const getEstateHref = (id: number) =>
    archivedOnly ? `${crmRoutes.estate(id)}?archived=1&returnTo=${archivedReturnTo}` : crmRoutes.estate(id);

  const openEstate = (id: number) => {
    router.push(getEstateHref(id));
  };

  const handleRowKeyDown = (event: KeyboardEvent<HTMLTableRowElement>, id: number) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openEstate(id);
    }
  };

  const getPublicationLabel = (item: CrmEstateListItem) => {
    return item.active ? "Активен" : "Неактивен";
  };

  return (
    <div className="crm-table-wrap">
      <table className="crm-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Объект</th>
            <th>Цена</th>
            <th>Площадь</th>
            <th>Авито</th>
            <th>Статус</th>
            {showAssigneeColumn ? <th>Назначены</th> : null}
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const canManageItem = canManageEstate(viewer, item);
            const primaryImage = item.images[0] ?? null;
            const dealType = getCrmEstateDealTypePresentation(item.deal_type);
            const avitoStatus = getAvitoListStatusPresentation(item.avito);
            const actions: ReactNode[] = archivedOnly
              ? [
                  <Link key="open-archived" href={getEstateHref(item.id)} className="crm-button crm-button--ghost crm-button--xs">
                    {canManageItem ? "Ред." : "Открыть"}
                  </Link>,
                ]
              : [
                  <Link key="open" href={crmRoutes.estate(item.id)} className="crm-button crm-button--ghost crm-button--xs">
                    {canManageItem ? "Ред." : "Открыть"}
                  </Link>,
                  <Link
                    key="public"
                    href={getPublicSiteUrl(`/detail/${item.id}`)}
                    className="crm-button crm-button--ghost crm-button--xs"
                    target="_blank"
                  >
                    Public
                  </Link>,
                ];

            if (!archivedOnly && isCrmAdminLike(viewer) && canManageItem && mode === "default") {
              actions.push(
                <CrmActionButton
                  key="coords"
                  path={`/api/v1/crm/estates/${item.id}/actions/define-coordinates`}
                  className="crm-button--secondary crm-button--xs"
                  successMessage="Координаты обновлены."
                >
                  Коорд.
                </CrmActionButton>,
              );
            }

            if (canUseQueues && mode === "moderation") {
              actions.push(
                <CrmActionButton
                  key="moderation-confirm"
                  path="/api/v1/crm/cian/moderation/confirm"
                  body={{ estate_ids: [item.id] }}
                  className="crm-button--secondary crm-button--xs"
                  successMessage="Объект переведен в выгрузку."
                >
                  В выгрузку
                </CrmActionButton>,
              );
              actions.push(
                <CrmActionButton
                  key="moderation-remove"
                  path="/api/v1/crm/cian/moderation/remove"
                  body={{ estate_ids: [item.id] }}
                  className="crm-button--danger crm-button--xs"
                  successMessage="Объект убран из модерации."
                >
                  Снять
                </CrmActionButton>,
              );
            }

            if (canUseQueues && mode === "upload") {
              actions.push(
                <CrmActionButton
                  key="upload-remove"
                  path="/api/v1/crm/cian/upload/remove"
                  body={{ estate_ids: [item.id] }}
                  className="crm-button--danger crm-button--xs"
                  successMessage="Объект убран из выгрузки."
                >
                  Снять
                </CrmActionButton>,
              );
            }

            if (archivedOnly && canManageItem) {
              actions.push(
                <CrmActionButton
                  key="restore"
                  path={`/api/v1/crm/estates/${item.id}/actions/restore`}
                  className="crm-button--secondary crm-button--xs"
                  refreshOnSuccess={false}
                  onSuccess={() => {
                    router.replace(activeListHref);
                  }}
                  successMessage="Объект восстановлен."
                >
                  Восстановить
                </CrmActionButton>,
              );
            }

            if (!archivedOnly && mode === "default" && canManageItem) {
              actions.push(
                <CrmActionButton
                  key="archive"
                  path={`/api/v1/crm/estates/${item.id}/actions/archive`}
                  className="crm-button--secondary crm-button--xs"
                  refreshOnSuccess={false}
                  onSuccess={() => {
                    router.replace(currentListHref);
                  }}
                  confirmText="Переместить объект в архив?"
                  successMessage="Объект перенесен в архив."
                >
                  В архив
                </CrmActionButton>,
              );
              actions.push(
                <CrmActionButton
                  key="toggle-active"
                  path={`/api/v1/crm/estates/${item.id}/actions/quick-update`}
                  body={{ active: !item.active }}
                  className="crm-button--secondary crm-button--xs"
                  successMessage={item.active ? "Объект снят с публикации." : "Объект опубликован."}
                >
                  {item.active ? "Снять с публикации" : "Опубликовать"}
                </CrmActionButton>,
              );
              actions.push(
                <CrmActionButton
                  key="toggle-priority"
                  path={`/api/v1/crm/estates/${item.id}/actions/quick-update`}
                  body={{ priority: !item.priority }}
                  className="crm-button--secondary crm-button--xs"
                  successMessage={item.priority ? "Приоритет снят." : "Приоритет включен."}
                >
                  {item.priority ? "Приор.-" : "Приор.+"}
                </CrmActionButton>,
              );
              actions.push(
                <CrmActionButton
                  key="delete"
                  path={`/api/v1/crm/estates/${item.id}`}
                  method="DELETE"
                  className="crm-button--danger crm-button--xs"
                  confirmText="Удалить объект?"
                  successMessage="Объект удален."
                >
                  Удалить
                </CrmActionButton>,
              );
            }

            return (
              <tr key={item.id} className={DEAL_ROW_CLASSES[dealType.variant]} tabIndex={0} onClick={() => openEstate(item.id)} onKeyDown={(event) => handleRowKeyDown(event, item.id)}>
                <td>{item.id}</td>
                <td className="crm-table__cell-estate">
                  <div className="crm-table__estate-cell">
                    <div className="crm-table__thumb">
                      {primaryImage ? (
                        <CrmEstateThumbnail estateId={item.id} image={primaryImage} />
                      ) : (
                        <span className="crm-table__thumb-placeholder">Нет фото</span>
                      )}
                    </div>
                    <div className="crm-table__estate-content">
                      <div className="crm-table__title">{item.title}</div>
                      <span className={`${styles.dealBadge} ${DEAL_BADGE_CLASSES[dealType.variant]}`}>{dealType.label}</span>
                    </div>
                  </div>
                </td>
                <td>
                  <div className="crm-table__price">{formatCrmCurrency(item.price)}</div>
                </td>
                <td>{item.area ?? "-"}</td>
                <td>
                  <span className={`${styles.avitoBadge} ${AVITO_BADGE_CLASSES[avitoStatus.variant]}`} title={avitoStatus.title}>
                    {avitoStatus.label}
                  </span>
                </td>
                <td>
                  <div className="crm-pipeline-list">
                    {item.client_links && item.client_links.length > 0 ? (
                      item.client_links.map((link) => (
                        <div key={link.link_id} className="crm-pipeline-row" onClick={(event) => event.stopPropagation()}>
                          <span className="crm-pipeline-row__label" title={link.client_name}>
                            {link.client_name}
                          </span>
                          <CrmPipelineStatusSelect
                            linkId={link.link_id}
                            status={link.status}
                            disabled={
                              archivedOnly ||
                              !canManageCrmClient(viewer, {
                                id: link.client_broker_id,
                                rop_id: link.client_broker_rop_id ?? null,
                              })
                            }
                          />
                        </div>
                      ))
                    ) : (
                      <span className="crm-table__meta">Без клиента</span>
                    )}
                  </div>

                  <div className="crm-table__status-stack">
                    {archivedOnly ? (
                      <span className="crm-table__status crm-table__status--inactive">В архиве</span>
                    ) : (
                      <span className={`crm-table__status ${item.active ? "crm-table__status--active" : "crm-table__status--inactive"}`}>
                        {getPublicationLabel(item)}
                      </span>
                    )}
                    {item.priority ? <span className="crm-table__status crm-table__status--priority">Приоритет</span> : null}
                    {item.is_private_sale ? <span className={`crm-pipeline-badge ${getCrmPipelineClassName("closed")}`}>Закрытая продажа</span> : null}
                  </div>
                </td>
                {showAssigneeColumn ? <td>{item.assigned_users.length > 0 ? item.assigned_users.map((user) => getDisplayName(user)).join(", ") : "—"}</td> : null}
                <td className="crm-table__cell-actions" onClick={(event) => event.stopPropagation()}>
                  <div className="crm-table__actions">
                    {actions.length > 0 ? actions : <span className="crm-table__meta">Нет действий</span>}
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
