"use client";

import Image from "next/image";
import Link from "next/link";
import { CrmActionButton } from "@/components/crm/shared/crm-action-button";
import { AvitoFeedListItem } from "@/lib/crm-api";
import { getAvitoPublicationStatusLabel } from "@/lib/crm-avito";
import { formatCrmCurrency } from "@/lib/crm-format";
import { crmRoutes } from "@/lib/crm-routes";

function getDisplayName(user: AvitoFeedListItem["broker"]): string {
  if (!user) {
    return "-";
  }

  const fullName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return fullName || user.email;
}

function normalizeImageUrl(url: string | null | undefined): string {
  const value = (url ?? "").trim();
  if (!value) {
    return "";
  }

  try {
    const parsedUrl = new URL(value);
    if (parsedUrl.pathname.startsWith("/storage/")) {
      return `${parsedUrl.pathname}${parsedUrl.search}${parsedUrl.hash}`;
    }
  } catch {
    // Relative URL, normalize below.
  }

  if (/^(https?:|data:|blob:)/i.test(value)) {
    return value;
  }

  return value.startsWith("/") ? value : `/${value}`;
}

function formatDate(value: string | null): string {
  if (!value) {
    return "-";
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : new Intl.DateTimeFormat("ru-RU", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }).format(date);
}

export function CrmAvitoFeedTable({ items }: { items: AvitoFeedListItem[] }) {
  return (
    <div className="crm-table-wrap">
      <table className="crm-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Объект</th>
            <th>Цена</th>
            <th>Площадь</th>
            <th>Брокер</th>
            <th>Авито</th>
            <th>Действия</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const imageSrc = normalizeImageUrl(item.main_image?.public_url || item.main_image?.url);

            return (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td className="crm-table__cell-estate">
                  <div className="crm-table__estate-cell">
                    <div className="crm-table__thumb">
                      {imageSrc ? (
                        <Image src={imageSrc} alt="" fill sizes="48px" unoptimized />
                      ) : (
                        <span className="crm-table__thumb-placeholder">Нет фото</span>
                      )}
                    </div>
                    <div className="crm-table__estate-content">
                      <Link href={crmRoutes.estate(item.id)} prefetch={false} className="crm-table__title">
                        {item.title}
                      </Link>
                      <div className="crm-table__meta">
                        {[item.deal_type, item.estate_type, item.avito.external_id ? `Avito ID: ${item.avito.external_id}` : null]
                          .filter(Boolean)
                          .join(" · ")}
                      </div>
                    </div>
                  </div>
                </td>
                <td>{item.price === null ? "-" : formatCrmCurrency(item.price)}</td>
                <td>{item.area ?? "-"}</td>
                <td>{getDisplayName(item.broker)}</td>
                <td>
                  <div className="crm-table__status-stack">
                    <span className="crm-table__status crm-table__status--priority">
                      {getAvitoPublicationStatusLabel(item.avito.publication_status)}
                    </span>
                    <span className="crm-table__meta">Одобрен: {formatDate(item.avito.approved_at)}</span>
                  </div>
                </td>
                <td className="crm-table__cell-actions">
                  <div className="crm-table__actions">
                    <CrmActionButton
                      path={`/api/v1/crm/estates/${item.id}/avito/remove-from-feed`}
                      className="crm-button--danger crm-button--xs"
                      confirmText="Снять объект из выгрузки Авито?"
                      successMessage="Объект снят из выгрузки Авито."
                    >
                      Снять
                    </CrmActionButton>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
