﻿"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import {
  approveEstateForAvito,
  AvitoModerationListItem,
  CrmApiError,
  CrmUser,
  requestEstateAvitoChanges,
} from "@/lib/crm-api";
import {
  getAvitoModerationStatusLabel,
  getAvitoPublicationStatusLabel,
  normalizeAvitoIssues,
} from "@/lib/crm-avito";
import { formatCrmCurrency } from "@/lib/crm-format";
import { getCrmRole } from "@/lib/crm-role";
import { crmRoutes } from "@/lib/crm-routes";

function getDisplayName(user: CrmUser | null): string {
  if (!user) {
    return "-";
  }

  const fullName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return fullName || user.email;
}

function normalizeImageUrl(url: string | null | undefined): string {
  const value = (url ?? "").trim();
  if (!value) {
    return "";
  }

  try {
    const parsedUrl = new URL(value);
    if (parsedUrl.pathname.startsWith("/storage/")) {
      return `${parsedUrl.pathname}${parsedUrl.search}${parsedUrl.hash}`;
    }
  } catch {
    // Relative URL, normalize below.
  }

  if (/^(https?:|data:|blob:)/i.test(value)) {
    return value;
  }

  return value.startsWith("/") ? value : `/${value}`;
}

function getRequestErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof CrmApiError && error.payload && typeof error.payload === "object") {
    const payload = error.payload as { message?: string; error?: string };
    return payload.message ?? payload.error ?? fallback;
  }

  return fallback;
}

function formatReviewDate(value: string | null): string {
  if (!value) {
    return "-";
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : new Intl.DateTimeFormat("ru-RU", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      }).format(date);
}

export function CrmAvitoModerationTable({
  items,
  viewer,
}: {
  items: AvitoModerationListItem[];
  viewer: CrmUser;
}) {
  const router = useRouter();
  const role = getCrmRole(viewer);
  const canModerate = role === "OWNER" || role === "ADMIN" || role === "ROP";
  const [pendingId, setPendingId] = useState<number | null>(null);
  const [commentEstateId, setCommentEstateId] = useState<number | null>(null);
  const [comment, setComment] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function approve(item: AvitoModerationListItem): Promise<void> {
    setPendingId(item.id);
    setError(null);

    try {
      await approveEstateForAvito(item.id);
      router.refresh();
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось одобрить объект."));
    } finally {
      setPendingId(null);
    }
  }

  async function requestChanges(item: AvitoModerationListItem): Promise<void> {
    const normalizedComment = comment.trim();
    if (!normalizedComment) {
      setError("Комментарий обязателен.");
      return;
    }

    setPendingId(item.id);
    setError(null);

    try {
      await requestEstateAvitoChanges(item.id, normalizedComment);
      setComment("");
      setCommentEstateId(null);
      router.refresh();
    } catch (requestError) {
      setError(getRequestErrorMessage(requestError, "Не удалось вернуть объект на доработку."));
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div className="crm-stack">
      {error ? <div className="crm-form__error">{error}</div> : null}
      <div className="crm-table-wrap">
        <table className="crm-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Объект</th>
              <th>Цена</th>
              <th>Площадь</th>
              <th>Брокер</th>
              <th>Статус</th>
              <th>Проверка</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => {
              const imageSrc = normalizeImageUrl(item.main_image?.thumbnail_url || item.main_image?.public_url || item.main_image?.url);
              const issues = normalizeAvitoIssues(item.avito.last_error);
              const errorCount = issues.filter((issue) => issue.severity !== "warning").length;
              const warningCount = issues.length - errorCount;

              return (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td className="crm-table__cell-estate">
                    <div className="crm-table__estate-cell">
                      <div className="crm-table__thumb">
                        {imageSrc ? (
                          <Image src={imageSrc} alt="" fill sizes="48px" unoptimized />
                        ) : (
                          <span className="crm-table__thumb-placeholder">Нет фото</span>
                        )}
                      </div>
                      <div className="crm-table__estate-content">
                        <Link href={crmRoutes.estate(item.id)} prefetch={false} className="crm-table__title">
                          {item.title}
                        </Link>
                        <div className="crm-table__meta">{item.deal_type}</div>
                      </div>
                    </div>
                  </td>
                  <td>{item.price === null ? "-" : formatCrmCurrency(item.price)}</td>
                  <td>{item.area ?? "-"}</td>
                  <td>{getDisplayName(item.broker)}</td>
                  <td>
                    <div className="crm-table__status-stack">
                      <span className="crm-table__status crm-table__status--priority">
                        {getAvitoModerationStatusLabel(item.avito.moderation_status)}
                      </span>
                      <span className="crm-table__meta">{getAvitoPublicationStatusLabel(item.avito.publication_status)}</span>
                      <span className="crm-table__meta">{formatReviewDate(item.avito.review_requested_at)}</span>
                    </div>
                  </td>
                  <td>
                    {issues.length > 0 ? (
                      <span className="crm-table__meta">
                        {errorCount} ошибок, {warningCount} предупреждений
                      </span>
                    ) : (
                      <span className="crm-table__meta">Не проверялся</span>
                    )}
                  </td>
                  <td className="crm-table__cell-actions">
                    {canModerate ? (
                      <div className="crm-table__actions">
                        <button
                          type="button"
                          className="crm-button crm-button--secondary crm-button--xs"
                          disabled={pendingId !== null}
                          onClick={() => {
                            void approve(item);
                          }}
                        >
                          {pendingId === item.id ? "..." : "Одобрить"}
                        </button>
                        <button
                          type="button"
                          className="crm-button crm-button--ghost crm-button--xs"
                          disabled={pendingId !== null}
                          onClick={() => {
                            setCommentEstateId(commentEstateId === item.id ? null : item.id);
                            setComment("");
                          }}
                        >
                          Доработка
                        </button>
                        {commentEstateId === item.id ? (
                          <div className="crm-stack crm-stack--compact">
                            <textarea
                              className="crm-textarea"
                              value={comment}
                              onChange={(event) => {
                                setComment(event.target.value);
                              }}
                              placeholder="Комментарий для брокера"
                            />
                            <button
                              type="button"
                              className="crm-button crm-button--danger crm-button--xs"
                              disabled={pendingId !== null}
                              onClick={() => {
                                void requestChanges(item);
                              }}
                            >
                              Подтвердить
                            </button>
                          </div>
                        ) : null}
                      </div>
                    ) : (
                      <span className="crm-table__meta">Нет действий</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

