"use client";

import { CrmDealsColumn } from "@/components/crm/deals/crm-deals-column";
import { CrmDealListItem, CrmPipelineStatus } from "@/lib/crm-api";

const DEAL_COLUMNS: Array<{ status: CrmPipelineStatus; title: string; emptyTitle: string; emptyDescription: string }> = [
  {
    status: "new",
    title: "Новый",
    emptyTitle: "Новых сделок нет",
    emptyDescription: "Новые обращения и свежие связи появятся здесь.",
  },
  {
    status: "in_progress",
    title: "В работе",
    emptyTitle: "Пока пусто",
    emptyDescription: "Сделки в активной работе появятся в этой колонке.",
  },
  {
    status: "showing",
    title: "Показ",
    emptyTitle: "Нет показов",
    emptyDescription: "Запланированные и идущие показы будут здесь.",
  },
  {
    status: "negotiation",
    title: "Переговоры",
    emptyTitle: "Нет переговоров",
    emptyDescription: "Сделки на согласовании появятся в этой колонке.",
  },
  {
    status: "closed",
    title: "Закрыто",
    emptyTitle: "Нет закрытых",
    emptyDescription: "Успешно завершённые сделки появятся здесь.",
  },
  {
    status: "rejected",
    title: "Отказ",
    emptyTitle: "Нет отказов",
    emptyDescription: "Отменённые или потерянные сделки появятся здесь.",
  },
];

export function CrmDealsBoard({
  groupedItems,
  selectedLinkId,
  onSelectDeal,
  onMoveDeal,
}: {
  groupedItems: Record<CrmPipelineStatus, CrmDealListItem[]>;
  selectedLinkId: number | null;
  onSelectDeal: (linkId: number) => void;
  onMoveDeal: (linkId: number, nextStatus: CrmPipelineStatus) => void;
}) {
  return (
    <div className="crm-deals-board">
      {DEAL_COLUMNS.map((column) => {
        const items = groupedItems[column.status];

        return (
          <CrmDealsColumn
            key={column.status}
            title={column.title}
            count={items.length}
            items={items}
            selectedLinkId={selectedLinkId}
            onSelectDeal={onSelectDeal}
            onMoveDeal={(linkId) => onMoveDeal(linkId, column.status)}
            emptyState={
              <div className="crm-deals-column__empty">
                <div className="crm-deals-column__empty-title">{column.emptyTitle}</div>
                <div className="crm-deals-column__empty-description">{column.emptyDescription}</div>
              </div>
            }
          />
        );
      })}
    </div>
  );
}
