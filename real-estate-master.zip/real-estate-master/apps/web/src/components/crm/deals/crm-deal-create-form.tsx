"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  CrmApiError,
  CrmClientListItem,
  CrmDealConflictPayload,
  CrmDealListItem,
  CrmEstateListItem,
  CrmListResponse,
  CrmPipelineStatus,
  createCrmDeal,
  crmClientFetch,
} from "@/lib/crm-api";
import { formatCrmCurrency } from "@/lib/crm-format";
import { CRM_PIPELINE_OPTIONS } from "@/lib/crm-pipeline";
import { crmRoutes } from "@/lib/crm-routes";

const INITIAL_STAGE_OPTIONS = CRM_PIPELINE_OPTIONS.filter(
  (option) => option.value !== "closed" && option.value !== "rejected",
);

function getUserName(user: { first_name: string; last_name: string; email: string }): string {
  return `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim() || user.email;
}

function getEstateBrokerName(estate: CrmEstateListItem): string {
  const broker = estate.assigned_users[0];
  return broker ? getUserName(broker) : "Брокер не назначен";
}

function getRequestMessage(error: unknown, fallback: string): string {
  if (!(error instanceof CrmApiError) || !error.payload || typeof error.payload !== "object") {
    return fallback;
  }

  const payload = error.payload as { message?: string | string[] };
  return Array.isArray(payload.message) ? payload.message.join(". ") : payload.message ?? fallback;
}

export function CrmDealCreateForm({
  onCreated,
  onCancel,
}: {
  onCreated: (item: CrmDealListItem, reused: boolean) => void;
  onCancel: () => void;
}) {
  const [clientQuery, setClientQuery] = useState("");
  const [clientOptions, setClientOptions] = useState<CrmClientListItem[]>([]);
  const [selectedClient, setSelectedClient] = useState<CrmClientListItem | null>(null);
  const [clientLoading, setClientLoading] = useState(false);
  const [clientError, setClientError] = useState<string | null>(null);
  const [estateQuery, setEstateQuery] = useState("");
  const [estateOptions, setEstateOptions] = useState<CrmEstateListItem[]>([]);
  const [selectedEstate, setSelectedEstate] = useState<CrmEstateListItem | null>(null);
  const [estateLoading, setEstateLoading] = useState(false);
  const [estateError, setEstateError] = useState<string | null>(null);
  const [stage, setStage] = useState<CrmPipelineStatus>("new");
  const [comment, setComment] = useState("");
  const [pending, setPending] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [conflict, setConflict] = useState<CrmDealConflictPayload | null>(null);

  useEffect(() => {
    const query = clientQuery.trim();
    if (!query || selectedClient) {
      setClientOptions([]);
      setClientLoading(false);
      setClientError(null);
      return;
    }

    let cancelled = false;
    const timeoutId = window.setTimeout(async () => {
      setClientLoading(true);
      setClientError(null);
      try {
        const response = await crmClientFetch<CrmListResponse<CrmClientListItem>>(
          `/api/v1/crm/clients?search=${encodeURIComponent(query)}&limit=8`,
        );
        if (!cancelled) {
          setClientOptions(response.items);
        }
      } catch (error) {
        if (!cancelled) {
          setClientOptions([]);
          setClientError(getRequestMessage(error, "Не удалось найти клиентов."));
        }
      } finally {
        if (!cancelled) {
          setClientLoading(false);
        }
      }
    }, 350);

    return () => {
      cancelled = true;
      window.clearTimeout(timeoutId);
    };
  }, [clientQuery, selectedClient]);

  useEffect(() => {
    const query = estateQuery.trim();
    if (!query || selectedEstate) {
      setEstateOptions([]);
      setEstateLoading(false);
      setEstateError(null);
      return;
    }

    let cancelled = false;
    const timeoutId = window.setTimeout(async () => {
      setEstateLoading(true);
      setEstateError(null);
      try {
        const response = await crmClientFetch<CrmListResponse<CrmEstateListItem>>(
          `/api/v1/crm/estates?search=${encodeURIComponent(query)}&active=true&limit=8`,
        );
        if (!cancelled) {
          setEstateOptions(response.items);
        }
      } catch (error) {
        if (!cancelled) {
          setEstateOptions([]);
          setEstateError(getRequestMessage(error, "Не удалось найти объекты."));
        }
      } finally {
        if (!cancelled) {
          setEstateLoading(false);
        }
      }
    }, 350);

    return () => {
      cancelled = true;
      window.clearTimeout(timeoutId);
    };
  }, [estateQuery, selectedEstate]);

  const selectedBrokerName = useMemo(
    () => (selectedClient ? getUserName(selectedClient.broker) : null),
    [selectedClient],
  );

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitError(null);
    setConflict(null);

    if (!selectedClient || !selectedEstate) {
      setSubmitError("Выберите клиента и объект.");
      return;
    }

    setPending(true);
    try {
      const response = await createCrmDeal({
        client_id: selectedClient.id,
        estate_id: selectedEstate.id,
        stage,
        comment: comment.trim() || null,
      });
      onCreated(response.item, Boolean(response.reused));
    } catch (error) {
      if (error instanceof CrmApiError && error.status === 409 && error.payload && typeof error.payload === "object") {
        setConflict(error.payload as CrmDealConflictPayload);
      } else {
        setSubmitError(getRequestMessage(error, "Не удалось создать сделку."));
      }
    } finally {
      setPending(false);
    }
  }

  return (
    <form className="crm-form" onSubmit={handleSubmit}>
      <div className="crm-form-grid crm-form-grid--wide">
        <label className="crm-field">
          <span className="crm-field__label">Клиент *</span>
          <input
            className="crm-input"
            value={clientQuery}
            placeholder="Имя или телефон"
            autoComplete="off"
            onChange={(event) => {
              setClientQuery(event.target.value);
              setSelectedClient(null);
            }}
          />
          {clientLoading ? <span className="crm-note">Ищем клиентов…</span> : null}
          {clientError ? <span className="crm-form__error">{clientError}</span> : null}
          {!clientLoading && clientQuery.trim() && !selectedClient && clientOptions.length === 0 && !clientError ? (
            <span className="crm-note">Клиенты не найдены.</span>
          ) : null}
        </label>

        <label className="crm-field">
          <span className="crm-field__label">Объект *</span>
          <input
            className="crm-input"
            value={estateQuery}
            placeholder="Название, адрес или ID"
            autoComplete="off"
            onChange={(event) => {
              setEstateQuery(event.target.value);
              setSelectedEstate(null);
            }}
          />
          {estateLoading ? <span className="crm-note">Ищем объекты…</span> : null}
          {estateError ? <span className="crm-form__error">{estateError}</span> : null}
          {!estateLoading && estateQuery.trim() && !selectedEstate && estateOptions.length === 0 && !estateError ? (
            <span className="crm-note">Доступные объекты не найдены.</span>
          ) : null}
        </label>
      </div>

      {clientOptions.length > 0 && !selectedClient ? (
        <div className="crm-stack" aria-label="Результаты поиска клиентов">
          {clientOptions.map((client) => (
            <button
              key={client.id}
              type="button"
              className="crm-button crm-button--ghost crm-button--wide"
              onClick={() => {
                setSelectedClient(client);
                setClientQuery(client.name);
                setClientOptions([]);
              }}
            >
              {client.name} · {client.phone || "без телефона"} · {getUserName(client.broker)}
            </button>
          ))}
        </div>
      ) : null}

      {estateOptions.length > 0 && !selectedEstate ? (
        <div className="crm-stack" aria-label="Результаты поиска объектов">
          {estateOptions.map((estate) => (
            <button
              key={estate.id}
              type="button"
              className="crm-button crm-button--ghost crm-button--wide"
              onClick={() => {
                setSelectedEstate(estate);
                setEstateQuery(estate.title);
                setEstateOptions([]);
              }}
            >
              #{estate.id} · {estate.title} · {estate.deal_type} · {formatCrmCurrency(estate.price)} ₽ · {estate.area ?? "—"} м² ·{" "}
              {estate.status || (estate.active ? "Активен" : "Неактивен")} · {getEstateBrokerName(estate)}
            </button>
          ))}
        </div>
      ) : null}

      <div className="crm-form-grid">
        <label className="crm-field">
          <span className="crm-field__label">Ответственный брокер</span>
          <input className="crm-input" value={selectedBrokerName ?? "Определится после выбора клиента"} disabled />
        </label>
        <label className="crm-field">
          <span className="crm-field__label">Начальный этап *</span>
          <select className="crm-select" value={stage} onChange={(event) => setStage(event.target.value as CrmPipelineStatus)}>
            {INITIAL_STAGE_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label className="crm-field">
        <span className="crm-field__label">Комментарий</span>
        <textarea className="crm-textarea" value={comment} rows={3} onChange={(event) => setComment(event.target.value)} />
      </label>

      {conflict ? (
        <div className="crm-action__feedback crm-action__feedback--error">
          <strong>{conflict.message || "Активная сделка с этим клиентом и объектом уже существует"}</strong>
          {conflict.existing_deal ? (
            <a
              className="crm-button crm-button--ghost crm-button--xs"
              href={conflict.deal_url || crmRoutes.deal(conflict.existing_deal.link_id)}
              target="_blank"
              rel="noopener noreferrer"
            >
              Открыть существующую сделку
            </a>
          ) : null}
        </div>
      ) : null}
      {submitError ? <div className="crm-action__feedback crm-action__feedback--error">{submitError}</div> : null}

      <div className="crm-form-actions">
        <button className="crm-button" type="submit" disabled={pending}>
          {pending ? "Создаём сделку…" : "Создать сделку"}
        </button>
        <button className="crm-button crm-button--ghost" type="button" disabled={pending} onClick={onCancel}>
          Отмена
        </button>
      </div>
    </form>
  );
}
