"use client";

import { useEffect, useRef, useState } from "react";
import { formatCrmCurrency, formatCrmDate } from "@/lib/crm-format";
import { CrmApiError, CrmDealListItem, CrmPipelineStatus, updateCrmDealStage } from "@/lib/crm-api";
import { CRM_PIPELINE_OPTIONS, getCrmPipelineClassName, getCrmPipelineLabel } from "@/lib/crm-pipeline";
import { cn } from "@/lib/utils";

function getDealPriceLabel(item: CrmDealListItem): string {
  if (item.estate_presentation_price) {
    return `${item.estate_presentation_price} ₽`;
  }

  if (item.estate_price !== null && item.estate_price !== undefined) {
    return `${formatCrmCurrency(item.estate_price)} ₽`;
  }

  return "—";
}

function getContactsLabel(item: CrmDealListItem): string {
  if (!item.contacts_visible) {
    return "Контакты скрыты";
  }

  const parts = [item.phone, item.email].filter(Boolean);
  return parts.length > 0 ? parts.join(" · ") : "—";
}

export function CrmDealDetailPanel({
  item,
  onClose,
  onStatusUpdated,
}: {
  item: CrmDealListItem;
  onClose: () => void;
  onStatusUpdated: (linkId: number, nextStatus: CrmPipelineStatus) => void;
}) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const panelRef = useRef<HTMLElement | null>(null);
  const status = item.status as CrmPipelineStatus;

  useEffect(() => {
    panelRef.current?.focus();
  }, [item.link_id]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        onClose();
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  async function handleStatusChange(nextStatus: CrmPipelineStatus) {
    if (nextStatus === item.status) {
      return;
    }

    setPending(true);
    setError(null);

    try {
      await updateCrmDealStage(item.link_id, nextStatus);

      onStatusUpdated(item.link_id, nextStatus);
    } catch (requestError) {
      if (requestError instanceof CrmApiError && requestError.payload && typeof requestError.payload === "object") {
        const payload = requestError.payload as { message?: string };
        setError(payload.message ?? "Не удалось изменить стадию сделки.");
      } else {
        setError("Не удалось изменить стадию сделки.");
      }
    } finally {
      setPending(false);
    }
  }

  return (
    <aside ref={panelRef} className="crm-panel crm-deal-panel" tabIndex={-1}>
      <div className="crm-deal-panel__header">
        <div>
          <h2 className="crm-deal-panel__title">{item.client_name}</h2>
          <div className="crm-deal-panel__subtitle">{item.estate_title}</div>
        </div>

        <button type="button" className="crm-deal-panel__close" onClick={onClose} aria-label="Закрыть панель сделки">
          ×
        </button>
      </div>

      <div className="crm-stack">
        <section className="crm-deal-panel__section">
          <div className="crm-field">
            <label className="crm-field__label" htmlFor={`deal-status-${item.link_id}`}>
              Стадия сделки
            </label>
            <div className="crm-deal-panel__status-control">
              <select
                id={`deal-status-${item.link_id}`}
                className={cn("crm-select crm-select--pipeline", getCrmPipelineClassName(status))}
                value={status}
                disabled={pending}
                onChange={(event) => handleStatusChange(event.target.value as CrmPipelineStatus)}
              >
                {CRM_PIPELINE_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>

              {pending ? (
                <div className="crm-deal-panel__inline-loader" aria-live="polite">
                  <span className="crm-deal-panel__inline-spinner" />
                  <span>Сохраняем…</span>
                </div>
              ) : null}
            </div>
          </div>

          {error ? <div className="crm-deal-panel__error">{error}</div> : null}

          <div className="crm-deal-panel__row">
            <span>Статус</span>
            <span className={cn("crm-pipeline-badge", getCrmPipelineClassName(status))}>{getCrmPipelineLabel(status)}</span>
          </div>
          <div className="crm-deal-panel__row">
            <span>Брокер</span>
            <strong>{item.broker_name}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Цена</span>
            <strong>{getDealPriceLabel(item)}</strong>
          </div>
        </section>

        <section className="crm-deal-panel__section">
          <div className="crm-deal-panel__row">
            <span>Клиент</span>
            <strong>{item.client_name}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Контакты</span>
            <strong>{getContactsLabel(item)}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Источник</span>
            <strong>{item.source || "—"}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Комментарий</span>
            <strong>{item.comment || "—"}</strong>
          </div>
        </section>

        <section className="crm-deal-panel__section">
          <div className="crm-deal-panel__row">
            <span>Объект</span>
            <strong>{item.estate_title}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Район</span>
            <strong>{item.district || "—"}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Метро</span>
            <strong>{item.metro_station || "—"}</strong>
          </div>
        </section>

        <section className="crm-deal-panel__section">
          <div className="crm-deal-panel__row">
            <span>Создано</span>
            <strong>{formatCrmDate(item.created_at)}</strong>
          </div>
          <div className="crm-deal-panel__row">
            <span>Обновлено</span>
            <strong>{formatCrmDate(item.update_at)}</strong>
          </div>
        </section>
      </div>
    </aside>
  );
}
