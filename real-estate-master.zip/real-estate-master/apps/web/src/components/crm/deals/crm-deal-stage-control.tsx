"use client";

import { useState } from "react";
import { CrmApiError, CrmPipelineStatus, updateCrmDealStage } from "@/lib/crm-api";
import { CRM_PIPELINE_OPTIONS, getCrmPipelineClassName, getCrmPipelineLabel } from "@/lib/crm-pipeline";
import { cn } from "@/lib/utils";

export function CrmDealStageControl({
  linkId,
  initialStatus,
}: {
  linkId: number;
  initialStatus: CrmPipelineStatus;
}) {
  const [status, setStatus] = useState(initialStatus);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function handleChange(nextStatus: CrmPipelineStatus) {
    if (nextStatus === status) {
      return;
    }

    const previousStatus = status;
    setStatus(nextStatus);
    setPending(true);
    setError(null);
    setSuccess(null);
    try {
      const response = await updateCrmDealStage(linkId, nextStatus);
      setStatus(response.item.status);
      setSuccess(nextStatus === "closed" ? "Сделка закрыта, объект отправлен в архив." : "Этап сделки обновлён.");
    } catch (requestError) {
      setStatus(previousStatus);
      if (requestError instanceof CrmApiError && requestError.payload && typeof requestError.payload === "object") {
        const payload = requestError.payload as { message?: string };
        setError(payload.message ?? "Не удалось изменить этап сделки.");
      } else {
        setError("Не удалось изменить этап сделки.");
      }
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="crm-stack">
      <div className="crm-deal-panel__status-control">
        <span className={cn("crm-pipeline-badge", getCrmPipelineClassName(status))}>{getCrmPipelineLabel(status)}</span>
        <select
          className={cn("crm-select crm-select--pipeline", getCrmPipelineClassName(status))}
          value={status}
          disabled={pending}
          aria-label="Этап сделки"
          onChange={(event) => handleChange(event.target.value as CrmPipelineStatus)}
        >
          {CRM_PIPELINE_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        {pending ? <span className="crm-note">Сохраняем этап…</span> : null}
      </div>
      {success ? <div className="crm-action__feedback">{success}</div> : null}
      {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}
    </div>
  );
}
