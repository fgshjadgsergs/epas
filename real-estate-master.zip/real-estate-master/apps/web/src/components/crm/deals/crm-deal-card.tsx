"use client";

import { formatCrmCurrency, formatCrmDate } from "@/lib/crm-format";
import { CrmDealListItem, CrmPipelineStatus } from "@/lib/crm-api";
import { getCrmPipelineClassName, getCrmPipelineLabel } from "@/lib/crm-pipeline";
import { cn } from "@/lib/utils";

function getDealPriceLabel(item: CrmDealListItem): string {
  if (item.estate_presentation_price) {
    return `${item.estate_presentation_price} ₽`;
  }

  if (item.estate_price !== null && item.estate_price !== undefined) {
    return `${formatCrmCurrency(item.estate_price)} ₽`;
  }

  return "—";
}

export function CrmDealCard({
  item,
  isActive,
  onSelect,
}: {
  item: CrmDealListItem;
  isActive: boolean;
  onSelect: () => void;
}) {
  const timestamp = item.update_at || item.created_at;
  const status = item.status as CrmPipelineStatus;

  return (
    <button
      type="button"
      className={cn("crm-deal-card", isActive && "crm-deal-card--active")}
      draggable
      onClick={onSelect}
      onDragStart={(event) => {
        event.dataTransfer.setData("text/plain", String(item.link_id));
        event.dataTransfer.effectAllowed = "move";
      }}
    >
      <div className="crm-deal-card__header">
        <div className="crm-deal-card__title">{item.client_name}</div>
        <span className={cn("crm-pipeline-badge", getCrmPipelineClassName(status))}>{getCrmPipelineLabel(status)}</span>
      </div>

      <div className="crm-deal-card__estate">{item.estate_title}</div>

      <div className="crm-deal-card__meta">
        <span>{item.broker_name}</span>
        <span>{getDealPriceLabel(item)}</span>
      </div>

      <div className="crm-deal-card__date">{formatCrmDate(timestamp)}</div>
    </button>
  );
}
