"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { CrmDealCreateForm } from "@/components/crm/deals/crm-deal-create-form";
import { CrmDealsBoard } from "@/components/crm/deals/crm-deals-board";
import { CrmPageHeader } from "@/components/crm/shared/crm-page-header";
import { CrmEmptyState, CrmPanel } from "@/components/crm/shared/crm-state";
import {
  CrmApiError,
  CrmDealBrokerItem,
  CrmDealListItem,
  CrmPipelineStatus,
  CrmUser,
  updateCrmDealStage,
} from "@/lib/crm-api";
import { crmRoutes } from "@/lib/crm-routes";
import { SearchParamsRecord, toUrlSearchParams } from "@/lib/public-query";

function getDealTimestamp(item: CrmDealListItem): number {
  return new Date(item.update_at || item.created_at).getTime();
}

function groupDealsByStatus(items: CrmDealListItem[]): Record<CrmPipelineStatus, CrmDealListItem[]> {
  const groups = items.reduce<Record<CrmPipelineStatus, CrmDealListItem[]>>(
    (acc, item) => {
      acc[item.status].push(item);
      return acc;
    },
    {
      new: [],
      in_progress: [],
      showing: [],
      negotiation: [],
      closed: [],
      rejected: [],
    },
  );

  for (const status of Object.keys(groups) as CrmPipelineStatus[]) {
    groups[status].sort((left, right) => getDealTimestamp(right) - getDealTimestamp(left));
  }

  return groups;
}

function getBrokerDisplayName(user: CrmDealBrokerItem): string {
  const fullName = `${user.first_name ?? ""} ${user.last_name ?? ""}`.trim();
  return fullName || user.email;
}

export function CrmDealsWorkspace({
  items,
  total,
  skip,
  limit,
  searchParams,
  selectedBrokerId,
  brokerOptions,
  viewer,
}: {
  items: CrmDealListItem[];
  total: number;
  skip: number;
  limit: number;
  searchParams: SearchParamsRecord;
  selectedBrokerId: string;
  brokerOptions: CrmDealBrokerItem[];
  viewer: CrmUser;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [dealItems, setDealItems] = useState(items);
  const [moveError, setMoveError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const canCreate = viewer.is_admin || viewer.role !== "VIEWER";

  useEffect(() => {
    setDealItems(items);
  }, [items]);

  const groupedItems = groupDealsByStatus(dealItems);

  function updateLocalStatus(linkId: number, nextStatus: CrmPipelineStatus) {
    setDealItems((prev) =>
      prev.map((item) =>
        item.link_id === linkId
          ? {
              ...item,
              status: nextStatus,
              update_at: new Date().toISOString(),
            }
          : item,
      ),
    );
  }

  function handleBrokerChange(nextBrokerId: string) {
    const nextParams = toUrlSearchParams(searchParams);
    nextParams.delete("skip");

    if (nextBrokerId) {
      nextParams.set("broker_id", nextBrokerId);
    } else {
      nextParams.delete("broker_id");
    }

    const query = nextParams.toString();
    router.replace(query ? `${pathname}?${query}` : pathname);
  }

  function handleOpenDeal(linkId: number) {
    window.open(crmRoutes.deal(linkId), "_blank", "noopener,noreferrer");
  }

  async function handleMoveDeal(linkId: number, nextStatus: CrmPipelineStatus) {
    const currentItem = dealItems.find((item) => item.link_id === linkId);
    if (!currentItem || currentItem.status === nextStatus) {
      return;
    }

    setMoveError(null);
    setFeedback(null);
    updateLocalStatus(linkId, nextStatus);

    try {
      await updateCrmDealStage(linkId, nextStatus);
    } catch (error) {
      updateLocalStatus(linkId, currentItem.status);
      if (error instanceof CrmApiError && error.payload && typeof error.payload === "object") {
        const payload = error.payload as { message?: string };
        setMoveError(payload.message ?? "Не удалось изменить стадию сделки.");
      } else {
        setMoveError("Не удалось изменить стадию сделки.");
      }
    }
  }

  function handleCreated(item: CrmDealListItem, reused: boolean) {
    setDealItems((current) => {
      const existingIndex = current.findIndex((deal) => deal.link_id === item.link_id);
      if (existingIndex === -1) {
        return [item, ...current];
      }
      return current.map((deal) => (deal.link_id === item.link_id ? item : deal));
    });
    setCreateOpen(false);
    setFeedback(reused ? "Закрытая связь переиспользована как новая сделка." : "Сделка создана.");
  }

  return (
    <div className="crm-stack">
      <CrmPageHeader
        title="Сделки"
        description={`Загружено сделок: ${dealItems.length} из ${total}. Skip: ${skip}, limit: ${limit}.`}
        action={
          canCreate ? (
            <button
              type="button"
              className="crm-button"
              onClick={() => {
                setCreateOpen((current) => !current);
                setFeedback(null);
              }}
            >
              Новая сделка
            </button>
          ) : null
        }
      />

      {createOpen ? (
        <CrmPanel>
          <CrmDealCreateForm onCreated={handleCreated} onCancel={() => setCreateOpen(false)} />
        </CrmPanel>
      ) : null}

      {brokerOptions.length > 0 ? (
        <CrmPanel>
          <div className="crm-filters">
            <label className="crm-field">
              <span className="crm-field__label">Брокер</span>
              <select className="crm-select" value={selectedBrokerId} onChange={(event) => handleBrokerChange(event.target.value)}>
                <option value="">Все брокеры</option>
                {brokerOptions.map((broker) => (
                  <option key={broker.id} value={broker.id}>
                    {getBrokerDisplayName(broker)}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </CrmPanel>
      ) : null}

      {feedback ? <div className="crm-action__feedback">{feedback}</div> : null}
      {moveError ? <div className="crm-action__feedback crm-action__feedback--error">{moveError}</div> : null}

      <div className="crm-deals-layout">
        <div className="crm-deals-layout__board">
          <CrmPanel>
            {dealItems.length > 0 ? (
              <CrmDealsBoard
                groupedItems={groupedItems}
                selectedLinkId={null}
                onSelectDeal={handleOpenDeal}
                onMoveDeal={handleMoveDeal}
              />
            ) : (
              <CrmEmptyState
                title="Сделки не найдены"
                description="Сделки появятся здесь в виде pipeline-доски после создания связи клиент–объект."
              />
            )}
          </CrmPanel>
        </div>
      </div>
    </div>
  );
}
