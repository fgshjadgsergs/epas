"use client";

import { DragEvent, ReactNode } from "react";
import { CrmDealCard } from "@/components/crm/deals/crm-deal-card";
import { CrmDealListItem } from "@/lib/crm-api";

export function CrmDealsColumn({
  title,
  count,
  items,
  selectedLinkId,
  onSelectDeal,
  onMoveDeal,
  emptyState,
}: {
  title: string;
  count: number;
  items: CrmDealListItem[];
  selectedLinkId: number | null;
  onSelectDeal: (linkId: number) => void;
  onMoveDeal: (linkId: number) => void;
  emptyState?: ReactNode;
}) {
  function handleDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    const linkId = Number(event.dataTransfer.getData("text/plain"));
    if (Number.isInteger(linkId) && linkId > 0) {
      onMoveDeal(linkId);
    }
  }

  return (
    <section className="crm-deals-column">
      <header className="crm-deals-column__header">
        <h2 className="crm-deals-column__title">{title}</h2>
        <span className="crm-deals-column__count">{count}</span>
      </header>

      <div
        className="crm-deals-column__body"
        onDragOver={(event) => event.preventDefault()}
        onDrop={handleDrop}
      >
        {items.length > 0
          ? items.map((item) => (
              <CrmDealCard
                key={item.link_id}
                item={item}
                isActive={selectedLinkId === item.link_id}
                onSelect={() => onSelectDeal(item.link_id)}
              />
            ))
          : emptyState}
      </div>
    </section>
  );
}
