"use client";

import { FormEvent, useState } from "react";
import {
  CrmDealCommentItem,
  CrmDealTaskItem,
  CrmDealTaskType,
  CrmItemResponse,
  crmClientFetch,
} from "@/lib/crm-api";
import { formatCrmDate } from "@/lib/crm-format";

const TASK_OPTIONS: Array<{ value: CrmDealTaskType; label: string }> = [
  { value: "CALL", label: "Звонок" },
  { value: "MEETING", label: "Встреча" },
  { value: "MESSAGE", label: "Сообщение" },
];

function getTaskLabel(type: CrmDealTaskType): string {
  return TASK_OPTIONS.find((item) => item.value === type)?.label ?? type;
}

export function CrmDealActivity({
  linkId,
  initialComments,
  initialTasks,
}: {
  linkId: number;
  initialComments: CrmDealCommentItem[];
  initialTasks: CrmDealTaskItem[];
}) {
  const [comments, setComments] = useState(initialComments);
  const [tasks, setTasks] = useState(initialTasks);
  const [commentText, setCommentText] = useState("");
  const [taskType, setTaskType] = useState<CrmDealTaskType>("CALL");
  const [taskText, setTaskText] = useState("");
  const [taskDueAt, setTaskDueAt] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCommentSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = commentText.trim();
    if (!text) {
      return;
    }

    setPending(true);
    setError(null);
    try {
      const response = await crmClientFetch<CrmItemResponse<CrmDealCommentItem>>(`/api/v1/crm/deals/${linkId}/comments`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({ text }),
      });
      setComments((prev) => [response.item, ...prev]);
      setCommentText("");
    } catch {
      setError("Не удалось добавить комментарий.");
    } finally {
      setPending(false);
    }
  }

  async function handleTaskSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = taskText.trim();
    if (!text) {
      return;
    }

    setPending(true);
    setError(null);
    try {
      const response = await crmClientFetch<CrmItemResponse<CrmDealTaskItem>>(`/api/v1/crm/deals/${linkId}/tasks`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({
          type: taskType,
          text,
          due_at: taskDueAt || null,
        }),
      });
      setTasks((prev) => [response.item, ...prev]);
      setTaskText("");
      setTaskDueAt("");
    } catch {
      setError("Не удалось добавить задачу.");
    } finally {
      setPending(false);
    }
  }

  async function handleTaskDoneChange(task: CrmDealTaskItem, done: boolean) {
    const previousTasks = tasks;
    setTasks((prev) => prev.map((item) => (item.id === task.id ? { ...item, done } : item)));
    setError(null);

    try {
      const response = await crmClientFetch<CrmItemResponse<CrmDealTaskItem>>(`/api/v1/crm/deals/${linkId}/tasks/${task.id}`, {
        method: "PUT",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify({ done }),
      });
      setTasks((prev) => prev.map((item) => (item.id === task.id ? response.item : item)));
    } catch {
      setTasks(previousTasks);
      setError("Не удалось обновить задачу.");
    }
  }

  return (
    <div className="crm-stack">
      {error ? <div className="crm-action__feedback crm-action__feedback--error">{error}</div> : null}

      <section className="crm-deal-panel__section">
        <h2 className="crm-client-panel__section-title">Комментарии</h2>
        <form className="crm-form" onSubmit={handleCommentSubmit}>
          <textarea
            className="crm-textarea"
            value={commentText}
            onChange={(event) => setCommentText(event.target.value)}
            rows={3}
          />
          <button type="submit" className="crm-button" disabled={pending || !commentText.trim()}>
            Добавить комментарий
          </button>
        </form>

        <div className="crm-deal-activity-list">
          {comments.length > 0 ? (
            comments.map((comment) => (
              <article key={comment.id} className="crm-deal-activity-card">
                <div className="crm-deal-activity-card__meta">
                  <strong>{comment.author_name}</strong>
                  <span>{formatCrmDate(comment.created_at)}</span>
                </div>
                <div className="crm-deal-activity-card__text">{comment.text}</div>
              </article>
            ))
          ) : (
            <div className="crm-note">Комментариев пока нет.</div>
          )}
        </div>
      </section>

      <section className="crm-deal-panel__section">
        <h2 className="crm-client-panel__section-title">Задачи</h2>
        <form className="crm-form crm-deal-task-form" onSubmit={handleTaskSubmit}>
          <select className="crm-select" value={taskType} onChange={(event) => setTaskType(event.target.value as CrmDealTaskType)}>
            {TASK_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          <input
            className="crm-input"
            value={taskText}
            onChange={(event) => setTaskText(event.target.value)}
          />
          <input
            className="crm-input"
            type="datetime-local"
            value={taskDueAt}
            onChange={(event) => setTaskDueAt(event.target.value)}
          />
          <button type="submit" className="crm-button" disabled={pending || !taskText.trim()}>
            Добавить задачу
          </button>
        </form>

        <div className="crm-deal-activity-list">
          {tasks.length > 0 ? (
            tasks.map((task) => (
              <article key={task.id} className={`crm-deal-activity-card${task.done ? " crm-deal-activity-card--done" : ""}`}>
                <label className="crm-deal-task-row">
                  <input
                    type="checkbox"
                    checked={task.done}
                    onChange={(event) => handleTaskDoneChange(task, event.target.checked)}
                  />
                  <span>
                    <strong>{getTaskLabel(task.type)}</strong>
                    <span>{task.text}</span>
                  </span>
                </label>
                <div className="crm-deal-activity-card__meta">
                  <span>{task.due_at ? `Срок: ${formatCrmDate(task.due_at)}` : "Без срока"}</span>
                  <span>{task.author_name}</span>
                </div>
              </article>
            ))
          ) : (
            <div className="crm-note">Задач пока нет.</div>
          )}
        </div>
      </section>
    </div>
  );
}
