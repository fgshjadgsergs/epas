"use client";

import { useEffect, useState } from "react";
import { DistrictDropdown } from "./district-dropdown";

export function HomeSearchForm() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      return undefined;
    }

    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.key === "Escape") {
        setIsOpen(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen]);

  return (
    <>
      <a
        className={`form-options-backdrop modal-backdrop${isOpen ? "" : " collapsed"}`}
        href="#searchbox-hero-1FormOptionsCollapse"
        role="button"
        aria-expanded={isOpen}
        aria-controls="searchbox-hero-1FormOptionsCollapse"
        onClick={(event) => {
          event.preventDefault();
          setIsOpen(false);
        }}
      />

      <form action="/listing" method="get" className="searchbox-form position-relative mx-lg-auto bg-white rounded shadow-sm">
        <div className="input-group position-relative px-3">
          <label htmlFor="searchboxKeyword" className="input-group-text bg-transparent px-0 border-0 text-secondary">
            <i className="fas fa-home" />
          </label>
          <input
            id="searchboxKeyword"
            name="search_by_address"
            className="form-control pe-5 form-control-lg border-0 shadow-none position-relative bg-transparent text-center"
            placeholder="Поиск"
            data-scroll-to="#searchBox"
          />
        </div>

        {isOpen ? (
          <div className="form-options position-absolute top-100 w-100 bg-white rounded-bottom pb-1 pt-1 shadow-sm">
            <div className="form-options-collapse position-relative border-top" id="searchbox-hero-1FormOptionsCollapse">
            <div className="row my-3 gx-3 px-3">
              <div className="col-12 d-flex flex-column">
                <div className="btn-group" role="group">
                  <input type="radio" className="btn-check" name="deal_type" value="продажа" id="is-sell" defaultChecked />
                  <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="is-sell">
                    <i className="fas fa-check" />
                    &nbsp;Продажа
                  </label>
                  <input type="radio" className="btn-check" name="deal_type" value="аренда" id="is-rent" />
                  <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="is-rent">
                    <i className="fas fa-check" />
                    &nbsp;Аренда
                  </label>
                  <input type="radio" className="btn-check" name="deal_type" value="арендный бизнес" id="is-rent-business" />
                  <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="is-rent-business">
                    <i className="fas fa-check" />
                    &nbsp;Арендный бизнес
                  </label>
                </div>
              </div>
            </div>

            <div className="row my-3 gx-3 px-3">
              <div className="col-12 col-md-5 col-md col-lg mb-3 mb-md-0 d-flex flex-column">
                <div className="btn-group" role="group">
                  <input type="checkbox" className="btn-check" name="is_moscow" id="searchCategoryMoscow" defaultChecked />
                  <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="searchCategoryMoscow">
                    <i className="fas fa-check" />
                    &nbsp;Москва
                  </label>
                  <input type="checkbox" className="btn-check" name="is_region" id="is-moscow-district" />
                  <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="is-moscow-district">
                    <i className="fas fa-check" />
                    &nbsp;Московская&nbsp;обл.
                  </label>
                </div>
              </div>

              <div className="col-12 col-md col-sm">
                <div className="flex-row">
                  <div className="col d-flex flex-column pe-0">
                    <button className="btn btn-primary d-block fw-bold" type="submit">
                      <i className="fas fa-search me-2" />
                      &nbsp;Поиск
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-top px-3 pt-3">
              <div className="row g-4 mb-4">
                <div className="col-12">
                  <div className="row g-3 position-relative">
                    <div className="col-12 d-flex flex-column">
                      <div className="btn-group" role="group">
                        <input type="radio" className="btn-check" name="price_for" value="full" id="is-full-price" defaultChecked />
                        <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="is-full-price">
                          <i className="fas fa-check" />
                          Полная стоимость
                        </label>
                        <input type="radio" className="btn-check" name="price_for" value="area" id="is-price-for-area" />
                        <label className="btn btn-outline-primary btn-default shadow-none fw-bold" htmlFor="is-price-for-area">
                          <i className="fas fa-check" />
                          Стоимость&nbsp;за м<sup>2</sup>
                        </label>
                      </div>
                    </div>

                    <div className="col">
                      <div className="btn-group btn-range w-100 dropdown">
                        <input id="price-from" className="form-control" type="number" placeholder="Руб. от" name="price_from" />
                      </div>
                    </div>
                    <div className="col-auto pt-2 text-secondary px-0">-</div>
                    <div className="col-6">
                      <div className="btn-group btn-range w-100 dropdown">
                        <input className="form-control" type="number" placeholder="Руб. до" name="price_to" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12">
                  <label className="form-label fw-bold fs-sm my-1">
                    Метраж м<sup>2</sup>
                  </label>
                  <div className="row g-3 position-relative">
                    <div className="col">
                      <div className="btn-group btn-range w-100 dropdown">
                        <input className="form-control" type="number" placeholder="От м2" name="area_from" />
                      </div>
                    </div>
                    <div className="col-auto pt-2 text-secondary px-0">-</div>
                    <div className="col-6">
                      <div className="btn-group btn-range w-100 dropdown">
                        <input className="form-control" type="number" placeholder="До м2" name="area_to" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12">
                  <div className="row g-3 position-relative">
                    <div className="col-12">
                      <label className="form-label fw-bold fs-sm my-1">
                        <img width="18" height="15" src="/static/img/16px-Mosmetro_logo_M.svg.png" alt="Метро" /> Станция метро
                      </label>
                      <input className="form-control" name="metro_station" type="text" placeholder="Введите станцию метро" />
                    </div>

                    <DistrictDropdown />
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
        ) : null}
      </form>
    </>
  );
}
