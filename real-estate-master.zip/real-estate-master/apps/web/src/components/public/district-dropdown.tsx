﻿"use client";

import { useState } from "react";
import { DISTRICT_OPTIONS } from "./constants";

interface DistrictDropdownProps {
  defaultValue?: string;
}

function getLabel(value: string): string {
  return DISTRICT_OPTIONS.find((item) => item.value === value)?.label ?? "Округ";
}

export function DistrictDropdown({ defaultValue = "" }: DistrictDropdownProps) {
  const [selectedValue, setSelectedValue] = useState(defaultValue);

  return (
    <div className="btn-group btn-select-dropdown">
      <button
        id="districtDropdown"
        type="button"
        className="btn btn-outline-primary btn-default dropdown-toggle d-flex align-items-center justify-content-between shadow-none fw-bold active"
        data-bs-toggle="dropdown"
        aria-expanded="false"
      >
        <i className="fas fa-map-marker-alt" />
        {getLabel(selectedValue)}
      </button>
      <input type="hidden" name="district" id="districtInput" value={selectedValue} />
      <ul id="dropElem" className="dropdown-menu w-100" aria-labelledby="districtDropdown">
        {DISTRICT_OPTIONS.map((option) => (
          <li key={option.value}>
            <button type="button" className="dropdown-item small" onClick={() => setSelectedValue(option.value)}>
              {option.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

