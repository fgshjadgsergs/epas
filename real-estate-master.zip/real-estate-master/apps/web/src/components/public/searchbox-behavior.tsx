"use client";

import { useEffect } from "react";

declare global {
  interface Window {
    bootstrap?: {
      Collapse: new (
        element: Element,
        options?: {
          toggle?: boolean;
        },
      ) => {
        show: () => void;
        hide: () => void;
      };
    };
  }
}

export function SearchboxBehavior() {
  useEffect(() => {
    const collapseElement = document.getElementById("searchbox-hero-1FormOptionsCollapse");
    const backdropElement = document.querySelector<HTMLAnchorElement>(
      '.form-options-backdrop[href="#searchbox-hero-1FormOptionsCollapse"]',
    );
    const triggerElements = document.querySelectorAll<HTMLElement>('[data-show-bs-collapse-id="#searchbox-hero-1FormOptionsCollapse"]');
    const Collapse = window.bootstrap?.Collapse;

    if (!collapseElement || !backdropElement || !Collapse) {
      return undefined;
    }

    const collapse = new Collapse(collapseElement, { toggle: false });

    const syncBackdrop = (isOpen: boolean): void => {
      backdropElement.classList.toggle("collapsed", !isOpen);
      backdropElement.setAttribute("aria-expanded", String(isOpen));
    };

    const openFilters = (): void => {
      syncBackdrop(true);
      collapse.show();
    };

    const closeFilters = (): void => {
      collapse.hide();
    };

    const handleBackdropClick = (event: MouseEvent): void => {
      event.preventDefault();
      closeFilters();
    };

    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.key === "Escape") {
        closeFilters();
      }
    };

    const handleCollapseShow = (): void => {
      syncBackdrop(true);
    };

    const handleCollapseHide = (): void => {
      syncBackdrop(false);
    };

    triggerElements.forEach((element) => {
      element.addEventListener("focus", openFilters);
      element.addEventListener("click", openFilters);
    });

    backdropElement.addEventListener("click", handleBackdropClick);
    collapseElement.addEventListener("show.bs.collapse", handleCollapseShow);
    collapseElement.addEventListener("hidden.bs.collapse", handleCollapseHide);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      triggerElements.forEach((element) => {
        element.removeEventListener("focus", openFilters);
        element.removeEventListener("click", openFilters);
      });

      backdropElement.removeEventListener("click", handleBackdropClick);
      collapseElement.removeEventListener("show.bs.collapse", handleCollapseShow);
      collapseElement.removeEventListener("hidden.bs.collapse", handleCollapseHide);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  return null;
}
