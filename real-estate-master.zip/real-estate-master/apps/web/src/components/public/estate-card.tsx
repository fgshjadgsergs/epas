﻿import Link from "next/link";
import { PublicEstateCard, resolveStoragePath } from "@/lib/public-api";
import {
  formatPricePerArea,
  formatProfit,
  isRentBusiness
} from "@/lib/public-format";
import { EstateCardGallery } from "./estate-card-gallery";

interface EstateCardProps {
  estate: PublicEstateCard;
  variant: "main" | "listing";
}

function getCardImages(estate: PublicEstateCard): string[] {
  const images =
    estate.images.length > 0
      ? estate.images
      : estate.imageUrl
      ? [estate.imageUrl]
      : [];

  if (images.length === 0) {
    return ["/static/img/logo-light.png"];
  }

  return images.map((image) => resolveStoragePath(image));
}

export function EstateCard({ estate }: EstateCardProps) {
  const cardImages = getCardImages(estate);
  const isBusiness = isRentBusiness(estate.dealType);

  const areaPrice = formatPricePerArea(estate.price, estate.area);
  const profit = formatProfit(estate.profit);

  const detailHref = `/detail/${estate.dbId}`;

  return (
    <article className="property-card">
      {/* ===== MEDIA ===== */}
      <div className="property-card__media">
        <span className="property-card__badge">{estate.dealType}</span>

        <EstateCardGallery images={cardImages} title={estate.title} />
      </div>

      {/* ===== BODY ===== */}
      <div className="property-card__body">
        <div className="property-card__row">
          <span className="property-card__price">
            ₽{estate.presentationPrice}
          </span>

          <span
            className={`property-card__tag property-card__tag--${estate.dealType.toLowerCase()}`}
          >
            {estate.dealType}
          </span>
        </div>

        <p className="property-card__address">{estate.title}</p>

        {/* ===== ХАРАКТЕРИСТИКИ ===== */}
        <dl className="property-card__meta">
          <div>
            <dt>Метраж</dt>
            <dd>{estate.area} м²</dd>
          </div>

          <div>
            <dt>Цена/м²</dt>
            <dd>{areaPrice ? `₽${areaPrice}` : "-"}</dd>
          </div>

          {/* 🔥 АРЕНДАТОР + ОКУПАЕМОСТЬ */}
          {isBusiness ? (
            <>
              <div>
                <dt>Арендатор</dt>
                <dd>{estate.tenantType || "-"}</dd>
              </div>

              <div>
                <dt>Окупаемость</dt>
                <dd>{profit ? `${profit} лет` : "-"}</dd>
              </div>
            </>
          ) : null}
        </dl>

        {/* ===== FOOTER ===== */}
        <div className="property-card__footer">
          <Link className="btn btn--secondary" href={detailHref}>
            Подробнее
          </Link>
        </div>
      </div>
    </article>
  );
}