﻿"use client";

import { useState } from "react";

interface DetailGalleryProps {
  images: string[];
  title: string;
}

export function DetailGallery({ images, title }: DetailGalleryProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const hasManyImages = images.length > 1;
  const currentImage = images[activeIndex] ?? images[0];

  const move = (delta: number): void => {
    setActiveIndex((current) => {
      const next = current + delta;

      if (next < 0) {
        return images.length - 1;
      }

      if (next >= images.length) {
        return 0;
      }

      return next;
    });
  };

  return (
    <div className="hero-area h-100">
      <div className="swiper-container h-100">
        <div id="listing-detail-hero-1-swiper" className="swiper h-100">
          <div className="swiper-wrapper">
            <div className="swiper-slide">
              <a href={currentImage} className="lightbox-link d-block h-100" target="_blank" rel="noreferrer">
                <img src={currentImage} className="listing-hero-img w-100 h-100" alt={title} loading="lazy" />
              </a>
            </div>
          </div>

          {hasManyImages ? (
            <>
              <button
                type="button"
                className="swiper-button-prev"
                aria-label="Предыдущее фото"
                onClick={() => move(-1)}
              />
              <button type="button" className="swiper-button-next" aria-label="Следующее фото" onClick={() => move(1)} />
              <div className="swiper-pagination">
                {images.map((image, index) => (
                  <button
                    key={`${image}-${index}`}
                    type="button"
                    className={`swiper-pagination-bullet${index === activeIndex ? " swiper-pagination-bullet-active" : ""}`}
                    aria-label={`Показать фото ${index + 1}`}
                    onClick={() => setActiveIndex(index)}
                  />
                ))}
              </div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}

