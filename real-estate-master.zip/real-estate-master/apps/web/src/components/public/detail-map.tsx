﻿"use client";

import { useEffect, useId, useRef } from "react";

declare global {
  interface Window {
    ymaps?: {
      Map: new (...args: unknown[]) => {
        destroy?: () => void;
        geoObjects: {
          add: (value: unknown) => void;
        };
      };
      Placemark: new (...args: unknown[]) => unknown;
      ready: (callback: () => void) => void;
    };
  }
}

interface DetailMapProps {
  coordinates: [number, number] | null;
  apiKey?: string;
}

export function DetailMap({ coordinates, apiKey }: DetailMapProps) {
  const mapId = useId().replace(/:/g, "");
  const mapRef = useRef<{ destroy?: () => void } | null>(null);

  useEffect(() => {
    if (!coordinates || !apiKey) {
      return undefined;
    }

    let isCancelled = false;

    const mountMap = (): void => {
      const ymaps = window.ymaps;
      if (!ymaps) {
        return;
      }

      ymaps.ready(() => {
        if (isCancelled) {
          return;
        }

        mapRef.current?.destroy?.();

        const map = new ymaps.Map(
          mapId,
          {
            center: [coordinates[1], coordinates[0]],
            zoom: 13,
          },
          { searchControlProvider: "yandex#search" },
        );

        const placemark = new ymaps.Placemark([coordinates[1], coordinates[0]], null, {
          preset: "islands#redDotIcon",
        });

        map.geoObjects.add(placemark);
        mapRef.current = map;
      });
    };

    if (window.ymaps) {
      mountMap();
    } else {
      const existingScript = document.getElementById("yandex-maps-script") as HTMLScriptElement | null;

      if (existingScript) {
        existingScript.addEventListener("load", mountMap, { once: true });
      } else {
        const script = document.createElement("script");
        script.id = "yandex-maps-script";
        script.src = `https://api-maps.yandex.ru/2.1?apikey=${encodeURIComponent(apiKey)}&load=package.standard&lang=ru_RU`;
        script.async = true;
        script.addEventListener("load", mountMap, { once: true });
        document.body.appendChild(script);
      }
    }

    return () => {
      isCancelled = true;
      mapRef.current?.destroy?.();
      mapRef.current = null;
    };
  }, [apiKey, coordinates, mapId]);

  if (!coordinates || !apiKey) {
    return <div className="detail-map detail-map--empty" aria-label="Карта" />;
  }

  return <div id={mapId} className="detail-map" />;
}

