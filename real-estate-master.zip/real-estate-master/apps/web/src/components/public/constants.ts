export const DISTRICT_OPTIONS = [
  { value: "ЦАО", label: "Центральный" },
  { value: "САО", label: "Северный" },
  { value: "СВАО", label: "Северо-Восточный" },
  { value: "ВАО", label: "Восточный" },
  { value: "ЮВАО", label: "Юго-Восточный" },
  { value: "ЮАО", label: "Южный" },
  { value: "ЮЗАО", label: "Юго-Западный" },
  { value: "ЗАО", label: "Западный" },
  { value: "СЗАО", label: "Северо-Западный" },
  { value: "Зеленоградский", label: "Зеленоградский" },
  { value: "ТиНао", label: "Троицкий-Новомосковский" },
] as const;
