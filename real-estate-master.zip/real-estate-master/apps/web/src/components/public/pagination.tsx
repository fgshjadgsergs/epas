﻿import Link from "next/link";

interface PaginationProps {
  page: number;
  perPage: number;
  totalCount: number;
  createHref: (page: number) => string;
}

function getTotalPages(totalCount: number, perPage: number): number {
  return Math.max(1, Math.ceil(totalCount / perPage));
}

function buildPages(currentPage: number, totalPages: number): number[] {
  const pages = new Set<number>();
  for (let page = currentPage - 2; page <= currentPage + 2; page += 1) {
    if (page >= 1 && page <= totalPages) {
      pages.add(page);
    }
  }

  pages.add(1);
  pages.add(totalPages);

  return [...pages].sort((left, right) => left - right);
}

export function Pagination({ page, perPage, totalCount, createHref }: PaginationProps) {
  const totalPages = getTotalPages(totalCount, perPage);
  if (totalPages <= 1) {
    return null;
  }

  const pages = buildPages(page, totalPages);

  return (
    <footer className="section-footer d-flex justify-content-center">
      <div className="btn-toolbar mb-0 me-3" role="toolbar">
        <div className="btn-group me-2" role="group">
          {page > 1 ? (
            <Link href={createHref(page - 1)} className="btn btn-outline-primary btn-default btn-sm px-3">
              Предыдущая
            </Link>
          ) : null}
          {pages.map((item) => (
            <Link
              key={item}
              href={createHref(item)}
              className={`btn btn-outline-primary btn-default btn-sm px-3${item === page ? " active" : ""}`}
            >
              {item}
            </Link>
          ))}
          {page < totalPages ? (
            <Link href={createHref(page + 1)} className="btn btn-outline-primary btn-default btn-sm px-3">
              Следующая
            </Link>
          ) : null}
        </div>
      </div>
    </footer>
  );
}

