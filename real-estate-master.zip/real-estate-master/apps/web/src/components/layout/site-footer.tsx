﻿export function SiteFooter() {
  return (
    <footer>
      <div id="footer-bottom-1" className="section py-3 footer-bottom">
        <div className="container-xl position-relative">
          <div className="row section-content">
            <div className="col-12 col-md-7 offset-md-5 col-lg-8 offset-lg-4 text-center text-md-start">
              <p className="fs-sm mb-0">&copy; 2025 EPAS Development. All Rights Reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

