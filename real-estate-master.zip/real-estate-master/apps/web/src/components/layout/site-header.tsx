﻿"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

function createListingHref(dealType: string, title: string): string {
  const params = new URLSearchParams({
    deal_type: dealType,
    title,
  });

  return `/listing?${params.toString()}`;
}

export function SiteHeader() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    document.body.classList.toggle("header-drawer-open", isOpen);

    return () => {
      document.body.classList.remove("header-drawer-open");
    };
  }, [isOpen]);

  const toggleDrawer = (): void => {
    setIsOpen((value) => !value);
  };

  const closeDrawer = (): void => {
    setIsOpen(false);
  };

  return (
    <>
      <header className="header">
        <div className="header__inner container-xl">
          <Link href="/" className="header__logo">
            <span className="header__logo-mark">Эпас</span>
            <span className="header__logo-text">Девелопмент</span>
          </Link>

          <nav className="header__nav" aria-label="Навигация">
            <Link className="header__link" href={createListingHref("аренда", "Аренда")}>
              Аренда
            </Link>
            <Link className="header__link" href={createListingHref("продажа", "Продажа")}>
              Продажа
            </Link>
            <Link className="header__link" href={createListingHref("арендный бизнес", "Арендный бизнес")}>
              Арендный бизнес
            </Link>
          </nav>

          <div className="header__actions">
            <a href="tel:+79990016588" className="header__phone">
              +7 (999) 001-65-88
            </a>
            <a href="#callback" className="btn btn--ghost" data-bs-toggle="modal" data-bs-target="#userSignInModal">
              Заявка
            </a>
          </div>

          <button className="header__burger" type="button" aria-label="Открыть меню" aria-expanded={isOpen} onClick={toggleDrawer}>
            <span className="header__burger-lines" aria-hidden="true" />
          </button>
        </div>
      </header>

      <div className={`header__drawer${isOpen ? " is-open" : ""}`} aria-hidden={!isOpen} onClick={closeDrawer}>
        <div className="header__drawer-panel" onClick={(event) => event.stopPropagation()}>
          <div className="header__drawer-top">
            <div className="header__drawer-title">Меню</div>
            <button className="header__drawer-close" type="button" aria-label="Закрыть меню" onClick={closeDrawer}>
              &times;
            </button>
          </div>

          <nav className="header__drawer-nav" aria-label="Навигация (мобильно)">
            <Link className="header__drawer-link" href={createListingHref("аренда", "Аренда")} onClick={closeDrawer}>
              Аренда
            </Link>
            <Link className="header__drawer-link" href={createListingHref("продажа", "Продажа")} onClick={closeDrawer}>
              Продажа
            </Link>
            <Link className="header__drawer-link" href={createListingHref("арендный бизнес", "Арендный бизнес")} onClick={closeDrawer}>
              Арендный бизнес
            </Link>
          </nav>

          <div className="header__drawer-actions">
            <a href="tel:+79990016588" className="header__drawer-phone">
              +7 (999) 001-65-88
            </a>
            <a
              href="#callback"
              className="btn btn--ghost w-100"
              data-bs-toggle="modal"
              data-bs-target="#userSignInModal"
              onClick={closeDrawer}
            >
              Заявка
            </a>
          </div>
        </div>
      </div>
    </>
  );
}

