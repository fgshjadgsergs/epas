﻿export function RequestModal() {
  return (
    <div className="modal fade" id="userSignInModal" tabIndex={-1}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content lux-modal-content">
          <button type="button" className="lux-modal__close" data-bs-dismiss="modal">
            &times;
          </button>

          <div className="lux-modal__header">
            <h3>Оставить заявку</h3>
            <p>Мы подберем объект под ваши требования</p>
          </div>

          <form className="lux-form">
            <div className="lux-form__group">
              <input type="tel" required placeholder=" " />
              <label>Номер телефона *</label>
            </div>

            <div className="lux-form__group">
              <input type="text" required placeholder=" " />
              <label>ФИО *</label>
            </div>

            <div className="lux-form__group">
              <textarea rows={3} placeholder=" " />
              <label>Расскажите об объекте, который ищете</label>
            </div>

            <button type="submit" className="lux-form__submit">
              Отправить заявку
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

