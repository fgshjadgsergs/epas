import { NextRequest, NextResponse } from "next/server";
import { CRM_INTERNAL_PREFIX, crmInternalPath, isCrmBypassPath, isCrmHost } from "@/lib/crm-routes";

function getRequestHost(request: NextRequest): string | null {
  return request.headers.get("x-forwarded-host") ?? request.headers.get("host");
}

function readUserAgent(request: NextRequest): string {
  return (request.headers.get("user-agent") ?? "-").replace(/\s+/g, " ").slice(0, 180);
}

function isSafariUserAgent(userAgent: string): boolean {
  return /safari/i.test(userAgent) && !/(chrome|chromium|android|crios|fxios|edgios)/i.test(userAgent);
}

function withDebugHeader(response: NextResponse, value: string): NextResponse {
  response.headers.set("x-debug-rewrite", value);
  return response;
}

export function middleware(request: NextRequest) {
  const host = getRequestHost(request);
  const { pathname } = request.nextUrl;
  const crmHost = isCrmHost(host);
  const isCrmPath = pathname === "/crm" || pathname.startsWith("/crm/");
  const userAgent = readUserAgent(request);
  const safari = isSafariUserAgent(userAgent);

  console.log(
    `[crm-middleware] host=${host ?? "-"} pathname=${pathname} crmHost=${crmHost} safari=${safari}${safari ? ` ua=${userAgent}` : ""}`,
  );

  if (pathname.startsWith(CRM_INTERNAL_PREFIX)) {
    if (crmHost) {
      return withDebugHeader(NextResponse.next(), `next:${pathname}`);
    }

    return withDebugHeader(new NextResponse("Not Found", { status: 404 }), `blocked-internal:${pathname}`);
  }

  if (isCrmPath && !crmHost) {
    return withDebugHeader(new NextResponse("Not Found", { status: 404 }), `blocked-public-crm:${pathname}`);
  }

  if (!crmHost || isCrmBypassPath(pathname)) {
    return NextResponse.next();
  }

  const url = request.nextUrl.clone();
  url.pathname = crmInternalPath(pathname);
  console.log(`[crm-middleware] rewrite ${pathname} -> ${url.pathname}`);
  return withDebugHeader(NextResponse.rewrite(url), `${pathname}->${url.pathname}`);
}

export const config = {
  matcher: ["/crm/:path*", "/crm-app/:path*", "/((?!api|_next|static|storage|favicon.ico|robots.txt|sitemap.xml).*)"],
};
