import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  images: {
    unoptimized: true,
  },
  async rewrites() {
    const apiBaseUrl =
      process.env.ESTATE_API_BASE_URL ?? process.env.NEXT_PUBLIC_ESTATE_API_BASE_URL ?? "http://127.0.0.1:3000";
    const storageBaseUrl = process.env.ESTATE_STORAGE_BASE_URL ?? apiBaseUrl;

    return [
      {
        source: "/api/v1/:path*",
        destination: `${apiBaseUrl}/api/v1/:path*`,
      },
      {
        source: "/storage/:path*",
        destination: `${storageBaseUrl}/storage/:path*`,
      },
    ];
  },
};

export default nextConfig;
