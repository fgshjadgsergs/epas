(function () {
  function clamp(i, n) { return (i + n) % n; }

  function initOne(frame) {
    if (frame.__galleryInited) return;
    frame.__galleryInited = true;

    const img = frame.querySelector(".card-gallery__img");
    const prev = frame.querySelector(".card-gallery__btn--prev");
    const next = frame.querySelector(".card-gallery__btn--next");
    const dotsWrap = frame.querySelector(".card-gallery__dots");

    if (!img) return;

    let images = [];
    try {
      images = JSON.parse(frame.getAttribute("data-images") || "[]");
    } catch (e) {
      images = [];
    }

    // Если реально одна картинка — стрелки не нужны
    if (!images || images.length <= 1) {
      if (prev) prev.style.display = "none";
      if (next) next.style.display = "none";
      if (dotsWrap) dotsWrap.style.display = "none";
      return;
    }

    let idx = 0;

    if (dotsWrap) {
      dotsWrap.innerHTML = images.map((_, i) =>
        `<span class="card-gallery__dot${i === 0 ? " is-active" : ""}"></span>`
      ).join("");
    }
    const dots = dotsWrap ? Array.from(dotsWrap.querySelectorAll(".card-gallery__dot")) : [];

    function render() {
      img.src = images[idx];
      dots.forEach((d, i) => d.classList.toggle("is-active", i === idx));
    }

    function go(delta) {
      idx = clamp(idx + delta, images.length);
      render();
    }

    prev && prev.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); go(-1); });
    next && next.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); go(+1); });

    render();
  }

  function initAll() {
    document.querySelectorAll(".js-card-gallery .card-gallery__frame").forEach(initOne);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAll);
  } else {
    initAll();
  }
})();
