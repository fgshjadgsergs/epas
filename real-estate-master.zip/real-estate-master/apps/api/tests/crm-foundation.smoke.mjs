import assert from "node:assert/strict";
import { startTestApp } from "./helpers/app.mjs";
import { CookieClient } from "./helpers/http.mjs";

const shouldRun = process.env.RUN_DB_SMOKE_TESTS === "1";

function uniqueEmail(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}@example.com`;
}

function createEstatePayload(title, overrides = {}) {
  return {
    title,
    description: "Smoke CRM foundation estate",
    area_description: "",
    internal_info: "",
    status: "",
    tags: "",
    estate_type: "",
    deal_type: "Продажа",
    area: 80,
    floor: 2,
    all_floors: 10,
    price: 11000000,
    region: "Москва",
    district: "ЦАО",
    metro_station: "Арбатская",
    priority: false,
    active: true,
    owner_type: "Собственник",
    owner_contacts: [],
    required_owner_phone: "+79990000111",
    required_owner_name: "Smoke Owner",
    not_define_coordinates: true,
    ...overrides,
  };
}

function createGarageCianPayload() {
  return {
    include: true,
    type: "Гараж",
    owner_contacts: [{ code: "+7", number: "9990000042" }],
    garage_type: "Гараж",
  };
}

function toExistingImages(images) {
  return images.map((image) => ({
    id: image.id,
    is_main: image.is_main,
  }));
}

async function login(client, username, password, expectedStatus = 201) {
  const response = await client.fetch("/api/v1/crm/auth/login", {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify({
      username,
      password,
    }),
  });

  assert.equal(response.status, expectedStatus);
  return response;
}

async function createUser(client, email) {
  const response = await client.fetch("/api/v1/crm/users", {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify({
      email,
      password: "123456789",
      first_name: "Foundation",
      last_name: "Smoke",
      phone_number: "+79990000112",
      is_admin: false,
    }),
  });
  assert.equal(response.status, 201);
  return response.json();
}

async function createEstate(client, payload) {
  const response = await client.fetch("/api/v1/crm/estates", {
    method: "POST",
    body: (() => {
      const form = new FormData();
      form.set("data", JSON.stringify(payload));
      form.append("new_images", new Blob([Buffer.from("image-bytes")], { type: "image/jpeg" }), "smoke.jpg");
      return form;
    })(),
  });
  assert.equal(response.status, 201);
  return response.json();
}

async function updateEstate(client, estateId, payload) {
  const response = await client.fetch(`/api/v1/crm/estates/${estateId}`, {
    method: "PUT",
    body: (() => {
      const form = new FormData();
      form.set("data", JSON.stringify(payload));
      return form;
    })(),
  });
  assert.equal(response.status, 200);
  return response.json();
}

async function safeDelete(client, path) {
  try {
    await client.fetch(path, { method: "DELETE" });
  } catch {
    // Best-effort cleanup only.
  }
}

export async function runCrmFoundationSmoke() {
  if (!shouldRun) {
    return {
      name: "crm-foundation",
      status: "skipped",
      reason: "RUN_DB_SMOKE_TESTS is not enabled",
    };
  }

  const { app, baseUrl } = await startTestApp();
  const adminClient = new CookieClient(baseUrl);
  const userClient = new CookieClient(baseUrl);

  const adminEmail = process.env.CRM_SMOKE_USERNAME ?? process.env.DEFAULT_ADMIN_EMAIL ?? "admin@gmail.com";
  const adminPassword = process.env.CRM_SMOKE_PASSWORD ?? process.env.DEFAULT_ADMIN_PASSWORD ?? "123456789";

  let userId = null;
  let adminEstateId = null;
  let userEstateId = null;

  try {
    await login(adminClient, adminEmail, adminPassword);

    const createdUser = await createUser(adminClient, uniqueEmail("crm-foundation-user"));
    userId = createdUser.item.id;
    await login(userClient, createdUser.item.email, "123456789");

    const adminEstate = await createEstate(adminClient, createEstatePayload(`foundation-admin-${Date.now()}`));
    adminEstateId = adminEstate.item.id;

    const userEstate = await createEstate(
      userClient,
      createEstatePayload(`foundation-user-${Date.now()}`, {
        deal_type: "Аренда",
        price: 250000,
      }),
    );
    userEstateId = userEstate.item.id;

    const adminList = await adminClient.fetch(`/api/v1/crm/estates?search=${encodeURIComponent("foundation-user")}`);
    assert.equal(adminList.status, 200);
    const adminListJson = await adminList.json();
    assert.ok(adminListJson.items.some((item) => item.id === userEstateId));
    assert.equal(adminListJson.filters.search.includes("foundation-user"), true);

    const filteredAdminList = await adminClient.fetch(
      `/api/v1/crm/estates?deal_type=${encodeURIComponent("Аренда")}&limit=1&skip=0`,
    );
    assert.equal(filteredAdminList.status, 200);
    const filteredAdminListJson = await filteredAdminList.json();
    assert.equal(filteredAdminListJson.limit, 1);
    assert.ok(filteredAdminListJson.total >= 1);
    assert.ok(filteredAdminListJson.items.every((item) => item.deal_type === "Аренда"));

    const forbiddenAdminList = await userClient.fetch("/api/v1/crm/estates");
    assert.equal(forbiddenAdminList.status, 403);

    const myList = await userClient.fetch(`/api/v1/crm/estates/my?deal_type=${encodeURIComponent("Аренда")}&limit=10`);
    assert.equal(myList.status, 200);
    const myListJson = await myList.json();
    assert.ok(myListJson.items.every((item) => item.user_id === userId));
    assert.ok(myListJson.items.some((item) => item.id === userEstateId));

    const metaResponse = await adminClient.fetch("/api/v1/crm/meta");
    assert.equal(metaResponse.status, 200);
    const metaJson = await metaResponse.json();
    assert.ok(metaJson.estate.form.choice_fields.deal_type.includes("Продажа"));
    assert.ok(metaJson.cian.choice_fields.type.includes("Гараж"));
    assert.ok(metaJson.estate.list.supported_filters.includes("cian_included"));

    const userMetaResponse = await userClient.fetch("/api/v1/crm/meta");
    assert.equal(userMetaResponse.status, 200);

    const updatedUserEstate = await updateEstate(userClient, userEstateId, {
      ...createEstatePayload(`foundation-user-moderation-${Date.now()}`, {
        deal_type: "Аренда",
        price: 260000,
      }),
      owner_contacts: userEstate.item.owner_contacts,
      existing_images: toExistingImages(userEstate.item.images),
      cian: createGarageCianPayload(),
    });
    assert.equal(updatedUserEstate.item.cian.include, true);

    const moderationList = await adminClient.fetch(`/api/v1/crm/estates/moderation?search=${encodeURIComponent("foundation-user-moderation")}`);
    assert.equal(moderationList.status, 200);
    const moderationListJson = await moderationList.json();
    assert.ok(moderationListJson.items.some((item) => item.id === userEstateId));

    const forbiddenModeration = await userClient.fetch("/api/v1/crm/estates/moderation");
    assert.equal(forbiddenModeration.status, 403);

    const confirmModeration = await adminClient.fetch("/api/v1/crm/cian/moderation/confirm", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        estate_ids: [userEstateId],
      }),
    });
    assert.equal(confirmModeration.status, 201);

    const uploadList = await adminClient.fetch(`/api/v1/crm/estates/upload?search=${encodeURIComponent("foundation-user-moderation")}`);
    assert.equal(uploadList.status, 200);
    const uploadListJson = await uploadList.json();
    assert.ok(uploadListJson.items.some((item) => item.id === userEstateId));

    const forbiddenUpload = await userClient.fetch("/api/v1/crm/estates/upload");
    assert.equal(forbiddenUpload.status, 403);

    const forbiddenCoordinateLookup = await userClient.fetch(`/api/v1/crm/estates/${adminEstateId}/actions/define-coordinates`, {
      method: "POST",
    });
    assert.equal(forbiddenCoordinateLookup.status, 403);

    const adminCoordinateLookup = await adminClient.fetch(`/api/v1/crm/estates/${adminEstateId}/actions/define-coordinates`, {
      method: "POST",
    });
    assert.ok([200, 400].includes(adminCoordinateLookup.status));
    const adminCoordinateLookupJson = await adminCoordinateLookup.json();
    if (adminCoordinateLookup.status === 200) {
      assert.equal(adminCoordinateLookupJson.item.id, adminEstateId);
      assert.equal(typeof adminCoordinateLookupJson.message, "string");
    } else {
      assert.equal(typeof adminCoordinateLookupJson.errors.coordinates, "string");
    }

    return {
      name: "crm-foundation",
      status: "passed",
    };
  } finally {
    if (userEstateId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/estates/${userEstateId}`);
    }
    if (adminEstateId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/estates/${adminEstateId}`);
    }
    if (userId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/users/${userId}`);
    }
    await app.close();
  }
}
