import assert from "node:assert/strict";
import { startTestApp } from "./helpers/app.mjs";
import { CookieClient } from "./helpers/http.mjs";

const shouldRun = process.env.RUN_DB_SMOKE_TESTS === "1";

function getErrors(body) {
  return body.errors ?? body.message?.errors ?? {};
}

function createEstatePayload(title) {
  return {
    title,
    description: "Smoke estate description",
    area_description: "",
    internal_info: "",
    status: "",
    tags: "",
    estate_type: "",
    deal_type: "Продажа",
    area: 100,
    floor: 1,
    all_floors: 10,
    levels_count: 2,
    occupied_floors_text: "1–2 этажи",
    price: 1000000,
    region: "Москва",
    district: "ЦАО",
    metro_station: "Арбатская",
    priority: false,
    active: true,
    owner_type: "Собственник",
    owner_contacts: [],
    required_owner_phone: "+79990000000",
    required_owner_name: "Smoke Owner",
    not_define_coordinates: true,
  };
}

async function login(client) {
  const response = await client.fetch("/api/v1/crm/auth/login", {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify({
      username: process.env.CRM_SMOKE_USERNAME ?? "admin@gmail.com",
      password: process.env.CRM_SMOKE_PASSWORD ?? "123456789",
    }),
  });

  assert.equal(response.status, 201);
}

export async function runCrmEstateSmoke() {
  if (!shouldRun) {
    return {
      name: "crm-estates",
      status: "skipped",
      reason: "RUN_DB_SMOKE_TESTS is not enabled",
    };
  }

  const { app, baseUrl } = await startTestApp();
  const client = new CookieClient(baseUrl);

  try {
    await login(client);

    const rentBusinessValidation = await client.fetch("/api/v1/crm/estates", {
      method: "POST",
      body: (() => {
        const form = new FormData();
        form.set("data", JSON.stringify({
          ...createEstatePayload(`rent-business-${Date.now()}`),
          deal_type: "Арендный бизнес",
        }));
        form.append("new_images", new Blob([Buffer.from("image-bytes")], { type: "image/jpeg" }), "one.jpg");
        return form;
      })(),
    });
    assert.equal(rentBusinessValidation.status, 400);
    const rentBusinessJson = await rentBusinessValidation.json();
    assert.equal(getErrors(rentBusinessJson).tenant_type, "Обязательно если арендный бизнес");
    assert.equal(getErrors(rentBusinessJson).map_, "Обязательно если арендный бизнес");

    const title = `node-smoke-${Date.now()}`;
    const createResponse = await client.fetch("/api/v1/crm/estates", {
      method: "POST",
      body: (() => {
        const form = new FormData();
        form.set("data", JSON.stringify(createEstatePayload(title)));
        form.append("new_images", new Blob([Buffer.from("image-bytes")], { type: "image/jpeg" }), "one.jpg");
        return form;
      })(),
    });
    assert.equal(createResponse.status, 201);
    const createJson = await createResponse.json();
    assert.equal(createJson.item.title, title);
    assert.equal(createJson.item.images.length, 1);
    assert.equal(createJson.item.images[0].is_main, true);
    assert.equal(createJson.item.levels_count, 2);
    assert.equal(createJson.item.occupied_floors_text, "1–2 этажи");

    const estateId = createJson.item.id;
    const updatePayload = {
      ...createEstatePayload(`${title}-updated`),
      owner_contacts: createJson.item.owner_contacts,
      existing_images: createJson.item.images.map((image) => ({
        id: image.id,
        is_main: image.is_main,
      })),
    };

    const updateResponse = await client.fetch(`/api/v1/crm/estates/${estateId}`, {
      method: "PUT",
      body: (() => {
        const form = new FormData();
        form.set("data", JSON.stringify(updatePayload));
        return form;
      })(),
    });
    assert.equal(updateResponse.status, 200);
    const updateJson = await updateResponse.json();
    assert.equal(updateJson.item.title, `${title}-updated`);
    assert.equal(updateJson.item.levels_count, 2);
    assert.equal(updateJson.item.occupied_floors_text, "1–2 этажи");

    const detailResponse = await client.fetch(`/api/v1/crm/estates/${estateId}`);
    assert.equal(detailResponse.status, 200);
    const detailJson = await detailResponse.json();
    assert.equal(detailJson.item.id, estateId);
    assert.equal(detailJson.item.levels_count, 2);
    assert.equal(detailJson.item.occupied_floors_text, "1–2 этажи");

    const deleteResponse = await client.fetch(`/api/v1/crm/estates/${estateId}`, {
      method: "DELETE",
    });
    assert.equal(deleteResponse.status, 200);

    return {
      name: "crm-estates",
      status: "passed",
    };
  } finally {
    await app.close();
  }
}
