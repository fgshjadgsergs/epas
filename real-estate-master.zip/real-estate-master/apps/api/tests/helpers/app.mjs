export async function startTestApp() {
  const moduleUrl = new URL("../../dist/app.factory.js", import.meta.url);
  const { createApp } = await import(moduleUrl.href);
  const app = await createApp();
  await app.listen(0);

  const server = app.getHttpServer();
  const address = server.address();
  const port = typeof address === "object" && address ? address.port : 3000;

  return {
    app,
    baseUrl: `http://127.0.0.1:${port}`,
  };
}
