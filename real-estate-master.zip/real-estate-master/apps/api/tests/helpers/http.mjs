export class CookieClient {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
    this.cookieHeader = "";
  }

  async fetch(path, init = {}) {
    const headers = new Headers(init.headers ?? {});
    if (this.cookieHeader) {
      headers.set("cookie", this.cookieHeader);
    }

    const response = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers,
    });

    const setCookies = typeof response.headers.getSetCookie === "function"
      ? response.headers.getSetCookie()
      : response.headers.get("set-cookie")
        ? [response.headers.get("set-cookie")]
        : [];

    if (setCookies.length > 0) {
      this.cookieHeader = setCookies.map((cookie) => cookie.split(";")[0]).join("; ");
    }

    return response;
  }
}
