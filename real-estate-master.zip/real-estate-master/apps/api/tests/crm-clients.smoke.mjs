import assert from "node:assert/strict";
import { arePhoneNumbersEquivalent, normalizePhone } from "../dist/common/utils/phone.utils.js";

export async function runCrmClientsSmoke() {
  const variants = [
    "+7 916 123-45-67",
    "8 (916) 123-45-67",
    "79161234567",
    "9161234567",
  ];

  for (const phone of variants) {
    assert.equal(normalizePhone(phone), "79161234567");
    assert.equal(arePhoneNumbersEquivalent(variants[0], phone), true);
  }

  assert.equal(normalizePhone("+49 (30) 123-456"), "4930123456");
  assert.equal(normalizePhone("  "), null);
  assert.equal(arePhoneNumbersEquivalent(null, null), false);

  return { name: "crm-clients-phone", status: "passed" };
}