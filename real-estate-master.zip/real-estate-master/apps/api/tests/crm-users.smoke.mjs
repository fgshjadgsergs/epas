import assert from "node:assert/strict";
import { startTestApp } from "./helpers/app.mjs";
import { CookieClient } from "./helpers/http.mjs";

const shouldRun = process.env.RUN_DB_SMOKE_TESTS === "1";

function getErrors(body) {
  return body.errors ?? body.message?.errors ?? {};
}

function uniqueEmail(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}@example.com`;
}

function createUserPayload(email, overrides = {}) {
  return {
    email,
    password: "123456789",
    first_name: "Smoke",
    last_name: "User",
    phone_number: "+79990000000",
    is_admin: false,
    ...overrides,
  };
}

function createEstatePayload(title) {
  return {
    title,
    description: "Smoke estate for user delete parity",
    area_description: "",
    internal_info: "",
    status: "",
    tags: "",
    estate_type: "",
    deal_type: "Продажа",
    area: 87,
    floor: 3,
    all_floors: 12,
    price: 14500000,
    region: "Москва",
    district: "ЦАО",
    metro_station: "Арбатская",
    priority: false,
    active: true,
    owner_type: "Собственник",
    owner_contacts: [],
    required_owner_phone: "+79990000010",
    required_owner_name: "Smoke Owner",
    not_define_coordinates: true,
  };
}

async function login(client, username, password, expectedStatus = 201) {
  const response = await client.fetch("/api/v1/crm/auth/login", {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify({
      username,
      password,
    }),
  });

  assert.equal(response.status, expectedStatus);
  return response;
}

async function safeDelete(client, path) {
  try {
    await client.fetch(path, { method: "DELETE" });
  } catch {
    // Best-effort cleanup only.
  }
}

export async function runCrmUsersSmoke() {
  if (!shouldRun) {
    return {
      name: "crm-users",
      status: "skipped",
      reason: "RUN_DB_SMOKE_TESTS is not enabled",
    };
  }

  const { app, baseUrl } = await startTestApp();
  const adminClient = new CookieClient(baseUrl);
  const userClient = new CookieClient(baseUrl);
  const otherUserClient = new CookieClient(baseUrl);

  const adminEmail = process.env.CRM_SMOKE_USERNAME ?? process.env.DEFAULT_ADMIN_EMAIL ?? "admin@gmail.com";
  const adminPassword = process.env.CRM_SMOKE_PASSWORD ?? process.env.DEFAULT_ADMIN_PASSWORD ?? "123456789";
  const bufferEmail = process.env.DEFAULT_ADMIN_EMAIL ?? adminEmail;

  let userAId = null;
  let userBId = null;
  let estateId = null;

  try {
    await login(adminClient, adminEmail, adminPassword);

    const createValidation = await adminClient.fetch("/api/v1/crm/users", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        email: "",
        password: "123",
        first_name: "",
        last_name: "",
        phone_number: "",
        is_admin: false,
      }),
    });
    assert.equal(createValidation.status, 400);
    const createValidationJson = await createValidation.json();
    assert.equal(getErrors(createValidationJson).email, "Field is required");
    assert.equal(getErrors(createValidationJson).password, "Пароль должен быть не меньше 9 символов");

    const emailA = uniqueEmail("crm-user-a");
    const createA = await adminClient.fetch("/api/v1/crm/users", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(createUserPayload(emailA)),
    });
    assert.equal(createA.status, 201);
    const createAJson = await createA.json();
    userAId = createAJson.item.id;
    assert.equal(createAJson.item.email, emailA);
    assert.ok(createAJson.parity.exact.length > 0);

    const duplicateCreate = await adminClient.fetch("/api/v1/crm/users", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(createUserPayload(emailA)),
    });
    assert.equal(duplicateCreate.status, 400);
    const duplicateCreateJson = await duplicateCreate.json();
    assert.equal(getErrors(duplicateCreateJson).email, "Email is already in use");

    const emailB = uniqueEmail("crm-user-b");
    const createB = await adminClient.fetch("/api/v1/crm/users", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(createUserPayload(emailB, { first_name: "Second" })),
    });
    assert.equal(createB.status, 201);
    const createBJson = await createB.json();
    userBId = createBJson.item.id;

    const listResponse = await adminClient.fetch(`/api/v1/crm/users?search=${encodeURIComponent(emailA)}`);
    assert.equal(listResponse.status, 200);
    const listJson = await listResponse.json();
    assert.ok(listJson.items.some((item) => item.email === emailA));

    const detailResponse = await adminClient.fetch(`/api/v1/crm/users/${userAId}`);
    assert.equal(detailResponse.status, 200);
    const detailJson = await detailResponse.json();
    assert.equal(detailJson.item.id, userAId);

    await login(userClient, emailA, "123456789");

    const forbiddenList = await userClient.fetch("/api/v1/crm/users");
    assert.equal(forbiddenList.status, 403);

    const forbiddenPassword = await userClient.fetch(`/api/v1/crm/users/${userBId}/change-password`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        password: "987654321",
        repeat_password: "987654321",
      }),
    });
    assert.equal(forbiddenPassword.status, 403);

    const profileValidation = await userClient.fetch("/api/v1/crm/profile", {
      method: "PUT",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        email: emailA,
        first_name: "",
        last_name: "",
        phone_number: "",
      }),
    });
    assert.equal(profileValidation.status, 400);
    const profileValidationJson = await profileValidation.json();
    assert.equal(getErrors(profileValidationJson).first_name, "Field is required");
    assert.equal(getErrors(profileValidationJson).last_name, "Field is required");
    assert.equal(getErrors(profileValidationJson).phone_number, "Field is required");

    const createEstateResponse = await userClient.fetch("/api/v1/crm/estates", {
      method: "POST",
      body: (() => {
        const form = new FormData();
        form.set("data", JSON.stringify(createEstatePayload(`user-delete-${Date.now()}`)));
        form.append("new_images", new Blob([Buffer.from("image-bytes")], { type: "image/jpeg" }), "user.jpg");
        return form;
      })(),
    });
    assert.equal(createEstateResponse.status, 201);
    const createEstateJson = await createEstateResponse.json();
    estateId = createEstateJson.item.id;

    const updatedEmailA = uniqueEmail("crm-user-a-renamed");
    const profileUpdate = await userClient.fetch("/api/v1/crm/profile", {
      method: "PUT",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        email: updatedEmailA,
        first_name: "Updated",
        last_name: "Profile",
        phone_number: "+79990000011",
      }),
    });
    assert.equal(profileUpdate.status, 200);
    const profileUpdateJson = await profileUpdate.json();
    assert.equal(profileUpdateJson.item.email, updatedEmailA);
    assert.ok(profileUpdateJson.parity.exact.some((note) => note.includes("self-email change invalidates")));

    const meAfterEmailChange = await userClient.fetch("/api/v1/crm/auth/me");
    assert.equal(meAfterEmailChange.status, 401);

    await login(userClient, updatedEmailA, "123456789");

    const selfPasswordChange = await userClient.fetch("/api/v1/crm/profile/change-password", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        password: "987654321",
        repeat_password: "987654321",
      }),
    });
    assert.equal(selfPasswordChange.status, 201);
    const selfPasswordChangeJson = await selfPasswordChange.json();
    assert.equal(selfPasswordChangeJson.message, "Пароль успешно изменен");

    const meAfterPasswordChange = await userClient.fetch("/api/v1/crm/auth/me");
    assert.equal(meAfterPasswordChange.status, 401);

    await login(userClient, updatedEmailA, "987654321");

    const updateB = await adminClient.fetch(`/api/v1/crm/users/${userBId}`, {
      method: "PUT",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        email: emailB,
        first_name: "Second",
        last_name: "Updated",
        phone_number: "+79990000012",
        is_admin: true,
      }),
    });
    assert.equal(updateB.status, 200);
    const updateBJson = await updateB.json();
    assert.equal(updateBJson.item.is_admin, true);

    const duplicateUpdate = await adminClient.fetch(`/api/v1/crm/users/${userAId}`, {
      method: "PUT",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        email: emailB,
        first_name: "Dup",
        last_name: "User",
        phone_number: "+79990000013",
        is_admin: false,
      }),
    });
    assert.equal(duplicateUpdate.status, 400);
    const duplicateUpdateJson = await duplicateUpdate.json();
    assert.equal(getErrors(duplicateUpdateJson).email, "Email is already in use");

    const adminChangePassword = await adminClient.fetch(`/api/v1/crm/users/${userBId}/change-password`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        password: "555555555",
        repeat_password: "555555555",
      }),
    });
    assert.equal(adminChangePassword.status, 201);
    const adminChangePasswordJson = await adminChangePassword.json();
    assert.equal(adminChangePasswordJson.message, "Пароль успешно изменен");

    await login(otherUserClient, emailB, "555555555");

    const adminMe = await adminClient.fetch("/api/v1/crm/auth/me");
    assert.equal(adminMe.status, 200);
    const adminMeJson = await adminMe.json();
    const bufferUserId = adminMeJson.user.id;

    const deleteBuffer = await adminClient.fetch(`/api/v1/crm/users/${bufferUserId}`, {
      method: "DELETE",
    });
    assert.equal(deleteBuffer.status, 400);
    const deleteBufferJson = await deleteBuffer.json();
    assert.equal(deleteBufferJson.message, "You can't delete buffer user");

    const deleteA = await adminClient.fetch(`/api/v1/crm/users/${userAId}`, {
      method: "DELETE",
    });
    assert.equal(deleteA.status, 200);
    const deleteAJson = await deleteA.json();
    assert.equal(deleteAJson.deleted, true);
    assert.equal(deleteAJson.reassigned_estates, 1);
    userAId = null;

    const estateDetail = await adminClient.fetch(`/api/v1/crm/estates/${estateId}`);
    assert.equal(estateDetail.status, 200);
    const estateDetailJson = await estateDetail.json();
    assert.equal(estateDetailJson.item.user.email, bufferEmail);

    const deletedUserLogin = await login(new CookieClient(baseUrl), updatedEmailA, "987654321", 401);
    const deletedUserLoginJson = await deletedUserLogin.json();
    assert.equal(deletedUserLoginJson.message, "Invalid username or password");

    const deleteEstate = await adminClient.fetch(`/api/v1/crm/estates/${estateId}`, {
      method: "DELETE",
    });
    assert.equal(deleteEstate.status, 200);
    estateId = null;

    const deleteB = await adminClient.fetch(`/api/v1/crm/users/${userBId}`, {
      method: "DELETE",
    });
    assert.equal(deleteB.status, 200);
    userBId = null;

    return {
      name: "crm-users",
      status: "passed",
    };
  } finally {
    if (estateId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/estates/${estateId}`);
    }
    if (userAId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/users/${userAId}`);
    }
    if (userBId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/users/${userBId}`);
    }
    await app.close();
  }
}
