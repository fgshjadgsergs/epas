import { runCrmAuthSmoke } from "./crm-auth.smoke.mjs";
import { runCrmCianSmoke } from "./crm-cian.smoke.mjs";
import { runCrmClientsSmoke } from "./crm-clients.smoke.mjs";
import { runCrmEstateSmoke } from "./crm-estates.smoke.mjs";
import { runCrmFoundationSmoke } from "./crm-foundation.smoke.mjs";
import { runCrmUsersSmoke } from "./crm-users.smoke.mjs";

const runners = [
  runCrmAuthSmoke,
  runCrmClientsSmoke,
  runCrmEstateSmoke,
  runCrmUsersSmoke,
  runCrmCianSmoke,
  runCrmFoundationSmoke,
];
const results = [];

for (const run of runners) {
  try {
    const result = await run();
    results.push(result);
    if (result.status === "passed") {
      console.log(`PASS ${result.name}`);
    } else if (result.status === "skipped") {
      console.log(`SKIP ${result.name}: ${result.reason}`);
    } else {
      console.log(`FAIL ${result.name}: ${result.reason ?? "unknown"}`);
      process.exitCode = 1;
    }
  } catch (error) {
    console.error(`FAIL ${run.name}:`, error);
    process.exitCode = 1;
  }
}

if (results.length === 0) {
  console.log("No smoke tests were registered.");
}
