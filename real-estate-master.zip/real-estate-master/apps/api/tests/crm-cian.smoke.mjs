import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { startTestApp } from "./helpers/app.mjs";
import { CookieClient } from "./helpers/http.mjs";

const shouldRun = process.env.RUN_DB_SMOKE_TESTS === "1";

function uniqueEmail(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}@example.com`;
}

function getErrors(body) {
  return body.errors ?? body.message?.errors ?? {};
}

function createEstatePayload(title, overrides = {}) {
  return {
    title,
    description: "Smoke CIAN estate description",
    area_description: "",
    internal_info: "",
    status: "",
    tags: "",
    estate_type: "",
    deal_type: "Продажа",
    area: 120,
    floor: 2,
    all_floors: 9,
    price: 12500000,
    region: "Москва",
    district: "ЦАО",
    metro_station: "Арбатская",
    priority: false,
    active: true,
    owner_type: "Собственник",
    owner_contacts: [],
    required_owner_phone: "+79990000021",
    required_owner_name: "Smoke Owner",
    not_define_coordinates: true,
    ...overrides,
  };
}

function createGarageCianPayload(overrides = {}) {
  return {
    include: true,
    type: "Гараж",
    owner_contacts: [{ code: "+7", number: "9990000021" }],
    garage_type: "Гараж",
    ...overrides,
  };
}

function toExistingImages(images) {
  return images.map((image) => ({
    id: image.id,
    is_main: image.is_main,
  }));
}

async function login(client, username, password, expectedStatus = 201) {
  const response = await client.fetch("/api/v1/crm/auth/login", {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify({
      username,
      password,
    }),
  });

  assert.equal(response.status, expectedStatus);
  return response;
}

async function safeDelete(client, path) {
  try {
    await client.fetch(path, { method: "DELETE" });
  } catch {
    // Best-effort cleanup only.
  }
}

async function createUser(client, email) {
  const response = await client.fetch("/api/v1/crm/users", {
    method: "POST",
    headers: {
      "content-type": "application/json",
    },
    body: JSON.stringify({
      email,
      password: "123456789",
      first_name: "Smoke",
      last_name: "Cian",
      phone_number: "+79990000031",
      is_admin: false,
    }),
  });
  assert.equal(response.status, 201);
  return response.json();
}

async function createEstate(client, payload) {
  const response = await client.fetch("/api/v1/crm/estates", {
    method: "POST",
    body: (() => {
      const form = new FormData();
      form.set("data", JSON.stringify(payload));
      form.append("new_images", new Blob([Buffer.from("image-bytes")], { type: "image/jpeg" }), "one.jpg");
      return form;
    })(),
  });
  assert.equal(response.status, 201);
  return response.json();
}

async function updateEstate(client, estateId, payload, expectedStatus = 200) {
  const response = await client.fetch(`/api/v1/crm/estates/${estateId}`, {
    method: "PUT",
    body: (() => {
      const form = new FormData();
      form.set("data", JSON.stringify(payload));
      return form;
    })(),
  });
  assert.equal(response.status, expectedStatus);
  return response;
}

async function readGeneratedXml() {
  const storageRoot = process.env.STORAGE_LOCAL_ROOT ?? "storage";
  return readFile(join(storageRoot, "cian.xml"), "utf8");
}

export async function runCrmCianSmoke() {
  if (!shouldRun) {
    return {
      name: "crm-cian",
      status: "skipped",
      reason: "RUN_DB_SMOKE_TESTS is not enabled",
    };
  }

  const { app, baseUrl } = await startTestApp();
  const adminClient = new CookieClient(baseUrl);
  const userClient = new CookieClient(baseUrl);

  const adminEmail = process.env.CRM_SMOKE_USERNAME ?? process.env.DEFAULT_ADMIN_EMAIL ?? "admin@gmail.com";
  const adminPassword = process.env.CRM_SMOKE_PASSWORD ?? process.env.DEFAULT_ADMIN_PASSWORD ?? "123456789";

  let userId = null;
  let adminEstateId = null;
  let moderationEstateId = null;
  let removedModerationEstateId = null;

  try {
    await login(adminClient, adminEmail, adminPassword);

    const createdAdminEstate = await createEstate(adminClient, {
      ...createEstatePayload(`cian-create-${Date.now()}`),
      cian: createGarageCianPayload(),
    });
    adminEstateId = createdAdminEstate.item.id;
    assert.equal(createdAdminEstate.item.cian.include, false);
    assert.equal(createdAdminEstate.item.cian.type, null);

    const updatedAdminEstate = await updateEstate(adminClient, adminEstateId, {
      ...createEstatePayload(`cian-admin-${Date.now()}`),
      owner_contacts: createdAdminEstate.item.owner_contacts,
      existing_images: toExistingImages(createdAdminEstate.item.images),
      cian: createGarageCianPayload(),
    });
    const updatedAdminEstateJson = await updatedAdminEstate.json();
    assert.equal(updatedAdminEstateJson.item.cian.include, true);
    assert.equal(updatedAdminEstateJson.item.cian.type, "Гараж");
    assert.equal(updatedAdminEstateJson.parity.cian_edit_flow, "exact_for_edit_only_non_atomic_save_cian_flow");

    const invalidTitle = `cian-invalid-${Date.now()}`;
    const invalidUpdate = await updateEstate(adminClient, adminEstateId, {
      ...createEstatePayload(invalidTitle),
      owner_contacts: updatedAdminEstateJson.item.owner_contacts,
      existing_images: toExistingImages(updatedAdminEstateJson.item.images),
      cian: createGarageCianPayload({
        owner_contacts: [],
      }),
    }, 400);
    const invalidUpdateJson = await invalidUpdate.json();
    assert.equal(getErrors(invalidUpdateJson).cian.owner_contacts, "Укажите контакты");

    const detailAfterInvalid = await adminClient.fetch(`/api/v1/crm/estates/${adminEstateId}`);
    assert.equal(detailAfterInvalid.status, 200);
    const detailAfterInvalidJson = await detailAfterInvalid.json();
    assert.equal(detailAfterInvalidJson.item.title, invalidTitle);

    const createdUser = await createUser(adminClient, uniqueEmail("crm-cian-user"));
    userId = createdUser.item.id;
    await login(userClient, createdUser.item.email, "123456789");

    const moderationEstate = await createEstate(userClient, createEstatePayload(`cian-moderation-${Date.now()}`));
    moderationEstateId = moderationEstate.item.id;
    const removedModerationEstate = await createEstate(userClient, createEstatePayload(`cian-remove-${Date.now()}`));
    removedModerationEstateId = removedModerationEstate.item.id;

    const moderatedUpdate = await updateEstate(userClient, moderationEstateId, {
      ...createEstatePayload(`cian-moderation-updated-${Date.now()}`),
      owner_contacts: moderationEstate.item.owner_contacts,
      existing_images: toExistingImages(moderationEstate.item.images),
      cian: createGarageCianPayload({
        owner_contacts: [{ code: "+7", number: "9990000041" }],
      }),
    });
    assert.equal((await moderatedUpdate.json()).item.cian.include, true);

    await updateEstate(userClient, removedModerationEstateId, {
      ...createEstatePayload(`cian-remove-updated-${Date.now()}`),
      owner_contacts: removedModerationEstate.item.owner_contacts,
      existing_images: toExistingImages(removedModerationEstate.item.images),
      cian: createGarageCianPayload({
        owner_contacts: [{ code: "+7", number: "9990000051" }],
      }),
    });

    const forbiddenXml = await userClient.fetch("/api/v1/crm/cian/actions/create-xml", {
      method: "POST",
    });
    assert.equal(forbiddenXml.status, 403);

    const createXmlBeforeConfirm = await adminClient.fetch("/api/v1/crm/cian/actions/create-xml", {
      method: "POST",
    });
    assert.equal(createXmlBeforeConfirm.status, 201);
    const xmlBeforeConfirm = await readGeneratedXml();
    assert.ok(xmlBeforeConfirm.includes(`<ExternalId>${adminEstateId}</ExternalId>`));
    assert.ok(!xmlBeforeConfirm.includes(`<ExternalId>${moderationEstateId}</ExternalId>`));
    assert.ok(!xmlBeforeConfirm.includes(`<ExternalId>${removedModerationEstateId}</ExternalId>`));

    const removeFromModeration = await adminClient.fetch("/api/v1/crm/cian/moderation/remove", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        estate_ids: [removedModerationEstateId],
      }),
    });
    assert.equal(removeFromModeration.status, 201);

    const confirmModeration = await adminClient.fetch("/api/v1/crm/cian/moderation/confirm", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        estate_ids: [moderationEstateId],
      }),
    });
    assert.equal(confirmModeration.status, 201);
    const confirmModerationJson = await confirmModeration.json();
    assert.equal(confirmModerationJson.updated, 1);

    const createXmlAfterConfirm = await adminClient.fetch("/api/v1/crm/cian/actions/create-xml", {
      method: "POST",
    });
    assert.equal(createXmlAfterConfirm.status, 201);
    const xmlAfterConfirm = await readGeneratedXml();
    assert.ok(xmlAfterConfirm.includes(`<ExternalId>${moderationEstateId}</ExternalId>`));
    assert.ok(!xmlAfterConfirm.includes(`<ExternalId>${removedModerationEstateId}</ExternalId>`));

    const removeFromUpload = await adminClient.fetch("/api/v1/crm/cian/upload/remove", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        estate_ids: [moderationEstateId],
      }),
    });
    assert.equal(removeFromUpload.status, 201);

    const createXmlAfterUploadRemove = await adminClient.fetch("/api/v1/crm/cian/actions/create-xml", {
      method: "POST",
    });
    assert.equal(createXmlAfterUploadRemove.status, 201);
    const xmlAfterUploadRemove = await readGeneratedXml();
    assert.ok(!xmlAfterUploadRemove.includes(`<ExternalId>${moderationEstateId}</ExternalId>`));

    return {
      name: "crm-cian",
      status: "passed",
    };
  } finally {
    if (removedModerationEstateId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/estates/${removedModerationEstateId}`);
    }
    if (moderationEstateId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/estates/${moderationEstateId}`);
    }
    if (adminEstateId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/estates/${adminEstateId}`);
    }
    if (userId !== null) {
      await safeDelete(adminClient, `/api/v1/crm/users/${userId}`);
    }
    await app.close();
  }
}
