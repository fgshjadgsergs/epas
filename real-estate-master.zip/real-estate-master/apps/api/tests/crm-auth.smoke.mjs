import assert from "node:assert/strict";
import { startTestApp } from "./helpers/app.mjs";
import { CookieClient } from "./helpers/http.mjs";

const shouldRun = process.env.RUN_DB_SMOKE_TESTS === "1";

function getErrors(body) {
  return body.errors ?? body.message?.errors ?? {};
}

export async function runCrmAuthSmoke() {
  if (!shouldRun) {
    return {
      name: "crm-auth",
      status: "skipped",
      reason: "RUN_DB_SMOKE_TESTS is not enabled",
    };
  }

  const { app, baseUrl } = await startTestApp();
  const client = new CookieClient(baseUrl);

  try {
    const shortUsername = await client.fetch("/api/v1/crm/auth/login", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        username: "ab",
        password: "123456789",
      }),
    });
    assert.equal(shortUsername.status, 400);
    const shortUsernameJson = await shortUsername.json();
    assert.equal(getErrors(shortUsernameJson).username, "Ensure username has at least 03 characters");

    const shortPassword = await client.fetch("/api/v1/crm/auth/login", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        username: "admin@gmail.com",
        password: "123",
      }),
    });
    assert.equal(shortPassword.status, 400);
    const shortPasswordJson = await shortPassword.json();
    assert.equal(getErrors(shortPasswordJson).password, "Ensure password has at least 09 characters");

    const login = await client.fetch("/api/v1/crm/auth/login", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        username: process.env.CRM_SMOKE_USERNAME ?? "admin@gmail.com",
        password: process.env.CRM_SMOKE_PASSWORD ?? "123456789",
      }),
    });
    assert.equal(login.status, 201);
    const loginJson = await login.json();
    assert.ok(loginJson.user.email);

    const me = await client.fetch("/api/v1/crm/auth/me");
    assert.equal(me.status, 200);
    const meJson = await me.json();
    assert.equal(meJson.user.email, loginJson.user.email);

    const logout = await client.fetch("/api/v1/crm/auth/logout", {
      method: "POST",
    });
    assert.equal(logout.status, 201);

    const meAfterLogout = await client.fetch("/api/v1/crm/auth/me");
    assert.equal(meAfterLogout.status, 401);

    return {
      name: "crm-auth",
      status: "passed",
    };
  } finally {
    await app.close();
  }
}
