import { INestApplication, Logger } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import cookieSession from "cookie-session";
import { AppModule } from "./app.module";

const SESSION_MAX_AGE_MS = 14 * 24 * 60 * 60 * 1000;
const SESSION_COOKIE_SAME_SITE = "lax" as const;

function readBooleanEnv(name: string, fallback: boolean): boolean {
  const value = process.env[name];
  if (value === undefined) {
    return fallback;
  }

  return value === "1" || value.toLowerCase() === "true";
}

export async function createApp(): Promise<INestApplication> {
  const app = await NestFactory.create(AppModule, {
    cors: {
      origin: true,
      credentials: true,
    },
  });
  const expressApp = app.getHttpAdapter().getInstance() as { set?: (name: string, value: unknown) => void };
  expressApp.set?.("trust proxy", 1);

  const sessionCookieSecure = readBooleanEnv("CRM_SESSION_COOKIE_SECURE", process.env.NODE_ENV === "production");
  Logger.log(
    `CRM session cookie config secure=${sessionCookieSecure} httpOnly=true sameSite=${SESSION_COOKIE_SAME_SITE} path=/ domain=host-only trustProxy=1`,
    "CookieSession",
  );

  app.use(
    cookieSession({
      name: "session",
      keys: [process.env.ADMIN_SECRET_KEY ?? "change it"],
      maxAge: SESSION_MAX_AGE_MS,
      sameSite: SESSION_COOKIE_SAME_SITE,
      httpOnly: true,
      secure: sessionCookieSecure,
      path: "/",
    }),
  );

  app.setGlobalPrefix("");
  app.enableShutdownHooks();

  return app;
}
