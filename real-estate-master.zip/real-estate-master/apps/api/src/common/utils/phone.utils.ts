export function normalizePhone(value: string | null | undefined): string | null {
  const raw = String(value ?? "").trim();
  const digits = raw.replace(/\D/g, "");
  if (!digits) {
    return null;
  }

  if (raw.startsWith("+") && !digits.startsWith("7")) {
    return digits;
  }

  if (digits.length === 11 && digits.startsWith("8")) {
    return `7${digits.slice(1)}`;
  }

  if (digits.length === 10) {
    return `7${digits}`;
  }

  return digits;
}

export function arePhoneNumbersEquivalent(
  left: string | null | undefined,
  right: string | null | undefined,
): boolean {
  const normalizedLeft = normalizePhone(left);
  return normalizedLeft !== null && normalizedLeft === normalizePhone(right);
}