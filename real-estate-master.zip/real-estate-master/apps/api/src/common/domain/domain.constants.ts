export const DEAL_TYPES = {
  SELL: "Продажа",
  RENT: "Аренда",
  RENT_BUSINESS: "Арендный бизнес",
} as const;

export const REGIONS = {
  MOSCOW: "Москва",
  MOSCOW_REGION: "Московская область",
} as const;

export const CIAN_TYPES = {
  GARAGE: "Гараж",
  BUILDING: "Здание",
  OFFICE: "Офис",
  FREE_APPOINTMENT_OBJECT: "Объект свободного назначения",
  INDUSTRY: "Производство",
  WAREHOUSE: "Склад",
  SHOPPING_AREA: "Торговая площадь",
  BUSINESS_SALE: "Готовый бизнес",
} as const;

export const DEAL_TYPE_VALUES = Object.values(DEAL_TYPES);
