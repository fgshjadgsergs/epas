type StorageDriver = "local" | "s3";

export interface AppEnvironment {
  NODE_ENV: string;
  PORT: number;
  DATABASE_URL: string;
  DEFAULT_ADMIN_EMAIL: string;
  DEFAULT_ADMIN_PASSWORD: string;
  ADMIN_SECRET_KEY: string;
  STORAGE_DRIVER: StorageDriver;
  STORAGE_BASE_URL: string;
  STORAGE_LOCAL_ROOT: string;
  AVITO_CLIENT_ID?: string;
  AVITO_CLIENT_SECRET?: string;
  AVITO_COMPANY_NAME?: string;
  AVITO_FEED_URL?: string;
  AVITO_DEFAULT_PHONE?: string;
  AVITO_DEFAULT_MANAGER_NAME?: string;
  AVITO_PUBLIC_BASE_URL?: string;
  S3_ENDPOINT?: string;
  S3_REGION?: string;
  S3_BUCKET?: string;
  S3_ACCESS_KEY_ID?: string;
  S3_SECRET_ACCESS_KEY?: string;
  S3_FORCE_PATH_STYLE: boolean;
  YANDEX_MAPS_API_KEY?: string;
}

function parseBoolean(input: string | undefined, fallback: boolean): boolean {
  if (input === undefined || input === "") {
    return fallback;
  }

  return ["1", "true", "yes", "on"].includes(input.toLowerCase());
}

export function validateEnvironment(config: Record<string, unknown>): AppEnvironment {
  const databaseUrl = String(config.DATABASE_URL ?? "").trim();
  if (!databaseUrl) {
    throw new Error("DATABASE_URL is required");
  }

  const storageDriver = String(config.STORAGE_DRIVER ?? "local").trim().toLowerCase();
  if (storageDriver !== "local" && storageDriver !== "s3") {
    throw new Error("STORAGE_DRIVER must be either `local` or `s3`");
  }

  const port = Number(config.PORT ?? 3000);
  if (!Number.isInteger(port) || port <= 0) {
    throw new Error("PORT must be a positive integer");
  }

  const validated: AppEnvironment = {
    NODE_ENV: String(config.NODE_ENV ?? "development"),
    PORT: port,
    DATABASE_URL: databaseUrl,
    DEFAULT_ADMIN_EMAIL: String(config.DEFAULT_ADMIN_EMAIL ?? "admin@gmail.com"),
    DEFAULT_ADMIN_PASSWORD: String(config.DEFAULT_ADMIN_PASSWORD ?? "123456789"),
    ADMIN_SECRET_KEY: String(config.ADMIN_SECRET_KEY ?? "change it"),
    STORAGE_DRIVER: storageDriver,
    STORAGE_BASE_URL: String(config.STORAGE_BASE_URL ?? "").trim(),
    STORAGE_LOCAL_ROOT: String(config.STORAGE_LOCAL_ROOT ?? "storage").trim(),
    AVITO_CLIENT_ID: config.AVITO_CLIENT_ID ? String(config.AVITO_CLIENT_ID).trim() : undefined,
    AVITO_CLIENT_SECRET: config.AVITO_CLIENT_SECRET ? String(config.AVITO_CLIENT_SECRET).trim() : undefined,
    AVITO_COMPANY_NAME: config.AVITO_COMPANY_NAME ? String(config.AVITO_COMPANY_NAME).trim() : undefined,
    AVITO_FEED_URL: config.AVITO_FEED_URL ? String(config.AVITO_FEED_URL).trim() : undefined,
    AVITO_DEFAULT_PHONE: config.AVITO_DEFAULT_PHONE ? String(config.AVITO_DEFAULT_PHONE).trim() : undefined,
    AVITO_DEFAULT_MANAGER_NAME: config.AVITO_DEFAULT_MANAGER_NAME ? String(config.AVITO_DEFAULT_MANAGER_NAME).trim() : undefined,
    AVITO_PUBLIC_BASE_URL: config.AVITO_PUBLIC_BASE_URL ? String(config.AVITO_PUBLIC_BASE_URL).trim() : undefined,
    S3_ENDPOINT: config.S3_ENDPOINT ? String(config.S3_ENDPOINT) : undefined,
    S3_REGION: config.S3_REGION ? String(config.S3_REGION) : undefined,
    S3_BUCKET: config.S3_BUCKET ? String(config.S3_BUCKET) : undefined,
    S3_ACCESS_KEY_ID: config.S3_ACCESS_KEY_ID ? String(config.S3_ACCESS_KEY_ID) : undefined,
    S3_SECRET_ACCESS_KEY: config.S3_SECRET_ACCESS_KEY ? String(config.S3_SECRET_ACCESS_KEY) : undefined,
    S3_FORCE_PATH_STYLE: parseBoolean(
      config.S3_FORCE_PATH_STYLE ? String(config.S3_FORCE_PATH_STYLE) : undefined,
      true,
    ),
    YANDEX_MAPS_API_KEY: config.YANDEX_MAPS_API_KEY ? String(config.YANDEX_MAPS_API_KEY) : undefined,
  };

  if (validated.STORAGE_DRIVER === "s3") {
    for (const key of [
      "S3_ENDPOINT",
      "S3_REGION",
      "S3_BUCKET",
      "S3_ACCESS_KEY_ID",
      "S3_SECRET_ACCESS_KEY",
    ] as const) {
      if (!validated[key]) {
        throw new Error(`${key} is required when STORAGE_DRIVER=s3`);
      }
    }
  }

  return validated;
}
