import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { CrmMetaController } from "./crm-meta.controller";
import { CrmMetaService } from "./crm-meta.service";

@Module({
  imports: [CrmAuthModule],
  controllers: [CrmMetaController],
  providers: [CrmMetaService],
})
export class CrmMetaModule {}
