import { Injectable } from "@nestjs/common";
import {
  AREA_UNIT_VALUES,
  CIAN_TYPE_VALUES,
  CRM_ESTATE_LIST_DEFAULT_LIMIT,
  CRM_USER_LIST_DEFAULT_LIMIT,
  DEAL_TYPE_VALUES,
  DISTRICT_VALUES,
  ESTATE_FREE_TEXT_FIELDS,
  ESTATE_REQUIRED_FIELDS,
  GARAGE_TYPE_VALUES,
  OWNER_TYPE_VALUES,
  READY_BUSINESS_TYPE_VALUES,
  REGION_VALUES,
  SPECIALTY_VALUES,
  VAT_TYPE_VALUES,
} from "../../common/domain/crm-form.constants";

@Injectable()
export class CrmMetaService {
  getMeta(): Record<string, unknown> {
    return {
      estate: {
        form: {
          choice_fields: {
            deal_type: DEAL_TYPE_VALUES,
            region: REGION_VALUES,
            district: DISTRICT_VALUES,
            owner_type: OWNER_TYPE_VALUES,
          },
          free_text_fields: ESTATE_FREE_TEXT_FIELDS,
          required_fields: ESTATE_REQUIRED_FIELDS,
        },
        list: {
          default_limit: CRM_ESTATE_LIST_DEFAULT_LIMIT,
          supported_filters: [
            "search",
            "status",
            "deal_type",
            "region",
            "district",
            "metro_station",
            "price_from",
            "price_to",
            "area_from",
            "area_to",
            "active",
            "archivedOnly",
            "cian_included",
            "skip",
            "limit",
          ],
        },
      },
      cian: {
        choice_fields: {
          type: CIAN_TYPE_VALUES,
          vat_type: VAT_TYPE_VALUES,
          garage_type: GARAGE_TYPE_VALUES,
          ready_business_type: READY_BUSINESS_TYPE_VALUES,
          land_area_unit: AREA_UNIT_VALUES,
          specialty: SPECIALTY_VALUES,
        },
      },
      users: {
        list: {
          default_limit: CRM_USER_LIST_DEFAULT_LIMIT,
          supported_filters: ["search", "skip", "limit"],
        },
      },
      clients: {
        list: {
          default_limit: CRM_USER_LIST_DEFAULT_LIMIT,
          supported_filters: ["search", "status", "broker_id", "estate_id", "skip", "limit"],
        },
      },
      parity: {
        exact: [
          "Business dictionaries mirror the current API enum and form choices.",
        ],
        approximate: [
          "Response is JSON metadata for the CRM client.",
        ],
      },
    };
  }
}
