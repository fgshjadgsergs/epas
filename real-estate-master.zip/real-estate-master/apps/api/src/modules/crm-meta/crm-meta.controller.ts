import { Controller, Get, UseGuards } from "@nestjs/common";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { CrmMetaService } from "./crm-meta.service";

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/meta")
export class CrmMetaController {
  constructor(private readonly crmMetaService: CrmMetaService) {}

  @Get()
  getMeta(): Record<string, unknown> {
    return this.crmMetaService.getMeta();
  }
}
