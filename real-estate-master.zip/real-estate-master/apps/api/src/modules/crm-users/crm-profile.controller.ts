import { Body, Controller, Get, Post, Put, Req, UseGuards } from "@nestjs/common";
import { Request } from "express";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser, CrmSessionPayload } from "../crm-auth/crm-auth.types";
import { CrmPasswordWritePayload, CrmProfileWritePayload, ParityNotes } from "../users/users.types";
import { UsersService } from "../users/users.service";

type CrmRequest = Request & {
  session?: CrmSessionPayload | null;
};

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/profile")
export class CrmProfileController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  getProfile(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    return this.usersService.getProfile(user);
  }

  @Put()
  updateProfile(
    @Body() payload: CrmProfileWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    return this.usersService.updateProfile(user, payload);
  }

  @Post("change-password")
  async changePassword(
    @Body() payload: CrmPasswordWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Req() request: CrmRequest,
  ): Promise<{ message: string; parity: ParityNotes }> {
    const result = await this.usersService.changeOwnPassword(user, payload);
    request.session = null;

    return {
      message: result.message,
      parity: result.parity,
    };
  }
}
