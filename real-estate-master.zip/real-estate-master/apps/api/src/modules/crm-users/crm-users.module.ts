import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { UsersModule } from "../users/users.module";
import { CrmProfileController } from "./crm-profile.controller";
import { CrmUsersController } from "./crm-users.controller";

@Module({
  imports: [UsersModule, CrmAuthModule],
  controllers: [CrmUsersController, CrmProfileController],
})
export class CrmUsersModule {}
