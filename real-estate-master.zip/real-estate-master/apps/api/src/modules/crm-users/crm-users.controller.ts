import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, Query, Req, UseGuards } from "@nestjs/common";
import { Request } from "express";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser, CrmSessionPayload } from "../crm-auth/crm-auth.types";
import { CrmPasswordWritePayload, CrmUserWritePayload, ParityNotes } from "../users/users.types";
import { UsersService } from "../users/users.service";

type CrmRequest = Request & {
  session?: CrmSessionPayload | null;
};

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/users")
export class CrmUsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  listUsers(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query("search") search?: string,
    @Query("skip") skip?: string,
    @Query("limit") limit?: string,
  ): Promise<{ items: Record<string, unknown>[]; total: number; parity: ParityNotes }> {
    return this.usersService.listForAdmin(user, {
      search,
      skip: skip !== undefined ? Number(skip) : undefined,
      limit: limit !== undefined ? Number(limit) : undefined,
    });
  }

  @Get(":userId")
  getUserById(
    @Param("userId", ParseIntPipe) userId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    return this.usersService.getByIdForAdmin(userId, user);
  }

  @Post()
  createUser(
    @Body() payload: CrmUserWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    return this.usersService.createForAdmin(payload, user);
  }

  @Put(":userId")
  updateUser(
    @Param("userId", ParseIntPipe) userId: number,
    @Body() payload: CrmUserWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    return this.usersService.updateForAdmin(userId, payload, user);
  }

  @Delete(":userId")
  deleteUser(
    @Param("userId", ParseIntPipe) userId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ deleted: true; reassigned_estates: number; parity: ParityNotes }> {
    return this.usersService.deleteForAdmin(userId, user);
  }

  @Post(":userId/change-password")
  async changePassword(
    @Param("userId", ParseIntPipe) userId: number,
    @Body() payload: CrmPasswordWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Req() request: CrmRequest,
  ): Promise<{ message: string; parity: ParityNotes }> {
    const result = await this.usersService.changePasswordForAdmin(userId, payload, user);

    if (result.clear_session) {
      request.session = null;
    }

    return {
      message: result.message,
      parity: result.parity,
    };
  }
}
