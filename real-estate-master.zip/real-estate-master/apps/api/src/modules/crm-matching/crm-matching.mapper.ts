import { Injectable } from "@nestjs/common";
import { CrmRole, User } from "@prisma/client";
import {
  bigintToNumber,
  decimalToNumber,
  formatInteger,
} from "../../common/utils/number.utils";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { canViewClientContacts } from "../crm-auth/crm-permissions";
import { StorageService } from "../storage/storage.service";
import {
  ClientMatchingProfileWithClient,
  CrmClientMatchingProfileItem,
  CrmMatchedClientItem,
  CrmMatchedEstateItem,
  EstateMatchWithRelations,
} from "./crm-matching.types";

function getBrokerName(user: Pick<User, "firstName" | "lastName" | "email">): string {
  const fullName = `${user.firstName} ${user.lastName}`.trim();
  return fullName || user.email;
}

function getEstateBroker(
  estate: Pick<EstateMatchWithRelations, "user"> & {
    assignments: Array<{ user: Pick<User, "id" | "firstName" | "lastName" | "email" | "role" | "ropId"> }>;
  },
): Pick<User, "id" | "firstName" | "lastName" | "email" | "role" | "ropId"> | null {
  if (estate.user) {
    return estate.user;
  }

  return estate.assignments[0]?.user ?? null;
}

@Injectable()
export class CrmMatchingMapper {
  constructor(private readonly storageService: StorageService) {}

  toProfileItem(profile: ClientMatchingProfileWithClient): CrmClientMatchingProfileItem {
    return {
      client_id: bigintToNumber(profile.clientId),
      deal_type: profile.dealType,
      price_from: decimalToNumber(profile.priceFrom),
      price_to: decimalToNumber(profile.priceTo),
      area_from: decimalToNumber(profile.areaFrom),
      area_to: decimalToNumber(profile.areaTo),
      created_at: profile.createdAt.toISOString(),
      update_at: profile.updateAt.toISOString(),
    };
  }

  toMatchedEstateItem(estate: EstateMatchWithRelations): CrmMatchedEstateItem {
    const price = decimalToNumber(estate.price);
    const broker = getEstateBroker(estate);
    const primaryImage =
      [...estate.images].sort(
        (left, right) =>
          Number(right.isMain) - Number(left.isMain) || Number(left.id > right.id) - Number(left.id < right.id),
      )[0] ?? null;

    return {
      estate_id: bigintToNumber(estate.id),
      title: estate.title,
      deal_type: estate.dealType,
      price,
      presentation_price: price === null ? null : formatInteger(price),
      area: decimalToNumber(estate.area),
      district: estate.district,
      metro_station: estate.metroStation,
      estate_type: estate.estateType,
      broker_id: broker ? bigintToNumber(broker.id) : null,
      broker_name: broker ? getBrokerName(broker) : null,
      image_url: primaryImage ? this.storageService.resolvePublicUrl(primaryImage.url) : null,
    };
  }

  toMatchedClientItem(
    profile: ClientMatchingProfileWithClient,
    viewer: AuthenticatedCrmUser,
  ): CrmMatchedClientItem {
    const contactsVisible = canViewClientContacts(
      viewer,
      {
        id: profile.client.id,
        brokerId: profile.client.brokerId,
        deletedAt: profile.client.deletedAt,
      },
      {
        id: profile.client.broker.id,
        role: profile.client.broker.role,
        ropId: profile.client.broker.ropId,
      },
    );

    const item: CrmMatchedClientItem = {
      client_id: bigintToNumber(profile.client.id),
      name: profile.client.name,
      contacts_visible: contactsVisible,
      source: profile.client.source,
      comment: profile.client.comment,
      broker_id: bigintToNumber(profile.client.broker.id),
      broker_name: getBrokerName(profile.client.broker),
      profile: this.toProfileItem(profile),
    };

    if (contactsVisible) {
      item.phone = profile.client.phone;
      item.email = profile.client.email;
    }

    return item;
  }
}
