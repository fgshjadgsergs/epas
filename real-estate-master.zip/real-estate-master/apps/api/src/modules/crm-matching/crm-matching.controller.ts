import { Body, Controller, Get, Param, ParseIntPipe, Put, UseGuards } from "@nestjs/common";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CrmMatchingService } from "./crm-matching.service";
import {
  CrmClientMatchingProfileItem,
  CrmClientMatchingProfileWritePayload,
  CrmMatchedClientItem,
  CrmMatchedEstateItem,
} from "./crm-matching.types";

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm")
export class CrmMatchingController {
  constructor(private readonly crmMatchingService: CrmMatchingService) {}

  @Get("clients/:clientId/matching-profile")
  getClientMatchingProfile(
    @Param("clientId", ParseIntPipe) clientId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: CrmClientMatchingProfileItem | null }> {
    return this.crmMatchingService.getClientMatchingProfile(clientId, user);
  }

  @Put("clients/:clientId/matching-profile")
  upsertClientMatchingProfile(
    @Param("clientId", ParseIntPipe) clientId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Body() payload: CrmClientMatchingProfileWritePayload,
  ): Promise<{ item: CrmClientMatchingProfileItem }> {
    return this.crmMatchingService.upsertClientMatchingProfile(clientId, payload, user);
  }

  @Get("clients/:clientId/matches")
  getClientMatches(
    @Param("clientId", ParseIntPipe) clientId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ profile: CrmClientMatchingProfileItem | null; items: CrmMatchedEstateItem[]; total: number }> {
    return this.crmMatchingService.getClientMatches(clientId, user);
  }

  @Get("estates/:estateId/matches")
  getEstateMatches(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ items: CrmMatchedClientItem[]; total: number }> {
    return this.crmMatchingService.getEstateMatches(estateId, user);
  }
}
