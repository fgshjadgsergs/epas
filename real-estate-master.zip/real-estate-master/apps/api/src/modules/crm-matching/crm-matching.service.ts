import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { CrmRole, Prisma, User } from "@prisma/client";
import { DEAL_TYPE_VALUES } from "../../common/domain/domain.constants";
import { PrismaService } from "../../prisma/prisma.service";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import {
  canEditClient,
  canViewClient,
  canViewEstate,
  isAdmin,
  isBroker,
  isOwner,
  isRop,
  isViewer,
  ScopedClientRef,
  ScopedEstateRef,
  ScopedUserRef,
} from "../crm-auth/crm-permissions";
import { CrmMatchingMapper } from "./crm-matching.mapper";
import {
  CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE,
  ClientMatchingProfileWithClient,
  CrmClientMatchingProfileItem,
  CrmClientMatchingProfileWritePayload,
  CrmMatchedClientItem,
  CrmMatchedEstateItem,
  ESTATE_MATCH_WITH_RELATIONS_INCLUDE,
  EstateMatchWithRelations,
} from "./crm-matching.types";

const MATCHING_FORBIDDEN_MESSAGE = "You can view only permitted matching data";

interface ParsedMatchingProfilePayload {
  deal_type: string;
  price_from: Prisma.Decimal | null;
  price_to: Prisma.Decimal | null;
  area_from: Prisma.Decimal | null;
  area_to: Prisma.Decimal | null;
}

function normalizeText(value: string | null | undefined): string {
  if (value === undefined || value === null) {
    return "";
  }

  return String(value).trim();
}

function parseNullableDecimal(value: string | number | null | undefined): Prisma.Decimal | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const normalized = String(value).trim().replace(/\s+/g, "").replace(",", ".");
  if (!normalized) {
    return null;
  }

  const parsed = Number(normalized);
  return Number.isFinite(parsed) && parsed >= 0 ? new Prisma.Decimal(parsed) : null;
}

function toBigIntId(value: number): bigint {
  return BigInt(value);
}

function isDecimalGreaterThan(left: Prisma.Decimal | null, right: Prisma.Decimal | null): boolean {
  if (!left || !right) {
    return false;
  }

  return left.gt(right);
}

@Injectable()
export class CrmMatchingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mapper: CrmMatchingMapper,
  ) {}

  async getClientMatchingProfile(
    clientId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: CrmClientMatchingProfileItem | null }> {
    const client = await this.getVisibleClientOrThrow(clientId, viewer);
    const profile = await this.prisma.clientMatchingProfile.findUnique({
      where: {
        clientId: client.id,
      },
      include: CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE,
    });

    return {
      item: profile ? this.mapper.toProfileItem(profile) : null,
    };
  }

  async upsertClientMatchingProfile(
    clientId: number,
    payload: CrmClientMatchingProfileWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: CrmClientMatchingProfileItem }> {
    const client = await this.getEditableClientOrThrow(clientId, viewer);
    const parsedPayload = this.parseMatchingProfilePayload(payload);

    const profile = await this.prisma.clientMatchingProfile.upsert({
      where: {
        clientId: client.id,
      },
      create: {
        clientId: client.id,
        dealType: parsedPayload.deal_type,
        priceFrom: parsedPayload.price_from,
        priceTo: parsedPayload.price_to,
        areaFrom: parsedPayload.area_from,
        areaTo: parsedPayload.area_to,
      },
      update: {
        dealType: parsedPayload.deal_type,
        priceFrom: parsedPayload.price_from,
        priceTo: parsedPayload.price_to,
        areaFrom: parsedPayload.area_from,
        areaTo: parsedPayload.area_to,
      },
      include: CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE,
    });

    return {
      item: this.mapper.toProfileItem(profile),
    };
  }

  async getClientMatches(
    clientId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ profile: CrmClientMatchingProfileItem | null; items: CrmMatchedEstateItem[]; total: number }> {
    const client = await this.getVisibleClientOrThrow(clientId, viewer);
    const profile = await this.prisma.clientMatchingProfile.findUnique({
      where: {
        clientId: client.id,
      },
      include: CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE,
    });

    if (!profile) {
      return {
        profile: null,
        items: [],
        total: 0,
      };
    }

    const estates = await this.prisma.estate.findMany({
      where: this.buildEstateMatchesWhere(viewer, profile),
      include: ESTATE_MATCH_WITH_RELATIONS_INCLUDE,
      orderBy: [{ updateAt: "desc" }, { id: "desc" }],
    });

    const visibleEstates = estates.filter((estate) => this.canViewEstate(viewer, estate));

    return {
      profile: this.mapper.toProfileItem(profile),
      items: visibleEstates.map((estate) => this.mapper.toMatchedEstateItem(estate)),
      total: visibleEstates.length,
    };
  }

  async getEstateMatches(
    estateId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ items: CrmMatchedClientItem[]; total: number }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer);

    const profiles = await this.prisma.clientMatchingProfile.findMany({
      where: this.buildClientProfileMatchesWhere(viewer, estate),
      include: CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE,
      orderBy: [{ updateAt: "desc" }, { id: "desc" }],
    });

    const visibleProfiles = profiles.filter((profile) => this.canViewClient(viewer, profile));

    return {
      items: visibleProfiles.map((profile) => this.mapper.toMatchedClientItem(profile, viewer)),
      total: visibleProfiles.length,
    };
  }

  private parseMatchingProfilePayload(payload: CrmClientMatchingProfileWritePayload): ParsedMatchingProfilePayload {
    const dealType = normalizeText(payload.deal_type);
    const priceFrom = parseNullableDecimal(payload.price_from);
    const priceTo = parseNullableDecimal(payload.price_to);
    const areaFrom = parseNullableDecimal(payload.area_from);
    const areaTo = parseNullableDecimal(payload.area_to);
    const errors: Record<string, string> = {};

    if (!dealType) {
      errors.deal_type = "Укажите тип сделки.";
    } else if (!DEAL_TYPE_VALUES.includes(dealType as (typeof DEAL_TYPE_VALUES)[number])) {
      errors.deal_type = "Указан недопустимый тип сделки.";
    }

    if (payload.price_from !== undefined && payload.price_from !== null && payload.price_from !== "" && priceFrom === null) {
      errors.price_from = "Укажите корректное значение цены.";
    }

    if (payload.price_to !== undefined && payload.price_to !== null && payload.price_to !== "" && priceTo === null) {
      errors.price_to = "Укажите корректное значение цены.";
    }

    if (payload.area_from !== undefined && payload.area_from !== null && payload.area_from !== "" && areaFrom === null) {
      errors.area_from = "Укажите корректное значение площади.";
    }

    if (payload.area_to !== undefined && payload.area_to !== null && payload.area_to !== "" && areaTo === null) {
      errors.area_to = "Укажите корректное значение площади.";
    }

    if (isDecimalGreaterThan(priceFrom, priceTo)) {
      errors.price_range = "Диапазон цены заполнен некорректно.";
    }

    if (isDecimalGreaterThan(areaFrom, areaTo)) {
      errors.area_range = "Диапазон площади заполнен некорректно.";
    }

    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({
        message: "Не удалось сохранить критерии подбора.",
        errors,
      });
    }

    return {
      deal_type: dealType,
      price_from: priceFrom,
      price_to: priceTo,
      area_from: areaFrom,
      area_to: areaTo,
    };
  }

  private buildEstateMatchesWhere(
    viewer: AuthenticatedCrmUser,
    profile: ClientMatchingProfileWithClient,
  ): Prisma.EstateWhereInput {
    this.assertMatchingAccess(viewer);

    const and: Prisma.EstateWhereInput[] = [
      {
        deletedAt: null,
        active: true,
        dealType: profile.dealType,
      },
      profile.priceFrom
        ? {
            price: {
              gte: profile.priceFrom,
            },
          }
        : {},
      profile.priceTo
        ? {
            price: {
              lte: profile.priceTo,
            },
          }
        : {},
      profile.areaFrom
        ? {
            area: {
              gte: profile.areaFrom,
            },
          }
        : {},
      profile.areaTo
        ? {
            area: {
              lte: profile.areaTo,
            },
          }
        : {},
    ];

    if (isRop(viewer)) {
      and.push({
        OR: [
          {
            assignments: {
              some: {
                user: {
                  role: CrmRole.BROKER,
                  ropId: toBigIntId(viewer.id),
                },
              },
            },
          },
          {
            assignments: {
              none: {},
            },
            user: {
              role: CrmRole.BROKER,
              ropId: toBigIntId(viewer.id),
            },
          },
        ],
      });
    } else if (!(isOwner(viewer) || isAdmin(viewer) || isBroker(viewer))) {
      throw new ForbiddenException(MATCHING_FORBIDDEN_MESSAGE);
    }

    return {
      AND: and,
    };
  }

  private buildClientProfileMatchesWhere(
    viewer: AuthenticatedCrmUser,
    estate: EstateMatchWithRelations,
  ): Prisma.ClientMatchingProfileWhereInput {
    this.assertMatchingAccess(viewer);

    const and: Prisma.ClientMatchingProfileWhereInput[] = [
      {
        dealType: estate.dealType,
      },
      {
        client: {
          deletedAt: null,
        },
      },
      estate.price
        ? {
            OR: [
              { priceFrom: null },
              {
                priceFrom: {
                  lte: estate.price,
                },
              },
            ],
          }
        : {},
      estate.price
        ? {
            OR: [
              { priceTo: null },
              {
                priceTo: {
                  gte: estate.price,
                },
              },
            ],
          }
        : {},
      estate.area
        ? {
            OR: [
              { areaFrom: null },
              {
                areaFrom: {
                  lte: estate.area,
                },
              },
            ],
          }
        : {},
      estate.area
        ? {
            OR: [
              { areaTo: null },
              {
                areaTo: {
                  gte: estate.area,
                },
              },
            ],
          }
        : {},
    ];

    if (isRop(viewer)) {
      and.push({
        client: {
          broker: {
            role: CrmRole.BROKER,
            ropId: toBigIntId(viewer.id),
          },
        },
      });
    } else if (isBroker(viewer)) {
      and.push({
        client: {
          brokerId: toBigIntId(viewer.id),
        },
      });
    } else if (!(isOwner(viewer) || isAdmin(viewer))) {
      throw new ForbiddenException(MATCHING_FORBIDDEN_MESSAGE);
    }

    return {
      AND: and,
    };
  }

  private async getVisibleClientOrThrow(
    clientId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<ClientMatchingProfileWithClient["client"]> {
    this.assertMatchingAccess(viewer);

    const client = await this.prisma.client.findFirst({
      where: {
        id: toBigIntId(clientId),
        deletedAt: null,
        ...this.buildClientScopeWhere(viewer),
      },
      include: {
        broker: true,
      },
    });

    if (!client || !this.canViewClientRecord(viewer, client)) {
      throw new NotFoundException(`Client ${clientId} not found`);
    }

    return client;
  }

  private async getEditableClientOrThrow(
    clientId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<ClientMatchingProfileWithClient["client"]> {
    const client = await this.getVisibleClientOrThrow(clientId, viewer);

    if (
      !canEditClient(
        viewer,
        {
          id: client.id,
          brokerId: client.brokerId,
          deletedAt: client.deletedAt,
        },
        this.toScopedUser(client.broker),
      )
    ) {
      throw new ForbiddenException(MATCHING_FORBIDDEN_MESSAGE);
    }

    return client;
  }

  private async getVisibleEstateOrThrow(
    estateId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<EstateMatchWithRelations> {
    this.assertMatchingAccess(viewer);

    const estate = await this.prisma.estate.findFirst({
      where: {
        id: toBigIntId(estateId),
        deletedAt: null,
        ...this.buildEstateVisibilityScopeWhere(viewer),
      },
      include: ESTATE_MATCH_WITH_RELATIONS_INCLUDE,
    });

    if (!estate || !this.canViewEstate(viewer, estate)) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    return estate;
  }

  private buildClientScopeWhere(viewer: AuthenticatedCrmUser): Prisma.ClientWhereInput {
    if (isOwner(viewer) || isAdmin(viewer)) {
      return {};
    }

    if (isRop(viewer)) {
      return {
        broker: {
          role: CrmRole.BROKER,
          ropId: toBigIntId(viewer.id),
        },
      };
    }

    if (isBroker(viewer)) {
      return {
        brokerId: toBigIntId(viewer.id),
      };
    }

    throw new ForbiddenException(MATCHING_FORBIDDEN_MESSAGE);
  }

  private buildEstateVisibilityScopeWhere(viewer: AuthenticatedCrmUser): Prisma.EstateWhereInput {
    if (isOwner(viewer) || isAdmin(viewer) || isBroker(viewer)) {
      return {};
    }

    if (isRop(viewer)) {
      return {
        OR: [
          {
            assignments: {
              some: {
                user: {
                  role: CrmRole.BROKER,
                  ropId: toBigIntId(viewer.id),
                },
              },
            },
          },
          {
            assignments: {
              none: {},
            },
            user: {
              role: CrmRole.BROKER,
              ropId: toBigIntId(viewer.id),
            },
          },
        ],
      };
    }

    throw new ForbiddenException(MATCHING_FORBIDDEN_MESSAGE);
  }

  private canViewClient(
    viewer: AuthenticatedCrmUser,
    profile: Pick<ClientMatchingProfileWithClient, "client">,
  ): boolean {
    return this.canViewClientRecord(viewer, profile.client);
  }

  private canViewClientRecord(
    viewer: AuthenticatedCrmUser,
    client: ClientMatchingProfileWithClient["client"],
  ): boolean {
    return canViewClient(
      viewer,
      {
        id: client.id,
        brokerId: client.brokerId,
        deletedAt: client.deletedAt,
      },
      this.toScopedUser(client.broker),
    );
  }

  private canViewEstate(
    viewer: AuthenticatedCrmUser,
    estate: EstateMatchWithRelations,
  ): boolean {
    return canViewEstate(viewer, this.toScopedEstate(estate), this.getEstateBroker(estate));
  }

  private toScopedEstate(estate: EstateMatchWithRelations): ScopedEstateRef {
    return {
      id: estate.id,
      userId: estate.userId,
      deletedAt: estate.deletedAt,
      assignedUserIds: estate.assignments.map((assignment) => assignment.userId),
      assignedUsers: estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
    };
  }

  private getEstateBroker(estate: EstateMatchWithRelations): ScopedUserRef {
    if (estate.user) {
      return this.toScopedUser(estate.user);
    }

    const firstAssignment = estate.assignments[0]?.user;
    if (firstAssignment) {
      return this.toScopedUser(firstAssignment);
    }

    return {
      id: BigInt(0),
      role: CrmRole.VIEWER,
      ropId: null,
    };
  }

  private toScopedUser(user: Pick<User, "id" | "role" | "ropId">): ScopedUserRef {
    return {
      id: user.id,
      role: user.role,
      ropId: user.ropId,
    };
  }

  private assertMatchingAccess(viewer: AuthenticatedCrmUser): void {
    if (isViewer(viewer)) {
      throw new ForbiddenException(MATCHING_FORBIDDEN_MESSAGE);
    }
  }
}
