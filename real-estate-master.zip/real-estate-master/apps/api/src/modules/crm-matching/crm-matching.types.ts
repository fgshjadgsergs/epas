import { Prisma } from "@prisma/client";

export interface CrmClientMatchingProfileWritePayload {
  deal_type?: string | null;
  price_from?: number | string | null;
  price_to?: number | string | null;
  area_from?: number | string | null;
  area_to?: number | string | null;
}

export interface CrmClientMatchingProfileItem {
  client_id: number;
  deal_type: string;
  price_from: number | null;
  price_to: number | null;
  area_from: number | null;
  area_to: number | null;
  created_at: string;
  update_at: string;
}

export interface CrmMatchedEstateItem {
  estate_id: number;
  title: string;
  deal_type: string;
  price: number | null;
  presentation_price: string | null;
  area: number | null;
  district: string | null;
  metro_station: string | null;
  estate_type: string | null;
  broker_id: number | null;
  broker_name: string | null;
  image_url: string | null;
}

export interface CrmMatchedClientItem {
  client_id: number;
  name: string;
  contacts_visible: boolean;
  phone?: string | null;
  email?: string | null;
  source: string | null;
  comment: string | null;
  broker_id: number;
  broker_name: string;
  profile: CrmClientMatchingProfileItem;
}

export const CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE = {
  client: {
    include: {
      broker: true,
    },
  },
} as const;

export const ESTATE_MATCH_WITH_RELATIONS_INCLUDE = {
  user: true,
  assignments: {
    include: {
      user: true,
    },
    orderBy: {
      createdAt: "asc" as const,
    },
  },
  images: true,
} as const;

export type ClientMatchingProfileWithClient = Prisma.ClientMatchingProfileGetPayload<{
  include: typeof CLIENT_MATCHING_PROFILE_WITH_CLIENT_INCLUDE;
}>;

export type EstateMatchWithRelations = Prisma.EstateGetPayload<{
  include: typeof ESTATE_MATCH_WITH_RELATIONS_INCLUDE;
}>;
