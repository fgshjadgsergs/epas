import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { StorageModule } from "../storage/storage.module";
import { CrmMatchingController } from "./crm-matching.controller";
import { CrmMatchingMapper } from "./crm-matching.mapper";
import { CrmMatchingService } from "./crm-matching.service";

@Module({
  imports: [CrmAuthModule, StorageModule],
  controllers: [CrmMatchingController],
  providers: [CrmMatchingMapper, CrmMatchingService],
})
export class CrmMatchingModule {}
