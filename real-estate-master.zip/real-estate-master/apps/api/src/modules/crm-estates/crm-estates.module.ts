import { Module } from "@nestjs/common";
import { CianModule } from "../cian/cian.module";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { StorageModule } from "../storage/storage.module";
import { YandexMapsModule } from "../yandex-maps/yandex-maps.module";
import { CrmEstatePresentationMapper } from "./crm-estate-presentation.mapper";
import { CrmEstatePresentationService } from "./crm-estate-presentation.service";
import { CrmEstatesController } from "./crm-estates.controller";
import { CrmEstatesMapper } from "./crm-estates.mapper";
import { EstateAssignmentsBootstrap } from "./estate-assignments.bootstrap";
import { CrmEstatesService } from "./crm-estates.service";

@Module({
  imports: [CrmAuthModule, CianModule, StorageModule, YandexMapsModule],
  controllers: [CrmEstatesController],
  providers: [
    CrmEstatesMapper,
    CrmEstatesService,
    EstateAssignmentsBootstrap,
    CrmEstatePresentationMapper,
    CrmEstatePresentationService,
  ],
})
export class CrmEstatesModule {}
