import {
  EstatePresentationImage,
  EstatePresentationPayload,
} from "./crm-estate-presentation.mapper";

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderText(value: string | null | undefined, fallback = "Не указано"): string {
  return escapeHtml((value ?? "").trim() || fallback);
}

function renderImage(url: string | null | undefined, alt: string, className: string): string {
  if (!url) {
    return `<div class="${className} presentation-image presentation-image--placeholder">Фото недоступно</div>`;
  }

  return `<img class="${className} presentation-image" src="${escapeHtml(url)}" alt="${escapeHtml(alt)}" />`;
}

function renderLogo(logoUrl: string | null | undefined): string {
  if (!logoUrl) {
    return `<div class="presentation-logo presentation-logo--empty">EPAS</div>`;
  }

  return `<img class="presentation-logo" src="${escapeHtml(logoUrl)}" alt="EPAS Development" />`;
}

function renderPhotoPage(image: EstatePresentationImage, title: string): string {
  return `
    <section class="presentation-page presentation-page--photo">
      ${renderImage(image.url, image.alt, "presentation-full-photo")}
      <div class="presentation-photo-caption">${escapeHtml(title)}</div>
    </section>
  `;
}

export function renderEstatePresentationHtml(presentation: EstatePresentationPayload): string {
  const visibleTechnicalFields = presentation.technicalFields.slice(0, 12);

  const floorPlanMarkup = presentation.floorPlanImage
    ? renderImage(
        presentation.floorPlanImage.url,
        presentation.floorPlanImage.alt ?? "Планировка",
        "presentation-floorplan-image",
      )
    : `<div class="presentation-floorplan-image presentation-image presentation-image--placeholder">Планировка пока не добавлена</div>`;

  const fullscreenPhotos = [
    ...presentation.coverImages,
    ...presentation.featureImages,
    ...presentation.galleryImages,
  ].filter((image) => image.url !== presentation.floorPlanImage?.url);

  const galleryPageMarkup = fullscreenPhotos
    .map((image) => renderPhotoPage(image, presentation.title))
    .join("");
  const mapMarkup = presentation.mapImageUrl
    ? renderImage(presentation.mapImageUrl, presentation.address ?? "Карта", "presentation-map-image")
    : `
      <div class="presentation-map-placeholder">
        <div class="presentation-map-pin"></div>
        <div class="presentation-map-label">${renderText(presentation.mapPlaceholderText, "Координаты не указаны")}</div>
      </div>
    `;

  return `
    <!doctype html>
    <html lang="ru">
      <head>
        <meta charset="utf-8" />
        <title>${escapeHtml(presentation.title)} - презентация</title>

        <style>
          @page {
            size: A4 landscape;
            margin: 0;
          }

          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }

          :root {
            --bg: #ffffff;
            --white: #ffffff;
            --text: #10233e;
            --muted: #66758d;
            --line: rgba(16, 44, 74, 0.12);

            --navy-1: #071827;
            --navy-2: #10233e;
            --navy-3: #102c4a;
            --navy-4: #183b61;

            --gold: #d5b36b;
            --gold-soft: #f2dfb0;
          }

          html,
          body {
            margin: 0;
            padding: 0;
            font-family: Arial, "Open Sans", sans-serif;
            font-weight: 800;
            color: var(--text);
            background: #ffffff;
            -webkit-font-smoothing: antialiased;
            text-rendering: geometricPrecision;
          }

          .presentation-page {
            position: relative;
            width: 297mm;
            height: 210mm;
            min-height: 210mm;
            padding: 8mm;
            display: flex;
            flex-direction: column;
            gap: 4mm;
            overflow: hidden;
            page-break-after: always;
            break-after: page;
            box-sizing: border-box;
            background: #ffffff;
          }

          .presentation-page:last-child {
            page-break-after: auto;
            break-after: auto;
          }

          .presentation-page::before {
            content: "";
            position: absolute;
            inset: 0 0 auto 0;
            height: 42mm;
            background: linear-gradient(135deg, var(--navy-1) 0%, var(--navy-3) 70%, var(--navy-4) 100%);
            z-index: 0;
          }

          .presentation-page > * {
            position: relative;
            z-index: 1;
          }

          .presentation-page__header {
            height: 31mm;
            padding: 4mm 6mm;
            border-radius: 7mm;
            color: #ffffff;
            background: rgba(255, 255, 255, 0.045);
            border: 1px solid rgba(255, 255, 255, 0.13);
            box-shadow: none;
            overflow: hidden;
          }

          .presentation-brand {
            height: 100%;
            display: grid;
            grid-template-columns: 62mm 1fr;
            align-items: center;
            gap: 5mm;
          }

          .presentation-logo {
            width: 62mm;
            height: 22mm;
            min-width: 62mm;
            max-width: 62mm;
            object-fit: contain;
            object-position: left center;
            border-radius: 0;
            background: transparent;
            border: 0;
            padding: 0;
            display: block;
            transform: scale(1.22);
            transform-origin: left center;
          }

          .presentation-logo--empty {
            width: 62mm;
            height: 22mm;
            min-width: 62mm;
            max-width: 62mm;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gold-soft);
            font-size: 12px;
            font-weight: 900;
            letter-spacing: 0.12em;
            border: 1px solid rgba(255, 255, 255, 0.25);
            border-radius: 3mm;
          }

          .presentation-brand__content {
            display: flex;
            flex-direction: column;
            gap: 1.1mm;
            min-width: 0;
          }

          .presentation-kicker {
            color: var(--gold-soft);
            font-size: 9.5px;
            line-height: 1.05;
            font-weight: 900;
            letter-spacing: 0.20em;
            text-transform: uppercase;
          }

          .presentation-title {
            margin: 0;
            font-size: 27px;
            line-height: 1.02;
            letter-spacing: -0.04em;
            font-weight: 900;
            color: #ffffff;
          }

          .presentation-title--small {
            font-size: 25px;
          }

          .presentation-address {
            margin: 0;
            font-size: 15px;
            line-height: 1.15;
            font-weight: 900;
            color: rgba(255, 255, 255, 0.86);
          }

          .presentation-image {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center center;
          }

          .presentation-image--placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--muted);
            font-size: 18px;
            font-weight: 900;
            text-align: center;
            padding: 8mm;
            background: #ffffff;
            border: 1px solid var(--line);
          }

          /* PAGE 1 */

          .presentation-first-page {
            flex: 1;
            display: grid;
            grid-template-columns: 0.84fr 1.5fr;
            gap: 6mm;
            min-height: 0;
          }

          .presentation-first-page__left {
            display: flex;
            flex-direction: column;
            gap: 3.6mm;
            min-height: 0;
          }

          .presentation-first-page__intro {
            height: 36mm;
            padding: 7mm;
            border-radius: 6mm;
            background: #ffffff;
            border: 1px solid var(--line);
            box-shadow: none;
            overflow: hidden;
          }

          .presentation-first-page__intro-title {
            margin: 0 0 4mm;
            font-size: 27px;
            line-height: 1.00;
            letter-spacing: -0.04em;
            font-weight: 900;
            color: var(--navy-2);
          }

          .presentation-first-page__intro-subtitle {
            margin: 0;
            font-size: 15px;
            line-height: 1.18;
            font-weight: 900;
            color: var(--muted);
          }

          .presentation-key-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 3.4mm;
          }

          .presentation-key-card {
            min-height: 24mm;
            padding: 5.4mm 7mm;
            border-radius: 6mm;
            background: #ffffff;
            border: 1px solid var(--line);
            box-shadow: none;
            overflow: hidden;
          }

          .presentation-key-card--price {
            background: #071827 !important;
            border-color: rgba(213, 179, 107, 0.32);
          }

          .presentation-key-card__label {
            margin: 0 0 1.6mm;
            font-size: 4mm;
            line-height: 1.05;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            font-weight: 900;
            color: var(--muted);
            white-space: nowrap;
          }

          .presentation-key-card--price .presentation-key-card__label {
            color: var(--gold-soft);
          }

          .presentation-key-card__value {
            margin: 0;
            font-size: 8.8mm;
            line-height: 1.00;
            letter-spacing: -0.045em;
            font-weight: 900;
            color: var(--navy-2);
            word-break: break-word;
          }

          .presentation-key-card--price .presentation-key-card__value {
            color: #ffffff;
            font-size: 9.3mm;
          }

          .presentation-first-page__right {
            min-height: 0;
          }

          .presentation-main-photo {
            width: 100%;
            height: 100%;
            min-height: 155mm;
            border-radius: 8mm;
            overflow: hidden;
            background: #ffffff;
            border: 1px solid rgba(16, 44, 74, 0.10);
            box-shadow: none;
            object-fit: contain;
            object-position: center center;
          }

          /* PAGE 2 */

          .presentation-page--details {
            position: relative;
            padding-bottom: 0;
          }

          .presentation-page--details .presentation-second-page {
            flex: 1;
            display: block;
            height: auto;
            min-height: 0;
            overflow: hidden;
            padding-bottom: 34mm;
            break-inside: avoid;
            page-break-inside: avoid;
          }

          .presentation-page--details .presentation-second-page__content {
            display: block;
            height: 116mm;
            min-height: 0;
            overflow: hidden;
            break-inside: avoid;
            page-break-inside: avoid;
          }

          .presentation-features-card,
          .presentation-contacts-card {
            padding: 4.4mm 4.8mm;
            border-radius: 6mm;
            background: #ffffff;
            border: 1px solid var(--line);
            box-shadow: none;
            overflow: hidden;
            break-inside: avoid;
            page-break-inside: avoid;
          }

          .presentation-features-card--full {
            height: 116mm;
          }

          .presentation-section-title {
            margin: 0 0 10mm;
            font-size: 27px;
            line-height: 1.00;
            letter-spacing: -0.03em;
            font-weight: 900;
            color: var(--navy-2);
          }

          .presentation-features-grid--large {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 4mm;
          }

          .presentation-feature-item--large {
            min-height: 24mm;
            padding: 4.7mm 5.5mm;
            border-radius: 5mm;
            background: #ffffff;
            border: 1px solid var(--line);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
          }

          .presentation-feature-item__label {
            margin: 0 0 1.8mm;
            font-size: 4.25mm;
            line-height: 1.05;
            text-transform: uppercase;
            letter-spacing: 0.095em;
            font-weight: 900;
            color: var(--muted);
            white-space: nowrap;
          }

          .presentation-feature-item__value {
            margin: 0;
            font-size: 8.4mm;
            line-height: 1.00;
            font-weight: 900;
            letter-spacing: -0.04em;
            color: var(--navy-2);
            word-break: break-word;
          }

          /* CONTACTS FIXED TO BOTTOM OF PAGE 2 */

          .presentation-page--details .presentation-contacts-card {
            position: absolute;
            left: 8mm;
            right: 8mm;
            bottom: 0;
            height: 31mm;
            padding: 4mm 7mm;
            border-radius: 6mm 6mm 0 0;
            background: #071827 !important;
            border: 1px solid rgba(213, 179, 107, 0.28);
            box-shadow: none;
            z-index: 5;
          }

          .presentation-page--details .presentation-contacts-card .presentation-section-title {
            color: #ffffff;
            margin-bottom: 3mm;
            font-size: 18px;
            line-height: 1.00;
          }

          .presentation-page--details .presentation-contacts-grid {
            display: grid;
            grid-template-columns: 1.15fr 1fr 1fr;
            gap: 10mm;
          }

          .presentation-page--details .presentation-contact-item__label {
            margin: 0 0 1.6mm;
            font-size: 9px;
            line-height: 1.1;
            color: var(--gold-soft);
            text-transform: uppercase;
            letter-spacing: 0.12em;
            font-weight: 900;
            white-space: nowrap;
          }

          .presentation-page--details .presentation-contact-item__value {
            margin: 0;
            font-size: 14px;
            line-height: 1.05;
            font-weight: 900;
            color: #ffffff;
            word-break: break-word;
          }

          /* PAGE 3 — PLAN + MAP */

          .presentation-page--plan {
            position: relative;
          }

          .presentation-plan-page {
            flex: 1;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 5mm;
            min-height: 0;
          }

          .presentation-plan-card,
          .presentation-map-card {
            position: relative;
            padding: 5mm;
            border-radius: 7mm;
            background: #ffffff;
            border: 1px solid var(--line);
            box-shadow: none;
            overflow: hidden;
          }

          .presentation-plan-card__title,
          .presentation-map-card__title {
            position: absolute;
            top: 5mm;
            left: 5mm;
            z-index: 2;
            margin: 0;
            padding: 2.5mm 4mm;
            border-radius: 999px;
            background: #ffffff;
            border: 1px solid rgba(16, 44, 74, 0.10);
            color: var(--navy-2);
            font-size: 15px;
            line-height: 1;
            font-weight: 900;
            letter-spacing: -0.01em;
            box-shadow: none;
          }

          .presentation-floorplan-image {
            width: 100%;
            height: 100%;
            border-radius: 5.5mm;
            object-fit: fill;
            object-position: center center;
            background: #ffffff;
            border: 1px solid rgba(16, 44, 74, 0.08);
          }

          .presentation-map-placeholder {
            width: 100%;
            height: 100%;
            border-radius: 5.5mm;
            background:
              linear-gradient(rgba(255, 255, 255, 0.28), rgba(255, 255, 255, 0.28)),
              repeating-linear-gradient(
                0deg,
                rgba(16, 44, 74, 0.08) 0,
                rgba(16, 44, 74, 0.08) 1px,
                transparent 1px,
                transparent 12px
              ),
              repeating-linear-gradient(
                90deg,
                rgba(16, 44, 74, 0.08) 0,
                rgba(16, 44, 74, 0.08) 1px,
                transparent 1px,
                transparent 12px
              ),
              linear-gradient(135deg, #e8edf3, #f8fbff);
            border: 1px solid rgba(16, 44, 74, 0.08);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
          }

          .presentation-map-image {
            width: 100%;
            height: 100%;
            border-radius: 5.5mm;
            object-fit: cover;
            object-position: center center;
            background: #f8fbff;
            border: 1px solid rgba(16, 44, 74, 0.08);
          }

          .presentation-map-pin {
            width: 22mm;
            height: 22mm;
            border-radius: 50% 50% 50% 0;
            background: var(--navy-3);
            transform: rotate(-45deg);
            position: relative;
            box-shadow: none;
          }

          .presentation-map-pin::after {
            content: "";
            position: absolute;
            width: 8mm;
            height: 8mm;
            border-radius: 50%;
            background: var(--gold);
            left: 7mm;
            top: 7mm;
          }

          .presentation-map-label {
            position: absolute;
            right: 8mm;
            bottom: 8mm;
            padding: 3mm 4mm;
            border-radius: 4mm;
            background: #ffffff;
            color: var(--navy-2);
            font-size: 14px;
            font-weight: 900;
            border: 1px solid rgba(16, 44, 74, 0.08);
            box-shadow: none;
          }

          /* FULLSCREEN PHOTO PAGES */

          .presentation-page--photo {
            padding: 0;
            background: #ffffff;
          }

          .presentation-page--photo::before {
            display: none;
          }

          .presentation-full-photo {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: contain;
            object-position: center center;
            background: #ffffff;
            z-index: 1;
          }

          .presentation-photo-caption {
            position: absolute;
            right: 0;
            bottom: 0;
            z-index: 2;
            min-width: 52mm;
            height: 14mm;
            padding: 3.6mm 7mm;
            border-radius: 8mm 0 0 0;
            background: #ffffff;
            color: var(--navy-2);
            font-size: 15px;
            font-weight: 900;
            text-align: center;
            border: 1px solid rgba(16, 44, 74, 0.08);
            box-shadow: none;
          }
        </style>
      </head>

      <body>
        <section class="presentation-page">
          <div class="presentation-page__header">
            <div class="presentation-brand">
              ${renderLogo(presentation.logoUrl)}
              <div class="presentation-brand__content">
                <div class="presentation-kicker">Коммерческая недвижимость</div>
                <h1 class="presentation-title">${escapeHtml(presentation.title)}</h1>
                <p class="presentation-address">${renderText(presentation.address)}</p>
              </div>
            </div>
          </div>

          <div class="presentation-first-page">
            <div class="presentation-first-page__left">
              <div class="presentation-first-page__intro">
                <h2 class="presentation-first-page__intro-title">${escapeHtml(presentation.title)}</h2>
                <p class="presentation-first-page__intro-subtitle">
                  Премиальная презентация объекта коммерческой недвижимости
                </p>
              </div>

              <div class="presentation-key-grid">
                <div class="presentation-key-card presentation-key-card--price">
                  <div class="presentation-key-card__label">Цена</div>
                  <p class="presentation-key-card__value">${renderText(presentation.price)}</p>
                </div>

                <div class="presentation-key-card">
                  <div class="presentation-key-card__label">Цена за м²</div>
                  <p class="presentation-key-card__value">${renderText(presentation.pricePerSquare)}</p>
                </div>

                <div class="presentation-key-card">
                  <div class="presentation-key-card__label">Тип сделки</div>
                  <p class="presentation-key-card__value">${renderText(presentation.dealType)}</p>
                </div>

                <div class="presentation-key-card">
                  <div class="presentation-key-card__label">Площадь</div>
                  <p class="presentation-key-card__value">${renderText(presentation.area)}</p>
                </div>
              </div>
            </div>

            <div class="presentation-first-page__right">
              ${renderImage(
                presentation.mainImage?.url,
                presentation.mainImage?.alt ?? presentation.title,
                "presentation-main-photo",
              )}
            </div>
          </div>
        </section>

        <section class="presentation-page presentation-page--details">
          <div class="presentation-page__header">
            <div class="presentation-brand">
              ${renderLogo(presentation.logoUrl)}
              <div class="presentation-brand__content">
                <div class="presentation-kicker">Подробности объекта</div>
                <h2 class="presentation-title presentation-title--small">${escapeHtml(presentation.title)}</h2>
                <p class="presentation-address">${renderText(presentation.address)}</p>
              </div>
            </div>
          </div>

          <div class="presentation-second-page">
            <div class="presentation-second-page__content">
              <div class="presentation-features-card presentation-features-card--full">
                <h3 class="presentation-section-title">Характеристики</h3>

                <div class="presentation-features-grid presentation-features-grid--large">
                  ${visibleTechnicalFields
                    .map(
                      (field) => `
                        <div class="presentation-feature-item presentation-feature-item--large">
                          <div class="presentation-feature-item__label">${escapeHtml(field.label)}</div>
                          <p class="presentation-feature-item__value">${escapeHtml(field.value)}</p>
                        </div>
                      `,
                    )
                    .join("")}
                </div>
              </div>
            </div>

            <div class="presentation-contacts-card">
              <h3 class="presentation-section-title">Контактная информация</h3>

              <div class="presentation-contacts-grid">
                <div class="presentation-contact-item">
                  <div class="presentation-contact-item__label">Контактное лицо</div>
                  <p class="presentation-contact-item__value">${renderText(presentation.contactName, "Не указан")}</p>
                </div>

                <div class="presentation-contact-item">
                  <div class="presentation-contact-item__label">Email</div>
                  <p class="presentation-contact-item__value">${renderText(presentation.contactEmail, "Не указан")}</p>
                </div>

                <div class="presentation-contact-item">
                  <div class="presentation-contact-item__label">Телефон</div>
                  <p class="presentation-contact-item__value">${renderText(presentation.contactPhone, "Не указан")}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="presentation-page presentation-page--plan">
          <div class="presentation-page__header">
            <div class="presentation-brand">
              ${renderLogo(presentation.logoUrl)}
              <div class="presentation-brand__content">
                <div class="presentation-kicker">Планировка и карта</div>
                <h2 class="presentation-title presentation-title--small">${escapeHtml(presentation.title)}</h2>
                <p class="presentation-address">${renderText(presentation.address)}</p>
              </div>
            </div>
          </div>

          <div class="presentation-plan-page">
            <div class="presentation-plan-card">
              <h3 class="presentation-plan-card__title">Планировка</h3>
              ${floorPlanMarkup}
            </div>

            <div class="presentation-map-card">
              <h3 class="presentation-map-card__title">Карта</h3>
              ${mapMarkup}
            </div>
          </div>
        </section>

        ${galleryPageMarkup}
      </body>
    </html>
  `;
}
