import { access, readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { Injectable } from "@nestjs/common";
import { lookup as lookupMimeType } from "mime-types";
import sharp from "sharp";
import {
  bigintToNumber,
  decimalToNumber,
  formatInteger,
} from "../../common/utils/number.utils";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { StorageService } from "../storage/storage.service";
import { EstateWithImagesAndUser } from "./crm-estates.types";

const MAX_INLINE_PRESENTATION_IMAGE_BYTES = 2 * 1024 * 1024;
const PRESENTATION_IMAGE_MAX_WIDTH = 1800;
const PRESENTATION_IMAGE_MAX_HEIGHT = 1200;
const PRESENTATION_IMAGE_JPEG_QUALITY = 78;

export interface EstatePresentationImage {
  url: string;
  alt: string;
}

export interface EstatePresentationField {
  label: string;
  value: string;
}

export interface EstatePresentationCoordinates {
  longitude: number;
  latitude: number;
  source: string;
  rawType: string;
  rawValue: string;
}

export interface EstatePresentationPayload {
  estateId: number;
  title: string;
  address: string | null;

  logoUrl: string | null;

  mainImage: EstatePresentationImage | null;
  coverImages: EstatePresentationImage[];
  floorPlanImage: EstatePresentationImage | null;
  featureImages: EstatePresentationImage[];
  galleryImages: EstatePresentationImage[];
  mapImageUrl: string | null;
  mapPlaceholderText: string;
  mapCoordinates: EstatePresentationCoordinates | null;

  price: string | null;
  area: string | null;
  pricePerSquare: string | null;
  dealType: string | null;
  description: string | null;
  technicalFields: EstatePresentationField[];

  contactName: string | null;
  contactEmail: string | null;
  contactPhone: string | null;
}

function formatDecimal(value: number | null, suffix = ""): string | null {
  if (value === null) {
    return null;
  }

  const formatted = new Intl.NumberFormat("ru-RU", {
    minimumFractionDigits: Number.isInteger(value) ? 0 : 1,
    maximumFractionDigits: 1,
  }).format(value);

  return suffix ? `${formatted} ${suffix}` : formatted;
}

function toAbsoluteUrl(url: string, origin: string): string {
  try {
    return new URL(url, origin).toString();
  } catch {
    return url;
  }
}

function compactTextParts(values: Array<string | null | undefined>): string | null {
  const normalized = values
    .map((value) => value?.trim())
    .filter((value): value is string => Boolean(value));

  return normalized.length > 0 ? normalized.join(", ") : null;
}

function compactName(firstName?: string | null, lastName?: string | null): string | null {
  return compactTextParts([firstName, lastName]);
}

function stringifyDebugValue(value: unknown): string {
  if (value === null || value === undefined) {
    return String(value);
  }

  if (typeof value === "string") {
    return value;
  }

  try {
    return JSON.stringify(value).slice(0, 160);
  } catch {
    return String(value).slice(0, 160);
  }
}

function parseCoordinatesString(coordinates: string | null | undefined, source: string): EstatePresentationCoordinates | null {
  if (!coordinates) {
    return null;
  }

  const parts = coordinates.trim().split(/\s+/).map((part) => Number(part));
  if (parts.length !== 2 || parts.some((part) => Number.isNaN(part))) {
    return null;
  }

  return {
    longitude: parts[0],
    latitude: parts[1],
    source,
    rawType: typeof coordinates,
    rawValue: stringifyDebugValue(coordinates),
  };
}

function parseFiniteNumber(value: unknown): number | null {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }

  if (typeof value !== "string" || !value.trim()) {
    return null;
  }

  const parsed = Number(value.trim().replace(",", "."));
  return Number.isFinite(parsed) ? parsed : null;
}

function resolveEstateCoordinates(estate: Record<string, unknown>): EstatePresentationCoordinates | null {
  const directCoordinates = parseCoordinatesString(estate.coordinates as string | null | undefined, "coordinates");
  if (directCoordinates) {
    return directCoordinates;
  }

  const coords = estate.coords;
  if (typeof coords === "string") {
    const parsedCoords = parseCoordinatesString(coords, "coords");
    if (parsedCoords) {
      return parsedCoords;
    }
  }

  if (coords && typeof coords === "object" && !Array.isArray(coords)) {
    const rawCoords = coords as Record<string, unknown>;
    const longitude = parseFiniteNumber(rawCoords.longitude ?? rawCoords.lng ?? rawCoords.lon);
    const latitude = parseFiniteNumber(rawCoords.latitude ?? rawCoords.lat);
    if (longitude !== null && latitude !== null) {
      return {
        longitude,
        latitude,
        source: "coords",
        rawType: "object",
        rawValue: stringifyDebugValue(coords),
      };
    }
  }

  const longitude = parseFiniteNumber(estate.longitude ?? estate.lng ?? estate.lon);
  const latitude = parseFiniteNumber(estate.latitude ?? estate.lat);
  if (longitude !== null && latitude !== null) {
    return {
      longitude,
      latitude,
      source: "lat_lng_fields",
      rawType: "fields",
      rawValue: stringifyDebugValue({ longitude, latitude }),
    };
  }

  return null;
}

@Injectable()
export class CrmEstatePresentationMapper {
  constructor(private readonly storageService: StorageService) {}

  async mapEstateToPresentation(
    estate: EstateWithImagesAndUser,
    origin: string,
    generator: AuthenticatedCrmUser,
  ): Promise<EstatePresentationPayload> {
    const estateAny = estate as any;

    const price = decimalToNumber(estateAny.price);
    const area = decimalToNumber(estateAny.area);

    const sortedImages = [...(estateAny.images ?? [])].sort(
      (left, right) =>
        Number(right.isMain) - Number(left.isMain) ||
        Number(left.id > right.id) - Number(left.id < right.id),
    );

    const presentationImages = await Promise.all(
      sortedImages.map(async (image, index) => ({
        url: await this.resolvePresentationImageUrl(image.url, origin),
        alt: `${estateAny.title} - фото ${index + 1}`,
        isPlan: Boolean(image.isPlan),
      })),
    );

    /*
      Новая логика фото:

      1–3 фото  -> первая страница: главное слева + 2 справа
      4-е фото  -> планировка
      Все фото  -> после характеристик, включая первые 3 фото

      То есть, чтобы планировка попала в отдельный блок,
      загружай её 4-й по счёту.
    */
      const mainImage = presentationImages[0] ?? null;
      const floorPlanImage = presentationImages.find((image) => image.isPlan) ?? null;
      const nonPlanImages = presentationImages.filter((image) => !image.isPlan);

      // 1–3 фото — первая страница
      const coverImages = nonPlanImages.slice(0, 3);

      // 5–6 фото — вторая страница после характеристик
      const featureImages = nonPlanImages.slice(3, 5);

      // 7+ фото — отдельная галерея
      const galleryImages = nonPlanImages.slice(5);

    const levelsCount = estateAny.levelsCount ?? null;
    const occupiedFloorsText = estateAny.occupiedFloorsText?.trim() || null;

    const technicalFields: EstatePresentationField[] = [
      { label: "Тип сделки", value: estateAny.dealType ?? "" },
      { label: "Тип объекта", value: estateAny.estateType ?? "" },
      { label: "Площадь", value: formatDecimal(area, "м²") ?? "" },
      {
        label: "Этаж",
        value:
          estateAny.floor === null || estateAny.floor === undefined
            ? ""
            : String(estateAny.floor),
      },
      ...(levelsCount !== null && levelsCount > 1
        ? [{ label: "Формат", value: "Многоуровневый объект" }]
        : []),
      ...(levelsCount !== null
        ? [{ label: "Количество уровней", value: String(levelsCount) }]
        : []),
      ...(occupiedFloorsText
        ? [{ label: "Занимаемые этажи / уровни", value: occupiedFloorsText }]
        : []),
      {
        label: "Всего этажей",
        value:
          estateAny.allFloors === null || estateAny.allFloors === undefined
            ? ""
            : String(estateAny.allFloors),
      },
      { label: "Регион", value: estateAny.region ?? "" },
      { label: "Район", value: estateAny.district ?? "" },
      { label: "Метро", value: estateAny.metroStation ?? "" },
      { label: "Арендатор", value: estateAny.tenantType ?? "" },
      { label: "Срок договора", value: estateAny.contractTerm ?? "" },
      {
        label: "МАП",
        value:
          estateAny.map_ === null || estateAny.map_ === undefined
            ? ""
            : `${formatInteger(decimalToNumber(estateAny.map_) ?? 0)} ₽`,
      },
      { label: "Индексация", value: estateAny.indexing ?? "" },
      {
        label: "ГАП",
        value:
          estateAny.gap === null || estateAny.gap === undefined
            ? ""
            : `${formatInteger(decimalToNumber(estateAny.gap) ?? 0)} ₽`,
      },
      {
        label: "Мощность",
        value:
          estateAny.powerKw === null || estateAny.powerKw === undefined
            ? ""
            : `${formatDecimal(decimalToNumber(estateAny.powerKw), "кВт")}`,
      },
      {
        label: "Высота потолков",
        value:
          estateAny.ceilingHeightM === null || estateAny.ceilingHeightM === undefined
            ? ""
            : `${formatDecimal(decimalToNumber(estateAny.ceilingHeightM), "м")}`,
      },
    ].filter((field) => field.value.trim().length > 0);

    const pricePerSquare =
      price !== null && area !== null && area > 0
        ? formatInteger(Math.round(price / area))
        : null;

    const logoUrl = await this.resolveLogoUrl();
    const estateId = bigintToNumber(estateAny.id);
    const coordinates = resolveEstateCoordinates(estateAny);

    console.log("[PDF LOGO]", logoUrl ? "loaded" : "not found");

    return {
      estateId,
      title: estateAny.title,
      address: compactTextParts([
        estateAny.region,
        estateAny.district,
        estateAny.metroStation,
      ]),

      logoUrl,

      mainImage,
      coverImages,
      floorPlanImage,
      featureImages,
      galleryImages,
      mapImageUrl: null,
      mapPlaceholderText: coordinates ? "Карта временно недоступна" : "Координаты не указаны",
      mapCoordinates: coordinates,

      price: price === null ? null : `${formatInteger(price)} ₽`,
      area: formatDecimal(area, "м²"),
      pricePerSquare: pricePerSquare ? `${pricePerSquare} ₽/м²` : null,
      dealType: estateAny.dealType ?? null,
      description: estateAny.description?.trim() || null,
      technicalFields,

      contactName: compactName(generator.first_name, generator.last_name) ?? generator.email,
      contactEmail: generator.email,
      contactPhone: generator.phone_number || null,
    };
  }

  private async resolveLogoUrl(): Promise<string | null> {
    const candidates = [
      resolve(
        process.cwd(),
        "apps",
        "api",
        "src",
        "modules",
        "storage",
        "assets",
        "epas-logo.png",
      ),

      resolve(process.cwd(), "apps", "web", "public", "static", "img", "epas_logo.png"),
      resolve(process.cwd(), "apps", "web", "public", "static", "img", "logo.png"),
      resolve(process.cwd(), "apps", "web", "public", "static", "img", "logo-light.png"),
      resolve(process.cwd(), "apps", "web", "public", "static", "img", "logo-dark.png"),

      resolve(
        process.cwd(),
        "apps",
        "api",
        "src",
        "modules",
        "crm-estates",
        "assets",
        "epas-logo.png",
      ),
      resolve(process.cwd(), "src", "modules", "storage", "assets", "epas-logo.png"),
      resolve(process.cwd(), "src", "modules", "crm-estates", "assets", "epas-logo.png"),

      resolve(process.cwd(), "epas-logo.png"),
      resolve(__dirname, "..", "storage", "assets", "epas-logo.png"),
      resolve(__dirname, "assets", "epas-logo.png"),
    ];

    console.log("[PDF LOGO CWD]", process.cwd());

    for (const candidate of candidates) {
      const logoUrl = await this.tryInlineAsset(candidate);

      if (logoUrl) {
        console.log("[PDF LOGO] loaded from:", candidate);
        return logoUrl;
      }
    }

    console.log("[PDF LOGO] candidates checked:", candidates);

    return null;
  }

  private async resolvePresentationImageUrl(path: string, origin: string): Promise<string> {
    const inlineImage = await this.tryInlineLocalImage(path);

    if (inlineImage) {
      return inlineImage;
    }

    return toAbsoluteUrl(this.storageService.resolvePublicUrl(path), origin);
  }

  private async tryInlineLocalImage(path: string): Promise<string | null> {
    if (!path || (process.env.STORAGE_DRIVER ?? "local") !== "local") {
      return null;
    }

    const storageRoot = process.env.STORAGE_LOCAL_ROOT ?? "storage";
    const normalized = path
      .replace(/\\/g, "/")
      .replace(/^\/+/, "")
      .replace(/^storage\//, "");

    const filePath = resolve(process.cwd(), storageRoot, normalized);

    try {
      await access(filePath);
      const buffer = await readFile(filePath);
      if (buffer.length <= MAX_INLINE_PRESENTATION_IMAGE_BYTES) {
        const mimeType = lookupMimeType(filePath) || "image/png";
        return this.toDataUrl(buffer, mimeType);
      }

      const compressed = await sharp(buffer, { failOn: "none" })
        .rotate()
        .resize({
          width: PRESENTATION_IMAGE_MAX_WIDTH,
          height: PRESENTATION_IMAGE_MAX_HEIGHT,
          fit: "inside",
          withoutEnlargement: true,
        })
        .jpeg({
          quality: PRESENTATION_IMAGE_JPEG_QUALITY,
          mozjpeg: true,
        })
        .toBuffer();

      console.warn(
        `[PDF IMAGE] compressed inline image path=${normalized} originalSize=${buffer.length} compressedSize=${compressed.length}`,
      );

      if (compressed.length > 0) {
        return this.toDataUrl(compressed, "image/jpeg");
      }

      return null;
    } catch (error) {
      if (error instanceof Error) {
        console.warn(
          `[PDF IMAGE] compression failed path=${normalized} message=${error.message}`,
        );
      }
      return null;
    }
  }

  private async tryInlineAsset(filePath: string): Promise<string | null> {
    try {
      await access(filePath);

      const buffer = await readFile(filePath);
      const mimeType = lookupMimeType(filePath) || "image/png";

      return this.toDataUrl(buffer, mimeType);
    } catch {
      return null;
    }
  }

  private toDataUrl(buffer: Buffer, mimeType: string): string {
    return `data:${mimeType};base64,${buffer.toString("base64")}`;
  }
}
