import { Prisma } from "@prisma/client";
import { CrmEstateCianPayload, ESTATE_WITH_CIAN_INCLUDE } from "../cian/cian.types";

export interface OwnerContact {
  owner_phone: string;
  owner_name: string;
}

export interface ExistingImagePayload {
  id: number;
  delete?: boolean;
  is_main?: boolean;
  is_plan?: boolean;
}

export interface UploadedImageFile {
  buffer: Buffer;
  originalname: string;
  mimetype: string;
}

export interface CrmEstateWritePayload {
  title?: string;
  description?: string;
  area_description?: string | null;
  internal_info?: string | null;
  status?: string | null;
  tags?: string | null;
  estate_type?: string | null;
  deal_type?: string;
  area?: number | string | null;
  floor?: number | string | null;
  all_floors?: number | string | null;
  levels_count?: number | string | null;
  occupied_floors_text?: string | null;
  price?: number | string | null;
  region?: string;
  district?: string | null;
  metro_station?: string | null;
  priority?: boolean | string | null;
  active?: boolean | string | null;
  is_private_sale?: boolean | string | null;
  tenant_type?: string | null;
  map_?: number | string | null;
  contract_term?: string | null;
  indexing?: string | null;
  gap?: number | string | null;
  power_kw?: number | string | null;
  ceiling_height_m?: number | string | null;
  owner_type?: string | null;
  owner_contacts?: OwnerContact[];
  required_owner_phone?: string | null;
  required_owner_name?: string | null;
  not_define_coordinates?: boolean | string | null;
  user_id?: number | string | null;
  assigned_user_ids?: Array<number | string>;
  existing_images?: ExistingImagePayload[];
  plan_image_new_index?: number | string | null;
  cian?: CrmEstateCianPayload | null;
}

export interface CrmEstateListQuery {
  search?: string;
  status?: string;
  archivedOnly?: string;
  deal_type?: string;
  region?: string;
  district?: string;
  metro_station?: string;
  price_from?: string;
  price_to?: string;
  area_from?: string;
  area_to?: string;
  active?: string;
  cian_included?: string;
  xml?: string;
  skip?: string;
  limit?: string;
}

export interface CrmEstateQuickPatchPayload {
  active?: boolean | string | null;
  priority?: boolean | string | null;
}

export interface CrmEstateReassignPayload {
  estate_ids?: Array<number | string>;
  broker_id?: number | string | null;
}

export type EstateWithImagesAndUser = Prisma.EstateGetPayload<{
  include: typeof ESTATE_WITH_CIAN_INCLUDE;
}>;
