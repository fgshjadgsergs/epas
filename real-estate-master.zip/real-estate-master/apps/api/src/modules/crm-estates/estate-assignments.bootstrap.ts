import { Injectable, Logger, OnModuleInit } from "@nestjs/common";
import { PrismaService } from "../../prisma/prisma.service";

function isMissingEstateAssignmentsTable(error: unknown): boolean {
  if (!error || typeof error !== "object") {
    return false;
  }

  const prismaError = error as {
    code?: string;
    meta?: {
      code?: string;
      message?: string;
    };
  };

  return (
    prismaError.code === "P2010" &&
    Boolean(
      prismaError.meta?.code === "42P01" ||
        prismaError.meta?.message?.includes('relation "estate_assignments" does not exist'),
    )
  );
}

@Injectable()
export class EstateAssignmentsBootstrap implements OnModuleInit {
  private readonly logger = new Logger(EstateAssignmentsBootstrap.name);

  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit(): Promise<void> {
    try {
      const inserted = await this.prisma.$executeRaw`
        INSERT INTO estate_assignments (estate_id, user_id, created_at)
        SELECT e.id, e.user_id, COALESCE(e.created_at, NOW())
        FROM estates e
        INNER JOIN users u
          ON u.id = e.user_id
        LEFT JOIN estate_assignments ea
          ON ea.estate_id = e.id
         AND ea.user_id = e.user_id
        WHERE e.user_id IS NOT NULL
          AND u.role IN ('BROKER', 'ADMIN')
          AND ea.id IS NULL
      `;

      this.logger.log(`Estate assignment bootstrap synced ${inserted} legacy assignments`);
    } catch (error) {
      if (isMissingEstateAssignmentsTable(error)) {
        this.logger.warn("Skipped estate assignment bootstrap because the estate_assignments table is missing");
        return;
      }

      throw error;
    }
  }
}
