import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
  Res,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { FilesInterceptor } from "@nestjs/platform-express";
import { Request, Response } from "express";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CrmEstatePresentationService } from "./crm-estate-presentation.service";
import {
  CrmEstateListQuery,
  CrmEstateQuickPatchPayload,
  CrmEstateReassignPayload,
  CrmEstateWritePayload,
  UploadedImageFile,
} from "./crm-estates.types";
import { CrmEstatesService } from "./crm-estates.service";

function parsePayload(rawData: unknown, body: Record<string, unknown>): CrmEstateWritePayload {
  if (typeof rawData === "string" && rawData.trim()) {
    return JSON.parse(rawData) as CrmEstateWritePayload;
  }

  return body as unknown as CrmEstateWritePayload;
}

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/estates")
export class CrmEstatesController {
  constructor(
    private readonly crmEstatesService: CrmEstatesService,
    private readonly crmEstatePresentationService: CrmEstatePresentationService,
  ) {}

  @Get()
  getAll(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: CrmEstateListQuery,
  ): Promise<Record<string, unknown>> {
    return this.crmEstatesService.listAll(user, query);
  }

  @Get("my")
  getMine(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: CrmEstateListQuery,
  ): Promise<Record<string, unknown>> {
    return this.crmEstatesService.listMine(user, query);
  }

  @Get("moderation")
  getModerationQueue(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: CrmEstateListQuery,
  ): Promise<Record<string, unknown>> {
    return this.crmEstatesService.listModerationQueue(user, query);
  }

  @Get("upload")
  getUploadQueue(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: CrmEstateListQuery,
  ): Promise<Record<string, unknown>> {
    return this.crmEstatesService.listUploadQueue(user, query);
  }

  @Get(":estateId/presentation.pdf")
  async downloadPresentationPdf(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Req() request: Request,
    @Res() response: Response,
    @Query("archived") archived?: string,
  ): Promise<void> {
    const forwardedProtocol = String(request.headers["x-forwarded-proto"] ?? request.protocol ?? "http").split(",")[0].trim();
    const forwardedHost = String(request.headers["x-forwarded-host"] ?? request.headers.host ?? "127.0.0.1:3000").split(",")[0].trim();
    const origin = `${forwardedProtocol}://${forwardedHost}`;
    const pdf = await this.crmEstatePresentationService.generatePdf(
      estateId,
      user,
      origin,
      ["1", "true", "yes", "on"].includes((archived ?? "").toLowerCase()),
    );

    response.setHeader("Content-Type", "application/pdf");
    response.setHeader("Cache-Control", "private, no-store, max-age=0, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setHeader("Expires", "0");
    response.setHeader("Vary", "Cookie");
    response.setHeader("Content-Disposition", `attachment; filename="estate-${estateId}-presentation.pdf"`);
    response.send(pdf);
  }

  @Get(":estateId")
  getDetail(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query("archived") archived?: string,
  ): Promise<{ item: Record<string, unknown> }> {
    return this.crmEstatesService.getDetail(estateId, user, ["1", "true", "yes", "on"].includes((archived ?? "").toLowerCase()));
  }

  @Post()
  @UseInterceptors(FilesInterceptor("new_images"))
  create(
    @Body("data") rawData: string | undefined,
    @Body() body: Record<string, unknown>,
    @UploadedFiles() newImages: UploadedImageFile[],
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: Record<string, unknown> }> {
    return this.crmEstatesService.create(parsePayload(rawData, body), newImages ?? [], user);
  }

  @Put(":estateId")
  @UseInterceptors(FilesInterceptor("new_images"))
  update(
    @Param("estateId", ParseIntPipe) estateId: number,
    @Body("data") rawData: string | undefined,
    @Body() body: Record<string, unknown>,
    @UploadedFiles() newImages: UploadedImageFile[],
    @Req() request: Request,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: Record<string, unknown> }> {
    return this.crmEstatesService.update(estateId, parsePayload(rawData, body), newImages ?? [], user, request);
  }

  @Post(":estateId/actions/define-coordinates")
  defineCoordinates(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<Record<string, unknown>> {
    return this.crmEstatesService.defineCoordinatesByAddress(estateId, user);
  }

  @Post(":estateId/actions/quick-update")
  quickUpdate(
    @Param("estateId", ParseIntPipe) estateId: number,
    @Body() payload: CrmEstateQuickPatchPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<Record<string, unknown>> {
    return this.crmEstatesService.quickUpdate(estateId, payload, user);
  }

  @Post(":estateId/actions/duplicate")
  duplicate(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; duplicated: true }> {
    return this.crmEstatesService.duplicate(estateId, user);
  }

  @Post("actions/reassign")
  reassign(
    @Body() payload: CrmEstateReassignPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ updated: number; broker_id: number }> {
    return this.crmEstatesService.reassign(payload, user);
  }

  @Delete(":estateId")
  delete(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ deleted: true }> {
    return this.crmEstatesService.delete(estateId, user);
  }

  @Post(":estateId/actions/archive")
  archive(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ archived: true }> {
    return this.crmEstatesService.archive(estateId, user);
  }

  @Post(":estateId/actions/restore")
  restore(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ restored: true }> {
    return this.crmEstatesService.restore(estateId, user);
  }
}
