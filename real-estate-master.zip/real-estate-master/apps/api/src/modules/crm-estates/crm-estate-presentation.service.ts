import { Injectable, InternalServerErrorException, Logger, OnModuleDestroy } from "@nestjs/common";
import puppeteer, { Browser, Page } from "puppeteer-core";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CrmEstatePresentationMapper, EstatePresentationPayload } from "./crm-estate-presentation.mapper";
import { renderEstatePresentationHtml } from "./crm-estate-presentation.template";
import { CrmEstatesService } from "./crm-estates.service";

const CHROMIUM_EXECUTABLE_CANDIDATES = [
  process.env.PUPPETEER_EXECUTABLE_PATH,
  process.env.CHROMIUM_PATH,
  "/usr/bin/chromium-browser",
  "/usr/bin/chromium",
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
].filter((value): value is string => Boolean(value));
const MAP_SCREENSHOT_WIDTH = 760;
const MAP_SCREENSHOT_HEIGHT = 520;
const MAP_SCREENSHOT_TIMEOUT_MS = 7000;

@Injectable()
export class CrmEstatePresentationService implements OnModuleDestroy {
  private readonly logger = new Logger(CrmEstatePresentationService.name);
  private browser: Browser | null = null;
  private browserPromise: Promise<Browser> | null = null;

  constructor(
    private readonly crmEstatesService: CrmEstatesService,
    private readonly mapper: CrmEstatePresentationMapper,
  ) {}

  async onModuleDestroy(): Promise<void> {
    const browser = this.browser;
    this.browser = null;
    this.browserPromise = null;

    if (browser?.isConnected()) {
      await browser.close();
    }
  }

  async generatePdf(
    estateId: number,
    viewer: AuthenticatedCrmUser,
    origin: string,
    archived = false,
  ): Promise<Buffer> {
    const startedAt = performance.now();
    const prepareStartedAt = performance.now();
    const estate = await this.crmEstatesService.getEstateForPresentation(estateId, viewer, archived);
    const presentation = await this.mapper.mapEstateToPresentation(estate, origin, viewer);
    const browser = await this.getBrowser();
    presentation.mapImageUrl = await this.renderMapScreenshotSafely(browser, presentation);
    const html = renderEstatePresentationHtml(presentation);
    const prepareMs = Math.round(performance.now() - prepareStartedAt);
    const page = await browser.newPage();

    try {
      const setContentStartedAt = performance.now();
      await page.setContent(html, {
        waitUntil: "domcontentloaded",
      });
      await this.waitForImages(page);
      await page.emulateMediaType("print");
      const setContentMs = Math.round(performance.now() - setContentStartedAt);

      const pdfStartedAt = performance.now();
      const pdf = await page.pdf({
        format: "A4",
        landscape: true,
        printBackground: true,
        preferCSSPageSize: true,
      });
      const pdfMs = Math.round(performance.now() - pdfStartedAt);
      const totalMs = Math.round(performance.now() - startedAt);

      this.logger.log(
        `Generated estate presentation PDF estateId=${estateId} archived=${archived} totalMs=${totalMs} prepareMs=${prepareMs} setContentMs=${setContentMs} pdfMs=${pdfMs}`,
      );

      return Buffer.from(pdf);
    } catch (error) {
      const totalMs = Math.round(performance.now() - startedAt);
      this.logger.error(
        `Failed to generate estate presentation PDF estateId=${estateId} archived=${archived} totalMs=${totalMs} prepareMs=${prepareMs} message=${error instanceof Error ? error.message : String(error)}`,
        error instanceof Error ? error.stack : undefined,
      );
      throw error;
    } finally {
      await page.close().catch(() => undefined);
    }
  }

  private async getBrowser(): Promise<Browser> {
    if (this.browser && !this.browser.isConnected()) {
      this.browser = null;
      this.browserPromise = null;
    }

    if (this.browser?.isConnected()) {
      return this.browser;
    }

    if (!this.browserPromise) {
      this.browserPromise = this.launchBrowser();
    }

    try {
      this.browser = await this.browserPromise;
      return this.browser;
    } catch (error) {
      this.browser = null;
      this.browserPromise = null;
      throw error;
    }
  }

  private async launchBrowser(): Promise<Browser> {
    const executablePath = CHROMIUM_EXECUTABLE_CANDIDATES[0];

    if (!executablePath) {
      throw new InternalServerErrorException("Chromium executable path is not configured");
    }

    return puppeteer.launch({
      executablePath,
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
    });
  }

  private async renderMapScreenshotSafely(browser: Browser, presentation: EstatePresentationPayload): Promise<string | null> {
    try {
      return await this.renderMapScreenshot(browser, presentation);
    } catch (error) {
      this.logger.warn(
        `[PDF MAP] screenshot fallback estateId=${presentation.estateId} provider=leaflet_osm reason=unexpected_error message=${error instanceof Error ? error.message : String(error)}`,
      );
      return null;
    }
  }

  private async renderMapScreenshot(browser: Browser, presentation: EstatePresentationPayload): Promise<string | null> {
    const startedAt = performance.now();
    const coordinates = presentation.mapCoordinates;

    this.logger.log(
      `[PDF MAP] screenshot started estateId=${presentation.estateId} hasCoordinates=${Boolean(coordinates)} provider=leaflet_osm coordinatesSource=${coordinates?.source ?? "none"} coordinatesType=${coordinates?.rawType ?? "none"} coordinatesValue=${coordinates?.rawValue ?? "none"}`,
    );

    if (!coordinates) {
      this.logger.warn(
        `[PDF MAP] screenshot fallback estateId=${presentation.estateId} provider=leaflet_osm reason=no_coordinates durationMs=${Math.round(performance.now() - startedAt)}`,
      );
      return null;
    }

    const page = await browser.newPage();

    try {
      await page.setViewport({
        width: MAP_SCREENSHOT_WIDTH,
        height: MAP_SCREENSHOT_HEIGHT,
        deviceScaleFactor: 1,
      });
      await page.setContent(this.renderMapHtml(coordinates.latitude, coordinates.longitude), {
        waitUntil: "domcontentloaded",
        timeout: MAP_SCREENSHOT_TIMEOUT_MS,
      });
      await page.waitForFunction("window.__mapReady === true", {
        timeout: MAP_SCREENSHOT_TIMEOUT_MS,
      });

      const screenshot = await page.screenshot({
        type: "png",
        clip: {
          x: 0,
          y: 0,
          width: MAP_SCREENSHOT_WIDTH,
          height: MAP_SCREENSHOT_HEIGHT,
        },
      });
      const durationMs = Math.round(performance.now() - startedAt);
      this.logger.log(
        `[PDF MAP] screenshot success estateId=${presentation.estateId} provider=leaflet_osm durationMs=${durationMs}`,
      );

      return `data:image/png;base64,${Buffer.from(screenshot).toString("base64")}`;
    } catch (error) {
      const durationMs = Math.round(performance.now() - startedAt);
      this.logger.warn(
        `[PDF MAP] screenshot fallback estateId=${presentation.estateId} provider=leaflet_osm reason=render_failed durationMs=${durationMs} message=${error instanceof Error ? error.message : String(error)}`,
      );
      return null;
    } finally {
      await page.close().catch(() => undefined);
    }
  }

  private renderMapHtml(latitude: number, longitude: number): string {
    return `
      <!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
          <style>
            html,
            body,
            #map {
              width: ${MAP_SCREENSHOT_WIDTH}px;
              height: ${MAP_SCREENSHOT_HEIGHT}px;
              margin: 0;
              padding: 0;
              overflow: hidden;
              background: #f4f7fb;
            }

            .leaflet-control-attribution {
              font: 10px/1.2 Arial, sans-serif;
            }

            .pdf-map-pin {
              width: 28px;
              height: 28px;
              border-radius: 50% 50% 50% 0;
              background: #102c4a;
              border: 3px solid #ffffff;
              transform: rotate(-45deg);
              box-shadow: 0 4px 12px rgba(16, 44, 74, 0.28);
            }

            .pdf-map-pin::after {
              content: "";
              position: absolute;
              width: 9px;
              height: 9px;
              border-radius: 50%;
              background: #d5b36b;
              left: 6px;
              top: 6px;
            }
          </style>
        </head>
        <body>
          <div id="map"></div>
          <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
          <script>
            window.__mapReady = false;
            window.__mapError = null;

            try {
              const latitude = ${JSON.stringify(latitude)};
              const longitude = ${JSON.stringify(longitude)};
              const map = L.map("map", {
                attributionControl: true,
                dragging: false,
                scrollWheelZoom: false,
                doubleClickZoom: false,
                boxZoom: false,
                keyboard: false,
                zoomControl: false,
                preferCanvas: true
              }).setView([latitude, longitude], 15);

              const layer = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                maxZoom: 19,
                crossOrigin: true,
                attribution: "&copy; OpenStreetMap"
              });

              layer.on("load", () => {
                window.__mapReady = true;
              });
              layer.on("tileerror", (event) => {
                window.__mapError = "tileerror";
              });

              layer.addTo(map);
              L.marker([latitude, longitude], {
                icon: L.divIcon({
                  className: "",
                  html: '<div class="pdf-map-pin"></div>',
                  iconSize: [28, 28],
                  iconAnchor: [14, 28]
                })
              }).addTo(map);

              setTimeout(() => {
                if (!window.__mapReady && !window.__mapError) {
                  window.__mapReady = true;
                }
              }, 4500);
            } catch (error) {
              window.__mapError = error && error.message ? error.message : String(error);
            }
          </script>
        </body>
      </html>
    `;
  }

  private async waitForImages(page: Page): Promise<void> {
    const timeoutMs = 5000;

    try {
      await Promise.race([
        page.evaluate(`(() => {
          const images = Array.from(document.images);

          return Promise.all(
            images.map((img) => {
              if (img.complete) {
                return Promise.resolve();
              }

              return new Promise((resolve) => {
                img.addEventListener("load", () => resolve(null), { once: true });
                img.addEventListener("error", () => resolve(null), { once: true });
              });
            }),
          ).then(() => undefined);
        })()`),
        new Promise<void>((resolve) => {
          setTimeout(() => resolve(), timeoutMs);
        }),
      ]);
    } catch (error) {
      this.logger.warn(
        `PDF image wait failed, continuing without full image wait: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
}
