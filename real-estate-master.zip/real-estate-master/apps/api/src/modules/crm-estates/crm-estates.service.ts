import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from "@nestjs/common";
import { CrmRole, Prisma, User } from "@prisma/client";
import { Request } from "express";
import { CRM_ESTATE_LIST_DEFAULT_LIMIT, ESTATE_REQUIRED_FIELDS } from "../../common/domain/crm-form.constants";
import { bigintToNumber } from "../../common/utils/number.utils";
import { PrismaService } from "../../prisma/prisma.service";
import { CianService, CianValidationException } from "../cian/cian.service";
import { ESTATE_WITH_CIAN_INCLUDE } from "../cian/cian.types";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CLIENT_PIPELINE_STATUSES, ClientPipelineStatus } from "../crm-clients/crm-clients.types";
import {
  canEditEstate,
  canHardDeleteEstate,
  canReassignEstate,
  canRestoreEstate,
  canSoftDeleteEstate,
  canViewEstate,
  canViewArchivedEstate,
  isAdmin,
  isBroker,
  isOwner,
  isRop,
  isViewer,
  ScopedUserRef,
} from "../crm-auth/crm-permissions";
import { ESTATE_IMAGE_VALIDATION_MESSAGE, isAllowedEstateImageUpload, StorageService } from "../storage/storage.service";
import { YandexMapsService } from "../yandex-maps/yandex-maps.service";
import { CrmEstatesMapper } from "./crm-estates.mapper";
import {
  CrmEstateListQuery,
  CrmEstateReassignPayload,
  CrmEstateQuickPatchPayload,
  CrmEstateWritePayload,
  EstateWithImagesAndUser,
  ExistingImagePayload,
  OwnerContact,
  UploadedImageFile,
} from "./crm-estates.types";

const REQUIRED_FIELD_MESSAGE = "Field is required";
const ADMIN_REQUIRED_MESSAGE = "Admin access required";
const MAX_CRM_ESTATE_LIST_LIMIT = 100;
const ESTATE_FORBIDDEN_MESSAGE = "You can manage only permitted estates";
const MAX_ESTATE_ASSIGNMENTS = 3;
const MAX_OCCUPIED_FLOORS_TEXT_LENGTH = 255;
const ASSIGNMENT_MANAGEMENT_FORBIDDEN_MESSAGE = "Только owner и admin могут менять назначения объекта";
const ASSIGNMENT_LIMIT_MESSAGE = "Можно назначить не больше 3 пользователей";
const ASSIGNMENT_ROLE_INVALID_MESSAGE = "Можно назначать только брокеров и администраторов";
const BROKER_REQUIRED_MESSAGE = "Выберите брокера для объекта";
const BROKER_REFERENCE_INVALID_MESSAGE = "Нужно выбрать пользователя с ролью брокер";

interface ParsedEstateListQuery {
  search: string | null;
  status: ClientPipelineStatus | null;
  deal_type: string | null;
  region: string | null;
  district: string | null;
  metro_station: string | null;
  price_from: number | null;
  price_to: number | null;
  area_from: number | null;
  area_to: number | null;
  active: boolean | null;
  archivedOnly: boolean;
  cian_included: boolean | null;
  skip: number;
  limit: number;
}

function normalizeText(value: string | null | undefined): string | null {
  if (value === undefined || value === null) {
    return null;
  }

  return String(value);
}

function parseNullableNumber(value: number | string | null | undefined): number | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }

  const normalized = value.trim().replace(/\s+/g, "").replace(/,/g, ".");
  if (!normalized) {
    return null;
  }

  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseNullableInteger(value: number | string | null | undefined): number | null {
  const parsed = parseNullableNumber(value);
  if (parsed === null) {
    return null;
  }

  return Number.isInteger(parsed) ? parsed : null;
}

function parseIntegerArray(values: Array<number | string> | null | undefined): number[] {
  if (!values || values.length === 0) {
    return [];
  }

  return values
    .map((value) => parseNullableInteger(value))
    .filter((value): value is number => value !== null && value > 0);
}

function parseBoolean(value: boolean | string | null | undefined, fallback: boolean): boolean {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }

  if (typeof value === "boolean") {
    return value;
  }

  return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}

function parseBooleanFilter(value: string | null | undefined): boolean | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  if (["1", "true", "yes", "on"].includes(value.toLowerCase())) {
    return true;
  }

  if (["0", "false", "no", "off"].includes(value.toLowerCase())) {
    return false;
  }

  return null;
}

function parsePipelineStatusFilter(value: string | null | undefined): ClientPipelineStatus | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const normalized = value.toLowerCase();
  return CLIENT_PIPELINE_STATUSES.includes(normalized as ClientPipelineStatus) ? (normalized as ClientPipelineStatus) : null;
}

function serializeOwnerContacts(contacts: OwnerContact[]): string {
  if (contacts.length === 0) {
    return "";
  }

  return contacts.map((contact) => `${contact.owner_phone} *-* ${contact.owner_name}`).join(", ");
}

function parseListQuery(query: CrmEstateListQuery): ParsedEstateListQuery {
  const priceFrom = parseNullableNumber(query.price_from);
  const priceTo = parseNullableNumber(query.price_to);
  const areaFrom = parseNullableNumber(query.area_from);
  const areaTo = parseNullableNumber(query.area_to);
  const limit = parseNullableInteger(query.limit);
  const skip = parseNullableInteger(query.skip);

  return {
    search: normalizeText(query.search)?.trim() || null,
    status: parsePipelineStatusFilter(query.status),
    deal_type: normalizeText(query.deal_type),
    region: normalizeText(query.region),
    district: normalizeText(query.district),
    metro_station: normalizeText(query.metro_station)?.trim() || null,
    price_from: priceFrom !== null && priceTo !== null && priceFrom > priceTo ? null : priceFrom,
    price_to: priceFrom !== null && priceTo !== null && priceFrom > priceTo ? null : priceTo,
    area_from: areaFrom !== null && areaTo !== null && areaFrom > areaTo ? null : areaFrom,
    area_to: areaFrom !== null && areaTo !== null && areaFrom > areaTo ? null : areaTo,
    active: parseBooleanFilter(query.active),
    archivedOnly: parseBoolean(query.archivedOnly, false),
    cian_included: parseBooleanFilter(query.cian_included ?? query.xml),
    skip: skip !== null && skip >= 0 ? skip : 0,
    limit:
      limit !== null && limit > 0
        ? Math.min(limit, MAX_CRM_ESTATE_LIST_LIMIT)
        : CRM_ESTATE_LIST_DEFAULT_LIMIT,
  };
}

@Injectable()
export class CrmEstatesService {
  private readonly logger = new Logger(CrmEstatesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly cianService: CianService,
    private readonly storageService: StorageService,
    private readonly yandexMapsService: YandexMapsService,
    private readonly mapper: CrmEstatesMapper,
  ) {}

  async listAll(
    viewer: AuthenticatedCrmUser,
    query: CrmEstateListQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number; filters: ParsedEstateListQuery; parity: Record<string, string[]> }> {
    this.assertCanAccessEstateLists(viewer);

    const filters = parseListQuery(query);
    const where = this.buildEstateListWhere(filters, this.buildEstateVisibilityWhere(viewer));
    const [estates, total] = await this.prisma.$transaction([
      this.prisma.estate.findMany({
        where,
        include: ESTATE_WITH_CIAN_INCLUDE,
        orderBy: {
          id: "desc",
        },
        skip: filters.skip,
        take: filters.limit,
      }),
      this.prisma.estate.count({ where }),
    ]);

    return {
      items: estates.map((estate) => this.mapper.toListItem(estate)),
      total,
      skip: filters.skip,
      limit: filters.limit,
      filters,
      parity: {
        exact: [
          "Business filters cover search, region, district, metro, price, area, active, and CIAN upload flags.",
        ],
        approximate: [
          "Response is JSON pagination data.",
        ],
      },
    };
  }

  async listMine(
    viewer: AuthenticatedCrmUser,
    query: CrmEstateListQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number; filters: ParsedEstateListQuery; parity: Record<string, string[]> }> {
    if (isViewer(viewer)) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }

    const filters = parseListQuery(query);
    const where = this.buildEstateListWhere(filters, {
      assignments: {
        some: {
          userId: BigInt(viewer.id),
        },
      },
    });
    const [estates, total] = await this.prisma.$transaction([
      this.prisma.estate.findMany({
        where,
        include: ESTATE_WITH_CIAN_INCLUDE,
        orderBy: {
          id: "desc",
        },
        skip: filters.skip,
        take: filters.limit,
      }),
      this.prisma.estate.count({ where }),
    ]);

    return {
      items: estates.map((estate) => this.mapper.toListItem(estate)),
      total,
      skip: filters.skip,
      limit: filters.limit,
      filters,
      parity: {
        exact: [
          "List is restricted to the current user's own estates.",
        ],
        approximate: [
          "Response is JSON pagination data.",
        ],
      },
    };
  }

  async listModerationQueue(
    viewer: AuthenticatedCrmUser,
    query: CrmEstateListQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number; filters: ParsedEstateListQuery; parity: Record<string, string[]> }> {
    this.assertCanAccessEstateLists(viewer);

    const filters = parseListQuery(query);
    const where = this.buildEstateListWhere(filters, {
      ...this.buildEstateScopeWhere(viewer),
      active: true,
      cianModeration: true,
    });
    const [estates, total] = await this.prisma.$transaction([
      this.prisma.estate.findMany({
        where,
        include: ESTATE_WITH_CIAN_INCLUDE,
        orderBy: {
          id: "desc",
        },
        skip: filters.skip,
        take: filters.limit,
      }),
      this.prisma.estate.count({ where }),
    ]);

    return {
      items: estates.map((estate) => this.mapper.toListItem(estate)),
      total,
      skip: filters.skip,
      limit: filters.limit,
      filters,
      parity: {
        exact: [
          "Queue predicate remains active && cian_moderation.",
        ],
        approximate: [
          "Response is JSON queue data.",
        ],
      },
    };
  }

  async listUploadQueue(
    viewer: AuthenticatedCrmUser,
    query: CrmEstateListQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number; filters: ParsedEstateListQuery; parity: Record<string, string[]> }> {
    this.assertCanAccessEstateLists(viewer);

    const filters = parseListQuery(query);
    const where = this.buildEstateListWhere(filters, {
      ...this.buildEstateScopeWhere(viewer),
      active: true,
      cianIncluded: true,
    });
    const [estates, total] = await this.prisma.$transaction([
      this.prisma.estate.findMany({
        where,
        include: ESTATE_WITH_CIAN_INCLUDE,
        orderBy: {
          id: "desc",
        },
        skip: filters.skip,
        take: filters.limit,
      }),
      this.prisma.estate.count({ where }),
    ]);

    return {
      items: estates.map((estate) => this.mapper.toListItem(estate)),
      total,
      skip: filters.skip,
      limit: filters.limit,
      filters,
      parity: {
        exact: [
          "Queue predicate remains active && cian_included.",
        ],
        approximate: [
          "Response is JSON queue data.",
        ],
      },
    };
  }

  async getDetail(
    estateId: number,
    viewer: AuthenticatedCrmUser,
    archived = false,
  ): Promise<{ item: Record<string, unknown> }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer, archived ? "archived" : "active");
    return {
      item: this.mapper.toDetail(estate, viewer),
    };
  }

  async getEstateForPresentation(
    estateId: number,
    viewer: AuthenticatedCrmUser,
    archived = false,
  ): Promise<EstateWithImagesAndUser> {
    return this.getVisibleEstateOrThrow(estateId, viewer, archived ? "archived" : "active");
  }

  async create(
    payload: CrmEstateWritePayload,
    newImages: UploadedImageFile[],
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: Record<string, unknown> }> {
    if (isViewer(viewer)) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }

    const errors = this.validateEstatePayload(payload, {
      isCreate: true,
      newImages,
    });
    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    const ownerContacts = [...(payload.owner_contacts ?? [])];
    ownerContacts.push({
      owner_phone: payload.required_owner_phone ?? "",
      owner_name: payload.required_owner_name ?? "",
    });

    const { estateData, assignedUserIds } = await this.buildEstateCreateData(payload, ownerContacts, viewer);
    const createdEstate = await this.prisma.estate.create({
      data: estateData,
      select: {
        id: true,
      },
    });

    await this.replaceEstateAssignments(bigintToNumber(createdEstate.id), assignedUserIds);

    let isMain = true;
    const createdEstateId = bigintToNumber(createdEstate.id);
    const planImageNewIndex = this.parsePlanImageNewIndex(payload.plan_image_new_index, newImages.length);
    for (const [index, image] of newImages.entries()) {
      const savedImage = await this.storageService.saveEstateImage({
        estateId: createdEstateId,
        buffer: image.buffer,
        originalFilename: image.originalname,
        contentType: image.mimetype,
      });
      await this.prisma.image.create({
        data: {
          url: savedImage.path,
          thumbnailUrl: savedImage.thumbnailPath,
          isMain,
          isPlan: planImageNewIndex === index,
          watermarkAppliedAt: savedImage.watermarkAppliedAt,
          estateId: createdEstate.id,
        },
      });
      isMain = false;
    }

    const reloaded = await this.getEstateOrThrow(bigintToNumber(createdEstate.id), "active");
    return {
      item: this.mapper.toDetail(reloaded, viewer),
      parity: {
        base_estate_write: "matched",
        image_create_flow: "matched",
        cian_write: "disabled_on_create",
      },
    };
  }

  async update(
    estateId: number,
    payload: CrmEstateWritePayload,
    newImages: UploadedImageFile[],
    viewer: AuthenticatedCrmUser,
    request: Request,
  ): Promise<{ item: Record<string, unknown>; parity: Record<string, unknown> }> {
    const existingEstate = await this.getVisibleEstateOrThrow(estateId, viewer, "any");
    this.assertCanMutateEstate(existingEstate, viewer);

    const errors = this.validateEstatePayload(payload, {
      isCreate: false,
      newImages,
    });
    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    const ownerContacts = payload.owner_contacts ?? [];
    const { estateData: updateData, assignedUserIds } = await this.buildEstateUpdateData(payload, ownerContacts, viewer, existingEstate);
    const cianFlagPatch = this.cianService.buildEstateEditFlagPatch(payload.cian, viewer, {
      cianIncluded: existingEstate.cianIncluded,
      cianModeration: existingEstate.cianModeration,
    });

    await this.prisma.$transaction(async (transaction) => {
      await transaction.estate.update({
        where: {
          id: BigInt(estateId),
        },
        data: {
          ...updateData,
          ...cianFlagPatch,
        },
      });

      await this.replaceEstateAssignments(estateId, assignedUserIds, transaction);
    });

    await this.applyImageMutations(estateId, payload.existing_images ?? [], newImages, payload.plan_image_new_index);

    let cianParity = {
      status: "skipped_without_cian_payload",
      preserved_weird_behavior: [] as string[],
    };

    try {
      cianParity = await this.cianService.saveForEditedEstate(estateId, payload.cian, request);
    } catch (error) {
      if (error instanceof CianValidationException) {
        throw new BadRequestException({
          errors: {
            cian: error.errors,
          },
        });
      }

      throw error;
    }

    const reloaded = await this.getVisibleEstateOrThrow(estateId, viewer, existingEstate.deletedAt ? "archived" : "active");
    return {
      item: this.mapper.toDetail(reloaded, viewer),
      parity: {
        base_estate_write: "matched",
        image_edit_flow: "matched_for_core_create_delete_is_main_is_plan_toggle",
        cian_edit_flow: cianParity.status,
        preserved_weird_behavior: cianParity.preserved_weird_behavior,
      },
    };
  }

  async defineCoordinatesByAddress(
    estateId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; message: string; parity: Record<string, string[]> }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer, "active");
    this.assertCanMutateEstate(estate, viewer);

    let coordinates: string;
    try {
      coordinates = await this.yandexMapsService.getCoordinatesByAddress(estate.title);
    } catch (error) {
      if (error instanceof Error) {
        throw new BadRequestException({
          errors: {
            coordinates: `Ошибка при запросе координат: \`${error.message}\`, исправьте адрес или введите координаты вручную в формате \`35.89421911 139.94637467\``,
          },
        });
      }

      throw new BadRequestException({
        errors: {
          coordinates: "Неизвестная ошибка при запросе координат по адресу",
        },
      });
    }

    await this.prisma.estate.update({
      where: {
        id: BigInt(estateId),
      },
      data: {
        coordinates,
      },
    });

    const reloaded = await this.getVisibleEstateOrThrow(estateId, viewer, "active");
    return {
      item: this.mapper.toDetail(reloaded, viewer),
      message: `Координаты успешно обновлены: ${coordinates}`,
      parity: {
        exact: [
          "Coordinate re-lookup uses the same estate edit permissions as regular estate updates.",
        ],
        approximate: [
          "Response is JSON.",
        ],
      },
    };
  }

  async quickUpdate(
    estateId: number,
    payload: CrmEstateQuickPatchPayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; message: string }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer, "active");
    this.assertCanMutateEstate(estate, viewer);

    const patch: Record<string, boolean> = {};
    if (payload.active !== undefined) {
      patch.active = parseBoolean(payload.active, estate.active);
    }
    if (payload.priority !== undefined) {
      patch.priority = parseBoolean(payload.priority, estate.priority);
    }

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException({
        errors: {
          payload: "No quick fields provided",
        },
      });
    }

    await this.prisma.estate.update({
      where: {
        id: BigInt(estateId),
      },
      data: patch,
    });

    const reloaded = await this.getVisibleEstateOrThrow(estateId, viewer, "active");
    const message = Object.entries(patch)
      .map(([key, value]) => `${key}=${value ? "on" : "off"}`)
      .join(", ");

    return {
      item: this.mapper.toDetail(reloaded, viewer),
      message: `Quick update applied: ${message}`,
    };
  }

  async duplicate(
    estateId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; duplicated: true }> {
    const sourceEstate = await this.getVisibleEstateOrThrow(estateId, viewer, "active");
    this.assertCanMutateEstate(sourceEstate, viewer);

    const assignedUserIds = this.getCurrentAssignedUserIds(sourceEstate);
    let duplicatedEstateId: number | null = null;

    try {
      const duplicatedEstate = await this.prisma.$transaction(async (transaction) => {
        const createdEstate = await transaction.estate.create({
          data: {
            title: sourceEstate.title,
            coordinates: sourceEstate.coordinates,
            description: sourceEstate.description,
            areaDescription: sourceEstate.areaDescription,
            internalInfo: sourceEstate.internalInfo,
            ownerPhonesRaw: sourceEstate.ownerPhonesRaw,
            ownerType: sourceEstate.ownerType,
            status: sourceEstate.status,
            tags: sourceEstate.tags,
            estateType: sourceEstate.estateType,
            dealType: sourceEstate.dealType,
            tenantType: sourceEstate.tenantType,
            map_: sourceEstate.map_,
            contractTerm: sourceEstate.contractTerm,
            indexing: sourceEstate.indexing,
            gap: sourceEstate.gap,
            powerKw: sourceEstate.powerKw,
            ceilingHeightM: sourceEstate.ceilingHeightM,
            area: sourceEstate.area,
            floor: sourceEstate.floor,
            allFloors: sourceEstate.allFloors,
            levelsCount: sourceEstate.levelsCount,
            occupiedFloorsText: sourceEstate.occupiedFloorsText,
            price: sourceEstate.price,
            region: sourceEstate.region,
            district: sourceEstate.district,
            metroStation: sourceEstate.metroStation,
            priority: false,
            active: true,
            isPrivateSale: sourceEstate.isPrivateSale,
            userId: this.toLegacyAssignedUserId(assignedUserIds),
            cianModeration: false,
            cianIncluded: false,
            avitoTitle: sourceEstate.avitoTitle,
            avitoFeedData: sourceEstate.avitoFeedData ?? Prisma.JsonNull,
          },
          select: {
            id: true,
          },
        });

        const createdEstateId = bigintToNumber(createdEstate.id);
        await this.replaceEstateAssignments(createdEstateId, assignedUserIds, transaction);

        return createdEstateId;
      });

      duplicatedEstateId = duplicatedEstate;

      const sourceImages = [...sourceEstate.images].sort((left, right) => {
        if (left.isMain !== right.isMain) {
          return left.isMain ? -1 : 1;
        }

        if (left.id === right.id) {
          return 0;
        }

        return left.id < right.id ? -1 : 1;
      });

      for (const image of sourceImages) {
        try {
          const duplicatedPath = await this.storageService.duplicateEstateImage(image.url, duplicatedEstateId);
          let duplicatedThumbnailPath: string | null = null;
          try {
            duplicatedThumbnailPath = await this.storageService.duplicateEstateThumbnail(image.thumbnailUrl, duplicatedPath);
          } catch (thumbnailError) {
            this.logger.warn(
              `Skipped estate thumbnail during duplicate sourceEstateId=${estateId} targetEstateId=${duplicatedEstateId} imageId=${bigintToNumber(image.id)} sourceThumbnailKey=${image.thumbnailUrl ?? "-"} error=${thumbnailError instanceof Error ? thumbnailError.message : String(thumbnailError)}`,
            );
            try {
              duplicatedThumbnailPath = await this.storageService.generateThumbnailForExistingEstateImage(duplicatedPath, { force: true });
            } catch (fallbackError) {
              this.logger.warn(
                `Failed to generate fallback estate thumbnail during duplicate sourceEstateId=${estateId} targetEstateId=${duplicatedEstateId} imageId=${bigintToNumber(image.id)} error=${fallbackError instanceof Error ? fallbackError.message : String(fallbackError)}`,
              );
            }
          }
          this.logger.log(
            `Duplicated estate image sourceEstateId=${estateId} targetEstateId=${duplicatedEstateId} imageId=${bigintToNumber(image.id)} sourceKey=${image.url} destinationKey=${duplicatedPath}`,
          );

          await this.prisma.image.create({
            data: {
              url: duplicatedPath,
              thumbnailUrl: duplicatedThumbnailPath,
              isMain: image.isMain,
              isPlan: image.isPlan,
              watermarkAppliedAt: image.watermarkAppliedAt,
              estateId: BigInt(duplicatedEstateId),
            },
          });
        } catch (error) {
          if (this.isMissingStorageSource(error)) {
            this.logger.warn(
              `Skipped missing estate image during duplicate sourceEstateId=${estateId} targetEstateId=${duplicatedEstateId} imageId=${bigintToNumber(image.id)} sourceKey=${image.url}`,
            );
            continue;
          }

          throw error;
        }
      }

      const reloaded = await this.getVisibleEstateOrThrow(duplicatedEstateId, viewer, "active");
      return {
        item: this.mapper.toDetail(reloaded, viewer),
        duplicated: true,
      };
    } catch (error) {
      if (duplicatedEstateId !== null) {
        await this.storageService.deleteEstateDirectory(duplicatedEstateId).catch(() => undefined);
        await this.prisma.estate.delete({
          where: {
            id: BigInt(duplicatedEstateId),
          },
        }).catch(() => undefined);
      }

      throw error;
    }
  }

  async delete(estateId: number, viewer: AuthenticatedCrmUser): Promise<{ deleted: true }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer, "active");
    const estateBroker = this.toFallbackScopedUser(estate);

    if (canHardDeleteEstate(viewer, this.toScopedEstate(estate))) {
      await this.prisma.image.deleteMany({
        where: {
          estateId: BigInt(estateId),
        },
      });
      await this.prisma.estate.delete({
        where: {
          id: BigInt(estateId),
        },
      });
      await this.storageService.deleteEstateDirectory(estateId);
      return { deleted: true };
    }

    if (!canSoftDeleteEstate(viewer, this.toScopedEstate(estate), estateBroker)) {
      throw new ForbiddenException(ESTATE_FORBIDDEN_MESSAGE);
    }

    await this.prisma.estate.update({
      where: {
        id: BigInt(estateId),
      },
      data: {
        deletedAt: new Date(),
        deletedById: BigInt(viewer.id),
      },
    });

    return { deleted: true };
  }

  async archive(estateId: number, viewer: AuthenticatedCrmUser): Promise<{ archived: true }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer, "active");

    if (!canEditEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      throw new ForbiddenException(ESTATE_FORBIDDEN_MESSAGE);
    }

    await this.prisma.estate.update({
      where: {
        id: BigInt(estateId),
      },
      data: {
        deletedAt: new Date(),
        deletedById: BigInt(viewer.id),
      },
    });

    return { archived: true };
  }

  async restore(estateId: number, viewer: AuthenticatedCrmUser): Promise<{ restored: true }> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer, "archived");
    const estateBroker = this.toFallbackScopedUser(estate);

    if (!canRestoreEstate(viewer, this.toScopedEstate(estate), estateBroker)) {
      throw new ForbiddenException(ESTATE_FORBIDDEN_MESSAGE);
    }

    await this.prisma.estate.update({
      where: {
        id: BigInt(estateId),
      },
      data: {
        deletedAt: null,
        deletedById: null,
        active: true,
      },
    });

    return { restored: true };
  }

  async reassign(
    payload: CrmEstateReassignPayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ updated: number; broker_id: number }> {
    if (isViewer(viewer) || isBroker(viewer)) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }

    const brokerId = parseNullableInteger(payload.broker_id);
    const estateIds = (payload.estate_ids ?? []).map((value) => Number(value)).filter((value) => Number.isInteger(value) && value > 0);

    if (!brokerId || estateIds.length === 0) {
      throw new BadRequestException({
        errors: {
          estate_ids: "estate_ids are required",
          broker_id: "broker_id is required",
        },
      });
    }

    const nextBroker = await this.getUserByIdOrThrow(brokerId);
    if (nextBroker.role !== CrmRole.BROKER) {
      throw new BadRequestException({
        errors: {
          broker_id: "broker_id must reference broker",
        },
      });
    }

    const estates = await this.prisma.estate.findMany({
      where: {
        id: {
          in: estateIds.map((id) => BigInt(id)),
        },
        deletedAt: null,
      },
      include: ESTATE_WITH_CIAN_INCLUDE,
    });

    if (estates.length !== estateIds.length) {
      throw new NotFoundException("One or more estates not found");
    }

    for (const estate of estates) {
      if (
        !canReassignEstate(
          viewer,
          this.toScopedEstate(estate),
          this.toFallbackScopedUser(estate),
          this.toScopedUser(nextBroker),
        )
      ) {
        throw new ForbiddenException(ESTATE_FORBIDDEN_MESSAGE);
      }
    }

    await this.prisma.$transaction(async (transaction) => {
      for (const estateId of estateIds) {
        await transaction.estate.update({
          where: {
            id: BigInt(estateId),
          },
          data: {
            userId: BigInt(brokerId),
          },
        });

        await transaction.estateAssignment.deleteMany({
          where: {
            estateId: BigInt(estateId),
          },
        });

        await transaction.estateAssignment.create({
          data: {
            estateId: BigInt(estateId),
            userId: BigInt(brokerId),
          },
        });
      }
    });

    return {
      updated: estateIds.length,
      broker_id: brokerId,
    };
  }

  private buildEstateListWhere(
    filters: ParsedEstateListQuery,
    baseWhere: Prisma.EstateWhereInput = {},
  ): Prisma.EstateWhereInput {
    const and: Prisma.EstateWhereInput[] = [];

    if (filters.search) {
      const searchId = parseNullableInteger(filters.search);
      and.push({
        OR: [
          ...(searchId ? [{ id: BigInt(searchId) }] : []),
          { title: { contains: filters.search, mode: "insensitive" } },
          { dealType: { contains: filters.search, mode: "insensitive" } },
          { district: { contains: filters.search, mode: "insensitive" } },
          { metroStation: { contains: filters.search, mode: "insensitive" } },
        ],
      });
    }

    if (filters.status) {
      and.push({
        clientLinks: {
          some: {
            status: filters.status,
            client: {
              deletedAt: null,
            },
          },
        },
      });
    }

    if (filters.deal_type) {
      and.push({
        dealType: filters.deal_type,
      });
    }

    if (filters.region) {
      and.push({
        region: filters.region,
      });
    }

    if (filters.district) {
      and.push({
        district: filters.district,
      });
    }

    if (filters.metro_station) {
      and.push({
        metroStation: {
          contains: filters.metro_station,
          mode: "insensitive",
        },
      });
    }

    if (filters.price_from !== null || filters.price_to !== null) {
      const priceFilter: Prisma.DecimalFilter = {};
      if (filters.price_from !== null) {
        priceFilter.gte = new Prisma.Decimal(filters.price_from);
      }
      if (filters.price_to !== null) {
        priceFilter.lte = new Prisma.Decimal(filters.price_to);
      }
      and.push({ price: priceFilter });
    }

    if (filters.area_from !== null || filters.area_to !== null) {
      const areaFilter: Prisma.DecimalFilter = {};
      if (filters.area_from !== null) {
        areaFilter.gte = new Prisma.Decimal(filters.area_from);
      }
      if (filters.area_to !== null) {
        areaFilter.lte = new Prisma.Decimal(filters.area_to);
      }
      and.push({ area: areaFilter });
    }

    if (filters.active !== null) {
      and.push({
        active: filters.active,
      });
    }

    if (filters.cian_included !== null) {
      and.push({
        cianIncluded: filters.cian_included,
      });
    }

    const baseAnd = baseWhere.AND ? (Array.isArray(baseWhere.AND) ? baseWhere.AND : [baseWhere.AND]) : [];

    return {
      ...baseWhere,
      deletedAt: filters.archivedOnly ? { not: null } : null,
      AND: [...baseAnd, ...and],
    };
  }

  private async applyImageMutations(
    estateId: number,
    existingImages: ExistingImagePayload[],
    newImages: UploadedImageFile[],
    planImageNewIndexInput?: number | string | null,
  ): Promise<void> {
    const planImageNewIndex = this.parsePlanImageNewIndex(planImageNewIndexInput, newImages.length);
    const shouldUpdatePlan =
      planImageNewIndex !== null || existingImages.some((image) => image.is_plan !== undefined);
    let selectedPlanImageId: bigint | null = null;

    for (const [index, image] of newImages.entries()) {
      const savedImage = await this.storageService.saveEstateImage({
        estateId,
        buffer: image.buffer,
        originalFilename: image.originalname,
        contentType: image.mimetype,
      });
      const createdImage = await this.prisma.image.create({
        data: {
          url: savedImage.path,
          thumbnailUrl: savedImage.thumbnailPath,
          estateId: BigInt(estateId),
          isMain: false,
          watermarkAppliedAt: savedImage.watermarkAppliedAt,
        },
      });

      if (planImageNewIndex === index) {
        selectedPlanImageId = createdImage.id;
      }
    }

    for (const image of existingImages) {
      const imageRow = await this.prisma.image.findUnique({
        where: {
          id: BigInt(image.id),
        },
      });
      if (!imageRow) {
        continue;
      }

      if (bigintToNumber(imageRow.estateId) !== estateId) {
        continue;
      }

      if (image.delete) {
        await this.storageService.deleteByPath(imageRow.url);
        if (imageRow.thumbnailUrl) {
          await this.storageService.deleteByPath(imageRow.thumbnailUrl).catch(() => undefined);
        }
        await this.prisma.image.delete({
          where: {
            id: imageRow.id,
          },
        });
        continue;
      }

      if (!image.delete && image.is_plan) {
        selectedPlanImageId = imageRow.id;
      }

      await this.prisma.image.update({
        where: {
          id: imageRow.id,
        },
        data: {
          isMain: Boolean(image.is_main),
        },
      });
    }

    if (shouldUpdatePlan) {
      await this.prisma.image.updateMany({
        where: {
          estateId: BigInt(estateId),
        },
        data: {
          isPlan: false,
        },
      });

      if (selectedPlanImageId !== null) {
        await this.prisma.image.update({
          where: {
            id: selectedPlanImageId,
          },
          data: {
            isPlan: true,
          },
        });
      }
    }
  }

  private parsePlanImageNewIndex(value: number | string | null | undefined, newImagesCount: number): number | null {
    const parsed = parseNullableInteger(value);
    if (parsed === null || parsed < 0 || parsed >= newImagesCount) {
      return null;
    }

    return parsed;
  }

  private async buildEstateCreateData(
    payload: CrmEstateWritePayload,
    ownerContacts: OwnerContact[],
    viewer: AuthenticatedCrmUser,
  ): Promise<{ estateData: Prisma.EstateUncheckedCreateInput; assignedUserIds: number[] }> {
    const baseData = await this.buildBaseEstateData(payload, ownerContacts, viewer, true);
    const assignedUserIds = await this.resolveAssignedUserIds(payload, viewer, []);

    return {
      estateData: {
        ...baseData,
        userId: this.toLegacyAssignedUserId(assignedUserIds),
      },
      assignedUserIds,
    };
  }

  private async buildEstateUpdateData(
    payload: CrmEstateWritePayload,
    ownerContacts: OwnerContact[],
    viewer: AuthenticatedCrmUser,
    existingEstate: EstateWithImagesAndUser,
  ): Promise<{ estateData: Prisma.EstateUncheckedUpdateInput; assignedUserIds: number[] }> {
    const baseData = await this.buildBaseEstateData(payload, ownerContacts, viewer, false, existingEstate);
    const assignedUserIds = await this.resolveAssignedUserIds(payload, viewer, this.getCurrentAssignedUserIds(existingEstate));

    return {
      estateData: {
        ...baseData,
        userId: this.toLegacyAssignedUserId(assignedUserIds),
      },
      assignedUserIds,
    };
  }

  private async buildBaseEstateData(
    payload: CrmEstateWritePayload,
    ownerContacts: OwnerContact[],
    _viewer: AuthenticatedCrmUser,
    isCreate: boolean,
    existingEstate?: EstateWithImagesAndUser,
  ): Promise<Omit<Prisma.EstateUncheckedCreateInput, "userId">> {
    const title = normalizeText(payload.title) ?? "";
    const shouldDefineCoordinates = !parseBoolean(payload.not_define_coordinates, false);
    let coordinates = existingEstate?.coordinates ?? null;

    if (isCreate && shouldDefineCoordinates) {
      try {
        coordinates = await this.yandexMapsService.getCoordinatesByAddress(title);
      } catch (error) {
        const reason = error instanceof Error ? error.message : "unknown error";
        this.logger.warn(`Estate create geocoding failed title="${title}" reason="${reason}"`);
      }
    }

    return {
      title,
      coordinates,
      description: normalizeText(payload.description) ?? "",
      areaDescription: normalizeText(payload.area_description),
      internalInfo: normalizeText(payload.internal_info),
      status: normalizeText(payload.status),
      tags: normalizeText(payload.tags),
      estateType: normalizeText(payload.estate_type),
      dealType: normalizeText(payload.deal_type) ?? "",
      tenantType: normalizeText(payload.tenant_type),
      map_: parseNullableNumber(payload.map_) ?? undefined,
      contractTerm: normalizeText(payload.contract_term),
      indexing: normalizeText(payload.indexing),
      gap: parseNullableNumber(payload.gap) === null ? null : new Prisma.Decimal(parseNullableNumber(payload.gap) ?? 0),
      powerKw:
        parseNullableNumber(payload.power_kw) === null ? null : new Prisma.Decimal(parseNullableNumber(payload.power_kw) ?? 0),
      ceilingHeightM:
        parseNullableNumber(payload.ceiling_height_m) === null
          ? null
          : new Prisma.Decimal(parseNullableNumber(payload.ceiling_height_m) ?? 0),
      area: new Prisma.Decimal(parseNullableNumber(payload.area) ?? 0),
      floor: parseNullableInteger(payload.floor),
      allFloors: parseNullableInteger(payload.all_floors) ?? 0,
      levelsCount:
        payload.levels_count === undefined
          ? existingEstate?.levelsCount ?? null
          : parseNullableInteger(payload.levels_count),
      occupiedFloorsText:
        payload.occupied_floors_text === undefined
          ? existingEstate?.occupiedFloorsText ?? null
          : normalizeText(payload.occupied_floors_text)?.trim() || null,
      price: new Prisma.Decimal(parseNullableNumber(payload.price) ?? 0),
      region: normalizeText(payload.region) ?? "",
      district: normalizeText(payload.district),
      metroStation: normalizeText(payload.metro_station),
      priority: parseBoolean(payload.priority, existingEstate?.priority ?? false),
      active: parseBoolean(payload.active, existingEstate?.active ?? true),
      isPrivateSale: parseBoolean(payload.is_private_sale, existingEstate?.isPrivateSale ?? false),
      ownerType: normalizeText(payload.owner_type),
      ownerPhonesRaw: serializeOwnerContacts(ownerContacts),
    };
  }

  private validateEstatePayload(
    payload: CrmEstateWritePayload,
    options: { isCreate: boolean; newImages: UploadedImageFile[] },
  ): Record<string, string> {
    const errors: Record<string, string> = {};

    for (const field of ESTATE_REQUIRED_FIELDS.always) {
      if (field === "area" || field === "price" || field === "all_floors") {
        continue;
      }

      if (!normalizeText(payload[field])) {
        errors[field] = REQUIRED_FIELD_MESSAGE;
      }
    }

    if (parseNullableNumber(payload.area) === null) {
      errors.area = REQUIRED_FIELD_MESSAGE;
    } else if ((parseNullableNumber(payload.area) ?? 0) < 0) {
      errors.area = "Площадь не может быть меньше чем 0";
    }

    if (parseNullableNumber(payload.price) === null) {
      errors.price = REQUIRED_FIELD_MESSAGE;
    } else if ((parseNullableNumber(payload.price) ?? 0) < 0) {
      errors.price = "Цена не может быть меньше чем 0";
    }

    if (parseNullableInteger(payload.all_floors) === null) {
      errors.all_floors = REQUIRED_FIELD_MESSAGE;
    } else if ((parseNullableInteger(payload.all_floors) ?? 0) < 0) {
      errors.all_floors = "Кол-во этажей не может быть меньше чем 0";
    }

    const levelsCount = parseNullableInteger(payload.levels_count);
    const occupiedFloorsText = normalizeText(payload.occupied_floors_text)?.trim() ?? "";

    if (
      payload.levels_count !== undefined &&
      payload.levels_count !== null &&
      payload.levels_count !== "" &&
      levelsCount === null
    ) {
      errors.levels_count = "Количество уровней должно быть целым числом";
    } else if (levelsCount !== null && levelsCount < 1) {
      errors.levels_count = "Количество уровней должно быть не меньше 1";
    }

    if (occupiedFloorsText && levelsCount === null) {
      errors.levels_count = "Укажите количество уровней";
    } else if (levelsCount !== null && levelsCount > 1 && !occupiedFloorsText) {
      errors.occupied_floors_text = "Укажите занимаемые этажи или уровни";
    } else if (occupiedFloorsText.length > MAX_OCCUPIED_FLOORS_TEXT_LENGTH) {
      errors.occupied_floors_text = `Не более ${MAX_OCCUPIED_FLOORS_TEXT_LENGTH} символов`;
    }

    const mapValue = parseNullableNumber(payload.map_);
    if (payload.map_ !== undefined && payload.map_ !== null && payload.map_ !== "" && mapValue === null) {
      errors.map_ = "Должно быть число";
    } else if (mapValue !== null && mapValue < 1) {
      errors.map_ = "Должно быть больше единицы";
    }

    if (payload.deal_type === "Арендный бизнес") {
      for (const field of ESTATE_REQUIRED_FIELDS.conditional.rent_business) {
        if (!normalizeText(payload[field] as string | null | undefined)) {
          errors[field] = "Обязательно если арендный бизнес";
        }
      }
    }

    for (const [field, message] of [
      ["gap", "ГАП не может быть меньше чем 0"],
      ["power_kw", "Мощность не может быть меньше чем 0"],
      ["ceiling_height_m", "Высота потолков не может быть меньше чем 0"],
    ] as const) {
      const numericValue = parseNullableNumber(payload[field]);
      if (payload[field] !== undefined && payload[field] !== null && payload[field] !== "" && numericValue === null) {
        errors[field] = "Должно быть число";
      } else if (numericValue !== null && numericValue < 0) {
        errors[field] = message;
      }
    }

    if (options.isCreate) {
      for (const field of ESTATE_REQUIRED_FIELDS.create_only) {
        if (field === "new_images") {
          continue;
        }

        if (!normalizeText(payload[field])) {
          errors[field] = REQUIRED_FIELD_MESSAGE;
        }
      }
      if (options.newImages.length === 0) {
        errors.images = "Обязательное нужно указать фото";
      }
    }

    if (
      options.newImages.some((image) =>
        !isAllowedEstateImageUpload({
          originalFilename: image.originalname,
          contentType: image.mimetype,
        }),
      )
    ) {
      errors.images = ESTATE_IMAGE_VALIDATION_MESSAGE;
    }

    if (payload.assigned_user_ids !== undefined) {
      const rawAssignedUserIds = payload.assigned_user_ids ?? [];
      if (!Array.isArray(rawAssignedUserIds) || rawAssignedUserIds.some((value) => parseNullableInteger(value) === null)) {
        errors.assigned_user_ids = "Некорректный список назначенных пользователей";
      } else if ([...new Set(parseIntegerArray(rawAssignedUserIds))].length > MAX_ESTATE_ASSIGNMENTS) {
        errors.assigned_user_ids = ASSIGNMENT_LIMIT_MESSAGE;
      }
    } else if (payload.user_id !== undefined && payload.user_id !== null && payload.user_id !== "" && parseNullableInteger(payload.user_id) === null) {
      errors.user_id = "Некорректный пользователь";
    }

    return errors;
  }

  private assertAdmin(viewer: AuthenticatedCrmUser): void {
    if (!viewer.is_admin) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }

  private assertCanAccessEstateLists(viewer: AuthenticatedCrmUser): void {
    if (isViewer(viewer)) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }

  private assertCanMutateEstate(estate: EstateWithImagesAndUser, viewer: AuthenticatedCrmUser): void {
    if (!canEditEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      throw new ForbiddenException(ESTATE_FORBIDDEN_MESSAGE);
    }
  }

  private async getEstateOrThrow(
    estateId: number,
    archivedState: "active" | "archived" | "any" = "active",
  ): Promise<EstateWithImagesAndUser> {
    const deletedAtWhere =
      archivedState === "active" ? null : archivedState === "archived" ? { not: null } : undefined;
    const estate = await this.prisma.estate.findFirst({
      where: {
        id: BigInt(estateId),
        ...(deletedAtWhere === undefined ? {} : { deletedAt: deletedAtWhere }),
      },
      include: ESTATE_WITH_CIAN_INCLUDE,
    });

    if (!estate) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    return estate;
  }

  private async getVisibleEstateOrThrow(
    estateId: number,
    viewer: AuthenticatedCrmUser,
    archivedState: "active" | "archived" | "any" = "active",
  ): Promise<EstateWithImagesAndUser> {
    if (isViewer(viewer)) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }

    const estate = await this.getEstateOrThrow(estateId, archivedState);
    const scopedEstate = this.toScopedEstate(estate);
    const scopedUser = this.toFallbackScopedUser(estate);
    const canView =
      archivedState === "archived"
        ? canViewArchivedEstate(viewer, scopedEstate, scopedUser)
        : canViewEstate(viewer, scopedEstate, scopedUser);

    if (!canView) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    return estate;
  }

  private buildEstateScopeWhere(viewer: AuthenticatedCrmUser): Prisma.EstateWhereInput {
    if (isOwner(viewer) || isAdmin(viewer)) {
      return {};
    }

    if (isRop(viewer)) {
      return {
        assignments: {
          some: {
            user: {
              role: CrmRole.BROKER,
              ropId: BigInt(viewer.id),
            },
          },
        },
      };
    }

    if (isBroker(viewer)) {
      return {
        assignments: {
          some: {
            userId: BigInt(viewer.id),
          },
        },
      };
    }

    throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
  }

  private buildEstateVisibilityWhere(viewer: AuthenticatedCrmUser): Prisma.EstateWhereInput {
    if (isOwner(viewer) || isAdmin(viewer) || isBroker(viewer)) {
      return {};
    }

    if (isRop(viewer)) {
      return {
        assignments: {
          some: {
            user: {
              role: CrmRole.BROKER,
              ropId: BigInt(viewer.id),
            },
          },
        },
      };
    }

    throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
  }

  private toScopedEstate(estate: EstateWithImagesAndUser) {
    return {
      id: estate.id,
      userId: estate.userId,
      deletedAt: estate.deletedAt,
      assignedUserIds: estate.assignments.map((assignment) => assignment.userId),
      assignedUsers: estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
    };
  }

  private toScopedUser(user: User): ScopedUserRef {
    return {
      id: user.id,
      role: user.role,
      ropId: user.ropId,
    };
  }

  private toFallbackScopedUser(estate: EstateWithImagesAndUser): ScopedUserRef {
    const fallbackUser = estate.assignments[0]?.user ?? estate.user;
    if (fallbackUser) {
      return this.toScopedUser(fallbackUser);
    }

    return {
      id: BigInt(0),
      role: CrmRole.VIEWER,
      ropId: null,
    };
  }

  private async getUserByIdOrThrow(userId: number): Promise<User> {
    const user = await this.prisma.user.findUnique({
      where: {
        id: BigInt(userId),
      },
    });

    if (!user) {
      throw new NotFoundException(`User ${userId} not found`);
    }

    return user;
  }

  private getRequestedAssignedUserIds(payload: CrmEstateWritePayload): number[] {
    if (Array.isArray(payload.assigned_user_ids)) {
      return [...new Set(parseIntegerArray(payload.assigned_user_ids))];
    }

    const legacyUserId = parseNullableInteger(payload.user_id);
    return legacyUserId === null ? [] : [legacyUserId];
  }

  private hasAssignmentPayload(payload: CrmEstateWritePayload): boolean {
    return Array.isArray(payload.assigned_user_ids) || payload.user_id !== undefined;
  }

  private getCurrentAssignedUserIds(estate: EstateWithImagesAndUser): number[] {
    if (estate.assignments.length > 0) {
      return [...new Set(estate.assignments.map((assignment) => bigintToNumber(assignment.userId)))];
    }

    return estate.userId === null ? [] : [bigintToNumber(estate.userId)];
  }

  private async resolveAssignedUserIds(
    payload: CrmEstateWritePayload,
    viewer: AuthenticatedCrmUser,
    currentAssignedUserIds: number[],
  ): Promise<number[]> {
    const requestedUserIds = this.getRequestedAssignedUserIds(payload);
    const assignmentPayloadProvided = this.hasAssignmentPayload(payload);

    if (requestedUserIds.length > MAX_ESTATE_ASSIGNMENTS) {
      throw new BadRequestException({
        errors: {
          assigned_user_ids: ASSIGNMENT_LIMIT_MESSAGE,
        },
      });
    }

    if (isBroker(viewer)) {
      if (assignmentPayloadProvided) {
        throw new ForbiddenException(ASSIGNMENT_MANAGEMENT_FORBIDDEN_MESSAGE);
      }

      return currentAssignedUserIds.length > 0 ? currentAssignedUserIds : [viewer.id];
    }

    if (isRop(viewer)) {
      if (assignmentPayloadProvided) {
        throw new ForbiddenException(ASSIGNMENT_MANAGEMENT_FORBIDDEN_MESSAGE);
      }

      return currentAssignedUserIds;
    }

    if (requestedUserIds.length === 0) {
      return [];
    }

    const targetUsers = await this.prisma.user.findMany({
      where: {
        id: {
          in: requestedUserIds.map((userId) => BigInt(userId)),
        },
      },
    });

    if (targetUsers.length !== requestedUserIds.length) {
      throw new BadRequestException({
        errors: {
          assigned_user_ids: "Один или несколько пользователей не найдены",
        },
      });
    }

    if (isOwner(viewer) || isAdmin(viewer)) {
      if (targetUsers.some((user) => user.role !== CrmRole.BROKER && user.role !== CrmRole.ADMIN)) {
        throw new BadRequestException({
          errors: {
            assigned_user_ids: ASSIGNMENT_ROLE_INVALID_MESSAGE,
          },
        });
      }

      return requestedUserIds;
    }

    throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
  }

  private toLegacyAssignedUserId(assignedUserIds: number[]): bigint | null {
    return assignedUserIds.length > 0 ? BigInt(assignedUserIds[0]) : null;
  }

  private async replaceEstateAssignments(
    estateId: number,
    assignedUserIds: number[],
    client: Prisma.TransactionClient | PrismaService = this.prisma,
  ): Promise<void> {
    await client.estateAssignment.deleteMany({
      where: {
        estateId: BigInt(estateId),
      },
    });

    if (assignedUserIds.length === 0) {
      return;
    }

    await client.estateAssignment.createMany({
      data: assignedUserIds.map((userId) => ({
        estateId: BigInt(estateId),
        userId: BigInt(userId),
      })),
      skipDuplicates: true,
    });
  }

  private isMissingStorageSource(error: unknown): boolean {
    if (!error || typeof error !== "object") {
      return false;
    }

    const record = error as {
      code?: unknown;
      name?: unknown;
      $metadata?: {
        httpStatusCode?: number;
      };
    };

    return (
      record.code === "ENOENT" ||
      record.code === "NoSuchKey" ||
      record.code === "NotFound" ||
      record.name === "NoSuchKey" ||
      record.$metadata?.httpStatusCode === 404
    );
  }
}
