import { Injectable } from "@nestjs/common";
import { CrmRole } from "@prisma/client";
import { DEAL_TYPES } from "../../common/domain/domain.constants";
import {
  bigintToNumber,
  decimalToNumber,
  formatInteger,
  roundToTenths,
} from "../../common/utils/number.utils";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { canViewOwnerContacts } from "../crm-auth/crm-permissions";
import { CianSerializer } from "../cian/cian.serializer";
import { resolveAvitoFeedData } from "../avito/avito-feed-data";
import { StorageService } from "../storage/storage.service";
import { EstateWithImagesAndUser, OwnerContact } from "./crm-estates.types";

function parseOwnerContacts(raw: string): OwnerContact[] {
  return raw
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((contact) => {
      const parts = contact.split(" *-* ");
      return {
        owner_phone: parts[0] ?? "",
        owner_name: parts[1] ?? "-",
      };
    });
}

function calculateProfit(dealType: string, price: number, mapValue: number | null): number | null {
  if (dealType !== DEAL_TYPES.RENT_BUSINESS || mapValue === null || mapValue === 0) {
    return null;
  }

  return roundToTenths(price / mapValue / 12);
}

function serializeCrmUser(user: {
  id: bigint;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  role: CrmRole;
  ropId: bigint | null;
}) {
  return {
    id: bigintToNumber(user.id),
    email: user.email,
    first_name: user.firstName,
    last_name: user.lastName,
    phone_number: user.phoneNumber,
    role: user.role,
    rop_id: user.ropId === null ? null : bigintToNumber(user.ropId),
    is_admin: user.role === CrmRole.OWNER || user.role === CrmRole.ADMIN,
  };
}

function getAssignedUsers(estate: EstateWithImagesAndUser) {
  if (estate.assignments.length > 0) {
    return estate.assignments.map((assignment) => assignment.user);
  }

  return estate.user ? [estate.user] : [];
}

@Injectable()
export class CrmEstatesMapper {
  constructor(
    private readonly storageService: StorageService,
    private readonly cianSerializer: CianSerializer,
  ) {}

  toListItem(estate: EstateWithImagesAndUser): Record<string, unknown> {
    const images = [...estate.images].sort(
      (left, right) =>
        Number(right.isMain) - Number(left.isMain) || Number(left.id > right.id) - Number(left.id < right.id),
    );
    const price = decimalToNumber(estate.price) ?? 0;
    const mapValue = decimalToNumber(estate.map_) ?? null;
    const assignedUsers = getAssignedUsers(estate);
    const assignedUserIds = assignedUsers.map((user) => bigintToNumber(user.id));

    return {
      id: bigintToNumber(estate.id),
      title: estate.title,
      status: estate.status,
      deal_type: estate.dealType,
      area: decimalToNumber(estate.area),
      price,
      presentation_price: formatInteger(price),
      metro_station: estate.metroStation,
      district: estate.district,
      active: estate.active,
      priority: estate.priority,
      is_private_sale: estate.isPrivateSale,
      avito: {
        moderation_status: estate.avitoModerationStatus,
        publication_status: estate.avitoStatus,
        included: estate.avitoIncluded,
        last_error: estate.avitoLastError,
      },
      user_id: assignedUserIds[0] ?? (estate.userId === null ? null : bigintToNumber(estate.userId)),
      assigned_user_ids: assignedUserIds,
      assigned_users: assignedUsers.map((user) => serializeCrmUser(user)),
      client_links: estate.clientLinks.map((link) => ({
        link_id: bigintToNumber(link.id),
        client_id: bigintToNumber(link.client.id),
        client_name: link.client.name,
        client_broker_id: bigintToNumber(link.client.brokerId),
        client_broker_rop_id: link.client.broker.ropId === null ? null : bigintToNumber(link.client.broker.ropId),
        status: link.status,
      })),
      images: images.map((image) => ({
        id: bigintToNumber(image.id),
        url: image.url,
        thumbnail_url: image.thumbnailUrl ? this.storageService.resolvePublicUrl(image.thumbnailUrl) : null,
        public_url: this.storageService.resolvePublicUrl(image.url),
        is_main: image.isMain,
        is_plan: image.isPlan,
      })),
      profit: calculateProfit(estate.dealType, price, mapValue),
    };
  }

  toDetail(estate: EstateWithImagesAndUser, viewer: AuthenticatedCrmUser): Record<string, unknown> {
    const images = [...estate.images].sort((left, right) => Number(right.isMain) - Number(left.isMain));
    const price = decimalToNumber(estate.price) ?? 0;
    const mapValue = decimalToNumber(estate.map_) ?? null;
    const assignedUsers = getAssignedUsers(estate);
    const assignedUserIds = assignedUsers.map((user) => bigintToNumber(user.id));
    const primaryAssignedUser = assignedUsers[0] ?? null;
    const canSeeOwnerFields = canViewOwnerContacts(
      viewer,
      {
        id: estate.id,
        userId: estate.userId,
        deletedAt: estate.deletedAt,
        assignedUserIds: assignedUsers.map((user) => user.id),
        assignedUsers: assignedUsers.map((user) => ({
          id: user.id,
          role: user.role,
          ropId: user.ropId,
        })),
      },
      estate.user
        ? {
            id: estate.user.id,
            role: estate.user.role,
            ropId: estate.user.ropId,
          }
        : {
            id: BigInt(0),
            role: CrmRole.BROKER,
            ropId: null,
          },
    );

    const detail: Record<string, unknown> = {
      id: bigintToNumber(estate.id),
      title: estate.title,
      coordinates: estate.coordinates,
      description: estate.description,
      area_description: estate.areaDescription,
      internal_info: estate.internalInfo,
      status: estate.status,
      tags: estate.tags,
      estate_type: estate.estateType,
      deal_type: estate.dealType,
      tenant_type: estate.tenantType,
      map_: mapValue,
      contract_term: estate.contractTerm,
      indexing: estate.indexing,
      gap: decimalToNumber(estate.gap),
      power_kw: decimalToNumber(estate.powerKw),
      ceiling_height_m: decimalToNumber(estate.ceilingHeightM),
      area: decimalToNumber(estate.area),
      floor: estate.floor,
      all_floors: estate.allFloors,
      levels_count: estate.levelsCount,
      occupied_floors_text: estate.occupiedFloorsText,
      price,
      presentation_price: formatInteger(price),
      region: estate.region,
      district: estate.district,
      metro_station: estate.metroStation,
      priority: estate.priority,
      active: estate.active,
      is_private_sale: estate.isPrivateSale,
      user_id: assignedUserIds[0] ?? (estate.userId === null ? null : bigintToNumber(estate.userId)),
      assigned_user_ids: assignedUserIds,
      assigned_users: assignedUsers.map((user) => serializeCrmUser(user)),
      user: primaryAssignedUser ? serializeCrmUser(primaryAssignedUser) : null,
      avito: {
        moderation_status: estate.avitoModerationStatus,
        publication_status: estate.avitoStatus,
        included: estate.avitoIncluded,
        avito_id: estate.avitoId === null ? null : bigintToNumber(estate.avitoId),
        external_id: estate.avitoExternalId,
        avitoTitle: estate.avitoTitle,
        last_error: estate.avitoLastError,
        last_validated_at: estate.avitoLastValidatedAt?.toISOString() ?? null,
        last_synced_at: estate.avitoLastSyncedAt?.toISOString() ?? null,
        review_comment: estate.avitoReviewComment,
        review_requested_at: estate.avitoReviewRequestedAt?.toISOString() ?? null,
        approved_at: estate.avitoApprovedAt?.toISOString() ?? null,
        approved_by_id: estate.avitoApprovedById === null ? null : bigintToNumber(estate.avitoApprovedById),
        feed_data: resolveAvitoFeedData(estate),
      },
      client_links: estate.clientLinks.map((link) => ({
        link_id: bigintToNumber(link.id),
        client_id: bigintToNumber(link.client.id),
        client_name: link.client.name,
        client_broker_id: bigintToNumber(link.client.brokerId),
        client_broker_rop_id: link.client.broker.ropId === null ? null : bigintToNumber(link.client.broker.ropId),
        status: link.status,
        created_at: link.createdAt.toISOString(),
        update_at: link.updateAt.toISOString(),
      })),
      cian: this.cianSerializer.toCrmPayload(estate),
      images: images.map((image) => ({
        id: bigintToNumber(image.id),
        url: image.url,
        thumbnail_url: image.thumbnailUrl ? this.storageService.resolvePublicUrl(image.thumbnailUrl) : null,
        public_url: this.storageService.resolvePublicUrl(image.url),
        is_main: image.isMain,
        is_plan: image.isPlan,
      })),
      profit: calculateProfit(estate.dealType, price, mapValue),
    };

    if (canSeeOwnerFields) {
      detail.owner_type = estate.ownerType;
      detail.owner_contacts = parseOwnerContacts(estate.ownerPhonesRaw);
    }

    return detail;
  }
}
