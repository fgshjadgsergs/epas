import { Body, Controller, Get, Param, ParseIntPipe, Patch, Post, Put, Query, UseGuards } from "@nestjs/common";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CrmDealsService } from "./crm-deals.service";
import {
  CrmDealBrokerItem,
  CrmDealCommentItem,
  CrmDealCommentWritePayload,
  CrmDealCreatePayload,
  CrmDealDetailItem,
  CrmDealListItem,
  CrmDealListQuery,
  CrmDealMutationResponse,
  CrmDealStagePayload,
  CrmDealTaskItem,
  CrmDealTaskWritePayload,
} from "./crm-deals.types";

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/deals")
export class CrmDealsController {
  constructor(private readonly crmDealsService: CrmDealsService) {}

  @Get()
  list(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: CrmDealListQuery,
  ): Promise<{ items: CrmDealListItem[]; total: number; skip: number; limit: number }> {
    return this.crmDealsService.list(user, query);
  }

  @Post()
  create(
    @Body() payload: CrmDealCreatePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<CrmDealMutationResponse> {
    return this.crmDealsService.create(payload, user);
  }
  @Get("brokers")
  listBrokers(@CurrentCrmUser() user: AuthenticatedCrmUser): Promise<{ items: CrmDealBrokerItem[] }> {
    return this.crmDealsService.listBrokers(user);
  }

  @Get(":linkId")
  getDetail(
    @Param("linkId", ParseIntPipe) linkId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealDetailItem }> {
    return this.crmDealsService.getDetail(linkId, user);
  }

  @Patch(":linkId/stage")
  updateStage(
    @Param("linkId", ParseIntPipe) linkId: number,
    @Body() payload: CrmDealStagePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<CrmDealMutationResponse> {
    return this.crmDealsService.updateStage(linkId, payload, user);
  }
  @Get(":linkId/comments")
  listComments(
    @Param("linkId", ParseIntPipe) linkId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ items: CrmDealCommentItem[] }> {
    return this.crmDealsService.listComments(linkId, user);
  }

  @Post(":linkId/comments")
  createComment(
    @Param("linkId", ParseIntPipe) linkId: number,
    @Body() payload: CrmDealCommentWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealCommentItem }> {
    return this.crmDealsService.createComment(linkId, payload, user);
  }

  @Get(":linkId/tasks")
  listTasks(
    @Param("linkId", ParseIntPipe) linkId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ items: CrmDealTaskItem[] }> {
    return this.crmDealsService.listTasks(linkId, user);
  }

  @Post(":linkId/tasks")
  createTask(
    @Param("linkId", ParseIntPipe) linkId: number,
    @Body() payload: CrmDealTaskWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealTaskItem }> {
    return this.crmDealsService.createTask(linkId, payload, user);
  }

  @Put(":linkId/tasks/:taskId")
  updateTask(
    @Param("linkId", ParseIntPipe) linkId: number,
    @Param("taskId", ParseIntPipe) taskId: number,
    @Body() payload: CrmDealTaskWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealTaskItem }> {
    return this.crmDealsService.updateTask(linkId, taskId, payload, user);
  }
}
