import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { CrmRole, Prisma, User } from "@prisma/client";
import { bigintToNumber } from "../../common/utils/number.utils";
import { PrismaService } from "../../prisma/prisma.service";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import {
  canViewArchivedEstate,
  canViewClient,
  canViewEstate,
  isAdmin,
  isBroker,
  isOwner,
  isRop,
  isViewer,
  ScopedClientRef,
  ScopedEstateRef,
  ScopedUserRef,
} from "../crm-auth/crm-permissions";
import { CLIENT_PIPELINE_STATUSES, ClientPipelineStatus } from "../crm-clients/crm-clients.types";
import { CrmDealsMapper } from "./crm-deals.mapper";
import {
  CrmDealDetailItem,
  CrmDealBrokerItem,
  CrmDealCommentItem,
  CrmDealCommentWritePayload,
  CrmDealCreatePayload,
  CrmDealListItem,
  CrmDealListQuery,
  CrmDealMutationResponse,
  CrmDealStagePayload,
  CrmDealTaskItem,
  CrmDealTaskType,
  CrmDealTaskWritePayload,
  DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE,
  DEAL_WITH_RELATIONS_INCLUDE,
  DealWithRelations,
} from "./crm-deals.types";

const DEALS_FORBIDDEN_MESSAGE = "You can view only permitted deals";
const MAX_DEALS_LIST_LIMIT = 100;
const DEAL_TASK_TYPES: CrmDealTaskType[] = ["CALL", "MEETING", "MESSAGE"];
const ACTIVE_DEAL_STAGES: ClientPipelineStatus[] = ["new", "in_progress", "showing", "negotiation"];

interface ParsedDealListQuery {
  search: string | null;
  status: ClientPipelineStatus | null;
  broker_id: number | null;
  client_id: number | null;
  estate_id: number | null;
  skip: number;
  limit: number;
}

function normalizeText(value: string | null | undefined): string {
  if (value === undefined || value === null) {
    return "";
  }

  return String(value).trim();
}

function parseNullableInteger(value: number | string | null | undefined): number | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
}

function parsePipelineStatus(value: string | null | undefined): ClientPipelineStatus | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const normalized = normalizeText(value).toLowerCase();
  return CLIENT_PIPELINE_STATUSES.includes(normalized as ClientPipelineStatus) ? (normalized as ClientPipelineStatus) : null;
}

function parseRequiredText(value: string | null | undefined): string {
  return normalizeText(value).trim();
}

function parseTaskType(value: string | null | undefined): CrmDealTaskType | null {
  const normalized = normalizeText(value).trim().toUpperCase();
  return DEAL_TASK_TYPES.includes(normalized as CrmDealTaskType) ? (normalized as CrmDealTaskType) : null;
}

function parseOptionalDate(value: string | null | undefined): Date | null {
  const normalized = normalizeText(value).trim();
  if (!normalized) {
    return null;
  }

  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? null : date;
}

function parseBoolean(value: boolean | string | null | undefined): boolean {
  if (typeof value === "boolean") {
    return value;
  }

  return ["1", "true", "yes", "on"].includes(normalizeText(value).trim().toLowerCase());
}

function parseDealListQuery(query: CrmDealListQuery): ParsedDealListQuery {
  const limit = parseNullableInteger(query.limit);
  const skip = parseNullableInteger(query.skip);

  return {
    search: normalizeText(query.search) || null,
    status: parsePipelineStatus(query.status),
    broker_id: parseNullableInteger(query.broker_id),
    client_id: parseNullableInteger(query.client_id),
    estate_id: parseNullableInteger(query.estate_id),
    skip: skip === null ? 0 : Math.max(skip, 0),
    limit: limit === null ? 50 : Math.min(limit, MAX_DEALS_LIST_LIMIT),
  };
}

function isDealActivityStorageError(error: unknown): boolean {
  return (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    ["P2021", "P2022"].includes(error.code)
  );
}

@Injectable()
export class CrmDealsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mapper: CrmDealsMapper,
  ) {}

  async list(
    viewer: AuthenticatedCrmUser,
    query: CrmDealListQuery,
  ): Promise<{ items: CrmDealListItem[]; total: number; skip: number; limit: number }> {
    this.assertDealsAccess(viewer);

    const filters = parseDealListQuery(query);
    const where = this.buildDealsWhere(filters, viewer);

    const [links, total] = await this.prisma.$transaction([
      this.prisma.clientEstateLink.findMany({
        where,
        include: DEAL_WITH_RELATIONS_INCLUDE,
        orderBy: [{ updateAt: "desc" }, { id: "desc" }],
        skip: filters.skip,
        take: filters.limit,
      }),
      this.prisma.clientEstateLink.count({ where }),
    ]);

    return {
      items: links
        .filter((link) => this.canViewDeal(viewer, link))
        .map((link) => this.mapper.toListItem(link, viewer)),
      total,
      skip: filters.skip,
      limit: filters.limit,
    };
  }

  async getDetail(
    linkId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealDetailItem }> {
    this.assertDealsAccess(viewer);

    const link = await this.getVisibleDealOrThrow(linkId, viewer);

    return {
      item: this.mapper.toDetailItem(link, viewer),
    };
  }

  async create(payload: CrmDealCreatePayload, viewer: AuthenticatedCrmUser): Promise<CrmDealMutationResponse> {
    this.assertDealsAccess(viewer);

    const clientId = parseNullableInteger(payload.client_id);
    const estateId = parseNullableInteger(payload.estate_id);
    const stage = parsePipelineStatus(payload.stage ?? "new");
    const comment = normalizeText(payload.comment).trim();
    if (!clientId || !estateId || !stage || !ACTIVE_DEAL_STAGES.includes(stage)) {
      throw new BadRequestException({
        errors: {
          client_id: clientId ? undefined : "Client is required",
          estate_id: estateId ? undefined : "Estate is required",
          stage: stage && ACTIVE_DEAL_STAGES.includes(stage) ? undefined : `Initial stage must be one of: ${ACTIVE_DEAL_STAGES.join(", ")}`,
        },
      });
    }

    const client = await this.prisma.client.findFirst({
      where: { id: BigInt(clientId), deletedAt: null },
      include: { broker: true },
    });
    if (
      !client ||
      !canViewClient(
        viewer,
        { id: client.id, brokerId: client.brokerId, deletedAt: client.deletedAt },
        this.toScopedUser(client.broker),
      )
    ) {
      throw new NotFoundException(`Client ${clientId} not found`);
    }

    const estate = await this.prisma.estate.findFirst({
      where: { id: BigInt(estateId), deletedAt: null, active: true },
      include: {
        user: true,
        assignments: { include: { user: true } },
      },
    });
    if (!estate) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    const estateBroker = estate.user
      ? this.toScopedUser(estate.user)
      : { id: BigInt(0), role: CrmRole.VIEWER, ropId: null };
    if (
      !canViewEstate(
        viewer,
        {
          id: estate.id,
          userId: estate.userId,
          deletedAt: estate.deletedAt,
          assignedUserIds: estate.assignments.map((assignment) => assignment.userId),
          assignedUsers: estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
        },
        estateBroker,
      )
    ) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    const existing = await this.prisma.clientEstateLink.findUnique({
      where: {
        clientId_estateId: {
          clientId: BigInt(clientId),
          estateId: BigInt(estateId),
        },
      },
      include: DEAL_WITH_RELATIONS_INCLUDE,
    });
    if (existing && this.isActiveDealStage(existing.status)) {
      this.throwActiveDealConflict(existing, viewer);
    }

    let linkId: bigint;
    try {
      linkId = await this.prisma.$transaction(async (transaction) => {
        const link = existing
          ? await transaction.clientEstateLink.update({
              where: { id: existing.id },
              data: { status: stage },
            })
          : await transaction.clientEstateLink.create({
              data: {
                clientId: BigInt(clientId),
                estateId: BigInt(estateId),
                status: stage,
              },
            });

        await transaction.dealStageEvent.create({
          data: {
            linkId: link.id,
            actorId: BigInt(viewer.id),
            fromStatus: existing?.status ?? null,
            toStatus: stage,
          },
        });

        if (comment) {
          await transaction.dealComment.create({
            data: {
              linkId: link.id,
              authorId: BigInt(viewer.id),
              text: comment,
            },
          });
        }

        return link.id;
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
        const duplicate = await this.prisma.clientEstateLink.findUnique({
          where: {
            clientId_estateId: {
              clientId: BigInt(clientId),
              estateId: BigInt(estateId),
            },
          },
          include: DEAL_WITH_RELATIONS_INCLUDE,
        });
        if (duplicate) {
          this.throwActiveDealConflict(duplicate, viewer);
        }
      }
      throw error;
    }

    const deal = await this.getVisibleDealOrThrow(bigintToNumber(linkId), viewer);
    return {
      item: this.mapper.toDetailItem(deal, viewer),
      reused: Boolean(existing),
    };
  }

  async updateStage(
    linkId: number,
    payload: CrmDealStagePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<CrmDealMutationResponse> {
    this.assertDealsAccess(viewer);

    const stage = parsePipelineStatus(payload.stage);
    if (!stage) {
      throw new BadRequestException({
        errors: {
          stage: `Stage must be one of: ${CLIENT_PIPELINE_STATUSES.join(", ")}`,
        },
      });
    }

    const existing = await this.getVisibleDealOrThrow(linkId, viewer);
    if (existing.status === stage) {
      return { item: this.mapper.toDetailItem(existing, viewer) };
    }

    await this.prisma.$transaction(async (transaction) => {
      await transaction.clientEstateLink.update({
        where: { id: existing.id },
        data: { status: stage },
      });
      await transaction.dealStageEvent.create({
        data: {
          linkId: existing.id,
          actorId: BigInt(viewer.id),
          fromStatus: existing.status,
          toStatus: stage,
        },
      });

      if (stage === "closed" && !existing.estate.deletedAt) {
        await transaction.estate.update({
          where: { id: existing.estate.id },
          data: {
            deletedAt: new Date(),
            deletedById: BigInt(viewer.id),
          },
        });
      }
    });

    const updated = await this.getVisibleDealOrThrow(linkId, viewer);
    return { item: this.mapper.toDetailItem(updated, viewer) };
  }
  async listBrokers(viewer: AuthenticatedCrmUser): Promise<{ items: CrmDealBrokerItem[] }> {
    this.assertDealsAccess(viewer);

    if (isBroker(viewer)) {
      const user = await this.prisma.user.findFirst({
        where: {
          id: BigInt(viewer.id),
          role: CrmRole.BROKER,
        },
      });

      return {
        items: user ? [this.mapper.toBrokerItem(user)] : [],
      };
    }

    const where: Prisma.UserWhereInput = {
      role: CrmRole.BROKER,
    };

    if (isRop(viewer)) {
      where.ropId = BigInt(viewer.id);
    } else if (!(isOwner(viewer) || isAdmin(viewer))) {
      throw new ForbiddenException(DEALS_FORBIDDEN_MESSAGE);
    }

    const brokers = await this.prisma.user.findMany({
      where,
      orderBy: [{ firstName: "asc" }, { lastName: "asc" }, { id: "asc" }],
    });

    return {
      items: brokers.map((broker) => this.mapper.toBrokerItem(broker)),
    };
  }

  async listComments(linkId: number, viewer: AuthenticatedCrmUser): Promise<{ items: CrmDealCommentItem[] }> {
    this.assertDealsAccess(viewer);
    await this.getVisibleDealOrThrow(linkId, viewer);

    try {
      const comments = await this.prisma.dealComment.findMany({
        where: {
          linkId: BigInt(linkId),
        },
        include: DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE,
        orderBy: {
          createdAt: "desc",
        },
      });

      return {
        items: comments.map((comment) => this.mapper.toCommentItem(comment)),
      };
    } catch (error) {
      if (isDealActivityStorageError(error)) {
        return { items: [] };
      }

      throw error;
    }
  }

  async createComment(
    linkId: number,
    payload: CrmDealCommentWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealCommentItem }> {
    this.assertDealsAccess(viewer);
    await this.getVisibleDealOrThrow(linkId, viewer);

    const text = parseRequiredText(payload.text);
    if (!text) {
      throw new BadRequestException({
        errors: {
          text: "Comment text is required",
        },
      });
    }

    const comment = await this.prisma.dealComment.create({
      data: {
        linkId: BigInt(linkId),
        authorId: BigInt(viewer.id),
        text,
      },
      include: DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE,
    });

    return {
      item: this.mapper.toCommentItem(comment),
    };
  }

  async listTasks(linkId: number, viewer: AuthenticatedCrmUser): Promise<{ items: CrmDealTaskItem[] }> {
    this.assertDealsAccess(viewer);
    await this.getVisibleDealOrThrow(linkId, viewer);

    try {
      const tasks = await this.prisma.dealTask.findMany({
        where: {
          linkId: BigInt(linkId),
        },
        include: DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE,
        orderBy: [{ completedAt: "asc" }, { dueAt: "asc" }, { createdAt: "desc" }],
      });

      return {
        items: tasks.map((task) => this.mapper.toTaskItem(task)),
      };
    } catch (error) {
      if (isDealActivityStorageError(error)) {
        return { items: [] };
      }

      throw error;
    }
  }

  async createTask(
    linkId: number,
    payload: CrmDealTaskWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealTaskItem }> {
    this.assertDealsAccess(viewer);
    await this.getVisibleDealOrThrow(linkId, viewer);

    const type = parseTaskType(payload.type);
    const text = parseRequiredText(payload.text);
    const dueAt = parseOptionalDate(payload.due_at);
    if (!type || !text) {
      throw new BadRequestException({
        errors: {
          type: `Task type must be one of: ${DEAL_TASK_TYPES.join(", ")}`,
          text: "Task text is required",
        },
      });
    }

    const task = await this.prisma.dealTask.create({
      data: {
        linkId: BigInt(linkId),
        authorId: BigInt(viewer.id),
        type,
        text,
        dueAt,
      },
      include: DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE,
    });

    return {
      item: this.mapper.toTaskItem(task),
    };
  }

  async updateTask(
    linkId: number,
    taskId: number,
    payload: CrmDealTaskWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: CrmDealTaskItem }> {
    this.assertDealsAccess(viewer);
    await this.getVisibleDealOrThrow(linkId, viewer);

    const existingTask = await this.prisma.dealTask.findFirst({
      where: {
        id: BigInt(taskId),
        linkId: BigInt(linkId),
      },
    });
    if (!existingTask) {
      throw new NotFoundException(`Deal task ${taskId} not found`);
    }

    const task = await this.prisma.dealTask.update({
      where: {
        id: BigInt(taskId),
      },
      data: {
        completedAt: parseBoolean(payload.done) ? new Date() : null,
      },
      include: DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE,
    });

    return {
      item: this.mapper.toTaskItem(task),
    };
  }

  private isActiveDealStage(status: string): boolean {
    return !["closed", "rejected"].includes(normalizeText(status).toLowerCase());
  }

  private throwActiveDealConflict(deal: DealWithRelations, viewer: AuthenticatedCrmUser): never {
    const linkId = bigintToNumber(deal.id);
    throw new ConflictException({
      code: "active_deal_exists",
      message: "Активная сделка с этим клиентом и объектом уже существует",
      existing_deal: this.mapper.toDetailItem(deal, viewer),
      deal_url: `/crm/deals/${linkId}`,
    });
  }
  private assertDealsAccess(viewer: AuthenticatedCrmUser): void {
    if (isViewer(viewer)) {
      throw new ForbiddenException(DEALS_FORBIDDEN_MESSAGE);
    }
  }

  private buildDealsWhere(
    filters: ParsedDealListQuery,
    viewer: AuthenticatedCrmUser,
  ): Prisma.ClientEstateLinkWhereInput {
    const where: Prisma.ClientEstateLinkWhereInput = {
      client: {
        deletedAt: null,
      },
    };

    const and: Prisma.ClientEstateLinkWhereInput[] = [];

    if (isRop(viewer)) {
      and.push({
        client: {
          broker: {
            role: CrmRole.BROKER,
            ropId: BigInt(viewer.id),
          },
        },
      });
      and.push({
        OR: [
          {
            estate: {
              assignments: {
                some: {
                  user: {
                    role: CrmRole.BROKER,
                    ropId: BigInt(viewer.id),
                  },
                },
              },
            },
          },
          {
            estate: {
              assignments: {
                none: {},
              },
              user: {
                role: CrmRole.BROKER,
                ropId: BigInt(viewer.id),
              },
            },
          },
        ],
      });
    } else if (isBroker(viewer)) {
      and.push({
        client: {
          brokerId: BigInt(viewer.id),
        },
      });
    } else if (!(isOwner(viewer) || isAdmin(viewer))) {
      throw new ForbiddenException(DEALS_FORBIDDEN_MESSAGE);
    }

    if (filters.search) {
      and.push({
        OR: [
          { client: { name: { contains: filters.search, mode: "insensitive" } } },
          { client: { phone: { contains: filters.search, mode: "insensitive" } } },
          { client: { email: { contains: filters.search, mode: "insensitive" } } },
          { client: { source: { contains: filters.search, mode: "insensitive" } } },
          { estate: { title: { contains: filters.search, mode: "insensitive" } } },
          { estate: { district: { contains: filters.search, mode: "insensitive" } } },
          { estate: { metroStation: { contains: filters.search, mode: "insensitive" } } },
        ],
      });
    }

    if (filters.status !== null) {
      and.push({
        status: filters.status,
      });
    }

    if (filters.broker_id !== null) {
      and.push({
        client: {
          brokerId: BigInt(filters.broker_id),
        },
      });
    }

    if (filters.client_id !== null) {
      and.push({
        clientId: BigInt(filters.client_id),
      });
    }

    if (filters.estate_id !== null) {
      and.push({
        estateId: BigInt(filters.estate_id),
      });
    }

    if (and.length > 0) {
      where.AND = and;
    }

    return where;
  }

  private async getVisibleDealOrThrow(linkId: number, viewer: AuthenticatedCrmUser): Promise<DealWithRelations> {
    const scopeWhere = this.buildDealsWhere(
      {
        search: null,
        status: null,
        broker_id: null,
        client_id: null,
        estate_id: null,
        skip: 0,
        limit: 1,
      },
      viewer,
    );

    const link = await this.prisma.clientEstateLink.findFirst({
      where: {
        id: BigInt(linkId),
        ...scopeWhere,
      },
      include: DEAL_WITH_RELATIONS_INCLUDE,
    });

    if (!link || !this.canViewDeal(viewer, link)) {
      throw new NotFoundException(`Deal ${linkId} not found`);
    }

    return link;
  }

  private canViewDeal(viewer: AuthenticatedCrmUser, link: DealWithRelations): boolean {
    return (
      canViewClient(viewer, this.toScopedClient(link), this.toScopedUser(link.client.broker)) &&
      (canViewEstate(viewer, this.toScopedEstate(link), this.getEstateBroker(link)) ||
        canViewArchivedEstate(viewer, this.toScopedEstate(link), this.getEstateBroker(link)))
    );
  }

  private toScopedClient(link: DealWithRelations): ScopedClientRef {
    return {
      id: link.client.id,
      brokerId: link.client.brokerId,
      deletedAt: link.client.deletedAt,
    };
  }

  private toScopedEstate(link: DealWithRelations): ScopedEstateRef {
    return {
      id: link.estate.id,
      userId: link.estate.userId,
      deletedAt: link.estate.deletedAt,
      assignedUserIds: link.estate.assignments.map((assignment) => assignment.userId),
      assignedUsers: link.estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
    };
  }

  private getEstateBroker(link: DealWithRelations): ScopedUserRef {
    if (link.estate.user) {
      return this.toScopedUser(link.estate.user);
    }

    return {
      id: BigInt(0),
      role: CrmRole.VIEWER,
      ropId: null,
    };
  }

  private toScopedUser(user: Pick<User, "id" | "role" | "ropId">): ScopedUserRef {
    return {
      id: user.id,
      role: user.role,
      ropId: user.ropId,
    };
  }
}
