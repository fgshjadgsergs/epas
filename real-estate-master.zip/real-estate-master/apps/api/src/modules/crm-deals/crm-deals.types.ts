import { Prisma } from "@prisma/client";
import { ClientPipelineStatus } from "../crm-clients/crm-clients.types";

export interface CrmDealListQuery {
  search?: string;
  status?: string;
  broker_id?: string;
  client_id?: string;
  estate_id?: string;
  skip?: string;
  limit?: string;
}

export interface CrmDealCreatePayload {
  client_id?: number | string | null;
  estate_id?: number | string | null;
  stage?: string | null;
  comment?: string | null;
}

export interface CrmDealStagePayload {
  stage?: string | null;
}

export interface CrmDealBrokerItem {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  rop_id: number | null;
}

export type CrmDealTaskType = "CALL" | "MEETING" | "MESSAGE";

export interface CrmDealCommentWritePayload {
  text?: string | null;
}

export interface CrmDealTaskWritePayload {
  type?: string | null;
  text?: string | null;
  due_at?: string | null;
  done?: boolean | string | null;
}

export interface CrmDealListItem {
  link_id: number;
  status: ClientPipelineStatus;
  client_id: number;
  client_name: string;
  phone?: string | null;
  email?: string | null;
  contacts_visible: boolean;
  source: string | null;
  comment: string | null;
  estate_id: number;
  estate_title: string;
  estate_price: number | null;
  estate_presentation_price: string | null;
  district: string | null;
  metro_station: string | null;
  broker_id: number;
  broker_name: string;
  created_at: string;
  update_at: string;
}

export interface CrmDealDetailItem extends CrmDealListItem {}

export interface CrmDealMutationResponse {
  item: CrmDealDetailItem;
  reused?: boolean;
}

export interface CrmDealCommentItem {
  id: number;
  author_id: number;
  author_name: string;
  text: string;
  created_at: string;
}

export interface CrmDealTaskItem {
  id: number;
  author_id: number;
  author_name: string;
  type: CrmDealTaskType;
  text: string;
  due_at: string | null;
  done: boolean;
  created_at: string;
  update_at: string;
}

export const DEAL_WITH_RELATIONS_INCLUDE = {
  client: {
    include: {
      broker: true,
    },
  },
  estate: {
    include: {
      user: true,
      assignments: {
        include: {
          user: true,
        },
        orderBy: {
          createdAt: "asc" as const,
        },
      },
    },
  },
} as const;

export type DealWithRelations = Prisma.ClientEstateLinkGetPayload<{
  include: typeof DEAL_WITH_RELATIONS_INCLUDE;
}>;

export const DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE = {
  author: true,
} as const;

export type DealCommentWithAuthor = Prisma.DealCommentGetPayload<{
  include: typeof DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE;
}>;

export type DealTaskWithAuthor = Prisma.DealTaskGetPayload<{
  include: typeof DEAL_ACTIVITY_WITH_AUTHOR_INCLUDE;
}>;
