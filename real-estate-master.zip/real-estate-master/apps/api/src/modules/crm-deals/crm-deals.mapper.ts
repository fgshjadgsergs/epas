import { Injectable } from "@nestjs/common";
import { CrmRole, User } from "@prisma/client";
import {
  bigintToNumber,
  decimalToNumber,
  formatInteger,
} from "../../common/utils/number.utils";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { canViewClientContacts } from "../crm-auth/crm-permissions";
import {
  CrmDealBrokerItem,
  CrmDealCommentItem,
  CrmDealDetailItem,
  CrmDealListItem,
  CrmDealTaskItem,
  DealCommentWithAuthor,
  DealTaskWithAuthor,
  DealWithRelations,
} from "./crm-deals.types";

function getBrokerName(user: Pick<User, "firstName" | "lastName" | "email">): string {
  const fullName = `${user.firstName} ${user.lastName}`.trim();
  return fullName || user.email;
}

@Injectable()
export class CrmDealsMapper {
  toBrokerItem(user: Pick<User, "id" | "email" | "firstName" | "lastName" | "ropId">): CrmDealBrokerItem {
    return {
      id: bigintToNumber(user.id),
      email: user.email,
      first_name: user.firstName,
      last_name: user.lastName,
      rop_id: user.ropId === null ? null : bigintToNumber(user.ropId),
    };
  }

  toListItem(link: DealWithRelations, viewer: AuthenticatedCrmUser): CrmDealListItem {
    return this.toBaseItem(link, viewer);
  }

  toDetailItem(link: DealWithRelations, viewer: AuthenticatedCrmUser): CrmDealDetailItem {
    return this.toBaseItem(link, viewer);
  }

  toCommentItem(comment: DealCommentWithAuthor): CrmDealCommentItem {
    return {
      id: bigintToNumber(comment.id),
      author_id: bigintToNumber(comment.author.id),
      author_name: getBrokerName(comment.author),
      text: comment.text,
      created_at: comment.createdAt.toISOString(),
    };
  }

  toTaskItem(task: DealTaskWithAuthor): CrmDealTaskItem {
    return {
      id: bigintToNumber(task.id),
      author_id: bigintToNumber(task.author.id),
      author_name: getBrokerName(task.author),
      type: task.type as CrmDealTaskItem["type"],
      text: task.text,
      due_at: task.dueAt ? task.dueAt.toISOString() : null,
      done: task.completedAt !== null,
      created_at: task.createdAt.toISOString(),
      update_at: task.updateAt.toISOString(),
    };
  }

  private toBaseItem(link: DealWithRelations, viewer: AuthenticatedCrmUser): CrmDealDetailItem {
    const canSeeContacts = canViewClientContacts(
      viewer,
      {
        id: link.client.id,
        brokerId: link.client.brokerId,
        deletedAt: link.client.deletedAt,
      },
      {
        id: link.client.broker.id,
        role: link.client.broker.role,
        ropId: link.client.broker.ropId,
      },
    );
    const estatePrice = decimalToNumber(link.estate.price);

    const item: CrmDealDetailItem = {
      link_id: bigintToNumber(link.id),
      status: link.status as CrmDealDetailItem["status"],
      client_id: bigintToNumber(link.client.id),
      client_name: link.client.name,
      contacts_visible: canSeeContacts,
      source: link.client.source,
      comment: link.client.comment,
      estate_id: bigintToNumber(link.estate.id),
      estate_title: link.estate.title,
      estate_price: estatePrice,
      estate_presentation_price: estatePrice === null ? null : formatInteger(estatePrice),
      district: link.estate.district,
      metro_station: link.estate.metroStation,
      broker_id: bigintToNumber(link.client.broker.id),
      broker_name: getBrokerName(link.client.broker),
      created_at: link.createdAt.toISOString(),
      update_at: link.updateAt.toISOString(),
    };

    if (canSeeContacts) {
      item.phone = link.client.phone;
      item.email = link.client.email;
    }

    return item;
  }
}
