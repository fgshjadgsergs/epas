import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { CrmDealsController } from "./crm-deals.controller";
import { CrmDealsMapper } from "./crm-deals.mapper";
import { CrmDealsService } from "./crm-deals.service";

@Module({
  imports: [CrmAuthModule],
  controllers: [CrmDealsController],
  providers: [CrmDealsMapper, CrmDealsService],
})
export class CrmDealsModule {}
