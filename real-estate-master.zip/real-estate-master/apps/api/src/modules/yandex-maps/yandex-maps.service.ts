import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";

interface YandexGeocoderResponse {
  response?: {
    GeoObjectCollection?: {
      featureMember?: Array<{
        GeoObject?: {
          Point?: {
            pos?: string;
          };
        };
      }>;
    };
  };
  error?: unknown;
  message?: string;
}

@Injectable()
export class YandexMapsService {
  constructor(private readonly configService: ConfigService) {}

  async getCoordinatesByAddress(address: string): Promise<string> {
    const apiKey = this.configService.get<string>("YANDEX_MAPS_API_KEY");
    if (!apiKey) {
      throw new Error("YANDEX_MAPS_API_KEY is not configured");
    }

    const url = new URL("https://geocode-maps.yandex.ru/1.x/");
    url.searchParams.set("apikey", apiKey);
    url.searchParams.set("geocode", address);
    url.searchParams.set("format", "json");

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to query Yandex geocoder: ${response.status} ${response.statusText}`);
    }

    const payload = (await response.json()) as YandexGeocoderResponse;
    const items = payload.response?.GeoObjectCollection?.featureMember ?? [];
    const coordinates = items[0]?.GeoObject?.Point?.pos;

    if (coordinates) {
      return coordinates;
    }

    if (payload.error) {
      throw new Error(`Error while getting coordinates for address: ${payload.message ?? "unknown error"}`);
    }

    throw new Error("Coordinates not found");
  }
}
