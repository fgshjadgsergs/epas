import { Module } from "@nestjs/common";
import { YandexMapsService } from "./yandex-maps.service";

@Module({
  providers: [YandexMapsService],
  exports: [YandexMapsService],
})
export class YandexMapsModule {}
