import { Controller, Get } from "@nestjs/common";

@Controller("api/v1/health")
export class HealthController {
  @Get()
  getHealth(): { status: "ok"; service: string; now: string } {
    return {
      status: "ok",
      service: "estate-api",
      now: new Date().toISOString(),
    };
  }
}
