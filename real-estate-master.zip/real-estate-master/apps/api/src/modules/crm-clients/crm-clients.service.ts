import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { ClientEstateLink, CrmRole, Prisma, User } from "@prisma/client";
import { bigintToNumber } from "../../common/utils/number.utils";
import { normalizePhone } from "../../common/utils/phone.utils";
import { PrismaService } from "../../prisma/prisma.service";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import {
  canEditClient,
  canSoftDeleteClient,
  canViewClient,
  canViewEstate,
  isAdmin,
  isBroker,
  isBrokerInActorsTeam,
  isOwner,
  isRop,
  isViewer,
  ScopedUserRef,
} from "../crm-auth/crm-permissions";
import { CrmClientsMapper } from "./crm-clients.mapper";
import {
  buildClientWithRelationsInclude,
  CLIENT_PIPELINE_STATUSES,
  CLIENT_WITH_RELATIONS_INCLUDE,
  ClientPipelineStatus,
  ClientWithRelations,
  CrmClientBrokerItem,
  CrmClientListQuery,
  CrmClientWritePayload,
} from "./crm-clients.types";

const REQUIRED_FIELD_MESSAGE = "Field is required";
const CLIENT_FORBIDDEN_MESSAGE = "You can manage only permitted clients";
const MAX_CLIENT_LIST_LIMIT = 100;

interface ParsedClientListQuery {
  search: string | null;
  broker_id: number | null;
  estate_id: number | null;
  status: ClientPipelineStatus | null;
  skip: number;
  limit: number;
}

interface ParsedClientEstateLink {
  estateId: number;
  status: ClientPipelineStatus;
}

type ClientLinkWithRelations = ClientEstateLink & {
  client: {
    id: bigint;
    brokerId: bigint;
    deletedAt: Date | null;
    broker: User;
  };
  estate: {
    id: bigint;
    userId: bigint | null;
    deletedAt: Date | null;
    user: User | null;
    assignments: Array<{
      userId: bigint;
      user: User;
    }>;
  };
};

function normalizeText(value: string | null | undefined): string {
  if (value === undefined || value === null) {
    return "";
  }

  return String(value).trim();
}

function parseNullableInteger(value: number | string | null | undefined): number | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
}

function parsePipelineStatus(value: string | null | undefined): ClientPipelineStatus | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const normalized = normalizeText(value).toLowerCase();
  return CLIENT_PIPELINE_STATUSES.includes(normalized as ClientPipelineStatus) ? (normalized as ClientPipelineStatus) : null;
}

function parseClientListQuery(query: CrmClientListQuery): ParsedClientListQuery {
  const limit = parseNullableInteger(query.limit);
  const skip = parseNullableInteger(query.skip);

  return {
    search: normalizeText(query.search) || null,
    broker_id: parseNullableInteger(query.brokerId ?? query.broker_id),
    estate_id: parseNullableInteger(query.estate_id),
    status: parsePipelineStatus(query.status),
    skip: skip === null ? 0 : Math.max(skip, 0),
    limit: limit === null ? 50 : Math.min(limit, MAX_CLIENT_LIST_LIMIT),
  };
}

@Injectable()
export class CrmClientsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mapper: CrmClientsMapper,
  ) {}

  async list(
    viewer: AuthenticatedCrmUser,
    query: CrmClientListQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number }> {
    this.assertClientsAccess(viewer);

    const filters = parseClientListQuery(query);
    await this.assertBrokerFilterAccess(filters.broker_id, viewer);
    const where = this.buildClientWhere(filters, viewer);

    const [clients, total] = await this.prisma.$transaction([
      this.prisma.client.findMany({
        where,
        include: buildClientWithRelationsInclude(filters.status ?? undefined),
        orderBy: {
          id: "desc",
        },
        skip: filters.skip,
        take: filters.limit,
      }),
      this.prisma.client.count({ where }),
    ]);

    return {
      items: clients.map((client) => this.mapper.toListItem(client, viewer)),
      total,
      skip: filters.skip,
      limit: filters.limit,
    };
  }

  async listBrokers(viewer: AuthenticatedCrmUser): Promise<{ items: CrmClientBrokerItem[] }> {
    this.assertClientsAccess(viewer);

    const where: Prisma.UserWhereInput = { role: CrmRole.BROKER };
    if (isBroker(viewer)) {
      where.id = BigInt(viewer.id);
    } else if (isRop(viewer)) {
      where.ropId = BigInt(viewer.id);
    } else if (!(isOwner(viewer) || isAdmin(viewer))) {
      throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
    }

    const brokers = await this.prisma.user.findMany({
      where,
      orderBy: [{ firstName: "asc" }, { lastName: "asc" }, { id: "asc" }],
    });

    return {
      items: brokers.map((broker) => ({
        id: bigintToNumber(broker.id),
        email: broker.email,
        first_name: broker.firstName,
        last_name: broker.lastName,
        rop_id: broker.ropId === null ? null : bigintToNumber(broker.ropId),
      })),
    };
  }

  async getDetail(
    clientId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown> }> {
    this.assertClientsAccess(viewer);
    const client = await this.getVisibleClientOrThrow(clientId, viewer);

    return {
      item: this.mapper.toDetail(client, viewer),
    };
  }

  async create(
    payload: CrmClientWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown> }> {
    this.assertClientsAccess(viewer);

    const errors = this.validateClientPayload(payload);
    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    const phone = this.normalizeNullableText(payload.phone);
    const phoneNormalized = normalizePhone(phone);
    await this.assertPhoneAvailable(phoneNormalized);
    const brokerId = await this.resolveTargetBrokerId(payload, viewer);
    const estateLinks = this.parseEstateLinks(payload);
    await this.assertEstateLinkScope(estateLinks.map((link) => link.estateId), viewer);

    const created = await this.prisma.client.create({
      data: {
        brokerId: BigInt(brokerId),
        name: normalizeText(payload.name),
        phone,
        phoneNormalized,
        email: this.normalizeNullableText(payload.email),
        source: this.normalizeNullableText(payload.source),
        comment: this.normalizeNullableText(payload.comment),
        estateLinks: estateLinks.length
          ? {
              create: estateLinks.map((link) => ({
                estateId: BigInt(link.estateId),
                status: link.status,
              })),
            }
          : undefined,
      },
      include: CLIENT_WITH_RELATIONS_INCLUDE,
    });

    return {
      item: this.mapper.toDetail(created, viewer),
    };
  }

  async update(
    clientId: number,
    payload: CrmClientWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown> }> {
    this.assertClientsAccess(viewer);

    const existingClient = await this.getVisibleClientOrThrow(clientId, viewer);
    this.assertCanManageClient(existingClient, viewer);

    const errors = this.validateClientPayload(payload);
    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    const phone = this.normalizeNullableText(payload.phone);
    const phoneNormalized = normalizePhone(phone);
    await this.assertPhoneAvailable(phoneNormalized, existingClient.id);
    const brokerId = await this.resolveTargetBrokerId(payload, viewer, existingClient);
    const estateLinks = this.parseEstateLinks(payload);
    await this.assertEstateLinkScope(estateLinks.map((link) => link.estateId), viewer);

    await this.prisma.$transaction([
      this.prisma.clientEstateLink.deleteMany({
        where: {
          clientId: BigInt(clientId),
        },
      }),
      this.prisma.client.update({
        where: {
          id: BigInt(clientId),
        },
        data: {
          brokerId: BigInt(brokerId),
          name: normalizeText(payload.name),
          phone,
          phoneNormalized,
          email: this.normalizeNullableText(payload.email),
          source: this.normalizeNullableText(payload.source),
          comment: this.normalizeNullableText(payload.comment),
          estateLinks: estateLinks.length
            ? {
                create: estateLinks.map((link) => ({
                  estateId: BigInt(link.estateId),
                  status: link.status,
                })),
              }
            : undefined,
        },
      }),
    ]);

    const updated = await this.getVisibleClientOrThrow(clientId, viewer);
    return {
      item: this.mapper.toDetail(updated, viewer),
    };
  }

  async delete(
    clientId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ deleted: true }> {
    this.assertClientsAccess(viewer);
    const client = await this.getVisibleClientOrThrow(clientId, viewer);
    const clientBroker = this.toScopedUser(client.broker);

    if (!canSoftDeleteClient(viewer, this.toScopedClient(client), clientBroker)) {
      throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
    }

    await this.prisma.client.update({
      where: {
        id: BigInt(clientId),
      },
      data: {
        deletedAt: new Date(),
      },
    });

    return { deleted: true };
  }

  private async assertPhoneAvailable(phoneNormalized: string | null, excludeClientId?: bigint): Promise<void> {
    if (!phoneNormalized) {
      return;
    }

    const duplicate = await this.prisma.client.findFirst({
      where: {
        phoneNormalized,
        deletedAt: null,
        ...(excludeClientId ? { id: { not: excludeClientId } } : {}),
      },
      include: { broker: true },
      orderBy: { id: "asc" },
    });

    if (!duplicate) {
      return;
    }

    const clientId = bigintToNumber(duplicate.id);
    throw new ConflictException({
      code: "client_phone_conflict",
      message: "Клиент с таким номером уже существует",
      errors: { phone: "Клиент с таким номером уже существует" },
      existingClient: {
        clientId,
        name: duplicate.name,
        phone: duplicate.phone,
        broker: {
          id: bigintToNumber(duplicate.broker.id),
          name: (duplicate.broker.firstName + " " + duplicate.broker.lastName).trim() || duplicate.broker.email,
          email: duplicate.broker.email,
        },
        href: "/clients/" + clientId,
      },
    });
  }

  private async assertBrokerFilterAccess(brokerId: number | null, viewer: AuthenticatedCrmUser): Promise<void> {
    if (brokerId === null || isOwner(viewer) || isAdmin(viewer)) {
      return;
    }

    if (isBroker(viewer)) {
      if (brokerId !== viewer.id) {
        throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
      }
      return;
    }

    if (isRop(viewer)) {
      const broker = await this.prisma.user.findFirst({
        where: { id: BigInt(brokerId), role: CrmRole.BROKER, ropId: BigInt(viewer.id) },
        select: { id: true },
      });
      if (broker) {
        return;
      }
    }

    throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
  }

  private validateClientPayload(payload: CrmClientWritePayload): Record<string, string> {
    const errors: Record<string, string> = {};

    if (!normalizeText(payload.name)) {
      errors.name = REQUIRED_FIELD_MESSAGE;
    }

    if (payload.broker_id !== undefined && payload.broker_id !== null && payload.broker_id !== "" && parseNullableInteger(payload.broker_id) === null) {
      errors.broker_id = "Invalid broker_id";
    }

    if (payload.estate_ids !== undefined && payload.estate_links !== undefined) {
      errors.estate_links = "Use estate_ids or estate_links, not both";
    }

    if (payload.estate_ids !== undefined) {
      const invalidEstateId = (payload.estate_ids ?? []).some((estateId) => parseNullableInteger(estateId) === null);
      if (invalidEstateId) {
        errors.estate_ids = "Invalid estate_ids";
      }
    }

    if (payload.estate_links !== undefined) {
      for (const link of payload.estate_links ?? []) {
        if (parseNullableInteger(link.estate_id) === null || parsePipelineStatus(link.status ?? "new") === null) {
          errors.estate_links = `Invalid estate_links. Allowed statuses: ${CLIENT_PIPELINE_STATUSES.join(", ")}`;
          break;
        }
      }
    }

    return errors;
  }

  private buildClientWhere(filters: ParsedClientListQuery, viewer: AuthenticatedCrmUser): Prisma.ClientWhereInput {
    const where: Prisma.ClientWhereInput = {
      deletedAt: null,
    };

    if (isRop(viewer)) {
      where.broker = {
        role: CrmRole.BROKER,
        ropId: BigInt(viewer.id),
      };
    } else if (isBroker(viewer)) {
      where.brokerId = BigInt(viewer.id);
    }

    const and: Prisma.ClientWhereInput[] = [];

    if (filters.search) {
      and.push({
        OR: [
          { name: { contains: filters.search, mode: "insensitive" } },
          { phone: { contains: filters.search, mode: "insensitive" } },
          { email: { contains: filters.search, mode: "insensitive" } },
          { source: { contains: filters.search, mode: "insensitive" } },
        ],
      });
    }

    if (filters.broker_id !== null) {
      and.push({
        brokerId: BigInt(filters.broker_id),
      });
    }

    if (filters.estate_id !== null) {
      and.push({
        estateLinks: {
          some: {
            estateId: BigInt(filters.estate_id),
            estate: {
              deletedAt: null,
            },
          },
        },
      });
    }

    if (filters.status !== null) {
      and.push({
        estateLinks: {
          some: {
            status: filters.status,
            estate: {
              deletedAt: null,
            },
          },
        },
      });
    }

    if (and.length > 0) {
      where.AND = and;
    }

    return where;
  }

  private assertClientsAccess(viewer: AuthenticatedCrmUser): void {
    if (isViewer(viewer)) {
      throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
    }
  }

  private assertCanManageClient(client: ClientWithRelations, viewer: AuthenticatedCrmUser): void {
    if (!canEditClient(viewer, this.toScopedClient(client), this.toScopedUser(client.broker))) {
      throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
    }
  }

  private async getVisibleClientOrThrow(clientId: number, viewer: AuthenticatedCrmUser): Promise<ClientWithRelations> {
    const client = await this.prisma.client.findFirst({
      where: {
        id: BigInt(clientId),
        deletedAt: null,
      },
      include: CLIENT_WITH_RELATIONS_INCLUDE,
    });

    if (!client) {
      throw new NotFoundException(`Client ${clientId} not found`);
    }

    if (!canViewClient(viewer, this.toScopedClient(client), this.toScopedUser(client.broker))) {
      throw new NotFoundException(`Client ${clientId} not found`);
    }

    return client;
  }

  private async getVisibleClientLinkOrThrow(linkId: number, viewer: AuthenticatedCrmUser): Promise<ClientLinkWithRelations> {
    const link = await this.prisma.clientEstateLink.findFirst({
      where: {
        id: BigInt(linkId),
        client: {
          deletedAt: null,
        },
        estate: {
          deletedAt: null,
        },
      },
      include: {
        client: {
          include: {
            broker: true,
          },
        },
        estate: {
          include: {
            user: true,
            assignments: {
              include: {
                user: true,
              },
              orderBy: {
                createdAt: "asc",
              },
            },
          },
        },
      },
    });

    if (!link) {
      throw new NotFoundException(`ClientEstateLink ${linkId} not found`);
    }

    if (
      !canViewClient(viewer, this.toScopedClient(link.client), this.toScopedUser(link.client.broker)) ||
      !canViewEstate(
        viewer,
        {
          id: link.estate.id,
          userId: link.estate.userId,
          deletedAt: link.estate.deletedAt,
          assignedUserIds: link.estate.assignments.map((assignment) => assignment.userId),
          assignedUsers: link.estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
        },
        link.estate.user
          ? this.toScopedUser(link.estate.user)
          : {
              id: BigInt(0),
              role: CrmRole.VIEWER,
              ropId: null,
            },
      )
    ) {
      throw new NotFoundException(`ClientEstateLink ${linkId} not found`);
    }

    return link;
  }

  private async getUserByIdOrThrow(userId: number): Promise<User> {
    const user = await this.prisma.user.findUnique({
      where: {
        id: BigInt(userId),
      },
    });

    if (!user) {
      throw new NotFoundException(`User ${userId} not found`);
    }

    return user;
  }

  private async resolveTargetBrokerId(
    payload: CrmClientWritePayload,
    viewer: AuthenticatedCrmUser,
    existingClient?: ClientWithRelations,
  ): Promise<number> {
    if (isBroker(viewer)) {
      return viewer.id;
    }

    const requestedBrokerId =
      parseNullableInteger(payload.broker_id) ??
      (existingClient ? bigintToNumber(existingClient.brokerId) : null);

    if (requestedBrokerId === null) {
      throw new BadRequestException({
        errors: {
          broker_id: REQUIRED_FIELD_MESSAGE,
        },
      });
    }

    const targetBroker = await this.getUserByIdOrThrow(requestedBrokerId);
    if (targetBroker.role !== CrmRole.BROKER) {
      throw new BadRequestException({
        errors: {
          broker_id: "broker_id must reference broker",
        },
      });
    }

    if (isOwner(viewer) || isAdmin(viewer)) {
      return requestedBrokerId;
    }

    if (isRop(viewer) && isBrokerInActorsTeam(viewer, this.toScopedUser(targetBroker))) {
      return requestedBrokerId;
    }

    throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
  }

  private parseEstateLinks(payload: CrmClientWritePayload): ParsedClientEstateLink[] {
    if (payload.estate_links && payload.estate_links.length > 0) {
      const links = payload.estate_links
        .map((link) => ({
          estateId: parseNullableInteger(link.estate_id),
          status: parsePipelineStatus(link.status ?? "new"),
        }))
        .filter((link): link is ParsedClientEstateLink => link.estateId !== null && link.status !== null);

      return this.deduplicateEstateLinks(links);
    }

    if (!payload.estate_ids) {
      return [];
    }

    const estateIds = payload.estate_ids
      .map((value) => parseNullableInteger(value))
      .filter((value): value is number => value !== null);

    return this.deduplicateEstateLinks(estateIds.map((estateId) => ({ estateId, status: "new" })));
  }

  private deduplicateEstateLinks(links: ParsedClientEstateLink[]): ParsedClientEstateLink[] {
    const uniqueLinks = new Map<number, ParsedClientEstateLink>();

    for (const link of links) {
      uniqueLinks.set(link.estateId, link);
    }

    return [...uniqueLinks.values()];
  }

  private async assertEstateLinkScope(estateIds: number[], viewer: AuthenticatedCrmUser): Promise<void> {
    if (estateIds.length === 0) {
      return;
    }

    const estates = await this.prisma.estate.findMany({
      where: {
        id: {
          in: estateIds.map((estateId) => BigInt(estateId)),
        },
        deletedAt: null,
      },
      include: {
        user: true,
        assignments: {
          include: {
            user: true,
          },
          orderBy: {
            createdAt: "asc",
          },
        },
      },
    });

    if (estates.length !== estateIds.length) {
      throw new NotFoundException("One or more estates not found");
    }

    for (const estate of estates) {
      if (
        !canViewEstate(
          viewer,
          {
            id: estate.id,
            userId: estate.userId,
            deletedAt: estate.deletedAt,
            assignedUserIds: estate.assignments.map((assignment) => assignment.userId),
            assignedUsers: estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
          },
          estate.user
            ? this.toScopedUser(estate.user)
            : {
                id: BigInt(0),
                role: CrmRole.VIEWER,
                ropId: null,
              },
        )
      ) {
        throw new ForbiddenException(CLIENT_FORBIDDEN_MESSAGE);
      }
    }
  }

  private normalizeNullableText(value: string | null | undefined): string | null {
    const normalized = normalizeText(value);
    return normalized || null;
  }

  private toScopedUser(user: User): ScopedUserRef {
    return {
      id: user.id,
      role: user.role,
      ropId: user.ropId,
    };
  }

  private toScopedClient(client: Pick<ClientWithRelations, "id" | "brokerId" | "deletedAt">) {
    return {
      id: client.id,
      brokerId: client.brokerId,
      deletedAt: client.deletedAt,
    };
  }
}
