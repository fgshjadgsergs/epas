import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { StorageModule } from "../storage/storage.module";
import { CrmClientsController } from "./crm-clients.controller";
import { CrmClientsMapper } from "./crm-clients.mapper";
import { CrmClientsService } from "./crm-clients.service";

@Module({
  imports: [CrmAuthModule, StorageModule],
  controllers: [CrmClientsController],
  providers: [CrmClientsMapper, CrmClientsService],
})
export class CrmClientsModule {}
