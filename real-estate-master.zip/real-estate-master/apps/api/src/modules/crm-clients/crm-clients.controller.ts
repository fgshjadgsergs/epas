import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put, Query, UseGuards } from "@nestjs/common";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CrmClientsService } from "./crm-clients.service";
import { CrmClientListQuery, CrmClientWritePayload } from "./crm-clients.types";

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/clients")
export class CrmClientsController {
  constructor(private readonly crmClientsService: CrmClientsService) {}

  @Get()
  list(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: CrmClientListQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number }> {
    return this.crmClientsService.list(user, query);
  }

  @Get("brokers")
  listBrokers(@CurrentCrmUser() user: AuthenticatedCrmUser) {
    return this.crmClientsService.listBrokers(user);
  }

  @Get(":clientId")
  getDetail(
    @Param("clientId", ParseIntPipe) clientId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown> }> {
    return this.crmClientsService.getDetail(clientId, user);
  }

  @Post()
  create(
    @Body() payload: CrmClientWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown> }> {
    return this.crmClientsService.create(payload, user);
  }

  @Put(":clientId")
  update(
    @Param("clientId", ParseIntPipe) clientId: number,
    @Body() payload: CrmClientWritePayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown> }> {
    return this.crmClientsService.update(clientId, payload, user);
  }

  @Delete(":clientId")
  delete(
    @Param("clientId", ParseIntPipe) clientId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ deleted: true }> {
    return this.crmClientsService.delete(clientId, user);
  }
}
