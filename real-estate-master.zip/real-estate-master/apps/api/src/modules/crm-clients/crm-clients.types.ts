import { Prisma } from "@prisma/client";

export const CLIENT_PIPELINE_STATUSES = [
  "new",
  "in_progress",
  "showing",
  "negotiation",
  "closed",
  "rejected",
] as const;

export type ClientPipelineStatus = (typeof CLIENT_PIPELINE_STATUSES)[number];

export interface CrmClientWritePayload {
  broker_id?: number | string | null;
  name?: string;
  phone?: string | null;
  email?: string | null;
  source?: string | null;
  comment?: string | null;
  estate_ids?: Array<number | string>;
  estate_links?: Array<{
    estate_id?: number | string | null;
    status?: string | null;
  }>;
}


export interface CrmClientListQuery {
  search?: string;
  brokerId?: string;
  broker_id?: string;
  estate_id?: string;
  status?: string;
  skip?: string;
  limit?: string;
}

export interface CrmClientBrokerItem {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  rop_id: number | null;
}

const CLIENT_ESTATE_RELATIONS_INCLUDE = {
  user: true,
  assignments: {
    include: {
      user: true,
    },
    orderBy: {
      createdAt: "asc" as const,
    },
  },
  images: {
    orderBy: { isMain: "desc" as const },
    take: 1,
  },
} as const;

export const CLIENT_WITH_RELATIONS_INCLUDE = {
  broker: true,
  estateLinks: {
    where: {
      estate: {
        deletedAt: null,
      },
    },
    include: {
      estate: {
        include: CLIENT_ESTATE_RELATIONS_INCLUDE,
      },
    },
    orderBy: {
      id: "asc",
    },
  },
} as const;

export function buildClientWithRelationsInclude(status?: ClientPipelineStatus) {
  return {
    broker: true,
    estateLinks: {
      where: {
        estate: {
          deletedAt: null,
        },
        ...(status ? { status } : {}),
      },
      include: {
        estate: {
          include: CLIENT_ESTATE_RELATIONS_INCLUDE,
        },
      },
      orderBy: {
        id: "asc" as const,
      },
    },
  } as const;
}

export type ClientWithRelations = Prisma.ClientGetPayload<{
  include: typeof CLIENT_WITH_RELATIONS_INCLUDE;
}>;
