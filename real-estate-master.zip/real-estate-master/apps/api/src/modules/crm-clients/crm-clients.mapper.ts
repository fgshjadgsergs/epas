import { Injectable } from "@nestjs/common";
import { CrmRole } from "@prisma/client";
import { bigintToNumber, decimalToNumber } from "../../common/utils/number.utils";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { canViewClientContacts } from "../crm-auth/crm-permissions";
import { StorageService } from "../storage/storage.service";
import { ClientWithRelations } from "./crm-clients.types";

@Injectable()
export class CrmClientsMapper {
  constructor(private readonly storageService: StorageService) {}

  toListItem(client: ClientWithRelations, viewer: AuthenticatedCrmUser): Record<string, unknown> {
    return this.toBaseItem(client, viewer);
  }

  toDetail(client: ClientWithRelations, viewer: AuthenticatedCrmUser): Record<string, unknown> {
    return this.toBaseItem(client, viewer);
  }

  private toBaseItem(client: ClientWithRelations, viewer: AuthenticatedCrmUser): Record<string, unknown> {
    const canSeeContacts = canViewClientContacts(
      viewer,
      {
        id: client.id,
        brokerId: client.brokerId,
        deletedAt: client.deletedAt,
      },
      {
        id: client.broker.id,
        role: client.broker.role,
        ropId: client.broker.ropId,
      },
    );

    const item: Record<string, unknown> = {
      id: bigintToNumber(client.id),
      broker_id: bigintToNumber(client.brokerId),
      name: client.name,
      source: client.source,
      comment: client.comment,
      created_at: client.createdAt.toISOString(),
      update_at: client.updateAt.toISOString(),
      broker: {
        id: bigintToNumber(client.broker.id),
        email: client.broker.email,
        first_name: client.broker.firstName,
        last_name: client.broker.lastName,
        phone_number: client.broker.phoneNumber,
        role: client.broker.role,
        rop_id: client.broker.ropId === null ? null : bigintToNumber(client.broker.ropId),
        is_admin: client.broker.role === CrmRole.OWNER || client.broker.role === CrmRole.ADMIN,
      },
      estates: client.estateLinks.map((link) => {
        const assignedUserIds =
          link.estate.assignments.length > 0
            ? link.estate.assignments.map((assignment) => bigintToNumber(assignment.userId))
            : link.estate.userId === null
              ? []
              : [bigintToNumber(link.estate.userId)];
        const primaryImage = link.estate.images[0] ?? null;

        return {
          link_id: bigintToNumber(link.id),
          id: bigintToNumber(link.estate.id),
          title: link.estate.title,
          deal_type: link.estate.dealType,
          price: decimalToNumber(link.estate.price),
          area: decimalToNumber(link.estate.area),
          user_id: assignedUserIds[0] ?? null,
          assigned_user_ids: assignedUserIds,
          status: link.status,
          thumbnail_url: primaryImage?.thumbnailUrl ? this.storageService.resolvePublicUrl(primaryImage.thumbnailUrl) : null,
          image_url: primaryImage ? this.storageService.resolvePublicUrl(primaryImage.thumbnailUrl ?? primaryImage.url) : null,
          public_page_url: link.estate.active && !link.estate.isPrivateSale ? "/detail/" + link.estate.id.toString() : null,
          broker: {
            id: bigintToNumber(client.broker.id),
            email: client.broker.email,
            first_name: client.broker.firstName,
            last_name: client.broker.lastName,
          },
          update_at: link.updateAt.toISOString(),
          created_at: link.createdAt.toISOString(),
        };
      }),
    };

    if (canSeeContacts) {
      item.phone = client.phone;
      item.email = client.email;
    }

    return item;
  }
}
