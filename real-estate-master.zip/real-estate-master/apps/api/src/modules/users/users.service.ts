import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { CrmRole, Prisma, User } from "@prisma/client";
import { hash } from "bcryptjs";
import { AppEnvironment } from "../../config/environment";
import { PrismaService } from "../../prisma/prisma.service";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { canAssignRole, canManageUser, isAdmin, isOwner, isRop, ScopedUserRef } from "../crm-auth/crm-permissions";
import {
  CrmPasswordWritePayload,
  CrmProfileWritePayload,
  CrmUserWritePayload,
  CrmUsersListOptions,
  ParityNotes,
  toCrmUserItem,
} from "./users.types";

const REQUIRED_FIELD_MESSAGE = "Field is required";
const PASSWORD_LEN = 9;
const PASSWORD_TOO_SHORT_MESSAGE = "Пароль должен быть не меньше 9 символов";
const PASSWORD_MISMATCH_MESSAGE = "Пароли не совпадают";
const PASSWORD_CHANGED_MESSAGE = "Пароль успешно изменен";
const DUPLICATE_EMAIL_MESSAGE = "Email is already in use";
const BUFFER_NOT_FOUND_MESSAGE = "Buffer user not found";
const BUFFER_DELETE_FORBIDDEN_MESSAGE = "You can't delete buffer user";
const ADMIN_REQUIRED_MESSAGE = "Admin access required";
const USER_MANAGEMENT_FORBIDDEN_MESSAGE = "User management access denied";
const ROLE_ASSIGN_FORBIDDEN_MESSAGE = "Role assignment is forbidden";
const ROP_REFERENCE_INVALID_MESSAGE = "ROP reference is invalid";

function normalizeText(value: string | null | undefined): string {
  if (value === undefined || value === null) {
    return "";
  }

  return String(value);
}

function parseBoolean(value: boolean | string | null | undefined, fallback: boolean): boolean {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }

  if (typeof value === "boolean") {
    return value;
  }

  return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}

function parseRole(
  roleValue: CrmRole | string | null | undefined,
  legacyIsAdmin: boolean | string | null | undefined,
  fallback: CrmRole,
): CrmRole {
  if (roleValue === undefined || roleValue === null || roleValue === "") {
    if (legacyIsAdmin !== undefined && legacyIsAdmin !== null && legacyIsAdmin !== "") {
      return parseBoolean(legacyIsAdmin, false) ? CrmRole.ADMIN : CrmRole.BROKER;
    }

    return fallback;
  }

  const normalized = String(roleValue).trim().toUpperCase();
  switch (normalized) {
    case CrmRole.OWNER:
      return CrmRole.OWNER;
    case CrmRole.ADMIN:
      return CrmRole.ADMIN;
    case CrmRole.ROP:
      return CrmRole.ROP;
    case CrmRole.BROKER:
      return CrmRole.BROKER;
    case CrmRole.VIEWER:
      return CrmRole.VIEWER;
    default:
      throw new BadRequestException({
        errors: {
          role: "Invalid role",
        },
      });
  }
}

function parseNullableNumber(value: number | string | null | undefined): number | null | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (value === null || value === "") {
    return null;
  }

  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new BadRequestException({
      errors: {
        rop_id: "Invalid rop_id",
      },
    });
  }

  return parsed;
}

function clampLimit(value: number | undefined): number {
  if (!Number.isFinite(value) || !value || value < 1) {
    return 100;
  }

  return Math.min(Math.trunc(value), 100);
}

function clampSkip(value: number | undefined): number {
  if (!Number.isFinite(value) || !value || value < 0) {
    return 0;
  }

  return Math.trunc(value);
}

function buildParity(
  exact: string[] = [],
  approximate: string[] = [],
  intentionallyChanged: string[] = [],
): ParityNotes {
  return {
    exact,
    approximate,
    intentionally_changed: intentionallyChanged,
  };
}

function isUniqueConstraintError(error: unknown): error is Prisma.PrismaClientKnownRequestError {
  return error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002";
}

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly configService: ConfigService<AppEnvironment, true>,
  ) {}

  findByEmail(email: string): Promise<User | null> {
    return this.prisma.user.findUnique({
      where: { email },
    });
  }

  async ensureDefaultAdmin(email: string, password: string): Promise<void> {
    const existingUser = await this.findByEmail(email);
    if (existingUser) {
      return;
    }

    await this.prisma.user.create({
      data: {
        email,
        hashedPassword: await hash(password, 10),
        isAdmin: true,
        role: CrmRole.ADMIN,
        firstName: "Bufer",
        lastName: "Bufer",
        phoneNumber: "-",
      },
    });
  }

  async listForAdmin(
    viewer: AuthenticatedCrmUser,
    options: CrmUsersListOptions,
  ): Promise<{ items: Record<string, unknown>[]; total: number; parity: ParityNotes }> {
    this.assertCanAccessUsers(viewer);

    const search = normalizeText(options.search).trim();
    const baseWhere = search
      ? {
          OR: [
            { email: { contains: search, mode: "insensitive" as const } },
            { firstName: { contains: search, mode: "insensitive" as const } },
            { lastName: { contains: search, mode: "insensitive" as const } },
          ],
        }
      : undefined;

    const where = this.mergeUserWhere(baseWhere, this.buildManagedUsersWhere(viewer));

    const skip = clampSkip(options.skip);
    const take = clampLimit(options.limit);

    const [users, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where,
        orderBy: {
          id: "desc",
        },
        skip,
        take,
      }),
      this.prisma.user.count({ where }),
    ]);

    return {
      items: users.map((user) => toCrmUserItem(user)),
      total,
      parity: buildParity(
        ["Role-scoped access and searchable fields are enforced."],
        ["Response is JSON list data."],
      ),
    };
  }

  async getByIdForAdmin(
    userId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    this.assertCanAccessUsers(viewer);

    const user = await this.getUserByIdOrThrow(userId);
    this.assertCanViewUser(viewer, user);

    return {
      item: toCrmUserItem(user),
      parity: buildParity(
        ["Role-scoped user detail lookup is enforced."],
        ["Response is JSON detail data."],
      ),
    };
  }

  async createForAdmin(
    payload: CrmUserWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    this.assertCanAccessUsers(viewer);

    const validated = await this.validateAdminWritePayload(payload, true, viewer);
    const existing = await this.findByEmail(validated.email);
    if (existing) {
      throw new BadRequestException({
        errors: {
          email: DUPLICATE_EMAIL_MESSAGE,
        },
      });
    }

    try {
      const created = await this.prisma.user.create({
        data: {
          email: validated.email,
          hashedPassword: await hash(validated.password, 10),
          firstName: validated.firstName,
          lastName: validated.lastName,
          phoneNumber: validated.phoneNumber,
          isAdmin: validated.role === CrmRole.OWNER || validated.role === CrmRole.ADMIN,
          role: validated.role,
          ropId: validated.ropId === null ? null : BigInt(validated.ropId),
        },
      });

      return {
        item: toCrmUserItem(created),
        parity: buildParity([
          "Role-based create permissions, bcrypt password hashing, and duplicate-email validation are enforced.",
        ]),
      };
    } catch (error) {
      this.rethrowDuplicateEmailAsFieldError(error);
      throw error;
    }
  }

  async updateForAdmin(
    userId: number,
    payload: CrmUserWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    this.assertCanAccessUsers(viewer);

    const existingUser = await this.getUserByIdOrThrow(userId);
    this.assertCanManageUser(viewer, existingUser);

    const validated = await this.validateAdminWritePayload(payload, false, viewer, existingUser);

    try {
      const updated = await this.prisma.user.update({
        where: {
          id: BigInt(userId),
        },
        data: {
          email: validated.email,
          firstName: validated.firstName,
          lastName: validated.lastName,
          phoneNumber: validated.phoneNumber,
          isAdmin: validated.role === CrmRole.OWNER || validated.role === CrmRole.ADMIN,
          role: validated.role,
          ropId: validated.ropId === null ? null : BigInt(validated.ropId),
        },
      });

      return {
        item: toCrmUserItem(updated),
        parity: buildParity(
          [
            "Role-based edit scope and editable fields are enforced.",
            "Password is intentionally ignored in the regular update flow.",
          ],
          ["Response is JSON edit data."],
          ["Duplicate-email update conflicts are normalized to field errors instead of bubbling as raw DB failures."],
        ),
      };
    } catch (error) {
      this.rethrowDuplicateEmailAsFieldError(error);
      throw error;
    }
  }

  async deleteForAdmin(
    userId: number,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ deleted: true; reassigned_estates: number; parity: ParityNotes }> {
    this.assertCanDeleteUsers(viewer);

    const [targetUser, bufferUser] = await Promise.all([
      this.getUserByIdOrThrow(userId),
      this.getBufferUserOrThrow(),
    ]);

    this.assertCanDeleteTargetUser(viewer, targetUser);

    if (targetUser.id === bufferUser.id) {
      throw new BadRequestException(BUFFER_DELETE_FORBIDDEN_MESSAGE);
    }

    const reassignedEstates = await this.prisma.$transaction(async (transaction) => {
      const affectedAssignments = await transaction.estateAssignment.findMany({
        where: {
          userId: targetUser.id,
        },
        select: {
          estateId: true,
        },
        distinct: ["estateId"],
      });

      await transaction.estateAssignment.deleteMany({
        where: {
          userId: targetUser.id,
        },
      });

      await transaction.estate.updateMany({
        where: {
          userId: targetUser.id,
        },
        data: {
          userId: null,
        },
      });

      await transaction.user.delete({
        where: {
          id: targetUser.id,
        },
      });

      return affectedAssignments.length;
    });

    return {
      deleted: true,
      reassigned_estates: reassignedEstates,
      parity: buildParity([
        "Delete blocks protected user removal, enforces RBAC, clears estate assignments, and removes legacy user_id mirrors before deleting.",
      ]),
    };
  }

  async changePasswordForAdmin(
    userId: number,
    payload: CrmPasswordWritePayload,
    viewer: AuthenticatedCrmUser,
  ): Promise<{ message: string; clear_session: boolean; parity: ParityNotes }> {
    this.assertAdmin(viewer);
    await this.getUserByIdOrThrow(userId);

    const hashedPassword = await this.hashValidatedPassword(payload);
    await this.prisma.user.update({
      where: {
        id: BigInt(userId),
      },
      data: {
        hashedPassword,
      },
    });

    return {
      message: PASSWORD_CHANGED_MESSAGE,
      clear_session: viewer.id === userId,
      parity: buildParity(
        ["Password length, confirmation, bcrypt hashing, and self-session clearing are enforced."],
        ["Response is JSON action data."],
      ),
    };
  }

  async getProfile(
    viewer: AuthenticatedCrmUser,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    const user = await this.getUserByEmailOrThrow(viewer.email);

    return {
      item: toCrmUserItem(user),
      parity: buildParity(
        ["Current-user-only scope is enforced."],
        ["Response is JSON profile data."],
      ),
    };
  }

  async updateProfile(
    viewer: AuthenticatedCrmUser,
    payload: CrmProfileWritePayload,
  ): Promise<{ item: Record<string, unknown>; parity: ParityNotes }> {
    const currentUser = await this.getUserByEmailOrThrow(viewer.email);
    const validated = this.validateProfileWritePayload(payload);

    try {
      const updated = await this.prisma.user.update({
        where: {
          id: currentUser.id,
        },
        data: {
          email: validated.email,
          firstName: validated.firstName,
          lastName: validated.lastName,
          phoneNumber: validated.phoneNumber,
        },
      });

      return {
        item: toCrmUserItem(updated),
        parity: buildParity(
          [
            "Only the current session user is editable.",
            "Session payload is left untouched, so self-email change invalidates the next authenticated request.",
          ],
          ["Response is JSON profile edit data."],
          ["Duplicate-email profile conflicts are normalized to field errors instead of bubbling as raw DB failures."],
        ),
      };
    } catch (error) {
      this.rethrowDuplicateEmailAsFieldError(error);
      throw error;
    }
  }

  async changeOwnPassword(
    viewer: AuthenticatedCrmUser,
    payload: CrmPasswordWritePayload,
  ): Promise<{ message: string; clear_session: true; parity: ParityNotes }> {
    await this.getUserByIdOrThrow(viewer.id);

    const hashedPassword = await this.hashValidatedPassword(payload);
    await this.prisma.user.update({
      where: {
        id: BigInt(viewer.id),
      },
      data: {
        hashedPassword,
      },
    });

    return {
      message: PASSWORD_CHANGED_MESSAGE,
      clear_session: true,
      parity: buildParity(
        ["Self password change clears the current session and enforces the same password rules."],
        ["Response is JSON action data."],
      ),
    };
  }

  private assertCanAccessUsers(viewer: AuthenticatedCrmUser): void {
    if (!isOwner(viewer) && !isAdmin(viewer) && !isRop(viewer)) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }

  private assertAdmin(viewer: AuthenticatedCrmUser): void {
    if (!viewer.is_admin) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }

  private assertCanDeleteUsers(viewer: AuthenticatedCrmUser): void {
    if (!isOwner(viewer) && !isAdmin(viewer)) {
      throw new ForbiddenException(USER_MANAGEMENT_FORBIDDEN_MESSAGE);
    }
  }

  private assertCanViewUser(viewer: AuthenticatedCrmUser, target: User): void {
    if (isOwner(viewer) || isAdmin(viewer)) {
      return;
    }

    if (
      isRop(viewer) &&
      (target.role === CrmRole.BROKER || target.role === CrmRole.VIEWER) &&
      target.ropId !== null &&
      Number(target.ropId) === viewer.id
    ) {
      return;
    }

    throw new ForbiddenException(USER_MANAGEMENT_FORBIDDEN_MESSAGE);
  }

  private assertCanManageUser(viewer: AuthenticatedCrmUser, target: User): void {
    if (!canManageUser(viewer, this.toScopedUser(target))) {
      throw new ForbiddenException(USER_MANAGEMENT_FORBIDDEN_MESSAGE);
    }
  }

  private assertCanDeleteTargetUser(viewer: AuthenticatedCrmUser, target: User): void {
    if (isOwner(viewer)) {
      return;
    }

    if (isAdmin(viewer) && target.role !== CrmRole.OWNER) {
      return;
    }

    throw new ForbiddenException(USER_MANAGEMENT_FORBIDDEN_MESSAGE);
  }

  private async getUserByIdOrThrow(userId: number): Promise<User> {
    const user = await this.prisma.user.findUnique({
      where: {
        id: BigInt(userId),
      },
    });

    if (!user) {
      throw new NotFoundException(`User ${userId} not found`);
    }

    return user;
  }

  private async getUserByEmailOrThrow(email: string): Promise<User> {
    const user = await this.findByEmail(email);
    if (!user) {
      throw new NotFoundException("User not found");
    }

    return user;
  }

  private async getBufferUserOrThrow(): Promise<User> {
    const bufferEmail = this.configService.get("DEFAULT_ADMIN_EMAIL", { infer: true });
    const bufferUser = await this.findByEmail(bufferEmail);
    if (!bufferUser) {
      throw new BadRequestException(BUFFER_NOT_FOUND_MESSAGE);
    }

    return bufferUser;
  }

  private validateAdminWritePayload(
    payload: CrmUserWritePayload,
    isCreate: boolean,
    viewer: AuthenticatedCrmUser,
    existingUser?: User,
  ): Promise<{
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    role: CrmRole;
    ropId: number | null;
  }> {
    return this.validateAdminWritePayloadInternal(payload, isCreate, viewer, existingUser);
  }

  private async validateAdminWritePayloadInternal(
    payload: CrmUserWritePayload,
    isCreate: boolean,
    viewer: AuthenticatedCrmUser,
    existingUser?: User,
  ): Promise<{
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    role: CrmRole;
    ropId: number | null;
  }> {
    const errors: Record<string, string> = {};
    const email = normalizeText(payload.email ?? existingUser?.email);
    const password = normalizeText(payload.password);
    const role = parseRole(payload.role, payload.is_admin, existingUser?.role ?? CrmRole.BROKER);
    const parsedRopId = parseNullableNumber(payload.rop_id);
    const ropId = await this.resolveRopId(viewer, role, parsedRopId, existingUser);

    if (!email) {
      errors.email = REQUIRED_FIELD_MESSAGE;
    }

    if (isCreate && password.length < PASSWORD_LEN) {
      errors.password = PASSWORD_TOO_SHORT_MESSAGE;
    }

    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    if (!canAssignRole(viewer, role)) {
      throw new ForbiddenException(ROLE_ASSIGN_FORBIDDEN_MESSAGE);
    }

    return {
      email,
      password,
      firstName: normalizeText(payload.first_name ?? existingUser?.firstName),
      lastName: normalizeText(payload.last_name ?? existingUser?.lastName),
      phoneNumber: normalizeText(payload.phone_number ?? existingUser?.phoneNumber),
      role,
      ropId,
    };
  }

  private validateProfileWritePayload(payload: CrmProfileWritePayload): {
    email: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
  } {
    const errors: Record<string, string> = {};
    const email = normalizeText(payload.email);
    const firstName = normalizeText(payload.first_name);
    const lastName = normalizeText(payload.last_name);
    const phoneNumber = normalizeText(payload.phone_number);

    if (!email) {
      errors.email = REQUIRED_FIELD_MESSAGE;
    }
    if (!firstName) {
      errors.first_name = REQUIRED_FIELD_MESSAGE;
    }
    if (!lastName) {
      errors.last_name = REQUIRED_FIELD_MESSAGE;
    }
    if (!phoneNumber) {
      errors.phone_number = REQUIRED_FIELD_MESSAGE;
    }

    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    return {
      email,
      firstName,
      lastName,
      phoneNumber,
    };
  }

  private async hashValidatedPassword(payload: CrmPasswordWritePayload): Promise<string> {
    const errors: Record<string, string> = {};
    const password = normalizeText(payload.password);
    const repeatPassword = normalizeText(payload.repeat_password ?? payload["repeat-password"]);

    if (password.length < PASSWORD_LEN) {
      errors.password = PASSWORD_TOO_SHORT_MESSAGE;
    }

    if (password !== repeatPassword) {
      errors.repeat_password = PASSWORD_MISMATCH_MESSAGE;
    }

    if (Object.keys(errors).length > 0) {
      throw new BadRequestException({ errors });
    }

    return hash(password, 10);
  }

  private rethrowDuplicateEmailAsFieldError(error: unknown): void {
    if (isUniqueConstraintError(error)) {
      throw new BadRequestException({
        errors: {
          email: DUPLICATE_EMAIL_MESSAGE,
        },
      });
    }
  }

  private buildManagedUsersWhere(viewer: AuthenticatedCrmUser): Prisma.UserWhereInput | undefined {
    if (isOwner(viewer) || isAdmin(viewer)) {
      return undefined;
    }

    if (isRop(viewer)) {
      return {
        role: {
          in: [CrmRole.BROKER, CrmRole.VIEWER],
        },
        ropId: BigInt(viewer.id),
      };
    }

    throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
  }

  private mergeUserWhere(
    left: Prisma.UserWhereInput | undefined,
    right: Prisma.UserWhereInput | undefined,
  ): Prisma.UserWhereInput | undefined {
    if (left && right) {
      return { AND: [left, right] };
    }

    return left ?? right;
  }

  private toScopedUser(user: User): ScopedUserRef {
    return {
      id: user.id,
      role: user.role,
      ropId: user.ropId,
    };
  }

  private async resolveRopId(
    viewer: AuthenticatedCrmUser,
    role: CrmRole,
    payloadRopId: number | null | undefined,
    existingUser?: User,
  ): Promise<number | null> {
    if (isRop(viewer)) {
      return viewer.id;
    }

    if (role === CrmRole.OWNER || role === CrmRole.ADMIN || role === CrmRole.ROP) {
      return null;
    }

    const nextRopId = payloadRopId === undefined ? (existingUser?.ropId === null || existingUser?.ropId === undefined ? null : Number(existingUser.ropId)) : payloadRopId;

    if (nextRopId === null) {
      return null;
    }

    const ropUser = await this.getUserByIdOrThrow(nextRopId);
    if (ropUser.role !== CrmRole.ROP) {
      throw new BadRequestException({
        errors: {
          rop_id: ROP_REFERENCE_INVALID_MESSAGE,
        },
      });
    }

    return nextRopId;
  }
}
