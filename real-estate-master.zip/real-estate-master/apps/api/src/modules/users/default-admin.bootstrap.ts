import { Injectable, Logger, OnModuleInit } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { UsersService } from "./users.service";

@Injectable()
export class DefaultAdminBootstrap implements OnModuleInit {
  private readonly logger = new Logger(DefaultAdminBootstrap.name);

  constructor(
    private readonly usersService: UsersService,
    private readonly configService: ConfigService,
  ) {}

  async onModuleInit(): Promise<void> {
    const email = this.configService.get<string>("DEFAULT_ADMIN_EMAIL", "admin@gmail.com");
    const password = this.configService.get<string>("DEFAULT_ADMIN_PASSWORD", "123456789");

    await this.usersService.ensureDefaultAdmin(email, password);
    this.logger.log(`Default admin bootstrap ensured for ${email}`);
  }
}
