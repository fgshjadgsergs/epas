import { Module } from "@nestjs/common";
import { DefaultAdminBootstrap } from "./default-admin.bootstrap";
import { UsersService } from "./users.service";

@Module({
  providers: [UsersService, DefaultAdminBootstrap],
  exports: [UsersService],
})
export class UsersModule {}
