import { CrmRole, User } from "@prisma/client";
import { bigintToNumber } from "../../common/utils/number.utils";

export interface CrmUsersListOptions {
  search?: string;
  skip?: number;
  limit?: number;
}

export interface CrmUserWritePayload {
  email?: string;
  password?: string;
  first_name?: string;
  last_name?: string;
  phone_number?: string;
  role?: CrmRole | string | null;
  rop_id?: number | string | null;
  is_admin?: boolean | string | null;
}

export interface CrmProfileWritePayload {
  email?: string;
  first_name?: string;
  last_name?: string;
  phone_number?: string;
}

export interface CrmPasswordWritePayload {
  password?: string;
  repeat_password?: string;
  "repeat-password"?: string;
}

export interface ParityNotes {
  exact: string[];
  approximate: string[];
  intentionally_changed: string[];
}

export function toCrmUserItem(user: User): Record<string, unknown> {
  const role = user.role;

  return {
    id: bigintToNumber(user.id),
    email: user.email,
    first_name: user.firstName,
    last_name: user.lastName,
    phone_number: user.phoneNumber,
    role,
    rop_id: user.ropId === null ? null : bigintToNumber(user.ropId),
    is_admin: role === CrmRole.OWNER || role === CrmRole.ADMIN,
    created_at: user.createdAt.toISOString(),
    update_at: user.updateAt.toISOString(),
  };
}
