import { Controller, ForbiddenException, Get, Param, ParseIntPipe, Post, Res, UseGuards } from "@nestjs/common";
import { Response } from "express";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { AvitoFeedService } from "./avito-feed.service";

const ADMIN_REQUIRED_MESSAGE = "Admin access required";

@Controller()
export class AvitoFeedController {
  constructor(private readonly avitoFeedService: AvitoFeedService) {}

  @Get("api/v1/avito/feed.xml")
  async getFeed(@Res() response: Response): Promise<void> {
    const xml = await this.avitoFeedService.generateXml();
    response
      .status(200)
      .type("application/xml; charset=utf-8")
      .send(xml);
  }

  @UseGuards(CrmAuthGuard)
  @Get("api/v1/crm/avito/feed/diagnostics")
  getDiagnostics(@CurrentCrmUser() user: AuthenticatedCrmUser) {
    this.assertAdmin(user);
    return this.avitoFeedService.getDiagnostics();
  }

  @UseGuards(CrmAuthGuard)
  @Get("api/v1/crm/avito/feed/items")
  getFeedItems(@CurrentCrmUser() user: AuthenticatedCrmUser) {
    this.assertAdmin(user);
    return this.avitoFeedService.listFeedItems();
  }

  @UseGuards(CrmAuthGuard)
  @Post("api/v1/crm/estates/:estateId/avito/remove-from-feed")
  removeFromFeed(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ) {
    this.assertAdmin(user);
    return this.avitoFeedService.removeFromFeed(estateId);
  }

  @UseGuards(CrmAuthGuard)
  @Post("api/v1/crm/estates/:estateId/avito/restore-to-feed")
  restoreToFeed(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ) {
    this.assertAdmin(user);
    return this.avitoFeedService.restoreToFeed(estateId);
  }

  private assertAdmin(user: AuthenticatedCrmUser): void {
    if (!user.is_admin) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }
}
