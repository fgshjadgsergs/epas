import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { AvitoModerationStatus, AvitoPublicationStatus, CrmRole, Prisma, User } from "@prisma/client";
import { bigintToNumber, decimalToNumber } from "../../common/utils/number.utils";
import { PrismaService } from "../../prisma/prisma.service";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import {
  canEditEstate,
  canViewEstate,
  isAdmin,
  isBroker,
  isOwner,
  isRop,
  isViewer,
  ScopedUserRef,
} from "../crm-auth/crm-permissions";
import { StorageService } from "../storage/storage.service";
import {
  AVITO_TITLE_MAX_LENGTH,
  AvitoFeedSettingsPayload,
  normalizeAvitoTitle,
  resolveAvitoFeedData,
  toAvitoFeedJson,
} from "./avito-feed-data";
import { AvitoValidationService } from "./avito-validation.service";
import {
  AVITO_ESTATE_INCLUDE,
  AvitoModerationQuery,
  AvitoValidationResult,
  EstateWithAvitoRelations,
} from "./avito.types";

const FORBIDDEN_MESSAGE = "You can manage only permitted estates";
const MODERATION_FORBIDDEN_MESSAGE = "Only OWNER, ADMIN or team ROP can moderate Avito review";
const MAX_MODERATION_LIST_LIMIT = 100;

function parsePositiveInteger(value: string | undefined, fallback: number, max: number): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) {
    return fallback;
  }

  return Math.min(parsed, max);
}

function parseSkip(value: string | undefined): number {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : 0;
}

function parseModerationStatus(value: AvitoModerationStatus | string | undefined): AvitoModerationStatus {
  if (!value) {
    return AvitoModerationStatus.PENDING_REVIEW;
  }

  if (Object.values(AvitoModerationStatus).includes(value as AvitoModerationStatus)) {
    return value as AvitoModerationStatus;
  }

  throw new BadRequestException("Invalid Avito moderation status");
}

function jsonErrors(validation: AvitoValidationResult): Prisma.InputJsonValue | typeof Prisma.JsonNull {
  return validation.ok ? Prisma.JsonNull : JSON.parse(JSON.stringify(validation.errors));
}

@Injectable()
export class AvitoModerationService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly storageService: StorageService,
    private readonly avitoValidationService: AvitoValidationService,
  ) {}

  async listModerationQueue(
    viewer: AuthenticatedCrmUser,
    query: AvitoModerationQuery,
  ): Promise<{ items: Record<string, unknown>[]; total: number; skip: number; limit: number; filters: Record<string, unknown> }> {
    if (isViewer(viewer) || isBroker(viewer)) {
      throw new ForbiddenException(MODERATION_FORBIDDEN_MESSAGE);
    }

    const status = parseModerationStatus(query.status);
    const skip = parseSkip(query.skip);
    const limit = parsePositiveInteger(query.limit, 50, MAX_MODERATION_LIST_LIMIT);
    const where: Prisma.EstateWhereInput = {
      ...this.buildModerationScopeWhere(viewer),
      avitoModerationStatus: status,
    };

    const [estates, total] = await this.prisma.$transaction([
      this.prisma.estate.findMany({
        where,
        include: AVITO_ESTATE_INCLUDE,
        orderBy: {
          avitoReviewRequestedAt: "desc",
        },
        skip,
        take: limit,
      }),
      this.prisma.estate.count({ where }),
    ]);

    return {
      items: estates.map((estate) => this.toModerationListItem(estate)),
      total,
      skip,
      limit,
      filters: {
        status,
      },
    };
  }

  async validateEstate(estateId: number, viewer: AuthenticatedCrmUser): Promise<AvitoValidationResult> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer);
    if (!canEditEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      throw new ForbiddenException(FORBIDDEN_MESSAGE);
    }

    return this.avitoValidationService.validateEstate(estate);
  }

  async updateFeedSettings(
    estateId: number,
    viewer: AuthenticatedCrmUser,
    payload: AvitoFeedSettingsPayload,
  ): Promise<Record<string, unknown>> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer);
    if (!canEditEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      throw new ForbiddenException(FORBIDDEN_MESSAGE);
    }
    if (payload.avitoTitle !== undefined && payload.avitoTitle !== null && typeof payload.avitoTitle !== "string") {
      throw new BadRequestException({
        message: "Название объявления Авито должно быть строкой",
        errors: { avitoTitle: "Название объявления Авито должно быть строкой" },
      });
    }

    const hasAvitoTitle = Object.prototype.hasOwnProperty.call(payload, "avitoTitle");
    const avitoTitle = hasAvitoTitle ? normalizeAvitoTitle(payload.avitoTitle) : estate.avitoTitle;
    if (hasAvitoTitle && avitoTitle && avitoTitle.length > AVITO_TITLE_MAX_LENGTH) {
      const message = `Название объявления Авито должно быть не длиннее ${AVITO_TITLE_MAX_LENGTH} символов`;
      throw new BadRequestException({
        message,
        errors: { avitoTitle: message },
      });
    }

    const now = new Date();
    const result = await this.prisma.$transaction(async (transaction) => {
      const next = await transaction.estate.update({
        where: { id: estate.id },
        data: {
          ...(hasAvitoTitle ? { avitoTitle } : {}),
          avitoFeedData: toAvitoFeedJson(payload),
        },
        include: AVITO_ESTATE_INCLUDE,
      });
      const validation = this.avitoValidationService.validateEstate(next);
      const updated = await transaction.estate.update({
        where: { id: estate.id },
        data: {
          avitoLastValidatedAt: now,
          avitoLastError: jsonErrors(validation),
          ...(estate.avitoModerationStatus === AvitoModerationStatus.APPROVED && !validation.ok
            ? { avitoIncluded: false, avitoStatus: AvitoPublicationStatus.NOT_INCLUDED }
            : {}),
        },
        include: AVITO_ESTATE_INCLUDE,
      });

      return { updated, validation };
    });

    return {
      item: this.toModerationListItem(result.updated),
      validation: result.validation,
    };
  }

  async submitReview(estateId: number, viewer: AuthenticatedCrmUser): Promise<Record<string, unknown>> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer);
    if (!canEditEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      throw new ForbiddenException(FORBIDDEN_MESSAGE);
    }
    if (
      estate.avitoModerationStatus !== AvitoModerationStatus.DRAFT &&
      estate.avitoModerationStatus !== AvitoModerationStatus.CHANGES_REQUESTED
    ) {
      throw new BadRequestException("Only DRAFT or CHANGES_REQUESTED estate can be submitted for Avito review");
    }

    const updated = await this.prisma.$transaction(async (transaction) => {
      const next = await transaction.estate.update({
        where: { id: estate.id },
        data: {
          avitoModerationStatus: AvitoModerationStatus.PENDING_REVIEW,
          avitoReviewRequestedAt: new Date(),
          avitoReviewComment: null,
        },
        include: AVITO_ESTATE_INCLUDE,
      });
      await transaction.avitoModerationEvent.create({
        data: {
          estateId: estate.id,
          actorId: BigInt(viewer.id),
          fromStatus: estate.avitoModerationStatus,
          toStatus: AvitoModerationStatus.PENDING_REVIEW,
        },
      });
      return next;
    });

    return { item: this.toModerationListItem(updated) };
  }

  async requestChanges(estateId: number, viewer: AuthenticatedCrmUser, comment: string): Promise<Record<string, unknown>> {
    const normalizedComment = comment.trim();
    if (!normalizedComment) {
      throw new BadRequestException("Comment is required");
    }

    const estate = await this.getVisibleEstateOrThrow(estateId, viewer);
    this.assertCanModerate(viewer, estate);
    if (estate.avitoModerationStatus !== AvitoModerationStatus.PENDING_REVIEW) {
      throw new BadRequestException("Only PENDING_REVIEW estate can be returned for changes");
    }

    const updated = await this.prisma.$transaction(async (transaction) => {
      const next = await transaction.estate.update({
        where: { id: estate.id },
        data: {
          avitoModerationStatus: AvitoModerationStatus.CHANGES_REQUESTED,
          avitoReviewComment: normalizedComment,
          avitoIncluded: false,
          avitoStatus: AvitoPublicationStatus.NOT_INCLUDED,
        },
        include: AVITO_ESTATE_INCLUDE,
      });
      await transaction.avitoModerationEvent.create({
        data: {
          estateId: estate.id,
          actorId: BigInt(viewer.id),
          fromStatus: estate.avitoModerationStatus,
          toStatus: AvitoModerationStatus.CHANGES_REQUESTED,
          comment: normalizedComment,
        },
      });
      return next;
    });

    return { item: this.toModerationListItem(updated) };
  }

  async approve(estateId: number, viewer: AuthenticatedCrmUser): Promise<Record<string, unknown>> {
    const estate = await this.getVisibleEstateOrThrow(estateId, viewer);
    this.assertCanModerate(viewer, estate);
    if (estate.avitoModerationStatus !== AvitoModerationStatus.PENDING_REVIEW) {
      throw new BadRequestException("Only PENDING_REVIEW estate can be approved");
    }

    const validation = this.avitoValidationService.validateEstate(estate);
    const now = new Date();
    const updated = await this.prisma.$transaction(async (transaction) => {
      const next = await transaction.estate.update({
        where: { id: estate.id },
        data: {
          avitoModerationStatus: AvitoModerationStatus.APPROVED,
          avitoApprovedAt: now,
          avitoApprovedById: BigInt(viewer.id),
          avitoLastValidatedAt: now,
          avitoIncluded: validation.ok,
          avitoStatus: validation.ok ? AvitoPublicationStatus.READY : AvitoPublicationStatus.NOT_INCLUDED,
          avitoExternalId: validation.ok ? String(bigintToNumber(estate.id)) : estate.avitoExternalId,
          avitoLastError: jsonErrors(validation),
        },
        include: AVITO_ESTATE_INCLUDE,
      });
      await transaction.avitoModerationEvent.create({
        data: {
          estateId: estate.id,
          actorId: BigInt(viewer.id),
          fromStatus: estate.avitoModerationStatus,
          toStatus: AvitoModerationStatus.APPROVED,
        },
      });
      return next;
    });

    return {
      item: this.toModerationListItem(updated),
      validation,
    };
  }

  private async getVisibleEstateOrThrow(estateId: number, viewer: AuthenticatedCrmUser): Promise<EstateWithAvitoRelations> {
    if (isViewer(viewer)) {
      throw new ForbiddenException(FORBIDDEN_MESSAGE);
    }

    const estate = await this.prisma.estate.findFirst({
      where: {
        id: BigInt(estateId),
      },
      include: AVITO_ESTATE_INCLUDE,
    });
    if (!estate) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    if (!canViewEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    return estate;
  }

  private assertCanModerate(viewer: AuthenticatedCrmUser, estate: EstateWithAvitoRelations): void {
    if (isOwner(viewer) || isAdmin(viewer)) {
      return;
    }

    if (isRop(viewer) && canEditEstate(viewer, this.toScopedEstate(estate), this.toFallbackScopedUser(estate))) {
      return;
    }

    throw new ForbiddenException(MODERATION_FORBIDDEN_MESSAGE);
  }

  private buildModerationScopeWhere(viewer: AuthenticatedCrmUser): Prisma.EstateWhereInput {
    if (isOwner(viewer) || isAdmin(viewer)) {
      return {};
    }

    if (isRop(viewer)) {
      return {
        assignments: {
          some: {
            user: {
              role: CrmRole.BROKER,
              ropId: BigInt(viewer.id),
            },
          },
        },
      };
    }

    throw new ForbiddenException(MODERATION_FORBIDDEN_MESSAGE);
  }

  private toModerationListItem(estate: EstateWithAvitoRelations): Record<string, unknown> {
    const mainImage = [...estate.images].sort(
      (left, right) =>
        Number(right.isMain) - Number(left.isMain) || Number(left.id > right.id) - Number(left.id < right.id),
    )[0] ?? null;
    const broker = estate.assignments[0]?.user ?? estate.user ?? null;

    return {
      id: bigintToNumber(estate.id),
      title: estate.title,
      address: estate.title,
      deal_type: estate.dealType,
      estate_type: estate.estateType,
      price: decimalToNumber(estate.price),
      area: decimalToNumber(estate.area),
      active: estate.active,
      deleted_at: estate.deletedAt?.toISOString() ?? null,
      is_private_sale: estate.isPrivateSale,
      broker: broker ? this.serializeUser(broker) : null,
      avito: {
        moderation_status: estate.avitoModerationStatus,
        publication_status: estate.avitoStatus,
        included: estate.avitoIncluded,
        avito_id: estate.avitoId === null ? null : bigintToNumber(estate.avitoId),
        external_id: estate.avitoExternalId,
        avitoTitle: estate.avitoTitle,
        last_error: estate.avitoLastError,
        last_validated_at: estate.avitoLastValidatedAt?.toISOString() ?? null,
        last_synced_at: estate.avitoLastSyncedAt?.toISOString() ?? null,
        review_comment: estate.avitoReviewComment,
        review_requested_at: estate.avitoReviewRequestedAt?.toISOString() ?? null,
        approved_at: estate.avitoApprovedAt?.toISOString() ?? null,
        approved_by_id: estate.avitoApprovedById === null ? null : bigintToNumber(estate.avitoApprovedById),
        feed_data: resolveAvitoFeedData(estate),
      },
      main_image: mainImage
        ? {
            id: bigintToNumber(mainImage.id),
            url: mainImage.url,
            thumbnail_url: mainImage.thumbnailUrl ? this.storageService.resolvePublicUrl(mainImage.thumbnailUrl) : null,
            public_url: this.storageService.resolvePublicUrl(mainImage.url),
          }
        : null,
    };
  }

  private serializeUser(user: User): Record<string, unknown> {
    return {
      id: bigintToNumber(user.id),
      email: user.email,
      first_name: user.firstName,
      last_name: user.lastName,
      phone_number: user.phoneNumber,
      role: user.role,
      rop_id: user.ropId === null ? null : bigintToNumber(user.ropId),
    };
  }

  private toScopedEstate(estate: EstateWithAvitoRelations) {
    return {
      id: estate.id,
      userId: estate.userId,
      deletedAt: estate.deletedAt,
      assignedUserIds: estate.assignments.map((assignment) => assignment.userId),
      assignedUsers: estate.assignments.map((assignment) => this.toScopedUser(assignment.user)),
    };
  }

  private toScopedUser(user: User): ScopedUserRef {
    return {
      id: user.id,
      role: user.role,
      ropId: user.ropId,
    };
  }

  private toFallbackScopedUser(estate: EstateWithAvitoRelations): ScopedUserRef {
    const fallbackUser = estate.assignments[0]?.user ?? estate.user;
    if (fallbackUser) {
      return this.toScopedUser(fallbackUser);
    }

    return {
      id: BigInt(0),
      role: CrmRole.VIEWER,
      ropId: null,
    };
  }
}
