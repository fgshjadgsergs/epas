import { Prisma } from "@prisma/client";
import { AVITO_ESTATE_INCLUDE } from "./avito.types";

export type AvitoFeedEstate = Prisma.EstateGetPayload<{
  include: typeof AVITO_ESTATE_INCLUDE;
}>;

export interface AvitoFeedIssue {
  code: string;
  field?: string;
  message: string;
  severity: "error" | "warning";
}

export interface AvitoFeedItem {
  id: string;
  category: string;
  operationType: string;
  objectType: string;
  title: string;
  description: string;
  price: number;
  address: string;
  propertyRights: string;
  officeType?: string;
  entrance?: string;
  floor?: number;
  layout?: string[];
  area: number;
  ceilingHeight?: number;
  decoration: string;
  powerGridCapacity?: number;
  buildingType: string;
  parkingType: string;
  rentalType?: string;
  transactionType?: string;
  latitude?: number;
  longitude?: number;
  images: string[];
  contactPhone: string;
  managerName?: string;
  companyName?: string;
}

export interface AvitoFeedDiagnosticsItem {
  estateId: string;
  externalId?: string;
  included: boolean;
  reasons: AvitoFeedIssue[];
}

export interface AvitoFeedDiagnostics {
  generatedAt: string;
  totalFound: number;
  included: number;
  skipped: number;
  feedUrl?: string;
  items: AvitoFeedDiagnosticsItem[];
  reasonSummary: Record<string, number>;
}

export interface AvitoFeedListItem {
  id: number;
  title: string;
  deal_type: string | null;
  estate_type: string | null;
  price: number | null;
  area: number | null;
  broker: {
    id: number;
    email: string;
    first_name: string;
    last_name: string;
    phone_number: string;
    role: string;
    rop_id: number | null;
  } | null;
  avito: {
    moderation_status: string;
    publication_status: string;
    included: boolean;
    external_id: string | null;
    last_error: unknown;
    last_validated_at: string | null;
    last_synced_at: string | null;
    approved_at: string | null;
  };
  main_image: {
    id: number;
    url: string;
    public_url: string;
  } | null;
  reasons: AvitoFeedIssue[];
}
