import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { StorageModule } from "../storage/storage.module";
import { AvitoApiClient } from "./avito-api.client";
import { AvitoAuthService } from "./avito-auth.service";
import { AvitoDiagnosticsController } from "./avito-diagnostics.controller";
import { AvitoDiagnosticsService } from "./avito-diagnostics.service";
import { AvitoFeedController } from "./avito-feed.controller";
import { AvitoFeedService } from "./avito-feed.service";
import { AvitoModerationController } from "./avito-moderation.controller";
import { AvitoModerationService } from "./avito-moderation.service";
import { AvitoValidationService } from "./avito-validation.service";
import { AvitoXmlService } from "./avito-xml.service";

@Module({
  imports: [CrmAuthModule, StorageModule],
  controllers: [AvitoDiagnosticsController, AvitoFeedController, AvitoModerationController],
  providers: [
    AvitoAuthService,
    AvitoApiClient,
    AvitoDiagnosticsService,
    AvitoXmlService,
    AvitoFeedService,
    AvitoValidationService,
    AvitoModerationService,
  ],
  exports: [AvitoAuthService, AvitoApiClient, AvitoValidationService],
})
export class AvitoModule {}
