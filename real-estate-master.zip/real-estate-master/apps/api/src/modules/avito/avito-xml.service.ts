import { Injectable } from "@nestjs/common";
import { AvitoFeedItem } from "./avito-feed.types";

function escapeXml(value: string | number): string {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function hasValue(value: string | number | null | undefined): value is string | number {
  return value !== null && value !== undefined && String(value).trim() !== "";
}

function tag(name: string, value: string | number | null | undefined): string {
  return hasValue(value) ? `    <${name}>${escapeXml(value)}</${name}>` : "";
}

@Injectable()
export class AvitoXmlService {
  render(items: AvitoFeedItem[]): string {
    const ads = items.map((item) => this.renderAd(item)).join("\n");

    return [
      '<?xml version="1.0" encoding="UTF-8"?>',
      '<Ads formatVersion="3" target="Avito.ru">',
      ads,
      "</Ads>",
      "",
    ].join("\n");
  }

  private renderAd(item: AvitoFeedItem): string {
    const lines = [
      "  <Ad>",
      tag("Id", item.id),
      tag("Category", item.category),
      tag("OperationType", item.operationType),
      tag("ObjectType", item.objectType),
      tag("Address", item.address),
      tag("Title", item.title),
      tag("Description", item.description),
      tag("Price", item.price),
      tag("OfficeType", item.officeType),
      tag("PropertyRights", item.propertyRights),
      tag("Entrance", item.entrance),
      tag("Floor", item.floor),
      this.renderOptions("Layout", item.layout),
      tag("Square", item.area),
      tag("CeilingHeight", item.ceilingHeight),
      tag("Decoration", item.decoration),
      tag("PowerGridCapacity", item.powerGridCapacity),
      tag("BuildingType", item.buildingType),
      tag("ParkingType", item.parkingType),
      tag("RentalType", item.rentalType),
      tag("TransactionType", item.transactionType),
      tag("Latitude", item.latitude),
      tag("Longitude", item.longitude),
      tag("ContactPhone", item.contactPhone),
      tag("ManagerName", item.managerName),
      tag("CompanyName", item.companyName),
      this.renderImages(item.images),
      "  </Ad>",
    ].filter(Boolean);

    return lines.join("\n");
  }

  private renderOptions(name: string, values: string[] | undefined): string {
    if (!values?.length) {
      return "";
    }

    const options = values.map((value) => `      <Option>${escapeXml(value)}</Option>`).join("\n");
    return [`    <${name}>`, options, `    </${name}>`].join("\n");
  }

  private renderImages(images: string[]): string {
    if (images.length === 0) {
      return "";
    }

    const imageTags = images.map((url) => `      <Image url="${escapeXml(url)}" />`).join("\n");
    return ["    <Images>", imageTags, "    </Images>"].join("\n");
  }
}
