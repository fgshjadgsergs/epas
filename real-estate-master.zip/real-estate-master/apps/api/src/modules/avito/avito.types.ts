import { AvitoModerationStatus, Prisma } from "@prisma/client";

export const AVITO_ESTATE_INCLUDE = {
  images: true,
  user: true,
  assignments: {
    include: {
      user: true,
    },
    orderBy: {
      createdAt: "asc" as const,
    },
  },
} as const;

export type EstateWithAvitoRelations = Prisma.EstateGetPayload<{
  include: typeof AVITO_ESTATE_INCLUDE;
}>;

export interface AvitoValidationError {
  code: string;
  field: string;
  message: string;
  severity: "error" | "warning";
}

export interface AvitoValidationResult {
  ok: boolean;
  errors: AvitoValidationError[];
}

export interface AvitoModerationQuery {
  status?: AvitoModerationStatus | string;
  skip?: string;
  limit?: string;
}

export interface AvitoRequestChangesPayload {
  comment?: string | null;
}
