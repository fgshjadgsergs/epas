export class AvitoConfigurationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AvitoConfigurationError";
  }
}

export class AvitoApiError extends Error {
  constructor(
    message: string,
    readonly status: number | null,
    readonly body?: unknown,
  ) {
    super(message);
    this.name = "AvitoApiError";
  }
}
