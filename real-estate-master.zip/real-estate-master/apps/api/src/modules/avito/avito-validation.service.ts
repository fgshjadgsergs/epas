import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { decimalToNumber } from "../../common/utils/number.utils";
import { AppEnvironment } from "../../config/environment";
import {
  AVITO_BUILDING_TYPES,
  AVITO_DECORATIONS,
  AVITO_ENTRANCES,
  AVITO_LAYOUTS,
  AVITO_OBJECT_TYPES,
  AVITO_OFFICE_TYPES,
  AVITO_OPERATION_RENT,
  AVITO_OPERATION_SELL,
  AVITO_PARKING_TYPES,
  AVITO_PROPERTY_RIGHTS,
  AVITO_RENTAL_TYPES,
  AVITO_TRANSACTION_TYPES,
  getAvitoOperationType,
  isAllowedValue,
  resolveAvitoFeedData,
} from "./avito-feed-data";
import { AvitoValidationError, AvitoValidationResult, EstateWithAvitoRelations } from "./avito.types";

function hasText(value: string | null | undefined): boolean {
  return typeof value === "string" && value.trim().length > 0;
}

function isPositiveDecimal(value: unknown): boolean {
  const parsed = decimalToNumber(value as Parameters<typeof decimalToNumber>[0]);
  return parsed !== null && parsed > 0;
}

function getBrokerPhone(estate: EstateWithAvitoRelations): string | null {
  const assignedUser = estate.assignments.find((assignment) => hasText(assignment.user.phoneNumber))?.user;
  return assignedUser?.phoneNumber || estate.user?.phoneNumber || null;
}

function addChoiceError(
  errors: AvitoValidationError[],
  value: string | undefined,
  allowed: readonly string[],
  code: string,
  field: string,
  message: string,
): void {
  if (!isAllowedValue(value, allowed)) {
    errors.push({ code, field, message, severity: "error" });
  }
}

@Injectable()
export class AvitoValidationService {
  constructor(private readonly configService: ConfigService<AppEnvironment>) {}

  validateEstate(estate: EstateWithAvitoRelations): AvitoValidationResult {
    const errors: AvitoValidationError[] = [];
    const feedData = resolveAvitoFeedData(estate);
    const operationType = getAvitoOperationType(estate.dealType);
    const objectType = feedData.object_type;
    const effectiveTitle = estate.avitoTitle?.trim() || estate.title?.trim();

    if (!estate.active) {
      errors.push({ code: "inactive_estate", field: "active", message: "Объект должен быть активен", severity: "error" });
    }
    if (estate.deletedAt) {
      errors.push({ code: "archived_estate", field: "deletedAt", message: "Архивный объект нельзя выгружать в Авито", severity: "error" });
    }
    if (estate.isPrivateSale) {
      errors.push({ code: "private_sale", field: "isPrivateSale", message: "Приватный объект нельзя выгружать в Авито", severity: "error" });
    }
    if (!operationType) {
      errors.push({ code: "unsupported_deal_type", field: "dealType", message: "Авито поддерживает только аренду или продажу", severity: "error" });
    }
    addChoiceError(
      errors,
      objectType,
      AVITO_OBJECT_TYPES,
      "unsupported_estate_type",
      "avito.object_type",
      "Выберите поддерживаемый вид коммерческого объекта Авито",
    );
    addChoiceError(
      errors,
      feedData.property_rights,
      AVITO_PROPERTY_RIGHTS,
      "missing_property_rights",
      "avito.property_rights",
      "Укажите право собственности: собственник или посредник",
    );
    if (!isPositiveDecimal(estate.price)) {
      errors.push({ code: "missing_price", field: "price", message: "Укажите цену больше 0", severity: "error" });
    }
    const area = decimalToNumber(estate.area);
    if (area === null || area < 5 || area > 100000) {
      errors.push({ code: "invalid_area", field: "area", message: "Площадь для Авито должна быть от 5 до 100 000 м²", severity: "error" });
    }
    if (!effectiveTitle) {
      errors.push({ code: "missing_title", field: "avitoTitle", message: "Не указано название объявления Авито", severity: "error" });
    }
    if (!hasText(estate.title)) {
      errors.push({ code: "missing_address", field: "title", message: "Укажите адрес объекта", severity: "error" });
    }
    if (!hasText(estate.description)) {
      errors.push({ code: "missing_description", field: "description", message: "Добавьте описание объекта", severity: "error" });
    }
    if (estate.images.length === 0 || !estate.images.some((image) => hasText(image.url))) {
      errors.push({ code: "missing_images", field: "images", message: "Добавьте минимум одно фото", severity: "error" });
    }
    const contactPhone = this.configService.get("AVITO_DEFAULT_PHONE", { infer: true }) || getBrokerPhone(estate);
    if (!hasText(contactPhone)) {
      errors.push({ code: "missing_contact_phone", field: "avito.contactPhone", message: "Укажите AVITO_DEFAULT_PHONE или телефон брокера", severity: "error" });
    }

    if (objectType && isAllowedValue(objectType, AVITO_OBJECT_TYPES)) {
      const isOffice = objectType === AVITO_OBJECT_TYPES[0];
      const isBuilding = objectType === AVITO_OBJECT_TYPES[8];

      if (!isBuilding && estate.floor === null) {
        errors.push({ code: "missing_floor", field: "floor", message: "Укажите этаж объекта", severity: "error" });
      }

      if (isOffice) {
        if (operationType === AVITO_OPERATION_RENT) {
          addChoiceError(errors, feedData.office_type, AVITO_OFFICE_TYPES, "missing_office_type", "avito.office_type", "Укажите, что сдаётся: помещение под офис или юридический адрес");
        }
        if (!feedData.layout?.length || feedData.layout.some((value) => !AVITO_LAYOUTS.includes(value as (typeof AVITO_LAYOUTS)[number]))) {
          errors.push({ code: "missing_layout", field: "avito.layout", message: "Выберите планировку офиса", severity: "error" });
        }
      } else {
        addChoiceError(errors, feedData.entrance, AVITO_ENTRANCES, "missing_entrance", "avito.entrance", "Укажите вход в помещение");
      }

      addChoiceError(errors, feedData.decoration, AVITO_DECORATIONS, "missing_decoration", "avito.decoration", "Укажите отделку помещения");
      addChoiceError(errors, feedData.building_type, AVITO_BUILDING_TYPES, "missing_building_type", "avito.building_type", "Укажите тип здания");
      addChoiceError(errors, feedData.parking_type, AVITO_PARKING_TYPES, "missing_parking_type", "avito.parking_type", "Укажите тип парковки");
    }

    if (operationType === AVITO_OPERATION_RENT) {
      addChoiceError(errors, feedData.rental_type, AVITO_RENTAL_TYPES, "missing_rental_type", "avito.rental_type", "Укажите тип аренды");
    }
    if (operationType === AVITO_OPERATION_SELL) {
      addChoiceError(errors, feedData.transaction_type, AVITO_TRANSACTION_TYPES, "missing_transaction_type", "avito.transaction_type", "Укажите тип сделки продажи");
    }

    if (!hasText(estate.coordinates)) {
      errors.push({ code: "missing_coordinates", field: "coordinates", message: "Желательно указать координаты", severity: "warning" });
    }
    if (estate.images.length > 0 && estate.images.length < 3) {
      errors.push({ code: "few_images", field: "images", message: "Желательно добавить больше фотографий", severity: "warning" });
    }
    if (!estate.images.some((image) => image.isPlan)) {
      errors.push({ code: "missing_plan_image", field: "images", message: "Желательно отметить фото планировки", severity: "warning" });
    }
    if (hasText(estate.description) && estate.description.trim().length < 100) {
      errors.push({ code: "short_description", field: "description", message: "Описание выглядит коротким", severity: "warning" });
    }

    return {
      ok: errors.every((error) => error.severity !== "error"),
      errors,
    };
  }
}

