import { Injectable } from "@nestjs/common";
import { AvitoApiClient } from "./avito-api.client";
import { AvitoAuthService } from "./avito-auth.service";

@Injectable()
export class AvitoDiagnosticsService {
  constructor(
    private readonly avitoAuthService: AvitoAuthService,
    private readonly avitoApiClient: AvitoApiClient,
  ) {}

  async checkAuth(): Promise<{ ok: true; status: "configured"; expiresIn: number }> {
    const token = await this.avitoAuthService.getAccessToken();
    return this.avitoAuthService.getDiagnostics(token);
  }

  getProfile(): Promise<unknown> {
    return this.avitoApiClient.get("/autoload/v2/profile");
  }

  getCategoryTree(): Promise<unknown> {
    return this.avitoApiClient.get("/autoload/v1/user-docs/tree");
  }

  getNodeFields(nodeSlug: string): Promise<unknown> {
    return this.avitoApiClient.get(`/autoload/v1/user-docs/node/${encodeURIComponent(nodeSlug)}/fields`);
  }
}
