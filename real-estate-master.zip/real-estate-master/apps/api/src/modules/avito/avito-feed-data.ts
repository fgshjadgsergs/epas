﻿import { Prisma } from "@prisma/client";

export const AVITO_CATEGORY_COMMERCIAL = "Коммерческая недвижимость";
export const AVITO_OPERATION_RENT = "Сдам";
export const AVITO_OPERATION_SELL = "Продам";

// TODO: confirm the exact Title limit against the official live Avito category schema.
export const AVITO_TITLE_MAX_LENGTH = 100;

export const AVITO_OBJECT_TYPES = [
  "Офисное помещение",
  "Помещение свободного назначения",
  "Торговое помещение",
  "Складское помещение",
  "Производственное помещение",
  "Помещение общественного питания",
  "Гостиница",
  "Автосервис",
  "Здание",
] as const;

export const AVITO_PROPERTY_RIGHTS = ["Собственник", "Посредник"] as const;
export const AVITO_OFFICE_TYPES = [
  "Помещение под офис",
  "Только юридический адрес",
] as const;
export const AVITO_ENTRANCES = ["С улицы", "Со двора"] as const;
export const AVITO_LAYOUTS = ["Кабинетная", "Открытая"] as const;
export const AVITO_DECORATIONS = [
  "Без отделки",
  "Чистовая",
  "Офисная",
] as const;
export const AVITO_BUILDING_TYPES = [
  "Бизнес-центр",
  "Торговый центр",
  "Административное здание",
  "Жилой дом",
  "Другой",
] as const;
export const AVITO_PARKING_TYPES = ["Нет", "На улице", "В здании"] as const;
export const AVITO_RENTAL_TYPES = ["Прямая", "Субаренда"] as const;
export const AVITO_TRANSACTION_TYPES = [
  "Продажа",
  "Переуступка права аренды",
] as const;

export type AvitoObjectType = (typeof AVITO_OBJECT_TYPES)[number];

export interface AvitoFeedData {
  object_type?: string;
  property_rights?: string;
  office_type?: string;
  entrance?: string;
  layout?: string[];
  decoration?: string;
  building_type?: string;
  parking_type?: string;
  rental_type?: string;
  transaction_type?: string;
}

export interface AvitoFeedSettingsPayload extends AvitoFeedData {
  avitoTitle?: string | null;
}

export function normalizeAvitoTitle(value: unknown): string | null {
  const normalized = typeof value === "string" ? value.trim() : "";
  return normalized || null;
}

type EstateFeedSource = {
  estateType: string | null;
  ownerType: string | null;
  avitoFeedData: Prisma.JsonValue | null;
};

function text(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

export function parseAvitoFeedData(value: unknown): AvitoFeedData {
  const source =
    value && typeof value === "object" && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : {};
  const layout = Array.isArray(source.layout)
    ? source.layout.map(text).filter((item): item is string => Boolean(item))
    : [];

  return {
    ...(text(source.object_type)
      ? { object_type: text(source.object_type) }
      : {}),
    ...(text(source.property_rights)
      ? { property_rights: text(source.property_rights) }
      : {}),
    ...(text(source.office_type)
      ? { office_type: text(source.office_type) }
      : {}),
    ...(text(source.entrance) ? { entrance: text(source.entrance) } : {}),
    ...(layout.length > 0 ? { layout } : {}),
    ...(text(source.decoration) ? { decoration: text(source.decoration) } : {}),
    ...(text(source.building_type)
      ? { building_type: text(source.building_type) }
      : {}),
    ...(text(source.parking_type)
      ? { parking_type: text(source.parking_type) }
      : {}),
    ...(text(source.rental_type)
      ? { rental_type: text(source.rental_type) }
      : {}),
    ...(text(source.transaction_type)
      ? { transaction_type: text(source.transaction_type) }
      : {}),
  };
}

export function inferAvitoObjectType(
  value: string | null,
): AvitoObjectType | undefined {
  const normalized = String(value ?? "")
    .trim()
    .toLowerCase();
  const mappings: Array<{ needles: string[]; value: AvitoObjectType }> = [
    { needles: ["office", "офис"], value: AVITO_OBJECT_TYPES[0] },
    {
      needles: ["free", "appointment", "псн", "свобод"],
      value: AVITO_OBJECT_TYPES[1],
    },
    { needles: ["shopping", "retail", "торгов"], value: AVITO_OBJECT_TYPES[2] },
    { needles: ["warehouse", "склад"], value: AVITO_OBJECT_TYPES[3] },
    {
      needles: ["production", "industrial", "производ"],
      value: AVITO_OBJECT_TYPES[4],
    },
    {
      needles: ["catering", "food", "общепит", "питан"],
      value: AVITO_OBJECT_TYPES[5],
    },
    { needles: ["hotel", "гостин"], value: AVITO_OBJECT_TYPES[6] },
    {
      needles: ["autoservice", "car service", "автосервис"],
      value: AVITO_OBJECT_TYPES[7],
    },
    { needles: ["building", "здани"], value: AVITO_OBJECT_TYPES[8] },
  ];

  return mappings.find((mapping) =>
    mapping.needles.some((needle) => normalized.includes(needle)),
  )?.value;
}

function inferPropertyRights(value: string | null): string | undefined {
  const normalized = String(value ?? "")
    .trim()
    .toLowerCase();
  if (normalized.includes("собств")) {
    return AVITO_PROPERTY_RIGHTS[0];
  }
  if (normalized.includes("посред") || normalized.includes("агент")) {
    return AVITO_PROPERTY_RIGHTS[1];
  }
  return undefined;
}

export function resolveAvitoFeedData(estate: EstateFeedSource): AvitoFeedData {
  const stored = parseAvitoFeedData(estate.avitoFeedData);
  return {
    ...stored,
    object_type: stored.object_type ?? inferAvitoObjectType(estate.estateType),
    property_rights:
      stored.property_rights ?? inferPropertyRights(estate.ownerType),
  };
}

export function getAvitoOperationType(
  value: string | null,
): string | undefined {
  const normalized = String(value ?? "")
    .trim()
    .toLowerCase();
  if (normalized.includes("арендный бизнес") || normalized.includes("rental business")) {
    return AVITO_OPERATION_SELL;
  }
  if (normalized.includes("аренд") || normalized.includes("rent")) {
    return AVITO_OPERATION_RENT;
  }
  if (
    normalized.includes("прод") ||
    normalized.includes("sale") ||
    normalized.includes("sell")
  ) {
    return AVITO_OPERATION_SELL;
  }
  return undefined;
}

export function isAllowedValue(
  value: string | undefined,
  allowed: readonly string[],
): boolean {
  return Boolean(value && allowed.includes(value));
}

export function toAvitoFeedJson(
  value: unknown,
): Prisma.InputJsonValue | typeof Prisma.JsonNull {
  const parsed = parseAvitoFeedData(value);
  return Object.keys(parsed).length > 0
    ? (parsed as Prisma.InputJsonValue)
    : Prisma.JsonNull;
}
