import { Injectable, Logger } from "@nestjs/common";
import { AvitoAuthService } from "./avito-auth.service";
import { AvitoApiError } from "./avito.errors";

const AVITO_API_BASE_URL = "https://api.avito.ru";
const AVITO_API_TIMEOUT_MS = 15_000;

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}

@Injectable()
export class AvitoApiClient {
  private readonly logger = new Logger(AvitoApiClient.name);

  constructor(private readonly avitoAuthService: AvitoAuthService) {}

  get<T>(path: string): Promise<T> {
    return this.request<T>("GET", path);
  }

  post<T>(path: string, body?: unknown): Promise<T> {
    return this.request<T>("POST", path, body);
  }

  private async request<T>(method: string, path: string, body?: unknown, retried = false): Promise<T> {
    const startedAt = Date.now();
    const token = await this.avitoAuthService.getAccessToken({ forceRefresh: retried });
    const url = `${AVITO_API_BASE_URL}${path.startsWith("/") ? path : `/${path}`}`;

    let response: Response;
    try {
      response = await fetchWithTimeout(
        url,
        {
          method,
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${token.accessToken}`,
            ...(body === undefined ? {} : { "Content-Type": "application/json" }),
          },
          body: body === undefined ? undefined : JSON.stringify(body),
        },
        AVITO_API_TIMEOUT_MS,
      );
    } catch (error) {
      const durationMs = Date.now() - startedAt;
      this.logger.warn(`method=${method} path=${path} status=network_error durationMs=${durationMs}`);
      throw new AvitoApiError(error instanceof Error ? error.message : "Avito API request failed", null);
    }

    const durationMs = Date.now() - startedAt;
    this.logger.log(`method=${method} path=${path} status=${response.status} durationMs=${durationMs}`);

    if ((response.status === 401 || response.status === 403) && !retried) {
      this.avitoAuthService.clearCachedToken();
      return this.request<T>(method, path, body, true);
    }

    const responseBody = await this.readJsonSafe(response);
    if (!response.ok) {
      throw new AvitoApiError("Avito API request failed", response.status, responseBody);
    }

    return responseBody as T;
  }

  private async readJsonSafe(response: Response): Promise<unknown> {
    const text = await response.text();
    if (!text) {
      return null;
    }

    try {
      return JSON.parse(text);
    } catch {
      return text.slice(0, 1000);
    }
  }
}
