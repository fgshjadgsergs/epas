import { BadRequestException, Injectable, Logger, NotFoundException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { AvitoModerationStatus, AvitoPublicationStatus, CrmRole, Prisma, User } from "@prisma/client";
import { AppEnvironment } from "../../config/environment";
import { bigintToNumber, decimalToNumber } from "../../common/utils/number.utils";
import { PrismaService } from "../../prisma/prisma.service";
import { StorageService } from "../storage/storage.service";
import { AvitoValidationService } from "./avito-validation.service";
import { AVITO_ESTATE_INCLUDE, AvitoValidationError } from "./avito.types";
import {
  AvitoFeedDiagnostics,
  AvitoFeedDiagnosticsItem,
  AvitoFeedEstate,
  AvitoFeedIssue,
  AvitoFeedItem,
  AvitoFeedListItem,
} from "./avito-feed.types";
import {
  AVITO_CATEGORY_COMMERCIAL,
  AVITO_OBJECT_TYPES,
  AVITO_OPERATION_RENT,
  AVITO_OPERATION_SELL,
  getAvitoOperationType,
  resolveAvitoFeedData,
} from "./avito-feed-data";
import { AvitoXmlService } from "./avito-xml.service";

const DEFAULT_PUBLIC_BASE_URL = "https://crm.epas.agency";
const INCLUDED_PUBLICATION_STATUSES = new Set<AvitoPublicationStatus>([
  AvitoPublicationStatus.READY,
  AvitoPublicationStatus.SENT,
  AvitoPublicationStatus.PROCESSING,
  AvitoPublicationStatus.PUBLISHED,
  AvitoPublicationStatus.ERROR,
  AvitoPublicationStatus.REJECTED,
]);
// TODO: confirm Avito XML removal semantics from live user-docs before adding REMOVED ads to any feed.

function issue(code: string, message: string, field?: string, severity: "error" | "warning" = "error"): AvitoFeedIssue {
  return field ? { code, field, message, severity } : { code, message, severity };
}

function hasText(value: string | null | undefined): boolean {
  return typeof value === "string" && value.trim().length > 0;
}

function stripHtml(value: string): string {
  return value
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+\n/g, "\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
}

function parseCoordinates(value: string | null): { longitude: number; latitude: number } | null {
  if (!value) {
    return null;
  }

  const parts = value
    .split(/[,\s]+/)
    .map((item) => Number(item))
    .filter((item) => Number.isFinite(item));
  if (parts.length < 2) {
    return null;
  }

  const [longitude, latitude] = parts;
  if (longitude < -180 || longitude > 180 || latitude < -90 || latitude > 90) {
    return null;
  }

  return { longitude, latitude };
}

function toAbsoluteBaseUrl(value: string | undefined): string {
  const normalized = String(value ?? "").trim();
  if (!normalized) {
    return DEFAULT_PUBLIC_BASE_URL;
  }

  try {
    const url = new URL(normalized);
    return `${url.protocol}//${url.host}`;
  } catch {
    return DEFAULT_PUBLIC_BASE_URL;
  }
}

@Injectable()
export class AvitoFeedService {
  private readonly logger = new Logger(AvitoFeedService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly storageService: StorageService,
    private readonly avitoValidationService: AvitoValidationService,
    private readonly avitoXmlService: AvitoXmlService,
    private readonly configService: ConfigService<AppEnvironment, true>,
  ) {}

  async generateXml(): Promise<string> {
    const startedAt = Date.now();
    const estates = await this.getFeedEstates();
    this.logger.log(`[AVITO FEED] start total=${estates.length}`);

    const items: AvitoFeedItem[] = [];
    let skipped = 0;

    for (const estate of estates) {
      const mapped = this.mapEstate(estate);
      if (mapped.included && mapped.item) {
        items.push(mapped.item);
        this.logger.log(`[AVITO FEED] included estateId=${estate.id.toString()}`);
        continue;
      }

      skipped += 1;
      this.logger.warn(
        `[AVITO FEED] skipped estateId=${estate.id.toString()} reasons=${mapped.reasons.map((reason) => reason.code).join(",")}`,
      );
    }

    this.logger.log(
      `[AVITO FEED] done total=${estates.length} included=${items.length} skipped=${skipped} durationMs=${Date.now() - startedAt}`,
    );
    return this.avitoXmlService.render(items);
  }

  async getDiagnostics(): Promise<AvitoFeedDiagnostics> {
    const estates = await this.getDiagnosticsEstates();
    const items: AvitoFeedDiagnosticsItem[] = estates.map((estate) => {
      const mapped = this.mapEstate(estate);
      return {
        estateId: estate.id.toString(),
        externalId: estate.avitoExternalId ?? undefined,
        included: mapped.included,
        reasons: mapped.reasons,
      };
    });
    const included = items.filter((item) => item.included).length;
    const reasonSummary: Record<string, number> = {};

    for (const item of items) {
      for (const reason of item.reasons) {
        reasonSummary[reason.code] = (reasonSummary[reason.code] ?? 0) + 1;
      }
    }

    const feedUrl = this.configService.get("AVITO_FEED_URL", { infer: true });
    return {
      generatedAt: new Date().toISOString(),
      totalFound: estates.length,
      included,
      skipped: items.length - included,
      ...(feedUrl ? { feedUrl } : {}),
      items,
      reasonSummary,
    };
  }

  async listFeedItems(): Promise<{ items: AvitoFeedListItem[]; total: number; skip: number; limit: number }> {
    const estates = await this.getFeedEstates();
    const items = estates.map((estate) => this.toFeedListItem(estate));

    return {
      items,
      total: items.length,
      skip: 0,
      limit: items.length,
    };
  }

  async removeFromFeed(estateId: number): Promise<{ updated: number }> {
    const result = await this.prisma.estate.updateMany({
      where: {
        id: BigInt(estateId),
      },
      data: {
        avitoIncluded: false,
        avitoStatus: AvitoPublicationStatus.NOT_INCLUDED,
      },
    });

    return {
      updated: result.count,
    };
  }

  async restoreToFeed(estateId: number): Promise<{ updated: number; validation: { ok: boolean; errors: unknown[] } }> {
    const estate = await this.prisma.estate.findUnique({
      where: {
        id: BigInt(estateId),
      },
      include: AVITO_ESTATE_INCLUDE,
    });

    if (!estate) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    const validation = this.avitoValidationService.validateEstate(estate);
    if (estate.avitoModerationStatus !== AvitoModerationStatus.APPROVED) {
      throw new BadRequestException({
        message: "Estate must be approved before returning to Avito feed",
        errors: [issue("not_approved", "Estate is not internally approved for Avito", "avitoModerationStatus")],
      });
    }
    if (!validation.ok) {
      throw new BadRequestException({
        message: "Estate did not pass local Avito validation",
        errors: validation.errors,
      });
    }

    const result = await this.prisma.estate.updateMany({
      where: {
        id: estate.id,
      },
      data: {
        avitoIncluded: true,
        avitoStatus: AvitoPublicationStatus.READY,
        avitoExternalId: estate.avitoExternalId ?? estate.id.toString(),
        avitoLastValidatedAt: new Date(),
        avitoLastError: Prisma.JsonNull,
      },
    });

    return {
      updated: result.count,
      validation,
    };
  }

  private getFeedEstates(): Promise<AvitoFeedEstate[]> {
    return this.prisma.estate.findMany({
      where: {
        active: true,
        deletedAt: null,
        isPrivateSale: false,
        avitoModerationStatus: AvitoModerationStatus.APPROVED,
        avitoIncluded: true,
        avitoExternalId: {
          not: null,
        },
        avitoStatus: {
          in: [...INCLUDED_PUBLICATION_STATUSES],
        },
      },
      include: AVITO_ESTATE_INCLUDE,
      orderBy: {
        id: "asc",
      },
    });
  }

  private toFeedListItem(estate: AvitoFeedEstate): AvitoFeedListItem {
    const mapped = this.mapEstate(estate);
    const mainImage = [...estate.images].sort(
      (left, right) =>
        Number(right.isMain) - Number(left.isMain) || Number(left.id > right.id) - Number(left.id < right.id),
    )[0] ?? null;
    const broker = estate.assignments.find((assignment) => assignment.user.role === CrmRole.BROKER)?.user ?? estate.user ?? null;

    return {
      id: bigintToNumber(estate.id),
      title: estate.title,
      deal_type: estate.dealType,
      estate_type: estate.estateType,
      price: decimalToNumber(estate.price),
      area: decimalToNumber(estate.area),
      broker: broker
        ? {
            id: bigintToNumber(broker.id),
            email: broker.email,
            first_name: broker.firstName,
            last_name: broker.lastName,
            phone_number: broker.phoneNumber,
            role: broker.role,
            rop_id: broker.ropId === null ? null : bigintToNumber(broker.ropId),
          }
        : null,
      avito: {
        moderation_status: estate.avitoModerationStatus,
        publication_status: estate.avitoStatus,
        included: estate.avitoIncluded,
        external_id: estate.avitoExternalId,
        last_error: estate.avitoLastError,
        last_validated_at: estate.avitoLastValidatedAt?.toISOString() ?? null,
        last_synced_at: estate.avitoLastSyncedAt?.toISOString() ?? null,
        approved_at: estate.avitoApprovedAt?.toISOString() ?? null,
      },
      main_image: mainImage
        ? {
            id: bigintToNumber(mainImage.id),
            url: mainImage.url,
            public_url: this.storageService.resolvePublicUrl(mainImage.url),
          }
        : null,
      reasons: mapped.reasons,
    };
  }

  private getDiagnosticsEstates(): Promise<AvitoFeedEstate[]> {
    return this.prisma.estate.findMany({
      include: AVITO_ESTATE_INCLUDE,
      orderBy: {
        id: "asc",
      },
    });
  }

  private mapEstate(estate: AvitoFeedEstate): { included: boolean; item?: AvitoFeedItem; reasons: AvitoFeedIssue[] } {
    try {
      const reasons = this.getBaseSkipReasons(estate);
      const validation = this.avitoValidationService.validateEstate(estate);
      const validationErrors = validation.errors.filter((error) => error.severity === "error");
      if (validationErrors.length > 0) {
        reasons.push(issue("validation_failed", "Estate did not pass local Avito validation"));
        reasons.push(...validationErrors.map((error) => this.validationErrorToIssue(error)));
      }

      const feedData = resolveAvitoFeedData(estate);
      const objectType = feedData.object_type;
      const operationType = getAvitoOperationType(estate.dealType);
      const effectiveTitle = estate.avitoTitle?.trim() || estate.title.trim();

      const price = decimalToNumber(estate.price);
      const area = decimalToNumber(estate.area);
      const contact = this.getContact(estate);
      const images = this.getImageUrls(estate);
      const coordinates = parseCoordinates(estate.coordinates);
      const companyName = this.getCompanyName();
      const ceilingHeight = decimalToNumber(estate.ceilingHeightM);
      const powerGridCapacity = decimalToNumber(estate.powerKw);

      if (price === null || price <= 0) {
        reasons.push(issue("missing_price", "Price is required", "price"));
      }
      if (area === null || area <= 0) {
        reasons.push(issue("missing_area", "Area is required", "area"));
      }
      if (!hasText(effectiveTitle)) {
        reasons.push(issue("missing_title", "Avito title is required", "avitoTitle"));
      }
      if (!hasText(estate.title)) {
        reasons.push(issue("missing_address", "Address is required", "title"));
      }
      if (!hasText(estate.description)) {
        reasons.push(issue("missing_description", "Description is required", "description"));
      }
      if (images.length === 0) {
        reasons.push(issue("missing_images", "At least one public image URL is required", "images"));
      }
      if (!contact.phone) {
        reasons.push(issue("missing_phone", "Contact phone is required", "contactPhone"));
      }
      if (estate.coordinates && !coordinates) {
        reasons.push(issue("invalid_coordinates", "Coordinates must be `longitude latitude`", "coordinates"));
      }

      if (reasons.some((reason) => reason.severity === "error")) {
        return { included: false, reasons: this.dedupeReasons(reasons) };
      }

      return {
        included: true,
        reasons: this.dedupeReasons(reasons),
        item: {
          id: String(estate.avitoExternalId || estate.id.toString()),
          category: AVITO_CATEGORY_COMMERCIAL,
          operationType: operationType!,
          objectType: objectType!,
          title: effectiveTitle,
          description: stripHtml(estate.description),
          price: price!,
          address: estate.title,
          propertyRights: feedData.property_rights!,
          ...(operationType === AVITO_OPERATION_RENT && objectType === AVITO_OBJECT_TYPES[0] && feedData.office_type
            ? { officeType: feedData.office_type }
            : {}),
          ...(objectType !== AVITO_OBJECT_TYPES[0] && feedData.entrance ? { entrance: feedData.entrance } : {}),
          ...(estate.floor === null ? {} : { floor: estate.floor }),
          ...(objectType === AVITO_OBJECT_TYPES[0] && feedData.layout?.length ? { layout: feedData.layout } : {}),
          area: area!,
          ...(ceilingHeight === null ? {} : { ceilingHeight }),
          decoration: feedData.decoration!,
          ...(powerGridCapacity === null ? {} : { powerGridCapacity }),
          buildingType: feedData.building_type!,
          parkingType: feedData.parking_type!,
          ...(operationType === AVITO_OPERATION_RENT && feedData.rental_type ? { rentalType: feedData.rental_type } : {}),
          ...(operationType === AVITO_OPERATION_SELL && feedData.transaction_type ? { transactionType: feedData.transaction_type } : {}),
          ...(coordinates ? { latitude: coordinates.latitude, longitude: coordinates.longitude } : {}),
          images,
          contactPhone: contact.phone!,
          ...(contact.managerName ? { managerName: contact.managerName } : {}),
          ...(companyName ? { companyName } : {}),
        },
      };
    } catch (error) {
      this.logger.warn(
        `[AVITO FEED] skipped estateId=${estate.id.toString()} reasons=xml_mapping_error message=${error instanceof Error ? error.message : String(error)}`,
      );
      return {
        included: false,
        reasons: [issue("xml_mapping_error", "Estate could not be mapped to Avito XML")],
      };
    }
  }

  private getBaseSkipReasons(estate: AvitoFeedEstate): AvitoFeedIssue[] {
    const reasons: AvitoFeedIssue[] = [];

    if (!estate.active) {
      reasons.push(issue("inactive", "Estate is inactive", "active"));
    }
    if (estate.deletedAt) {
      reasons.push(issue("deleted", "Estate is deleted or archived", "deletedAt"));
    }
    if (estate.isPrivateSale) {
      reasons.push(issue("private_sale", "Private sale is not included in Avito feed", "isPrivateSale"));
    }
    if (estate.avitoModerationStatus !== AvitoModerationStatus.APPROVED) {
      reasons.push(issue("not_approved", "Estate is not internally approved for Avito", "avitoModerationStatus"));
    }
    if (!estate.avitoIncluded) {
      reasons.push(issue("avito_not_included", "Estate is not marked for Avito feed", "avitoIncluded"));
    }
    if (!estate.avitoExternalId) {
      reasons.push(issue("missing_external_id", "Avito external id is required", "avitoExternalId"));
    }
    if (!INCLUDED_PUBLICATION_STATUSES.has(estate.avitoStatus)) {
      reasons.push(issue("avito_status_not_feedable", "Avito publication status is not included in active feed", "avitoStatus"));
    }

    return reasons;
  }

  private validationErrorToIssue(error: AvitoValidationError): AvitoFeedIssue {
    const codeByField: Record<string, string> = {
      price: "missing_price",
      area: "missing_area",
      title: "missing_address",
      description: "missing_description",
      images: "missing_images",
      "broker.phoneNumber": "missing_phone",
    };

    return {
      code: codeByField[error.field] ?? error.code,
      field: error.field,
      message: error.message,
      severity: error.severity,
    };
  }

  private getImageUrls(estate: AvitoFeedEstate): string[] {
    const baseUrl = this.getPublicBaseUrl();
    const seen = new Set<string>();
    const urls: string[] = [];
    const images = [...estate.images].sort((left, right) => Number(right.isMain) - Number(left.isMain));

    for (const image of images) {
      const publicUrl = this.toPublicUrl(this.storageService.resolvePublicUrl(image.url), baseUrl);
      if (!publicUrl || seen.has(publicUrl)) {
        continue;
      }

      seen.add(publicUrl);
      urls.push(publicUrl);
    }

    return urls;
  }

  private toPublicUrl(value: string, baseUrl: string): string | null {
    const normalized = value.trim();
    if (!normalized) {
      return null;
    }

    try {
      const url = new URL(normalized);
      if (url.hostname === "localhost" || url.hostname === "127.0.0.1") {
        return null;
      }
      if (url.pathname.startsWith("/crm/storage/")) {
        url.pathname = url.pathname.slice("/crm".length);
      }
      return url.toString();
    } catch {
      const path = normalized.replace(/^\/?crm\/storage\//, "/storage/").replace(/^storage\//, "/storage/");
      if (!path.startsWith("/storage/")) {
        return null;
      }

      return new URL(path, baseUrl).toString();
    }
  }

  private getContact(estate: AvitoFeedEstate): { phone: string | null; managerName: string | null } {
    const assignedBroker = estate.assignments.find((assignment) => assignment.user.role === CrmRole.BROKER)?.user;
    const fallbackUser = assignedBroker ?? estate.user;
    const defaultPhone = this.configService.get("AVITO_DEFAULT_PHONE", { infer: true });
    const defaultManagerName = this.configService.get("AVITO_DEFAULT_MANAGER_NAME", { infer: true });
    const phone = [defaultPhone, assignedBroker?.phoneNumber, estate.user?.phoneNumber].find(hasText) ?? null;

    return {
      phone,
      managerName: defaultManagerName || (fallbackUser ? this.getUserName(fallbackUser) : null),
    };
  }

  private getUserName(user: User): string | null {
    const fullName = [user.firstName, user.lastName].filter(hasText).join(" ").trim();
    return fullName || user.email || null;
  }

  private getCompanyName(): string | null {
    return this.configService.get("AVITO_COMPANY_NAME", { infer: true }) || null;
  }

  private getPublicBaseUrl(): string {
    return toAbsoluteBaseUrl(
      this.configService.get("AVITO_PUBLIC_BASE_URL", { infer: true }) ||
        this.configService.get("AVITO_FEED_URL", { infer: true }) ||
        this.configService.get("STORAGE_BASE_URL", { infer: true }),
    );
  }

  private dedupeReasons(reasons: AvitoFeedIssue[]): AvitoFeedIssue[] {
    const seen = new Set<string>();
    return reasons.filter((reason) => {
      const key = `${reason.code}:${reason.field ?? ""}:${reason.severity}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }
}


