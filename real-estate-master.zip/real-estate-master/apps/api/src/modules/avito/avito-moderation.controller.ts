import { Body, Controller, Get, Param, ParseIntPipe, Post, Put, Query, UseGuards } from "@nestjs/common";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { AvitoFeedSettingsPayload } from "./avito-feed-data";
import { AvitoModerationService } from "./avito-moderation.service";
import { AvitoModerationQuery, AvitoRequestChangesPayload } from "./avito.types";

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm")
export class AvitoModerationController {
  constructor(private readonly avitoModerationService: AvitoModerationService) {}

  @Get("avito/moderation")
  getModerationQueue(
    @CurrentCrmUser() user: AuthenticatedCrmUser,
    @Query() query: AvitoModerationQuery,
  ): Promise<Record<string, unknown>> {
    return this.avitoModerationService.listModerationQueue(user, query);
  }

  @Get("estates/:estateId/avito/validation")
  validateEstate(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ) {
    return this.avitoModerationService.validateEstate(estateId, user);
  }

  @Put("estates/:estateId/avito/settings")
  updateFeedSettings(
    @Param("estateId", ParseIntPipe) estateId: number,
    @Body() payload: AvitoFeedSettingsPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<Record<string, unknown>> {
    return this.avitoModerationService.updateFeedSettings(estateId, user, payload);
  }

  @Post("estates/:estateId/avito/submit-review")
  submitReview(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<Record<string, unknown>> {
    return this.avitoModerationService.submitReview(estateId, user);
  }

  @Post("estates/:estateId/avito/approve")
  approve(
    @Param("estateId", ParseIntPipe) estateId: number,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<Record<string, unknown>> {
    return this.avitoModerationService.approve(estateId, user);
  }

  @Post("estates/:estateId/avito/request-changes")
  requestChanges(
    @Param("estateId", ParseIntPipe) estateId: number,
    @Body() payload: AvitoRequestChangesPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<Record<string, unknown>> {
    return this.avitoModerationService.requestChanges(estateId, user, String(payload.comment ?? ""));
  }
}
