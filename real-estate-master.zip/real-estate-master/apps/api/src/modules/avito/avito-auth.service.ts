import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { AppEnvironment } from "../../config/environment";
import { AvitoApiError, AvitoConfigurationError } from "./avito.errors";

interface AvitoTokenResponse {
  access_token?: string;
  expires_in?: number;
  token_type?: string;
}

interface CachedToken {
  accessToken: string;
  expiresAtMs: number;
}

const AVITO_TOKEN_URL = "https://api.avito.ru/token";
const TOKEN_REFRESH_SKEW_MS = 60_000;
const TOKEN_REQUEST_TIMEOUT_MS = 10_000;

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}

@Injectable()
export class AvitoAuthService {
  private cachedToken: CachedToken | null = null;
  private pendingTokenRequest: Promise<CachedToken> | null = null;

  constructor(private readonly configService: ConfigService<AppEnvironment, true>) {}

  async getAccessToken(options: { forceRefresh?: boolean } = {}): Promise<CachedToken> {
    if (!options.forceRefresh && this.cachedToken && this.cachedToken.expiresAtMs - TOKEN_REFRESH_SKEW_MS > Date.now()) {
      return this.cachedToken;
    }

    if (!options.forceRefresh && this.pendingTokenRequest) {
      return this.pendingTokenRequest;
    }

    this.pendingTokenRequest = this.requestAccessToken();
    try {
      this.cachedToken = await this.pendingTokenRequest;
      return this.cachedToken;
    } finally {
      this.pendingTokenRequest = null;
    }
  }

  clearCachedToken(): void {
    this.cachedToken = null;
  }

  getDiagnostics(token: CachedToken): { ok: true; status: "configured"; expiresIn: number } {
    return {
      ok: true,
      status: "configured",
      expiresIn: Math.max(0, Math.floor((token.expiresAtMs - Date.now()) / 1000)),
    };
  }

  private async requestAccessToken(): Promise<CachedToken> {
    const clientId = this.configService.get("AVITO_CLIENT_ID", { infer: true });
    const clientSecret = this.configService.get("AVITO_CLIENT_SECRET", { infer: true });

    if (!clientId || !clientSecret) {
      throw new AvitoConfigurationError("AVITO_CLIENT_ID and AVITO_CLIENT_SECRET are required");
    }

    const body = new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
    });

    let response: Response;
    try {
      response = await fetchWithTimeout(
        AVITO_TOKEN_URL,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json",
          },
          body,
        },
        TOKEN_REQUEST_TIMEOUT_MS,
      );
    } catch (error) {
      throw new AvitoApiError(error instanceof Error ? error.message : "Avito token request failed", null);
    }

    const responseBody = await this.readJsonSafe(response);
    if (!response.ok) {
      throw new AvitoApiError("Avito token request failed", response.status, responseBody);
    }

    const tokenResponse = responseBody as AvitoTokenResponse;
    if (!tokenResponse.access_token || !tokenResponse.expires_in) {
      throw new AvitoApiError("Avito token response is invalid", response.status, responseBody);
    }

    return {
      accessToken: tokenResponse.access_token,
      expiresAtMs: Date.now() + tokenResponse.expires_in * 1000,
    };
  }

  private async readJsonSafe(response: Response): Promise<unknown> {
    const text = await response.text();
    if (!text) {
      return null;
    }

    try {
      return JSON.parse(text);
    } catch {
      return text.slice(0, 1000);
    }
  }
}
