import {
  BadGatewayException,
  BadRequestException,
  Controller,
  ForbiddenException,
  Get,
  ServiceUnavailableException,
  Query,
  UseGuards,
} from "@nestjs/common";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { AvitoDiagnosticsService } from "./avito-diagnostics.service";
import { AvitoApiError, AvitoConfigurationError } from "./avito.errors";

const ADMIN_REQUIRED_MESSAGE = "Admin access required";

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/avito/diagnostics")
export class AvitoDiagnosticsController {
  constructor(private readonly avitoDiagnosticsService: AvitoDiagnosticsService) {}

  @Get("auth")
  checkAuth(@CurrentCrmUser() user: AuthenticatedCrmUser) {
    this.assertAdmin(user);
    return this.runDiagnostic(() => this.avitoDiagnosticsService.checkAuth());
  }

  @Get("profile")
  getProfile(@CurrentCrmUser() user: AuthenticatedCrmUser) {
    this.assertAdmin(user);
    return this.runDiagnostic(() => this.avitoDiagnosticsService.getProfile());
  }

  @Get("nodes")
  getCategoryTree(@CurrentCrmUser() user: AuthenticatedCrmUser) {
    this.assertAdmin(user);
    return this.runDiagnostic(() => this.avitoDiagnosticsService.getCategoryTree());
  }

  @Get("node-fields")
  getNodeFields(@CurrentCrmUser() user: AuthenticatedCrmUser, @Query("nodeSlug") nodeSlug?: string) {
    this.assertAdmin(user);
    const normalizedNodeSlug = String(nodeSlug ?? "").trim();
    if (!normalizedNodeSlug) {
      throw new BadRequestException("nodeSlug is required");
    }

    return this.runDiagnostic(() => this.avitoDiagnosticsService.getNodeFields(normalizedNodeSlug));
  }

  private assertAdmin(user: AuthenticatedCrmUser): void {
    if (!user.is_admin) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }

  private async runDiagnostic<T>(operation: () => Promise<T>): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      if (error instanceof AvitoConfigurationError) {
        throw new ServiceUnavailableException({
          code: "AVITO_CONFIGURATION_ERROR",
          message: error.message,
        });
      }

      if (error instanceof AvitoApiError) {
        throw new BadGatewayException({
          code: "AVITO_API_ERROR",
          message: error.message,
          avitoStatus: error.status,
          avitoBody: error.body,
        });
      }

      throw error;
    }
  }
}
