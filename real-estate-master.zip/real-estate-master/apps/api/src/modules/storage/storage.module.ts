import { Module } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { S3Client } from "@aws-sdk/client-s3";
import { EstateImageWatermarkService } from "./estate-image-watermark.service";
import { LocalStorageAdapter } from "./local-storage.adapter";
import { S3StorageAdapter } from "./s3-storage.adapter";
import { STORAGE_ADAPTER, StorageAdapter, StorageService } from "./storage.service";

@Module({
  providers: [
    {
      provide: STORAGE_ADAPTER,
      inject: [ConfigService],
      useFactory: (configService: ConfigService): StorageAdapter => {
        const driver = configService.get<string>("STORAGE_DRIVER", "local");
        const baseUrl = configService.get<string>("STORAGE_BASE_URL", "");

        if (driver === "s3") {
          return new S3StorageAdapter(
            new S3Client({
              endpoint: configService.get<string>("S3_ENDPOINT"),
              region: configService.get<string>("S3_REGION"),
              credentials: {
                accessKeyId: configService.get<string>("S3_ACCESS_KEY_ID", ""),
                secretAccessKey: configService.get<string>("S3_SECRET_ACCESS_KEY", ""),
              },
              forcePathStyle: configService.get<boolean>("S3_FORCE_PATH_STYLE", true),
            }),
            configService.get<string>("S3_BUCKET", ""),
            baseUrl,
          );
        }

        return new LocalStorageAdapter(configService.get<string>("STORAGE_LOCAL_ROOT", "storage"), baseUrl);
      },
    },
    EstateImageWatermarkService,
    StorageService,
  ],
  exports: [StorageService],
})
export class StorageModule {}
