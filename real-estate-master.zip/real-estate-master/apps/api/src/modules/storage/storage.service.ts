import { extname, posix as pathPosix } from "node:path";
import { BadRequestException, Inject, Injectable } from "@nestjs/common";
import sharp from "sharp";
import { EstateImageWatermarkService } from "./estate-image-watermark.service";

export interface SaveEstateImageInput {
  estateId: number;
  buffer: Buffer;
  originalFilename?: string;
  contentType?: string;
}

export interface SavedEstateImage {
  path: string;
  thumbnailPath: string | null;
  watermarkAppliedAt: Date;
}

export interface StorageAdapter {
  resolvePublicUrl(path: string): string;
  saveEstateImage(input: SaveEstateImageInput): Promise<string>;
  duplicateEstateImage(path: string, targetEstateId: number): Promise<string>;
  readByPath(path: string): Promise<Buffer>;
  writeByPath(path: string, buffer: Buffer, contentType?: string): Promise<void>;
  deleteByPath(path: string): Promise<void>;
  deleteEstateDirectory(estateId: number): Promise<void>;
}

export const STORAGE_ADAPTER = Symbol("STORAGE_ADAPTER");
export const ALLOWED_ESTATE_IMAGE_EXTENSIONS = ["jpg", "jpeg", "png", "webp", "gif", "avif"] as const;
export const ALLOWED_ESTATE_IMAGE_CONTENT_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/avif",
] as const;
export const ESTATE_IMAGE_VALIDATION_MESSAGE = "Можно загружать только изображения JPG, JPEG, PNG, WEBP, GIF или AVIF";

const ESTATE_IMAGE_THUMBNAIL_WIDTH = 480;
const ESTATE_IMAGE_THUMBNAIL_QUALITY = 78;

function normalizeImageContentType(contentType?: string): string {
  return String(contentType ?? "")
    .split(";")[0]
    .trim()
    .toLowerCase();
}

function normalizeImageExtension(originalFilename?: string): string {
  return extname(String(originalFilename ?? ""))
    .replace(".", "")
    .trim()
    .toLowerCase();
}

function buildEstateThumbnailPath(path: string): string {
  const normalized = path.replace(/\\/g, "/").replace(/^\/+/, "");
  const directory = pathPosix.dirname(normalized);
  const extension = pathPosix.extname(normalized);
  const stem = pathPosix.basename(normalized, extension);

  return `${directory}/thumbs/${stem}.jpg`;
}

export function isAllowedEstateImageUpload(input: {
  originalFilename?: string;
  contentType?: string;
}): boolean {
  const normalizedContentType = normalizeImageContentType(input.contentType);
  const normalizedExtension = normalizeImageExtension(input.originalFilename);
  const hasAllowedContentType = normalizedContentType
    ? ALLOWED_ESTATE_IMAGE_CONTENT_TYPES.includes(normalizedContentType as (typeof ALLOWED_ESTATE_IMAGE_CONTENT_TYPES)[number])
    : false;
  const hasAllowedExtension = normalizedExtension
    ? ALLOWED_ESTATE_IMAGE_EXTENSIONS.includes(normalizedExtension as (typeof ALLOWED_ESTATE_IMAGE_EXTENSIONS)[number])
    : false;

  if (normalizedContentType && normalizedExtension) {
    return hasAllowedContentType && hasAllowedExtension;
  }

  return hasAllowedContentType || hasAllowedExtension;
}

@Injectable()
export class StorageService {
  constructor(
    @Inject(STORAGE_ADAPTER) private readonly adapter: StorageAdapter,
    private readonly estateImageWatermarkService: EstateImageWatermarkService,
  ) {}

  resolvePublicUrl(path: string): string {
    return this.adapter.resolvePublicUrl(path);
  }

  async saveEstateImage(input: SaveEstateImageInput): Promise<SavedEstateImage> {
    if (!isAllowedEstateImageUpload(input)) {
      throw new BadRequestException({
        errors: {
          images: ESTATE_IMAGE_VALIDATION_MESSAGE,
        },
      });
    }

    const watermarked = await this.estateImageWatermarkService.applyWatermark(input.buffer);
    const path = await this.adapter.saveEstateImage({
      ...input,
      buffer: watermarked.buffer,
    });
    const thumbnailPath = await this.writeEstateImageThumbnail(path, watermarked.buffer, true);

    return {
      path,
      thumbnailPath,
      watermarkAppliedAt: watermarked.appliedAt,
    };
  }

  duplicateEstateImage(path: string, targetEstateId: number): Promise<string> {
    return this.adapter.duplicateEstateImage(path, targetEstateId);
  }

  async duplicateEstateThumbnail(sourceThumbnailPath: string | null | undefined, targetImagePath: string): Promise<string | null> {
    const targetThumbnailPath = buildEstateThumbnailPath(targetImagePath);

    if (sourceThumbnailPath) {
      const source = await this.adapter.readByPath(sourceThumbnailPath);
      await this.adapter.writeByPath(targetThumbnailPath, source, "image/jpeg");
      return targetThumbnailPath;
    }

    return this.generateThumbnailForExistingEstateImage(targetImagePath, { force: true });
  }

  async generateThumbnailForExistingEstateImage(path: string, options: { force?: boolean } = {}): Promise<string | null> {
    if (!options.force) {
      const existingThumbnailPath = buildEstateThumbnailPath(path);
      if (await this.pathExists(existingThumbnailPath)) {
        return existingThumbnailPath;
      }
    }

    const source = await this.adapter.readByPath(path);
    return this.writeEstateImageThumbnail(path, source, Boolean(options.force));
  }

  async applyWatermarkToExistingEstateImage(path: string): Promise<Date> {
    const source = await this.adapter.readByPath(path);
    const watermarked = await this.estateImageWatermarkService.applyWatermark(source);
    await this.adapter.writeByPath(path, watermarked.buffer, this.inferEstateImageContentType(path));
    return watermarked.appliedAt;
  }

  deleteByPath(path: string): Promise<void> {
    return this.adapter.deleteByPath(path);
  }

  deleteEstateDirectory(estateId: number): Promise<void> {
    return this.adapter.deleteEstateDirectory(estateId);
  }

  private inferEstateImageContentType(path: string): string {
    const extension = extname(path).replace(".", "").trim().toLowerCase();

    switch (extension) {
      case "jpg":
      case "jpeg":
        return "image/jpeg";
      case "png":
        return "image/png";
      case "webp":
        return "image/webp";
      case "gif":
        return "image/gif";
      case "avif":
        return "image/avif";
      default:
        return "application/octet-stream";
    }
  }

  private async writeEstateImageThumbnail(path: string, sourceBuffer: Buffer, force: boolean): Promise<string | null> {
    const thumbnailPath = buildEstateThumbnailPath(path);
    if (!force && (await this.pathExists(thumbnailPath))) {
      return thumbnailPath;
    }

    const thumbnail = await sharp(sourceBuffer, {
      animated: false,
    })
      .rotate()
      .resize({
        width: ESTATE_IMAGE_THUMBNAIL_WIDTH,
        withoutEnlargement: true,
      })
      .jpeg({
        quality: ESTATE_IMAGE_THUMBNAIL_QUALITY,
        mozjpeg: true,
      })
      .toBuffer();

    await this.adapter.writeByPath(thumbnailPath, thumbnail, "image/jpeg");
    return thumbnailPath;
  }

  private async pathExists(path: string): Promise<boolean> {
    try {
      await this.adapter.readByPath(path);
      return true;
    } catch {
      return false;
    }
  }
}
