import { copyFile, mkdir, readFile, rm, unlink, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { extname, join } from "node:path";
import { extension as mimeExtension } from "mime-types";
import { SaveEstateImageInput, StorageAdapter } from "./storage.service";

export class LocalStorageAdapter implements StorageAdapter {
  constructor(
    private readonly storageRoot: string,
    private readonly baseUrl: string,
  ) {}

  resolvePublicUrl(path: string): string {
    if (!path) {
      return "";
    }

    const normalized = path.replace(/\\/g, "/").replace(/^\/+/, "");
    const trimmedBaseUrl = this.baseUrl.replace(/\/+$/, "");

    return trimmedBaseUrl ? `${trimmedBaseUrl}/${normalized}` : normalized;
  }

  async saveEstateImage(input: SaveEstateImageInput): Promise<string> {
    const extension = this.resolveExtension(input.originalFilename, input.contentType);
    const fileName = `${randomUUID()}.${extension}`;
    const relativePath = `storage/real-estates/${input.estateId}/${fileName}`;
    const fullDirectoryPath = join(this.storageRoot, "real-estates", String(input.estateId));
    const fullFilePath = join(fullDirectoryPath, fileName);

    await mkdir(fullDirectoryPath, { recursive: true });
    await writeFile(fullFilePath, input.buffer);

    return relativePath;
  }

  async duplicateEstateImage(path: string, targetEstateId: number): Promise<string> {
    const normalized = path.replace(/^storage[\\/]/, "");
    const parts = normalized.split(/[\\/]+/).filter(Boolean);
    const sourcePath = join(this.storageRoot, ...parts);
    const extension = extname(path).replace(".", "").trim().toLowerCase() || "bin";
    const fileName = `${randomUUID()}.${extension}`;
    const relativePath = `storage/real-estates/${targetEstateId}/${fileName}`;
    const fullDirectoryPath = join(this.storageRoot, "real-estates", String(targetEstateId));
    const targetPath = join(fullDirectoryPath, fileName);

    await mkdir(fullDirectoryPath, { recursive: true });
    await copyFile(sourcePath, targetPath);

    return relativePath;
  }

  async readByPath(path: string): Promise<Buffer> {
    const normalized = path.replace(/^storage[\\/]/, "");
    const parts = normalized.split(/[\\/]+/).filter(Boolean);
    return readFile(join(this.storageRoot, ...parts));
  }

  async writeByPath(path: string, buffer: Buffer): Promise<void> {
    const normalized = path.replace(/^storage[\\/]/, "");
    const parts = normalized.split(/[\\/]+/).filter(Boolean);
    const targetPath = join(this.storageRoot, ...parts);
    const targetDirectory = join(this.storageRoot, ...parts.slice(0, -1));

    await mkdir(targetDirectory, { recursive: true });
    await writeFile(targetPath, buffer);
  }

  async deleteByPath(path: string): Promise<void> {
    const normalized = path.replace(/^storage[\\/]/, "");
    const parts = normalized.split(/[\\/]+/).filter(Boolean);
    await unlink(join(this.storageRoot, ...parts)).catch(() => undefined);
  }

  async deleteEstateDirectory(estateId: number): Promise<void> {
    await rm(join(this.storageRoot, "real-estates", String(estateId)), {
      recursive: true,
      force: true,
    }).catch(() => undefined);
  }

  private resolveExtension(originalFilename?: string, contentType?: string): string {
    if (originalFilename) {
      const fileExtension = extname(originalFilename).replace(".", "").trim();
      if (fileExtension) {
        return fileExtension.toLowerCase();
      }
    }

    if (contentType) {
      const byMime = mimeExtension(contentType);
      if (byMime) {
        return byMime.toLowerCase();
      }
    }

    return "bin";
  }
}
