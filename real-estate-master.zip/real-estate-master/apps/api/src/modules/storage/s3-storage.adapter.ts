import { randomUUID } from "node:crypto";
import { extname } from "node:path";
import {
  CopyObjectCommand,
  DeleteObjectCommand,
  DeleteObjectsCommand,
  GetObjectCommand,
  ListObjectsV2Command,
  PutObjectCommand,
  S3Client,
} from "@aws-sdk/client-s3";
import { extension as mimeExtension } from "mime-types";
import { SaveEstateImageInput, StorageAdapter } from "./storage.service";

export class S3StorageAdapter implements StorageAdapter {
  constructor(
    private readonly client: S3Client,
    private readonly bucket: string,
    private readonly baseUrl: string,
  ) {}

  resolvePublicUrl(path: string): string {
    if (!path) {
      return "";
    }

    const normalized = path.replace(/\\/g, "/").replace(/^\/+/, "");
    const trimmedBaseUrl = this.baseUrl.replace(/\/+$/, "");

    return trimmedBaseUrl ? `${trimmedBaseUrl}/${normalized}` : normalized;
  }

  async saveEstateImage(input: SaveEstateImageInput): Promise<string> {
    const extension = this.resolveExtension(input.originalFilename, input.contentType);
    const key = `storage/real-estates/${input.estateId}/${randomUUID()}.${extension}`;

    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        Body: input.buffer,
        ContentType: input.contentType ?? "application/octet-stream",
      }),
    );

    return key;
  }

  async duplicateEstateImage(path: string, targetEstateId: number): Promise<string> {
    const extension = extname(path).replace(".", "").trim().toLowerCase() || "bin";
    const key = `storage/real-estates/${targetEstateId}/${randomUUID()}.${extension}`;
    const copySource = `${this.bucket}/${encodeURIComponent(path).replace(/%2F/g, "/")}`;

    await this.client.send(
      new CopyObjectCommand({
        Bucket: this.bucket,
        CopySource: copySource,
        Key: key,
      }),
    );

    return key;
  }

  async readByPath(path: string): Promise<Buffer> {
    const response = await this.client.send(
      new GetObjectCommand({
        Bucket: this.bucket,
        Key: path,
      }),
    );

    const byteArray = await response.Body?.transformToByteArray();
    return Buffer.from(byteArray ?? []);
  }

  async writeByPath(path: string, buffer: Buffer, contentType?: string): Promise<void> {
    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: path,
        Body: buffer,
        ContentType: contentType ?? "application/octet-stream",
      }),
    );
  }

  async deleteByPath(path: string): Promise<void> {
    await this.client.send(
      new DeleteObjectCommand({
        Bucket: this.bucket,
        Key: path,
      }),
    );
  }

  async deleteEstateDirectory(estateId: number): Promise<void> {
    const prefix = `storage/real-estates/${estateId}/`;
    const listed = await this.client.send(
      new ListObjectsV2Command({
        Bucket: this.bucket,
        Prefix: prefix,
      }),
    );

    const objects = (listed.Contents ?? [])
      .map((item) => item.Key)
      .filter((key): key is string => Boolean(key))
      .map((key) => ({ Key: key }));

    if (objects.length === 0) {
      return;
    }

    await this.client.send(
      new DeleteObjectsCommand({
        Bucket: this.bucket,
        Delete: {
          Objects: objects,
        },
      }),
    );
  }

  private resolveExtension(originalFilename?: string, contentType?: string): string {
    if (originalFilename) {
      const fileExtension = extname(originalFilename).replace(".", "").trim();
      if (fileExtension) {
        return fileExtension.toLowerCase();
      }
    }

    if (contentType) {
      const byMime = mimeExtension(contentType);
      if (byMime) {
        return byMime.toLowerCase();
      }
    }

    return "bin";
  }
}
