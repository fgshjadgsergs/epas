import { access, readFile } from "node:fs/promises";
import { join } from "node:path";
import { Injectable } from "@nestjs/common";
import sharp from "sharp";

interface WatermarkResult {
  buffer: Buffer;
  appliedAt: Date;
}

@Injectable()
export class EstateImageWatermarkService {
  private watermarkBufferPromise: Promise<Buffer> | null = null;

  async applyWatermark(sourceBuffer: Buffer): Promise<WatermarkResult> {
    const sourceImage = sharp(sourceBuffer, {
      animated: true,
    });
    const metadata = await sourceImage.metadata();
    const width = metadata.width ?? 0;
    const height = metadata.height ?? 0;

    if (width <= 0 || height <= 0) {
      return {
        buffer: sourceBuffer,
        appliedAt: new Date(),
      };
    }

    const watermarkBuffer = await this.getPreparedWatermark(width, height);
    const watermarkMetadata = await sharp(watermarkBuffer).metadata();
    const watermarkWidth = watermarkMetadata.width ?? Math.max(220, Math.round(width * 0.28));
    const watermarkHeight = watermarkMetadata.height ?? Math.max(42, Math.round(height * 0.08));
    const composites = this.buildWatermarkLayout(width, height, watermarkBuffer, watermarkWidth, watermarkHeight);

    const buffer = await sharp(sourceBuffer, {
      animated: true,
    })
      .composite(composites)
      .toBuffer();

    return {
      buffer,
      appliedAt: new Date(),
    };
  }

  private async getPreparedWatermark(imageWidth: number, imageHeight: number): Promise<Buffer> {
    const baseWatermark = await this.getWatermarkBuffer();
    const targetWidth = Math.max(220, Math.round(imageWidth * 0.28));
    const maxWidth = Math.max(220, Math.round(imageWidth * 0.34));
    const maxHeight = Math.max(42, Math.round(imageHeight * 0.08));

    return sharp(baseWatermark)
      .resize({
        width: Math.min(targetWidth, maxWidth),
        height: maxHeight,
        fit: "inside",
        withoutEnlargement: true,
      })
      .png()
      .toBuffer();
  }

  private buildWatermarkLayout(
    imageWidth: number,
    imageHeight: number,
    watermarkBuffer: Buffer,
    watermarkWidth: number,
    watermarkHeight: number,
  ): Array<{ input: Buffer; left: number; top: number }> {
    const marginX = Math.max(20, Math.round(imageWidth * 0.04));
    const topY = Math.max(20, Math.round(imageHeight * 0.08));
    const centerY = Math.max(topY + watermarkHeight + 24, Math.round((imageHeight - watermarkHeight) / 2));
    const bottomY = Math.max(topY, imageHeight - watermarkHeight - topY);
    const leftX = marginX;
    const centerX = Math.max(marginX, Math.round((imageWidth - watermarkWidth) / 2));
    const rightX = Math.max(marginX, imageWidth - watermarkWidth - marginX);

    const positions = [
      { left: leftX, top: topY },
      { left: rightX, top: topY },
      { left: centerX, top: centerY },
      { left: leftX, top: bottomY },
      { left: rightX, top: bottomY },
    ];

    return positions
      .filter((position, index, items) => {
        if (position.left < 0 || position.top < 0) {
          return false;
        }

        if (
          position.left > imageWidth - watermarkWidth ||
          position.top > imageHeight - watermarkHeight
        ) {
          return false;
        }

        return (
          items.findIndex(
            (candidate) => candidate.left === position.left && candidate.top === position.top,
          ) === index
        );
      })
      .map((position) => ({
        input: watermarkBuffer,
        left: position.left,
        top: position.top,
      }));
  }

  private async getWatermarkBuffer(): Promise<Buffer> {
    if (!this.watermarkBufferPromise) {
      this.watermarkBufferPromise = this.resolveWatermarkPath().then(async (watermarkPath) => {
        const original = await readFile(watermarkPath);
        return this.extractPrimaryWatermark(original);
      });
    }

    return this.watermarkBufferPromise;
  }

  private async extractPrimaryWatermark(sourceBuffer: Buffer): Promise<Buffer> {
    const watermark = sharp(sourceBuffer);
    const metadata = await watermark.metadata();
    const width = metadata.width ?? 0;
    const height = metadata.height ?? 0;

    if (width <= 0 || height <= 0) {
      return sourceBuffer;
    }

    // The provided source asset contains multiple logo copies across the
    // canvas. We take the exact central logo row bounds so future uploads do
    // not inherit the side duplicates.
    const left = Math.max(0, Math.min(width - 1, 443));
    const top = Math.max(0, Math.min(height - 1, 445));
    const extractedWidth = Math.max(1, Math.min(564, width - left));
    const extractedHeight = Math.max(1, Math.min(37, height - top));

    return sharp(sourceBuffer)
      .extract({
        left,
        top,
        width: extractedWidth,
        height: extractedHeight,
      })
      .png()
      .toBuffer();
  }

  private async resolveWatermarkPath(): Promise<string> {
    const candidates = [
      join(__dirname, "assets", "estate-watermark.png"),
      join(process.cwd(), "apps", "api", "src", "modules", "storage", "assets", "estate-watermark.png"),
      join(process.cwd(), "Vod Znak2.png"),
    ];

    for (const candidate of candidates) {
      try {
        await access(candidate);
        return candidate;
      } catch {
        continue;
      }
    }

    throw new Error("Watermark asset not found");
  }
}
