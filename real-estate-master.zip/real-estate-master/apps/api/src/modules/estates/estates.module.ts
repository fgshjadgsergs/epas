import { Module } from "@nestjs/common";
import { EstateMapper } from "./estate.mapper";
import { EstateQueryParser } from "./estate-query.parser";
import { EstatesController } from "./estates.controller";
import { EstatesService } from "./estates.service";
import { StorageModule } from "../storage/storage.module";

@Module({
  imports: [StorageModule],
  controllers: [EstatesController],
  providers: [EstateQueryParser, EstateMapper, EstatesService],
})
export class EstatesModule {}
