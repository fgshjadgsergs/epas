import { Module } from "@nestjs/common";
import { CrmAuthModule } from "../crm-auth/crm-auth.module";
import { CianSerializer } from "./cian.serializer";
import { CianService } from "./cian.service";
import { CianXmlService } from "./cian-xml.service";
import { CrmCianController } from "./crm-cian.controller";

@Module({
  imports: [CrmAuthModule],
  controllers: [CrmCianController],
  providers: [CianSerializer, CianXmlService, CianService],
  exports: [CianSerializer, CianXmlService, CianService],
})
export class CianModule {}
