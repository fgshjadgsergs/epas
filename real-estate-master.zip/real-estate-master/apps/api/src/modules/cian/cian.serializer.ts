import { Injectable } from "@nestjs/common";
import { decimalToNumber } from "../../common/utils/number.utils";
import {
  AREA_UNIT_DTO_BY_ENUM,
  CIAN_SUBTYPE_ORDER,
  GARAGE_DTO_BY_ENUM,
  READY_BUSINESS_DTO_BY_ENUM,
  VAT_DTO_BY_ENUM,
} from "./cian.constants";
import { AnyCianRecord, EstateWithCianRelations, EstateWithCianXmlRelations, SelectedCianSubtype } from "./cian.types";

type EstateWithAnyCian = EstateWithCianRelations | EstateWithCianXmlRelations;

function parsePhones(raw: string): Array<{ code: string; number: string }> {
  if (!raw) {
    return [];
  }

  return raw.split(";").map((item) => item.trim()).filter(Boolean).map((phone) => ({
    code: phone.slice(0, 2),
    number: phone.slice(2),
  }));
}

function getFirstRecord(estate: EstateWithAnyCian, relationKey: SelectedCianSubtype["relationKey"]): AnyCianRecord | null {
  const relation = estate[relationKey] as AnyCianRecord[] | undefined;
  return relation && relation.length > 0 ? relation[0] : null;
}

@Injectable()
export class CianSerializer {
  toCrmPayload(estate: EstateWithCianRelations): Record<string, unknown> {
    const result: Record<string, unknown> = {
      include: estate.cianIncluded || estate.cianModeration,
      type: null,
      owner_contacts: [],
      vat_type: null,
      ready_business_type: null,
      specialty: null,
      garage_type: null,
      land_area: null,
      land_area_unit: null,
      building_area: null,
    };

    for (const descriptor of CIAN_SUBTYPE_ORDER) {
      const record = getFirstRecord(estate, descriptor.relationKey);
      if (!record) {
        continue;
      }

      result.type = descriptor.dtoType;
      result.owner_contacts = parsePhones(record.phones);

      if ("specialty" in record && record.specialty) {
        result.specialty = record.specialty;
      }
      if ("vatType" in record && record.vatType) {
        result.vat_type = VAT_DTO_BY_ENUM[record.vatType];
      }
      if ("readyBusinessType" in record && record.readyBusinessType) {
        result.ready_business_type = READY_BUSINESS_DTO_BY_ENUM[record.readyBusinessType];
      }
      if ("type_" in record && record.type_) {
        result.garage_type = GARAGE_DTO_BY_ENUM[record.type_];
      }
      if ("area" in record) {
        const landArea = decimalToNumber(record.area);
        if (landArea) {
          result.land_area = landArea;
        }
      }
      if ("unit" in record && record.unit) {
        result.land_area_unit = AREA_UNIT_DTO_BY_ENUM[record.unit];
      }
      if ("buildingArea" in record) {
        const buildingArea = decimalToNumber(record.buildingArea);
        if (buildingArea) {
          result.building_area = buildingArea;
        }
      }
    }

    return result;
  }

  selectFirstSubtypeForXml(estate: EstateWithAnyCian): SelectedCianSubtype | null {
    for (const descriptor of CIAN_SUBTYPE_ORDER) {
      const record = getFirstRecord(estate, descriptor.relationKey);
      if (record) {
        return {
          relationKey: descriptor.relationKey,
          dtoType: descriptor.dtoType,
          record,
        };
      }
    }

    return null;
  }
}
