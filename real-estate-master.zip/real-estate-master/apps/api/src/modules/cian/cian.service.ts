import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { AreaUnitType, GarageType, Prisma, ReadyBusinessType, VatType } from "@prisma/client";
import { Request } from "express";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { AppEnvironment } from "../../config/environment";
import { PrismaService } from "../../prisma/prisma.service";
import {
  AREA_UNIT_ENUM_BY_DTO,
  CIAN_SUBTYPE_ORDER,
  GARAGE_ENUM_BY_DTO,
  READY_BUSINESS_ENUM_BY_DTO,
  VAT_ENUM_BY_DTO,
} from "./cian.constants";
import { CianXmlService } from "./cian-xml.service";
import { CrmEstateCianPayload, ESTATE_WITH_CIAN_XML_INCLUDE, EstateWithCianXmlRelations } from "./cian.types";

const ADMIN_REQUIRED_MESSAGE = "Admin access required";
const REQUIRED_FIELD_MESSAGE = "Field is required";

function parseBoolean(value: boolean | string | null | undefined, fallback: boolean): boolean {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }

  if (typeof value === "boolean") {
    return value;
  }

  return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}

function parseNullableNumber(value: number | string | null | undefined): number | null {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

interface NormalizedCianPayload {
  type: (typeof CIAN_SUBTYPE_ORDER)[number]["relationKey"];
  serializedPhones: string;
  vatType: VatType | null;
  readyBusinessType: ReadyBusinessType | null;
  garageType: GarageType | null;
  specialty: string | null;
  landArea: number | null;
  landAreaUnit: AreaUnitType | null;
  buildingArea: number | null;
}

export class CianValidationException extends Error {
  constructor(readonly errors: Record<string, unknown>) {
    super("CIAN validation failed");
  }
}

@Injectable()
export class CianService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly configService: ConfigService<AppEnvironment, true>,
    private readonly cianXmlService: CianXmlService,
  ) {}

  buildEstateEditFlagPatch(
    payload: CrmEstateCianPayload | null | undefined,
    viewer: AuthenticatedCrmUser,
    existingState: { cianIncluded: boolean; cianModeration: boolean },
  ): Prisma.EstateUncheckedUpdateInput {
    if (!payload) {
      return {};
    }

    if (viewer.is_admin) {
      return {
        cianIncluded: parseBoolean(payload.include, false),
        cianModeration: false,
      };
    }

    return {
      cianIncluded: existingState.cianIncluded,
      cianModeration: parseBoolean(payload.include, false),
    };
  }

  async saveForEditedEstate(
    estateId: number,
    payload: CrmEstateCianPayload | null | undefined,
    request: Request,
  ): Promise<{ status: string; preserved_weird_behavior: string[] }> {
    if (!payload) {
      return {
        status: "skipped_without_cian_payload",
        preserved_weird_behavior: [
          "JSON API can omit the CIAN payload; existing subtype data is preserved when it is omitted.",
        ],
      };
    }

    if (!parseBoolean(payload.include, false)) {
      return {
        status: "exact_for_include_false_short_circuit",
        preserved_weird_behavior: [
          "include=false leaves existing CIAN subtype rows untouched.",
        ],
      };
    }

    const estate = await this.getEstateForCianOrThrow(estateId);
    const normalized = this.validateAndNormalizePayload(payload, estate);
    const previewEstate = this.buildPreviewEstate(estate, normalized);
    this.cianXmlService.assertRenderable(previewEstate, this.cianXmlService.resolveRequestBaseUrl(request));

    await this.prisma.$transaction(async (transaction) => {
      await Promise.all([
        transaction.cianGarage.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianBuilding.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianOffice.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianFreeAppointmentObject.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianIndustry.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianWarehouse.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianShoppingArea.deleteMany({ where: { estateId: BigInt(estateId) } }),
        transaction.cianBusinessSale.deleteMany({ where: { estateId: BigInt(estateId) } }),
      ]);

      switch (normalized.type) {
        case "cianGarages":
          await transaction.cianGarage.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              type_: normalized.garageType as GarageType,
            },
          });
          break;
        case "cianBuildings":
          await transaction.cianBuilding.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            },
          });
          break;
        case "cianOffices":
          await transaction.cianOffice.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              jkId: 0,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            },
          });
          break;
        case "cianFreeAppointmentObjects":
          await transaction.cianFreeAppointmentObject.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              specialty: normalized.specialty as string,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            },
          });
          break;
        case "cianIndustries":
          await transaction.cianIndustry.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            },
          });
          break;
        case "cianWarehouses":
          await transaction.cianWarehouse.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            },
          });
          break;
        case "cianShoppingAreas":
          await transaction.cianShoppingArea.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              specialty: normalized.specialty as string,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            },
          });
          break;
        case "cianBusinessSales":
          await transaction.cianBusinessSale.create({
            data: {
              estateId: BigInt(estateId),
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              readyBusinessType: normalized.readyBusinessType as ReadyBusinessType,
              specialty: normalized.specialty as string,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
            },
          });
          break;
      }
    });

    return {
      status: "exact_for_edit_only_non_atomic_save_cian_flow",
      preserved_weird_behavior: [
        "Base estate and image changes are already committed before CIAN subtype persistence runs.",
        "include=false leaves existing subtype rows untouched.",
        "jk_id remains disabled and is hardcoded to 0 for the supported subtype set.",
      ],
    };
  }

  async createXmlForAdmin(
    viewer: AuthenticatedCrmUser,
    request: Request,
  ): Promise<{ message: string; path: string; generated_objects: number; parity: Record<string, string> }> {
    this.assertAdmin(viewer);

    const estates = await this.prisma.estate.findMany({
      where: {
        active: true,
        cianIncluded: true,
        deletedAt: null,
        isPrivateSale: false,
      },
      include: ESTATE_WITH_CIAN_XML_INCLUDE,
    });

    const result = await this.cianXmlService.writeFeed(
      estates,
      this.cianXmlService.resolveRequestBaseUrl(request),
      this.configService.get("STORAGE_LOCAL_ROOT", { infer: true }),
    );

    return {
      message: "XML файл сформирован",
      path: result.path,
      generated_objects: result.generated_objects,
      parity: {
        xml_generation: "exact_for_manual_sync_storage_file_flow",
        remote_upload: "intentionally_not_implemented",
      },
    };
  }

  async confirmModerationForAdmin(
    viewer: AuthenticatedCrmUser,
    estateIds: number[],
  ): Promise<{ message: string; updated: number; parity: Record<string, string> }> {
    this.assertAdmin(viewer);

    const result = await this.prisma.estate.updateMany({
      where: {
        id: {
          in: estateIds.map((id) => BigInt(id)),
        },
      },
      data: {
        cianIncluded: true,
        cianModeration: false,
      },
    });

    return {
      message: "Объекты отмечены для выгрузки успешно.",
      updated: result.count,
      parity: {
        moderation_confirm: "exact_for_flag_transition_only",
      },
    };
  }

  async removeFromModerationForAdmin(
    viewer: AuthenticatedCrmUser,
    estateIds: number[],
  ): Promise<{ updated: number; parity: Record<string, string> }> {
    this.assertAdmin(viewer);

    const result = await this.prisma.estate.updateMany({
      where: {
        id: {
          in: estateIds.map((id) => BigInt(id)),
        },
      },
      data: {
        cianModeration: false,
      },
    });

    return {
      updated: result.count,
      parity: {
        moderation_delete: "exact_for_flag_transition_only",
      },
    };
  }

  async removeFromUploadForAdmin(
    viewer: AuthenticatedCrmUser,
    estateIds: number[],
  ): Promise<{ updated: number; parity: Record<string, string> }> {
    this.assertAdmin(viewer);

    const result = await this.prisma.estate.updateMany({
      where: {
        id: {
          in: estateIds.map((id) => BigInt(id)),
        },
      },
      data: {
        cianIncluded: false,
      },
    });

    return {
      updated: result.count,
      parity: {
        upload_delete: "exact_for_flag_transition_only_without_xml_regeneration",
      },
    };
  }

  private assertAdmin(viewer: AuthenticatedCrmUser): void {
    if (!viewer.is_admin) {
      throw new ForbiddenException(ADMIN_REQUIRED_MESSAGE);
    }
  }

  private async getEstateForCianOrThrow(estateId: number): Promise<EstateWithCianXmlRelations> {
    const estate = await this.prisma.estate.findUnique({
      where: {
        id: BigInt(estateId),
      },
      include: ESTATE_WITH_CIAN_XML_INCLUDE,
    });

    if (!estate) {
      throw new NotFoundException(`Estate ${estateId} not found`);
    }

    return estate;
  }

  private validateAndNormalizePayload(payload: CrmEstateCianPayload, estate: EstateWithCianXmlRelations): NormalizedCianPayload {
    const type = this.resolveRelationKey(payload.type);
    if (!type) {
      throw new CianValidationException({
        type: REQUIRED_FIELD_MESSAGE,
      });
    }

    const contacts = payload.owner_contacts ?? [];
    if (contacts.length === 0) {
      throw new CianValidationException({
        owner_contacts: "Укажите контакты",
      });
    }
    for (const phone of contacts) {
      if (phone.code !== "+7") {
        throw new CianValidationException({
          owner_contacts: "Код должен быть +7",
        });
      }
      if (String(phone.number ?? "").length !== 10) {
        throw new CianValidationException({
          owner_contacts: "10 цифр должно быть в номере телефона без +7",
        });
      }
    }

    const vatType = payload.vat_type ? VAT_ENUM_BY_DTO[payload.vat_type] ?? null : null;
    const readyBusinessType = payload.ready_business_type
      ? READY_BUSINESS_ENUM_BY_DTO[payload.ready_business_type] ?? null
      : null;
    const garageType = payload.garage_type ? GARAGE_ENUM_BY_DTO[payload.garage_type] ?? null : null;
    const landAreaUnit = payload.land_area_unit ? AREA_UNIT_ENUM_BY_DTO[payload.land_area_unit] ?? null : null;
    const landArea = parseNullableNumber(payload.land_area);
    const buildingArea = parseNullableNumber(payload.building_area);
    const specialty = payload.specialty ? String(payload.specialty) : null;

    switch (type) {
      case "cianGarages":
        if (!garageType) {
          throw new CianValidationException({ garage_type: "Укажите тип гаража" });
        }
        break;
      case "cianBuildings":
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        if (!buildingArea) {
          throw new CianValidationException({ building_area: "Укажите площадь здания" });
        }
        break;
      case "cianOffices":
        if (!estate.floor) {
          throw new CianValidationException({ include: "Этаж требуется для Циан" });
        }
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        if (!buildingArea) {
          throw new CianValidationException({ building_area: "Укажите площадь здания" });
        }
        break;
      case "cianFreeAppointmentObjects":
        if (!estate.floor) {
          throw new CianValidationException({ include: "Этаж требуется для Циан" });
        }
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!specialty) {
          throw new CianValidationException({ specialty: "Укажите назначение" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        if (!buildingArea) {
          throw new CianValidationException({ building_area: "Укажите площадь здания" });
        }
        break;
      case "cianIndustries":
        if (!estate.floor) {
          throw new CianValidationException({ include: "Этаж требуется для Циан" });
        }
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        if (!buildingArea) {
          throw new CianValidationException({ building_area: "Укажите площадь здания" });
        }
        break;
      case "cianWarehouses":
        if (!estate.floor) {
          throw new CianValidationException({ include: "Этаж требуется для Циан" });
        }
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        if (!buildingArea) {
          throw new CianValidationException({ building_area: "Укажите площадь здания" });
        }
        break;
      case "cianShoppingAreas":
        if (!estate.floor) {
          throw new CianValidationException({ include: "Этаж требуется для Циан" });
        }
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        if (!specialty) {
          throw new CianValidationException({ specialty: "Укажите назначение" });
        }
        if (!buildingArea) {
          throw new CianValidationException({ building_area: "Укажите площадь здания" });
        }
        break;
      case "cianBusinessSales":
        if (!estate.map_) {
          throw new CianValidationException({ include: "МАП требуется для Циан" });
        }
        if (!vatType) {
          throw new CianValidationException({ vat_type: "Укажите тип НДС" });
        }
        if (!specialty) {
          throw new CianValidationException({ specialty: "Укажите назначение" });
        }
        if (!readyBusinessType) {
          throw new CianValidationException({ ready_business_type: "Укажите тип бизнеса" });
        }
        if (!landArea) {
          throw new CianValidationException({ land_area: "Укажите площадь земли" });
        }
        if (!landAreaUnit) {
          throw new CianValidationException({ land_area_unit: "Укажите единицу измерения" });
        }
        break;
    }

    return {
      type,
      serializedPhones: contacts.map((contact) => `${contact.code}${contact.number}`).join(";"),
      vatType,
      readyBusinessType,
      garageType,
      specialty,
      landArea,
      landAreaUnit,
      buildingArea,
    };
  }

  private resolveRelationKey(value: string | null | undefined): (typeof CIAN_SUBTYPE_ORDER)[number]["relationKey"] | null {
    const descriptor = CIAN_SUBTYPE_ORDER.find((item) => item.dtoType === value);
    return descriptor?.relationKey ?? null;
  }

  private buildPreviewEstate(estate: EstateWithCianXmlRelations, normalized: NormalizedCianPayload): EstateWithCianXmlRelations {
    return {
      ...estate,
      cianGarages:
        normalized.type === "cianGarages"
          ? [{ id: BigInt(0), estateId: estate.id, phones: normalized.serializedPhones, type_: normalized.garageType as GarageType }]
          : [],
      cianBuildings:
        normalized.type === "cianBuildings"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            }]
          : [],
      cianOffices:
        normalized.type === "cianOffices"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              jkId: 0,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            }]
          : [],
      cianFreeAppointmentObjects:
        normalized.type === "cianFreeAppointmentObjects"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              specialty: normalized.specialty as string,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            }]
          : [],
      cianIndustries:
        normalized.type === "cianIndustries"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            }]
          : [],
      cianWarehouses:
        normalized.type === "cianWarehouses"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            }]
          : [],
      cianShoppingAreas:
        normalized.type === "cianShoppingAreas"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              specialty: normalized.specialty as string,
              jkId: 0,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
              buildingArea: new Prisma.Decimal(normalized.buildingArea as number),
            }]
          : [],
      cianBusinessSales:
        normalized.type === "cianBusinessSales"
          ? [{
              id: BigInt(0),
              estateId: estate.id,
              phones: normalized.serializedPhones,
              vatType: normalized.vatType as VatType,
              readyBusinessType: normalized.readyBusinessType as ReadyBusinessType,
              specialty: normalized.specialty as string,
              area: new Prisma.Decimal(normalized.landArea as number),
              unit: normalized.landAreaUnit as AreaUnitType,
            }]
          : [],
    };
  }
}
