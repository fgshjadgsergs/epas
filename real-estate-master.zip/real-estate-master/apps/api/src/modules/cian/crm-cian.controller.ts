import { Body, Controller, Post, Req, UseGuards } from "@nestjs/common";
import { Request } from "express";
import { CurrentCrmUser } from "../crm-auth/current-crm-user.decorator";
import { CrmAuthGuard } from "../crm-auth/crm-auth.guard";
import { AuthenticatedCrmUser } from "../crm-auth/crm-auth.types";
import { CianService } from "./cian.service";
import { EstateIdsPayload } from "./cian.types";

function parseEstateIds(body: EstateIdsPayload): number[] {
  return (body.estate_ids ?? [])
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);
}

@UseGuards(CrmAuthGuard)
@Controller("api/v1/crm/cian")
export class CrmCianController {
  constructor(private readonly cianService: CianService) {}

  @Post("actions/create-xml")
  createXml(
    @Req() request: Request,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ message: string; path: string; generated_objects: number; parity: Record<string, string> }> {
    return this.cianService.createXmlForAdmin(user, request);
  }

  @Post("moderation/confirm")
  confirmModeration(
    @Body() body: EstateIdsPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ message: string; updated: number; parity: Record<string, string> }> {
    return this.cianService.confirmModerationForAdmin(user, parseEstateIds(body));
  }

  @Post("moderation/remove")
  removeFromModeration(
    @Body() body: EstateIdsPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ updated: number; parity: Record<string, string> }> {
    return this.cianService.removeFromModerationForAdmin(user, parseEstateIds(body));
  }

  @Post("upload/remove")
  removeFromUpload(
    @Body() body: EstateIdsPayload,
    @CurrentCrmUser() user: AuthenticatedCrmUser,
  ): Promise<{ updated: number; parity: Record<string, string> }> {
    return this.cianService.removeFromUploadForAdmin(user, parseEstateIds(body));
  }
}
