import { Injectable } from "@nestjs/common";
import {
  CianBuilding,
  CianBusinessSale,
  CianFreeAppointmentObject,
  CianGarage,
  CianIndustry,
  CianOffice,
  CianShoppingArea,
  CianWarehouse,
  Prisma,
} from "@prisma/client";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { Request } from "express";
import { DEAL_TYPES } from "../../common/domain/domain.constants";
import { bigintToNumber, decimalToNumber } from "../../common/utils/number.utils";
import { RENT_LIKE_DEAL_TYPES } from "./cian.constants";
import { CianSerializer } from "./cian.serializer";
import { EstateWithCianXmlRelations } from "./cian.types";

interface XmlNode {
  name: string;
  text?: string;
  children?: XmlNode[];
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function node(name: string, text?: string, children?: XmlNode[]): XmlNode {
  return {
    name,
    ...(text !== undefined ? { text } : {}),
    ...(children && children.length > 0 ? { children } : {}),
  };
}

function renderXml(nodeValue: XmlNode, depth = 0): string {
  const indent = "  ".repeat(depth);
  const children = nodeValue.children ?? [];

  if (children.length === 0) {
    return `${indent}<${nodeValue.name}>${escapeXml(nodeValue.text ?? "")}</${nodeValue.name}>`;
  }

  const lines = [`${indent}<${nodeValue.name}>`];
  for (const child of children) {
    lines.push(renderXml(child, depth + 1));
  }
  lines.push(`${indent}</${nodeValue.name}>`);

  return lines.join("\n");
}

function intString(value: Prisma.Decimal | number | null | undefined): string {
  const normalized = decimalToNumber(value);
  if (normalized === null) {
    throw new Error("Numeric value required for XML generation");
  }

  return String(Math.trunc(normalized));
}

function normalizeDescription(value: string): string {
  return value.replaceAll("</p>", "\n").replaceAll("<br>", "\n").replace(/<[^>]+>/gs, "");
}

function buildImageUrl(baseUrl: string, relativePath: string): string {
  const normalizedBaseUrl = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const normalizedPath = relativePath.replace(/^\/+/, "");

  return `${normalizedBaseUrl}${normalizedPath}`;
}

function buildBaseChildren(estate: EstateWithCianXmlRelations, phones: string): XmlNode[] {
  return [
    node("ExternalId", String(bigintToNumber(estate.id))),
    node("Description", normalizeDescription(estate.description)),
    node("Address", estate.title),
    node(
      "Phones",
      undefined,
      phones.split(";").map((item) => item.trim()).filter(Boolean).map((phone) =>
        node("PhoneSchema", undefined, [
          node("CountryCode", phone.slice(0, 2)),
          node("Number", phone.slice(2)),
        ])),
    ),
  ];
}

function buildPhotoNode(estate: EstateWithCianXmlRelations, baseUrl: string): XmlNode {
  return node(
    "Photos",
    undefined,
    estate.images.map((image) =>
      node("PhotoSchema", undefined, [
        node("FullUrl", buildImageUrl(baseUrl, image.url)),
        node("IsDefault", image.isMain ? "true" : "false"),
      ])),
  );
}

function buildLandNode(area: Prisma.Decimal, unit: "HECTARE" | "SOTKA"): XmlNode {
  return node("Land", undefined, [node("Area", intString(area)), node("AreaUnitType", unit.toLowerCase())]);
}

function garageXmlType(type: "BOX" | "GARAGE" | "PARKING_PLACE"): string {
  switch (type) {
    case "BOX":
      return "box";
    case "GARAGE":
      return "garage";
    case "PARKING_PLACE":
      return "parkingPlace";
  }
}

function buildBargainTerms(price: Prisma.Decimal, vatType: string, dealType: string): XmlNode {
  const children = [node("Price", intString(price))];

  if (RENT_LIKE_DEAL_TYPES.has(dealType)) {
    children.push(node("PriceType", "all"));
  }

  children.push(node("VatType", vatType));

  if (RENT_LIKE_DEAL_TYPES.has(dealType)) {
    children.push(node("ClientFee", "0"));
    children.push(node("AgentFee", "0"));
  }

  return node("BargainTerms", undefined, children);
}

@Injectable()
export class CianXmlService {
  constructor(private readonly serializer: CianSerializer) {}

  resolveRequestBaseUrl(request: Request): string {
    const forwardedProtocol = request.header("x-forwarded-proto")?.split(",")[0]?.trim();
    const forwardedHost = request.header("x-forwarded-host")?.split(",")[0]?.trim();
    const protocol = forwardedProtocol || request.protocol || "http";
    const host = forwardedHost || request.get("host") || "localhost";

    return `${protocol}://${host}/`;
  }

  assertRenderable(estate: EstateWithCianXmlRelations, baseUrl: string): void {
    this.buildObjectNode(estate, baseUrl);
  }

  buildObjectNode(estate: EstateWithCianXmlRelations, baseUrl: string): XmlNode | null {
    const selected = this.serializer.selectFirstSubtypeForXml(estate);
    if (!selected) {
      return null;
    }

    const baseChildren = buildBaseChildren(estate, selected.record.phones);
    const photoNode = buildPhotoNode(estate, baseUrl);

    switch (selected.relationKey) {
      case "cianGarages": {
        const garage = selected.record as CianGarage;
        const bargainTermsChildren = [node("Price", intString(estate.price))];
        if (estate.dealType === DEAL_TYPES.RENT) {
          bargainTermsChildren.push(node("PriceType", "all"));
          bargainTermsChildren.push(node("ClientFee", "0"));
        }

        return node("object", undefined, [
          node("Category", RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "garageRent" : "garageSale"),
          ...baseChildren,
          node("Garage", undefined, [node("Type", garageXmlType(garage.type_))]),
          node("TotalArea", intString(estate.area)),
          photoNode,
          node("Building"),
          node("BargainTerms", undefined, bargainTermsChildren),
        ]);
      }
      case "cianBuildings": {
        const building = selected.record as CianBuilding;
        return node("object", undefined, [
          node("Category", RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "buildingRent" : "buildingSale"),
          ...baseChildren,
          photoNode,
          node("Building", undefined, [
            node("FloorsCount", String(estate.allFloors)),
            node("TotalArea", intString(building.buildingArea)),
          ]),
          buildLandNode(building.area, building.unit),
          buildBargainTerms(estate.price, building.vatType.toLowerCase(), estate.dealType),
        ]);
      }
      case "cianOffices": {
        const office = selected.record as CianOffice;
        return node("object", undefined, [
          node("Category", RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "officeRent" : "officeSale"),
          ...baseChildren,
          node("TotalArea", intString(estate.area)),
          node("FloorNumber", String(estate.floor)),
          photoNode,
          node("Building", undefined, [
            node("FloorsCount", String(estate.allFloors)),
            node("TotalArea", intString(office.buildingArea)),
          ]),
          buildLandNode(office.area, office.unit),
          buildBargainTerms(estate.price, office.vatType.toLowerCase(), estate.dealType),
        ]);
      }
      case "cianFreeAppointmentObjects": {
        const freeAppointmentObject = selected.record as CianFreeAppointmentObject;
        return node("object", undefined, [
          node(
            "Category",
            RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "freeAppointmentObjectRent" : "freeAppointmentObjectSale",
          ),
          ...baseChildren,
          node("TotalArea", intString(estate.area)),
          node("FloorNumber", String(estate.floor)),
          node("Specialty", undefined, [node("Types", undefined, [node("String", freeAppointmentObject.specialty)])]),
          photoNode,
          node("Building", undefined, [
            node("FloorsCount", String(estate.allFloors)),
            node("TotalArea", intString(freeAppointmentObject.buildingArea)),
          ]),
          buildLandNode(freeAppointmentObject.area, freeAppointmentObject.unit),
          buildBargainTerms(estate.price, freeAppointmentObject.vatType.toLowerCase(), estate.dealType),
        ]);
      }
      case "cianIndustries": {
        const industry = selected.record as CianIndustry;
        return node("object", undefined, [
          node("Category", RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "industryRent" : "industrySale"),
          ...baseChildren,
          node("TotalArea", intString(estate.area)),
          node("FloorNumber", String(estate.floor)),
          photoNode,
          node("Building", undefined, [
            node("FloorsCount", String(estate.allFloors)),
            node("TotalArea", intString(industry.buildingArea)),
          ]),
          buildLandNode(industry.area, industry.unit),
          buildBargainTerms(estate.price, industry.vatType.toLowerCase(), estate.dealType),
        ]);
      }
      case "cianWarehouses": {
        const warehouse = selected.record as CianWarehouse;
        return node("object", undefined, [
          node("Category", RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "warehouseRent" : "warehouseSale"),
          ...baseChildren,
          node("TotalArea", intString(estate.area)),
          node("FloorNumber", String(estate.floor)),
          photoNode,
          node("Building", undefined, [
            node("FloorsCount", String(estate.allFloors)),
            node("TotalArea", intString(warehouse.buildingArea)),
          ]),
          buildLandNode(warehouse.area, warehouse.unit),
          buildBargainTerms(estate.price, warehouse.vatType.toLowerCase(), estate.dealType),
        ]);
      }
      case "cianShoppingAreas": {
        const shoppingArea = selected.record as CianShoppingArea;
        return node("object", undefined, [
          node("Category", RENT_LIKE_DEAL_TYPES.has(estate.dealType) ? "shoppingAreaRent" : "shoppingAreaSale"),
          ...baseChildren,
          node("TotalArea", intString(estate.area)),
          node("FloorNumber", String(estate.floor)),
          node("Specialty", undefined, [node("Types", undefined, [node("String", shoppingArea.specialty)])]),
          photoNode,
          node("Building", undefined, [
            node("FloorsCount", String(estate.allFloors)),
            node("TotalArea", intString(shoppingArea.buildingArea)),
          ]),
          buildLandNode(shoppingArea.area, shoppingArea.unit),
          buildBargainTerms(estate.price, shoppingArea.vatType.toLowerCase(), estate.dealType),
        ]);
      }
      case "cianBusinessSales": {
        const businessSale = selected.record as CianBusinessSale;
        return node("object", undefined, [
          node("Category", "businessSale"),
          node("ReadyBusinessType", businessSale.readyBusinessType === "READY_BUSINESS" ? "readyBusiness" : "rentalBusiness"),
          ...baseChildren,
          node("TotalArea", intString(estate.area)),
          node("Specialty", undefined, [node("Types", undefined, [node("String", businessSale.specialty)])]),
          node("MonthlyIncome", undefined, [node("Income", intString(estate.map_))]),
          photoNode,
          buildLandNode(businessSale.area, businessSale.unit),
          node("BargainTerms", undefined, [
            node("Price", intString(estate.price)),
            node("VatType", businessSale.vatType.toLowerCase()),
          ]),
        ]);
      }
    }
  }

  async writeFeed(
    estates: EstateWithCianXmlRelations[],
    baseUrl: string,
    storageRoot: string,
  ): Promise<{ path: string; generated_objects: number }> {
    const objectNodes = estates
      .map((estate) => this.buildObjectNode(estate, baseUrl))
      .filter((value): value is XmlNode => value !== null);
    const feedNode = node("feed", undefined, [node("feed_version", "2"), ...objectNodes]);
    const output = `${renderXml(feedNode)}\n`;

    await mkdir(storageRoot, { recursive: true });
    await writeFile(join(storageRoot, "cian.xml"), output, "utf8");

    return {
      path: "storage/cian.xml",
      generated_objects: objectNodes.length,
    };
  }
}
