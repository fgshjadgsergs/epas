import { AreaUnitType, GarageType, ReadyBusinessType, VatType } from "@prisma/client";
import { CIAN_TYPES, DEAL_TYPES } from "../../common/domain/domain.constants";

export const CIAN_SUBTYPE_ORDER = [
  { relationKey: "cianGarages", dtoType: CIAN_TYPES.GARAGE },
  { relationKey: "cianBuildings", dtoType: CIAN_TYPES.BUILDING },
  { relationKey: "cianOffices", dtoType: CIAN_TYPES.OFFICE },
  { relationKey: "cianFreeAppointmentObjects", dtoType: CIAN_TYPES.FREE_APPOINTMENT_OBJECT },
  { relationKey: "cianIndustries", dtoType: CIAN_TYPES.INDUSTRY },
  { relationKey: "cianWarehouses", dtoType: CIAN_TYPES.WAREHOUSE },
  { relationKey: "cianShoppingAreas", dtoType: CIAN_TYPES.SHOPPING_AREA },
  { relationKey: "cianBusinessSales", dtoType: CIAN_TYPES.BUSINESS_SALE },
] as const;

export type CianRelationKey = (typeof CIAN_SUBTYPE_ORDER)[number]["relationKey"];

export const VAT_DTO_BY_ENUM: Record<VatType, string> = {
  [VatType.INCLUDED]: "Включен",
  [VatType.USN]: "УСН",
};

export const VAT_ENUM_BY_DTO: Record<string, VatType> = {
  "Включен": VatType.INCLUDED,
  "УСН": VatType.USN,
};

export const GARAGE_DTO_BY_ENUM: Record<GarageType, string> = {
  [GarageType.BOX]: "Бокс",
  [GarageType.GARAGE]: "Гараж",
  [GarageType.PARKING_PLACE]: "Парковочное место",
};

export const GARAGE_ENUM_BY_DTO: Record<string, GarageType> = {
  "Бокс": GarageType.BOX,
  "Гараж": GarageType.GARAGE,
  "Парковочное место": GarageType.PARKING_PLACE,
};

export const READY_BUSINESS_DTO_BY_ENUM: Record<ReadyBusinessType, string> = {
  [ReadyBusinessType.READY_BUSINESS]: "Готовый бизнес",
  [ReadyBusinessType.RENTAL_BUSINESS]: "Арендный бизнес",
};

export const READY_BUSINESS_ENUM_BY_DTO: Record<string, ReadyBusinessType> = {
  "Готовый бизнес": ReadyBusinessType.READY_BUSINESS,
  "Арендный бизнес": ReadyBusinessType.RENTAL_BUSINESS,
};

export const AREA_UNIT_DTO_BY_ENUM: Record<AreaUnitType, string> = {
  [AreaUnitType.HECTARE]: "hectare",
  [AreaUnitType.SOTKA]: "sotka",
};

export const AREA_UNIT_ENUM_BY_DTO: Record<string, AreaUnitType> = {
  hectare: AreaUnitType.HECTARE,
  sotka: AreaUnitType.SOTKA,
};

export const RENT_LIKE_DEAL_TYPES = new Set<string>([DEAL_TYPES.RENT, DEAL_TYPES.RENT_BUSINESS]);
