import {
  CianBuilding,
  CianBusinessSale,
  CianFreeAppointmentObject,
  CianGarage,
  CianIndustry,
  CianOffice,
  CianShoppingArea,
  CianWarehouse,
  Prisma,
} from "@prisma/client";
import { CianRelationKey } from "./cian.constants";

export interface CianPhoneContact {
  code: string;
  number: string;
}

export interface CrmEstateCianPayload {
  include?: boolean | string | null;
  type?: string | null;
  owner_contacts?: CianPhoneContact[] | null;
  vat_type?: string | null;
  ready_business_type?: string | null;
  specialty?: string | null;
  garage_type?: string | null;
  land_area?: number | string | null;
  land_area_unit?: string | null;
  building_area?: number | string | null;
}

export interface EstateIdsPayload {
  estate_ids?: Array<number | string>;
}

export const ESTATE_CIAN_RELATIONS_INCLUDE = {
  cianBuildings: true,
  cianBusinessSales: true,
  cianFreeAppointmentObjects: true,
  cianGarages: true,
  cianIndustries: true,
  cianOffices: true,
  cianShoppingAreas: true,
  cianWarehouses: true,
} as const;

export const ESTATE_WITH_CIAN_INCLUDE = {
  images: true,
  user: true,
  assignments: {
    include: {
      user: true,
    },
    orderBy: {
      createdAt: "asc" as const,
    },
  },
  clientLinks: {
    where: {
      client: {
        deletedAt: null,
      },
    },
    include: {
      client: {
        include: {
          broker: true,
        },
      },
    },
    orderBy: {
      id: "asc",
    },
  },
  ...ESTATE_CIAN_RELATIONS_INCLUDE,
} as const;

export const ESTATE_WITH_CIAN_XML_INCLUDE = {
  images: true,
  ...ESTATE_CIAN_RELATIONS_INCLUDE,
} as const;

export type EstateWithCianRelations = Prisma.EstateGetPayload<{
  include: typeof ESTATE_WITH_CIAN_INCLUDE;
}>;

export type EstateWithCianXmlRelations = Prisma.EstateGetPayload<{
  include: typeof ESTATE_WITH_CIAN_XML_INCLUDE;
}>;

export type AnyCianRecord =
  | CianGarage
  | CianBuilding
  | CianOffice
  | CianFreeAppointmentObject
  | CianIndustry
  | CianWarehouse
  | CianShoppingArea
  | CianBusinessSale;

export interface SelectedCianSubtype {
  relationKey: CianRelationKey;
  dtoType: string;
  record: AnyCianRecord;
}
