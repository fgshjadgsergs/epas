import { BadRequestException, Injectable, UnauthorizedException } from "@nestjs/common";
import { compare } from "bcryptjs";
import { UsersService } from "../users/users.service";
import { AuthenticatedCrmUser, CrmSessionPayload, toAuthenticatedCrmUser } from "./crm-auth.types";

@Injectable()
export class CrmAuthService {
  constructor(private readonly usersService: UsersService) {}

  async validateCredentials(username: string, password: string): Promise<AuthenticatedCrmUser> {
    if (username.length < 3) {
      throw new BadRequestException({
        errors: {
          username: "Ensure username has at least 03 characters",
        },
      });
    }

    if (password.length < 9) {
      throw new BadRequestException({
        errors: {
          password: "Ensure password has at least 09 characters",
        },
      });
    }

    const user = await this.usersService.findByEmail(username);
    if (!user) {
      throw new UnauthorizedException("Invalid username or password");
    }

    const passwordMatches = await compare(password, user.hashedPassword);
    if (!passwordMatches) {
      throw new UnauthorizedException("Invalid username or password");
    }

    return toAuthenticatedCrmUser(user);
  }

  async resolveSessionUser(session: CrmSessionPayload | null | undefined): Promise<AuthenticatedCrmUser | null> {
    const username = session?.username;
    if (!username) {
      return null;
    }

    const user = await this.usersService.findByEmail(username);
    if (!user) {
      return null;
    }

    return toAuthenticatedCrmUser(user);
  }
}
