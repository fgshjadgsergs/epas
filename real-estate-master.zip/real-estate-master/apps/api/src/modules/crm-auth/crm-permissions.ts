import { CrmRole } from "@prisma/client";
import { AuthenticatedCrmUser } from "./crm-auth.types";

type IdLike = number | bigint;

export interface ScopedEstateRef {
  id: IdLike;
  userId?: IdLike | null;
  deletedAt: Date | null;
  assignedUserIds?: IdLike[];
  assignedUsers?: ScopedUserRef[];
}

export interface ScopedClientRef {
  id: IdLike;
  brokerId: IdLike;
  deletedAt: Date | null;
}

export interface ScopedUserRef {
  id: IdLike;
  role: CrmRole;
  ropId: IdLike | null;
}

function toNumber(value: IdLike | null | undefined): number | null {
  if (value === null || value === undefined) {
    return null;
  }

  return typeof value === "bigint" ? Number(value) : value;
}

export function isOwner(actor: AuthenticatedCrmUser): boolean {
  return actor.role === CrmRole.OWNER;
}

export function isAdmin(actor: AuthenticatedCrmUser): boolean {
  return actor.role === CrmRole.ADMIN;
}

export function isRop(actor: AuthenticatedCrmUser): boolean {
  return actor.role === CrmRole.ROP;
}

export function isBroker(actor: AuthenticatedCrmUser): boolean {
  return actor.role === CrmRole.BROKER;
}

export function isViewer(actor: AuthenticatedCrmUser): boolean {
  return actor.role === CrmRole.VIEWER;
}

export function isOwnEstate(actor: AuthenticatedCrmUser, estate: ScopedEstateRef): boolean {
  return getAssignedUserIds(estate).includes(actor.id);
}

export function isBrokerInActorsTeam(actor: AuthenticatedCrmUser, broker: ScopedUserRef): boolean {
  return isRop(actor) && broker.role === CrmRole.BROKER && toNumber(broker.ropId) === actor.id;
}

export function isTeamEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  return isRop(actor) && getAssignedUsers(estate, estateBroker).some((user) => isBrokerInActorsTeam(actor, user));
}

function getAssignedUserIds(estate: ScopedEstateRef): number[] {
  if (estate.assignedUserIds && estate.assignedUserIds.length > 0) {
    return estate.assignedUserIds
      .map((value) => toNumber(value))
      .filter((value): value is number => value !== null);
  }

  const legacyUserId = toNumber(estate.userId);
  return legacyUserId === null ? [] : [legacyUserId];
}

function getAssignedUsers(estate: ScopedEstateRef, estateBroker?: ScopedUserRef): ScopedUserRef[] {
  if (estate.assignedUsers && estate.assignedUsers.length > 0) {
    return estate.assignedUsers;
  }

  return estateBroker ? [estateBroker] : [];
}

export function canAssignRole(actor: AuthenticatedCrmUser, nextRole: CrmRole): boolean {
  if (isOwner(actor)) {
    return true;
  }

  if (isAdmin(actor)) {
    return nextRole !== CrmRole.OWNER;
  }

  if (isRop(actor)) {
    return nextRole === CrmRole.BROKER || nextRole === CrmRole.VIEWER;
  }

  return false;
}

export function canManageUser(actor: AuthenticatedCrmUser, target: ScopedUserRef): boolean {
  if (isOwner(actor)) {
    return true;
  }

  if (isAdmin(actor)) {
    return target.role !== CrmRole.OWNER;
  }

  if (isRop(actor)) {
    return isBrokerInActorsTeam(actor, target) || (target.role === CrmRole.VIEWER && toNumber(target.ropId) === actor.id);
  }

  return false;
}

export function canViewEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  if (estate.deletedAt) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, estateBroker);
  }

  if (isBroker(actor)) {
    return true;
  }

  if (isViewer(actor)) {
    return false;
  }

  return false;
}

export function canViewArchivedEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  if (!estate.deletedAt) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, estateBroker);
  }

  if (isBroker(actor)) {
    return true;
  }

  return false;
}

export function canEditEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  if (estate.deletedAt) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, estateBroker);
  }

  if (isBroker(actor)) {
    return isOwnEstate(actor, estate);
  }

  return false;
}

export function canSoftDeleteEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  if (estate.deletedAt) {
    return false;
  }

  if (isBroker(actor)) {
    return isOwnEstate(actor, estate);
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, estateBroker);
  }

  return false;
}

export function canHardDeleteEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
): boolean {
  if (estate.deletedAt) {
    return false;
  }

  return isOwner(actor) || isAdmin(actor);
}

export function canRestoreEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  if (!estate.deletedAt) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, estateBroker);
  }

  if (isBroker(actor)) {
    return isOwnEstate(actor, estate);
  }

  return false;
}

export function canViewOwnerContacts(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  if (!canViewEstate(actor, estate, estateBroker)) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, estateBroker);
  }

  if (isBroker(actor)) {
    return isOwnEstate(actor, estate);
  }

  return false;
}

export function canViewInternalEstateFields(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  estateBroker: ScopedUserRef,
): boolean {
  return canViewEstate(actor, estate, estateBroker) && !isViewer(actor);
}

export function canReassignEstate(
  actor: AuthenticatedCrmUser,
  estate: ScopedEstateRef,
  currentBroker: ScopedUserRef,
  nextBroker: ScopedUserRef,
): boolean {
  if (estate.deletedAt) {
    return false;
  }

  if (nextBroker.role !== CrmRole.BROKER) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamEstate(actor, estate, currentBroker) && isBrokerInActorsTeam(actor, nextBroker);
  }

  return false;
}

export function isOwnClient(actor: AuthenticatedCrmUser, client: ScopedClientRef): boolean {
  return toNumber(client.brokerId) === actor.id;
}

export function isTeamClient(
  actor: AuthenticatedCrmUser,
  client: ScopedClientRef,
  clientBroker: ScopedUserRef,
): boolean {
  return isRop(actor) && isBrokerInActorsTeam(actor, clientBroker) && toNumber(client.brokerId) === toNumber(clientBroker.id);
}

export function canViewClient(
  actor: AuthenticatedCrmUser,
  client: ScopedClientRef,
  clientBroker: ScopedUserRef,
): boolean {
  if (client.deletedAt) {
    return false;
  }

  if (isOwner(actor) || isAdmin(actor)) {
    return true;
  }

  if (isRop(actor)) {
    return isTeamClient(actor, client, clientBroker);
  }

  if (isBroker(actor)) {
    return isOwnClient(actor, client);
  }

  return false;
}

export function canEditClient(
  actor: AuthenticatedCrmUser,
  client: ScopedClientRef,
  clientBroker: ScopedUserRef,
): boolean {
  return canViewClient(actor, client, clientBroker);
}

export function canSoftDeleteClient(
  actor: AuthenticatedCrmUser,
  client: ScopedClientRef,
  clientBroker: ScopedUserRef,
): boolean {
  return canViewClient(actor, client, clientBroker);
}

export function canViewClientContacts(
  actor: AuthenticatedCrmUser,
  client: ScopedClientRef,
  clientBroker: ScopedUserRef,
): boolean {
  return canViewClient(actor, client, clientBroker);
}
