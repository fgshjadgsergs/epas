import { CrmRole, User } from "@prisma/client";

export interface CrmSessionPayload {
  username?: string;
  user_id?: number;
}

export interface AuthenticatedCrmUser {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  role: CrmRole;
  rop_id: number | null;
  is_admin: boolean;
}

export function toAuthenticatedCrmUser(user: User): AuthenticatedCrmUser {
  const role = user.role;

  return {
    id: Number(user.id),
    email: user.email,
    first_name: user.firstName,
    last_name: user.lastName,
    phone_number: user.phoneNumber,
    role,
    rop_id: user.ropId === null ? null : Number(user.ropId),
    is_admin: role === CrmRole.OWNER || role === CrmRole.ADMIN,
  };
}
