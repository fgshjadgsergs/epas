import { CanActivate, ExecutionContext, Injectable, Logger, UnauthorizedException } from "@nestjs/common";
import { Request } from "express";
import { CrmAuthService } from "./crm-auth.service";
import { AuthenticatedCrmUser, CrmSessionPayload } from "./crm-auth.types";

type CrmRequest = Request & {
  session?: CrmSessionPayload | null;
  crmUser?: AuthenticatedCrmUser;
};

function readUserAgent(request: Request): string {
  const userAgent = request.headers["user-agent"];
  const value = Array.isArray(userAgent) ? userAgent.join(" ") : userAgent;

  return (value ?? "-").replace(/\s+/g, " ").slice(0, 180);
}

@Injectable()
export class CrmAuthGuard implements CanActivate {
  private readonly logger = new Logger(CrmAuthGuard.name);

  constructor(private readonly crmAuthService: CrmAuthService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<CrmRequest>();
    const user = await this.crmAuthService.resolveSessionUser(request.session);

    if (!user) {
      this.logger.warn(`unauthorized path=${request.originalUrl ?? request.url} ua=${readUserAgent(request)}`);
      throw new UnauthorizedException("Authentication required");
    }

    request.crmUser = user;
    return true;
  }
}
