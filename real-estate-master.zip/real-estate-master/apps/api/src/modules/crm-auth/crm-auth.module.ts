import { Module } from "@nestjs/common";
import { UsersModule } from "../users/users.module";
import { CrmAuthController } from "./crm-auth.controller";
import { CrmAuthGuard } from "./crm-auth.guard";
import { CrmAuthService } from "./crm-auth.service";

@Module({
  imports: [UsersModule],
  controllers: [CrmAuthController],
  providers: [CrmAuthService, CrmAuthGuard],
  exports: [CrmAuthService, CrmAuthGuard],
})
export class CrmAuthModule {}
