import { Body, Controller, Get, Logger, Post, Req, UseGuards } from "@nestjs/common";
import { Request } from "express";
import { CurrentCrmUser } from "./current-crm-user.decorator";
import { CrmAuthGuard } from "./crm-auth.guard";
import { CrmAuthService } from "./crm-auth.service";
import { AuthenticatedCrmUser, CrmSessionPayload } from "./crm-auth.types";

type CrmRequest = Request & {
  session?: CrmSessionPayload | null;
};

function readUserAgent(request: Request): string {
  const userAgent = request.headers["user-agent"];
  const value = Array.isArray(userAgent) ? userAgent.join(" ") : userAgent;

  return (value ?? "-").replace(/\s+/g, " ").slice(0, 180);
}

@Controller("api/v1/crm/auth")
export class CrmAuthController {
  private readonly logger = new Logger(CrmAuthController.name);

  constructor(private readonly crmAuthService: CrmAuthService) {}

  @Post("login")
  async login(
    @Body("username") username: string,
    @Body("password") password: string,
    @Req() request: CrmRequest,
  ): Promise<{ user: AuthenticatedCrmUser }> {
    const user = await this.crmAuthService.validateCredentials(username ?? "", password ?? "");

    if (!request.session) {
      request.session = {};
    }

    request.session.username = user.email;
    request.session.user_id = user.id;

    this.logger.log(`login success userId=${user.id} email=${user.email} ua=${readUserAgent(request)}`);

    return { user };
  }

  @UseGuards(CrmAuthGuard)
  @Get("me")
  getCurrentUser(@CurrentCrmUser() user: AuthenticatedCrmUser): { user: AuthenticatedCrmUser } {
    return { user };
  }

  @Post("logout")
  logout(@Req() request: CrmRequest): { ok: true } {
    if (request.session) {
      request.session = null;
    }

    return { ok: true };
  }
}
