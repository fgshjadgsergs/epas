import { createParamDecorator, ExecutionContext, UnauthorizedException } from "@nestjs/common";
import { Request } from "express";
import { AuthenticatedCrmUser } from "./crm-auth.types";

type CrmRequest = Request & {
  crmUser?: AuthenticatedCrmUser;
};

export const CurrentCrmUser = createParamDecorator(
  (_: unknown, context: ExecutionContext): AuthenticatedCrmUser => {
    const request = context.switchToHttp().getRequest<CrmRequest>();
    if (!request.crmUser) {
      throw new UnauthorizedException("Authentication required");
    }

    return request.crmUser;
  },
);
