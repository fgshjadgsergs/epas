import { readdir, stat } from "node:fs/promises";
import { basename, extname, join } from "node:path";
import { PrismaClient } from "@prisma/client";
import { bigintToNumber } from "../common/utils/number.utils";

interface RepairOptions {
  dryRun: boolean;
  estateIds: number[];
  storageRoot: string;
}

interface CandidateMatch {
  url: string;
  filename: string;
  distance: number;
}

const DEFAULT_ESTATE_IDS = [343, 344, 345, 346];

function parsePositiveIntegerList(value: string | undefined, fallback: number[]): number[] {
  if (!value) {
    return fallback;
  }

  const parsed = value
    .split(",")
    .map((item) => Number.parseInt(item.trim(), 10))
    .filter((item) => Number.isInteger(item) && item > 0);

  return parsed.length > 0 ? parsed : fallback;
}

function parseOptions(argv: string[]): RepairOptions {
  const estateIdsArg = argv.find((argument) => argument.startsWith("--estate-ids="));
  const storageRootArg = argv.find((argument) => argument.startsWith("--storage-root="));

  return {
    dryRun: !argv.includes("--write"),
    estateIds: parsePositiveIntegerList(estateIdsArg?.split("=")[1], DEFAULT_ESTATE_IDS),
    storageRoot: storageRootArg?.split("=")[1]?.trim() || process.env.STORAGE_LOCAL_ROOT || "storage",
  };
}

function normalizeStoragePath(path: string): string {
  return path.replace(/\\/g, "/").replace(/^\/+/, "").replace(/^storage\//, "");
}

function toImageUrl(estateId: number, filename: string): string {
  return `storage/real-estates/${estateId}/${filename}`;
}

function levenshteinDistance(left: string, right: string): number {
  const distances = Array.from({ length: left.length + 1 }, (_, index) => index);

  for (let rightIndex = 1; rightIndex <= right.length; rightIndex += 1) {
    let previous = distances[0];
    distances[0] = rightIndex;

    for (let leftIndex = 1; leftIndex <= left.length; leftIndex += 1) {
      const current = distances[leftIndex];
      const cost = left[leftIndex - 1] === right[rightIndex - 1] ? 0 : 1;
      distances[leftIndex] = Math.min(distances[leftIndex] + 1, distances[leftIndex - 1] + 1, previous + cost);
      previous = current;
    }
  }

  return distances[left.length];
}

async function fileExists(storageRoot: string, imageUrl: string): Promise<boolean> {
  const normalized = normalizeStoragePath(imageUrl);

  try {
    const result = await stat(join(storageRoot, normalized));
    return result.isFile();
  } catch {
    return false;
  }
}

async function listEstateFilenames(storageRoot: string, estateId: number): Promise<string[]> {
  try {
    const directoryEntries = await readdir(join(storageRoot, "real-estates", String(estateId)), {
      withFileTypes: true,
    });

    return directoryEntries.filter((entry) => entry.isFile()).map((entry) => entry.name);
  } catch {
    return [];
  }
}

function findObviousMatch(
  estateId: number,
  imageUrl: string,
  filenames: string[],
  referencedUrls: Set<string>,
): CandidateMatch | null {
  const expectedFilename = basename(imageUrl);
  const expectedExtension = extname(expectedFilename).toLowerCase();
  const expectedStem = expectedFilename.slice(0, expectedFilename.length - expectedExtension.length);
  const candidates = filenames
    .filter((filename) => extname(filename).toLowerCase() === expectedExtension)
    .map((filename) => {
      const extension = extname(filename);
      const stem = filename.slice(0, filename.length - extension.length);
      return {
        url: toImageUrl(estateId, filename),
        filename,
        distance: levenshteinDistance(expectedStem, stem),
      };
    })
    .filter((candidate) => candidate.distance > 0 && candidate.distance <= 2)
    .filter((candidate) => !referencedUrls.has(candidate.url))
    .sort((left, right) => left.distance - right.distance || left.filename.localeCompare(right.filename));

  if (candidates.length === 0) {
    return null;
  }

  if (candidates.length > 1 && candidates[0].distance === candidates[1].distance) {
    return null;
  }

  return candidates[0];
}

async function main(): Promise<void> {
  const options = parseOptions(process.argv.slice(2));
  const prisma = new PrismaClient();
  let seen = 0;
  let existing = 0;
  let repairable = 0;
  let updated = 0;
  let unresolved = 0;

  console.log(
    `[image-path-repair] start dryRun=${options.dryRun} estateIds=${options.estateIds.join(",")} storageRoot=${options.storageRoot}`,
  );

  try {
    for (const estateId of options.estateIds) {
      const images = await prisma.image.findMany({
        where: {
          estateId: BigInt(estateId),
        },
        orderBy: {
          id: "asc",
        },
      });
      const filenames = await listEstateFilenames(options.storageRoot, estateId);
      const referencedUrls = new Set(images.map((image) => image.url));

      console.log(
        `[image-path-repair] estate=${estateId} dbImages=${images.length} fsFiles=${filenames.length}`,
      );

      for (const image of images) {
        seen += 1;
        const imageId = bigintToNumber(image.id);

        if (await fileExists(options.storageRoot, image.url)) {
          existing += 1;
          console.log(`[image-path-repair] ok image=${imageId} estate=${estateId} path=${image.url}`);
          continue;
        }

        const match = findObviousMatch(estateId, image.url, filenames, referencedUrls);
        if (!match) {
          unresolved += 1;
          console.warn(`[image-path-repair] unresolved image=${imageId} estate=${estateId} dbPath=${image.url}`);
          continue;
        }

        repairable += 1;
        console.log(
          `[image-path-repair] ${options.dryRun ? "dry-run" : "update"} image=${imageId} estate=${estateId} from=${image.url} to=${match.url} filename=${match.filename} distance=${match.distance}`,
        );

        if (!options.dryRun) {
          await prisma.image.update({
            where: {
              id: image.id,
            },
            data: {
              url: match.url,
            },
          });
          referencedUrls.delete(image.url);
          referencedUrls.add(match.url);
          updated += 1;
        }
      }
    }
  } finally {
    await prisma.$disconnect();
  }

  console.log(
    `[image-path-repair] done seen=${seen} existing=${existing} repairable=${repairable} updated=${updated} unresolved=${unresolved} dryRun=${options.dryRun}`,
  );
}

void main().catch((error) => {
  console.error("[image-path-repair] fatal", error);
  process.exitCode = 1;
});
