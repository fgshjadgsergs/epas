import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { AppModule } from "../app.module";
import { bigintToNumber } from "../common/utils/number.utils";
import { normalizePhone } from "../common/utils/phone.utils";
import { PrismaService } from "../prisma/prisma.service";

async function main(): Promise<void> {
  const app = await NestFactory.createApplicationContext(AppModule, { logger: false });
  const prisma = app.get(PrismaService);

  try {
    const clients = await prisma.client.findMany({
      where: { deletedAt: null, phone: { not: null } },
      select: {
        id: true,
        name: true,
        phone: true,
        broker: {
          select: {
            email: true,
            firstName: true,
            lastName: true,
          },
        },
      },
      orderBy: { id: "asc" },
    });
    const groups = new Map<string, typeof clients>();

    for (const client of clients) {
      const normalized = normalizePhone(client.phone);
      if (!normalized) {
        continue;
      }
      groups.set(normalized, [...(groups.get(normalized) ?? []), client]);
    }

    const duplicates = [...groups.entries()]
      .filter(([, items]) => items.length > 1)
      .map(([phoneNormalized, items]) => ({
        phoneNormalized,
        clients: items.map((client) => ({
          id: bigintToNumber(client.id),
          name: client.name,
          phone: client.phone,
          broker: `${client.broker.firstName} ${client.broker.lastName}`.trim() || client.broker.email,
        })),
      }));

    console.log(`[client-phone-audit] scanned=${clients.length} duplicateGroups=${duplicates.length}`);
    console.log(JSON.stringify(duplicates, null, 2));
  } finally {
    await app.close();
  }
}

void main().catch((error) => {
  console.error("[client-phone-audit] failed", error);
  process.exitCode = 1;
});