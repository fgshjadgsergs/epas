import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { Image } from "@prisma/client";
import { bigintToNumber } from "../common/utils/number.utils";
import { AppModule } from "../app.module";
import { StorageService } from "../modules/storage/storage.service";
import { PrismaService } from "../prisma/prisma.service";

interface BackfillOptions {
  dryRun: boolean;
  force: boolean;
  batchSize: number;
  limit: number | null;
  estateId: number | null;
}

function parsePositiveInteger(value: string | undefined, fallback: number | null): number | null {
  if (!value) {
    return fallback;
  }

  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function parseOptions(argv: string[]): BackfillOptions {
  const dryRun = argv.includes("--dry-run");
  const force = argv.includes("--force");
  const batchSizeArg = argv.find((argument) => argument.startsWith("--batch-size="));
  const limitArg = argv.find((argument) => argument.startsWith("--limit="));
  const estateIdArg = argv.find((argument) => argument.startsWith("--estate-id="));

  return {
    dryRun,
    force,
    batchSize: parsePositiveInteger(batchSizeArg?.split("=")[1], 25) ?? 25,
    limit: parsePositiveInteger(limitArg?.split("=")[1], null),
    estateId: parsePositiveInteger(estateIdArg?.split("=")[1], null),
  };
}

function isMissingStorageSource(error: unknown): boolean {
  if (!error || typeof error !== "object") {
    return false;
  }

  const record = error as {
    code?: unknown;
    name?: unknown;
    $metadata?: {
      httpStatusCode?: number;
    };
  };

  return (
    record.code === "ENOENT" ||
    record.code === "NoSuchKey" ||
    record.code === "NotFound" ||
    record.name === "NoSuchKey" ||
    record.$metadata?.httpStatusCode === 404
  );
}

async function main(): Promise<void> {
  const options = parseOptions(process.argv.slice(2));
  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ["log", "warn", "error"],
  });

  const prisma = app.get(PrismaService);
  const storageService = app.get(StorageService);
  let cursor: bigint | null = null;
  let seen = 0;
  let updated = 0;
  let skippedMissing = 0;
  let failed = 0;

  try {
    console.log(
      `[watermark-backfill] start dryRun=${options.dryRun} force=${options.force} batchSize=${options.batchSize} limit=${options.limit ?? "all"} estateId=${options.estateId ?? "all"}`,
    );

    while (true) {
      const remaining = options.limit === null ? options.batchSize : Math.max(options.limit - seen, 0);
      if (remaining === 0) {
        break;
      }

      const images: Image[] = await prisma.image.findMany({
        where: {
          ...(options.force ? {} : { watermarkAppliedAt: null }),
          ...(options.estateId === null ? {} : { estateId: BigInt(options.estateId) }),
          ...(cursor === null ? {} : { id: { gt: cursor } }),
        },
        orderBy: {
          id: "asc",
        },
        take: Math.min(options.batchSize, remaining),
      });

      if (images.length === 0) {
        break;
      }

      for (const image of images) {
        seen += 1;
        const imageId = bigintToNumber(image.id);
        const estateId = bigintToNumber(image.estateId);

        if (options.dryRun) {
          console.log(
            `[watermark-backfill] dry-run image=${imageId} estate=${estateId} path=${image.url} alreadyWatermarked=${Boolean(image.watermarkAppliedAt)}`,
          );
          continue;
        }

        try {
          const watermarkAppliedAt = await storageService.applyWatermarkToExistingEstateImage(image.url);
          await prisma.image.update({
            where: {
              id: image.id,
            },
            data: {
              watermarkAppliedAt,
            },
          });

          updated += 1;
          console.log(`[watermark-backfill] updated image=${imageId} estate=${estateId}`);
        } catch (error) {
          if (isMissingStorageSource(error)) {
            skippedMissing += 1;
            console.warn(`[watermark-backfill] skipped missing file image=${imageId} estate=${estateId} path=${image.url}`);
            continue;
          }

          failed += 1;
          console.error(`[watermark-backfill] failed image=${imageId} estate=${estateId}:`, error);
        }
      }

      cursor = images[images.length - 1]?.id ?? cursor;
    }

    console.log(
      `[watermark-backfill] done seen=${seen} updated=${updated} skippedMissing=${skippedMissing} failed=${failed} dryRun=${options.dryRun} force=${options.force}`,
    );
  } finally {
    await app.close();
  }
}

void main().catch((error) => {
  console.error("[watermark-backfill] fatal", error);
  process.exitCode = 1;
});
