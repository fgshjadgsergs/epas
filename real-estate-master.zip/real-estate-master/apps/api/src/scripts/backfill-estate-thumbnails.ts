import "reflect-metadata";
import { stat } from "node:fs/promises";
import { resolve } from "node:path";
import { NestFactory } from "@nestjs/core";
import { Image } from "@prisma/client";
import sharp from "sharp";
import { AppModule } from "../app.module";
import { bigintToNumber } from "../common/utils/number.utils";
import { StorageService } from "../modules/storage/storage.service";
import { PrismaService } from "../prisma/prisma.service";

interface BackfillOptions {
  dryRun: boolean;
  force: boolean;
  all: boolean;
  estateIds: number[];
  storageRoot: string;
  batchSize: number;
}

interface OriginalStats {
  imageId: number;
  estateId: number;
  path: string;
  sizeMb: number;
  width: number | null;
  height: number | null;
  format: string | null;
}

function parsePositiveInteger(value: string | undefined, fallback: number): number {
  const parsed = Number.parseInt(value ?? "", 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function parsePositiveIntegerList(value: string | undefined): number[] {
  return (value ?? "")
    .split(",")
    .map((item) => Number.parseInt(item.trim(), 10))
    .filter((item) => Number.isInteger(item) && item > 0);
}

function parseOptions(argv: string[]): BackfillOptions {
  const estateIdsArg = argv.find((argument) => argument.startsWith("--estate-ids="));
  const storageRootArg = argv.find((argument) => argument.startsWith("--storage-root="));
  const batchSizeArg = argv.find((argument) => argument.startsWith("--batch-size="));
  const estateIds = parsePositiveIntegerList(estateIdsArg?.split("=")[1]);

  return {
    dryRun: !argv.includes("--write"),
    force: argv.includes("--force"),
    all: argv.includes("--all") || estateIds.length === 0,
    estateIds,
    storageRoot: storageRootArg?.split("=")[1]?.trim() || process.env.STORAGE_LOCAL_ROOT || "storage",
    batchSize: parsePositiveInteger(batchSizeArg?.split("=")[1], 50),
  };
}

function normalizeStoragePath(path: string): string {
  return path.replace(/\\/g, "/").replace(/^\/+/, "").replace(/^storage\//, "");
}

function isMissingStorageSource(error: unknown): boolean {
  if (!error || typeof error !== "object") {
    return false;
  }

  const record = error as {
    code?: unknown;
    name?: unknown;
    $metadata?: {
      httpStatusCode?: number;
    };
  };

  return (
    record.code === "ENOENT" ||
    record.code === "NoSuchKey" ||
    record.code === "NotFound" ||
    record.name === "NoSuchKey" ||
    record.$metadata?.httpStatusCode === 404
  );
}

async function readOriginalStats(storageRoot: string, image: Image): Promise<OriginalStats | null> {
  const filePath = resolve(storageRoot, normalizeStoragePath(image.url));

  try {
    const [fileStat, metadata] = await Promise.all([
      stat(filePath),
      sharp(filePath, { animated: true }).metadata(),
    ]);

    return {
      imageId: bigintToNumber(image.id),
      estateId: bigintToNumber(image.estateId),
      path: image.url,
      sizeMb: Number((fileStat.size / 1024 / 1024).toFixed(2)),
      width: metadata.width ?? null,
      height: metadata.height ?? null,
      format: metadata.format ?? null,
    };
  } catch {
    return null;
  }
}

function pushLargest(largest: OriginalStats[], stats: OriginalStats): void {
  largest.push(stats);
  largest.sort((left, right) => right.sizeMb - left.sizeMb);
  largest.splice(10);
}

async function main(): Promise<void> {
  const options = parseOptions(process.argv.slice(2));
  process.env.STORAGE_LOCAL_ROOT = options.storageRoot;

  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ["log", "warn", "error"],
  });
  const prisma = app.get(PrismaService);
  const storageService = app.get(StorageService);
  let cursor: bigint | null = null;
  let seen = 0;
  let skipped = 0;
  let generated = 0;
  let errors = 0;
  const largestOriginals: OriginalStats[] = [];

  try {
    console.log(
      `[image-thumbs-backfill] start dryRun=${options.dryRun} force=${options.force} all=${options.all} estateIds=${options.estateIds.join(",") || "-"} storageRoot=${options.storageRoot} batchSize=${options.batchSize}`,
    );

    while (true) {
      const images: Image[] = await prisma.image.findMany({
        where: {
          ...(options.force ? {} : { thumbnailUrl: null }),
          ...(options.all ? {} : { estateId: { in: options.estateIds.map((estateId) => BigInt(estateId)) } }),
          ...(cursor === null ? {} : { id: { gt: cursor } }),
        },
        orderBy: {
          id: "asc",
        },
        take: options.batchSize,
      });

      if (images.length === 0) {
        break;
      }

      for (const image of images) {
        seen += 1;
        const imageId = bigintToNumber(image.id);
        const estateId = bigintToNumber(image.estateId);
        const stats = await readOriginalStats(options.storageRoot, image);
        if (stats) {
          pushLargest(largestOriginals, stats);
        }

        if (image.thumbnailUrl && !options.force) {
          skipped += 1;
          console.log(`[image-thumbs-backfill] skip image=${imageId} estate=${estateId} reason=has_thumbnail`);
          continue;
        }

        if (options.dryRun) {
          skipped += 1;
          console.log(
            `[image-thumbs-backfill] dry-run image=${imageId} estate=${estateId} path=${image.url} sizeMb=${stats?.sizeMb ?? "?"} dimensions=${stats?.width ?? "?"}x${stats?.height ?? "?"}`,
          );
          continue;
        }

        try {
          const thumbnailPath = await storageService.generateThumbnailForExistingEstateImage(image.url, {
            force: options.force,
          });
          await prisma.image.update({
            where: {
              id: image.id,
            },
            data: {
              thumbnailUrl: thumbnailPath,
            },
          });

          generated += 1;
          console.log(`[image-thumbs-backfill] generated image=${imageId} estate=${estateId} thumbnail=${thumbnailPath}`);
        } catch (error) {
          errors += 1;
          if (isMissingStorageSource(error)) {
            console.warn(`[image-thumbs-backfill] missing image=${imageId} estate=${estateId} path=${image.url}`);
            continue;
          }

          console.error(`[image-thumbs-backfill] error image=${imageId} estate=${estateId} path=${image.url}`, error);
        }
      }

      cursor = images[images.length - 1]?.id ?? cursor;
    }

    console.log(
      `[image-thumbs-backfill] done seen=${seen} skipped=${skipped} generated=${generated} errors=${errors} largestOriginals=${JSON.stringify(largestOriginals)}`,
    );
  } finally {
    await app.close();
  }
}

void main().catch((error) => {
  console.error("[image-thumbs-backfill] fatal", error);
  process.exitCode = 1;
});
