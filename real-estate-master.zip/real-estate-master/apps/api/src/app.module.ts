import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { validateEnvironment } from "./config/environment";
import { AvitoModule } from "./modules/avito/avito.module";
import { CianModule } from "./modules/cian/cian.module";
import { CrmAuthModule } from "./modules/crm-auth/crm-auth.module";
import { CrmClientsModule } from "./modules/crm-clients/crm-clients.module";
import { CrmDealsModule } from "./modules/crm-deals/crm-deals.module";
import { CrmEstatesModule } from "./modules/crm-estates/crm-estates.module";
import { CrmMatchingModule } from "./modules/crm-matching/crm-matching.module";
import { CrmMetaModule } from "./modules/crm-meta/crm-meta.module";
import { CrmUsersModule } from "./modules/crm-users/crm-users.module";
import { EstatesModule } from "./modules/estates/estates.module";
import { HealthModule } from "./modules/health/health.module";
import { StorageModule } from "./modules/storage/storage.module";
import { UsersModule } from "./modules/users/users.module";
import { YandexMapsModule } from "./modules/yandex-maps/yandex-maps.module";
import { PrismaModule } from "./prisma/prisma.module";

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      cache: true,
      expandVariables: true,
      validate: validateEnvironment,
    }),
    PrismaModule,
    StorageModule,
    UsersModule,
    CrmAuthModule,
    AvitoModule,
    CianModule,
    CrmClientsModule,
    CrmDealsModule,
    CrmMatchingModule,
    CrmUsersModule,
    CrmEstatesModule,
    CrmMetaModule,
    YandexMapsModule,
    HealthModule,
    EstatesModule,
  ],
})
export class AppModule {}
