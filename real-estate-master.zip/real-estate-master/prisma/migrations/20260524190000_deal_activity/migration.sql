CREATE TABLE "deal_comments" (
  "id" BIGSERIAL NOT NULL,
  "link_id" BIGINT NOT NULL,
  "author_id" BIGINT NOT NULL,
  "text" TEXT NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "deal_comments_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "deal_tasks" (
  "id" BIGSERIAL NOT NULL,
  "link_id" BIGINT NOT NULL,
  "author_id" BIGINT NOT NULL,
  "type" TEXT NOT NULL,
  "text" TEXT NOT NULL,
  "due_at" TIMESTAMP(3),
  "completed_at" TIMESTAMP(3),
  "update_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "deal_tasks_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "deal_comments_link_id_idx" ON "deal_comments"("link_id");
CREATE INDEX "deal_comments_author_id_idx" ON "deal_comments"("author_id");
CREATE INDEX "deal_tasks_link_id_idx" ON "deal_tasks"("link_id");
CREATE INDEX "deal_tasks_author_id_idx" ON "deal_tasks"("author_id");

ALTER TABLE "deal_comments"
  ADD CONSTRAINT "deal_comments_link_id_fkey"
  FOREIGN KEY ("link_id") REFERENCES "client_estate_links"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "deal_comments"
  ADD CONSTRAINT "deal_comments_author_id_fkey"
  FOREIGN KEY ("author_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "deal_tasks"
  ADD CONSTRAINT "deal_tasks_link_id_fkey"
  FOREIGN KEY ("link_id") REFERENCES "client_estate_links"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "deal_tasks"
  ADD CONSTRAINT "deal_tasks_author_id_fkey"
  FOREIGN KEY ("author_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
