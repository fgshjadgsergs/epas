CREATE TABLE "deal_stage_events" (
    "id" BIGSERIAL NOT NULL,
    "link_id" BIGINT NOT NULL,
    "actor_id" BIGINT NOT NULL,
    "from_status" TEXT,
    "to_status" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "deal_stage_events_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "deal_stage_events_link_id_idx" ON "deal_stage_events"("link_id");
CREATE INDEX "deal_stage_events_actor_id_idx" ON "deal_stage_events"("actor_id");

ALTER TABLE "deal_stage_events"
ADD CONSTRAINT "deal_stage_events_link_id_fkey"
FOREIGN KEY ("link_id") REFERENCES "client_estate_links"("id")
ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "deal_stage_events"
ADD CONSTRAINT "deal_stage_events_actor_id_fkey"
FOREIGN KEY ("actor_id") REFERENCES "users"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
