CREATE TYPE "AvitoModerationStatus" AS ENUM ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'CHANGES_REQUESTED');

CREATE TYPE "AvitoPublicationStatus" AS ENUM ('NOT_INCLUDED', 'READY', 'SENT', 'PROCESSING', 'PUBLISHED', 'REJECTED', 'ERROR', 'REMOVED');

ALTER TABLE "estates"
  ADD COLUMN "avito_moderation_status" "AvitoModerationStatus" NOT NULL DEFAULT 'DRAFT',
  ADD COLUMN "avito_status" "AvitoPublicationStatus" NOT NULL DEFAULT 'NOT_INCLUDED',
  ADD COLUMN "avito_included" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN "avito_id" BIGINT,
  ADD COLUMN "avito_external_id" TEXT,
  ADD COLUMN "avito_last_error" JSONB,
  ADD COLUMN "avito_last_validated_at" TIMESTAMP(3),
  ADD COLUMN "avito_last_synced_at" TIMESTAMP(3),
  ADD COLUMN "avito_review_comment" TEXT,
  ADD COLUMN "avito_review_requested_at" TIMESTAMP(3),
  ADD COLUMN "avito_approved_at" TIMESTAMP(3),
  ADD COLUMN "avito_approved_by_id" BIGINT;

CREATE TABLE "avito_moderation_events" (
  "id" BIGSERIAL NOT NULL,
  "estate_id" BIGINT NOT NULL,
  "actor_id" BIGINT NOT NULL,
  "from_status" "AvitoModerationStatus",
  "to_status" "AvitoModerationStatus" NOT NULL,
  "comment" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "avito_moderation_events_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "estates_avito_moderation_status_idx" ON "estates"("avito_moderation_status");
CREATE INDEX "estates_avito_status_idx" ON "estates"("avito_status");
CREATE INDEX "estates_avito_approved_by_id_idx" ON "estates"("avito_approved_by_id");

CREATE INDEX "avito_moderation_events_estate_id_idx" ON "avito_moderation_events"("estate_id");
CREATE INDEX "avito_moderation_events_actor_id_idx" ON "avito_moderation_events"("actor_id");
CREATE INDEX "avito_moderation_events_to_status_idx" ON "avito_moderation_events"("to_status");

ALTER TABLE "estates" ADD CONSTRAINT "estates_avito_approved_by_id_fkey" FOREIGN KEY ("avito_approved_by_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "avito_moderation_events" ADD CONSTRAINT "avito_moderation_events_estate_id_fkey" FOREIGN KEY ("estate_id") REFERENCES "estates"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "avito_moderation_events" ADD CONSTRAINT "avito_moderation_events_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
