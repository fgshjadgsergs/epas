ALTER TABLE "estates"
ADD COLUMN IF NOT EXISTS "avito_feed_data" JSONB;
