ALTER TABLE "images" ADD COLUMN "thumbnail_url" TEXT;
