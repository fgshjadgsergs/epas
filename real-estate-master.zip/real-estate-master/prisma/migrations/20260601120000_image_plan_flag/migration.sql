ALTER TABLE "images" ADD COLUMN "is_plan" BOOLEAN NOT NULL DEFAULT false;

CREATE UNIQUE INDEX "images_one_plan_per_estate"
  ON "images" ("estate_id")
  WHERE "is_plan" = true;
