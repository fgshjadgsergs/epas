ALTER TABLE "estates"
ADD COLUMN "levels_count" INTEGER,
ADD COLUMN "occupied_floors_text" TEXT;
