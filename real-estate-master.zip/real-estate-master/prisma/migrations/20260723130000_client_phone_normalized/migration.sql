ALTER TABLE "clients"
ADD COLUMN IF NOT EXISTS "phone_normalized" TEXT;

UPDATE "clients" AS client
SET "phone_normalized" = CASE
  WHEN normalized.digits = '' THEN NULL
  WHEN normalized.raw_phone ~ '^[[:space:]]*[+]' AND left(normalized.digits, 1) <> '7'
    THEN normalized.digits
  WHEN length(normalized.digits) = 11 AND left(normalized.digits, 1) = '8'
    THEN '7' || substring(normalized.digits FROM 2)
  WHEN length(normalized.digits) = 10
    THEN '7' || normalized.digits
  ELSE normalized.digits
END
FROM (
  SELECT
    "id",
    COALESCE("phone", '') AS raw_phone,
    regexp_replace(COALESCE("phone", ''), '[^0-9]', '', 'g') AS digits
  FROM "clients"
) AS normalized
WHERE client."id" = normalized."id"
  AND client."phone_normalized" IS NULL;

CREATE INDEX IF NOT EXISTS "clients_phone_normalized_idx"
ON "clients" ("phone_normalized");