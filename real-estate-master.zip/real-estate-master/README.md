# Real Estate

Платформа коммерческой недвижимости на `NestJS + Prisma + PostgreSQL` для API и `Next.js` для публичного сайта и CRM.

## Стек

- NestJS API
- Next.js frontend
- Prisma ORM
- PostgreSQL
- Docker Compose
- Nginx для reverse proxy и раздачи статического `/storage`

## Структура репозитория

- `apps/api` — API-приложение
- `apps/web` — публичный сайт и CRM frontend
- `docker` — production Dockerfiles
- `prisma` — схема и миграции
- `storage` — локальный storage mount

## Файлы окружения

Шаблоны runtime-конфигов:

- `.env.node.template`
- `.env.web.template`

Обычные локальные runtime-файлы:

- `.env.node`
- `.env.web`

Опционально можно использовать неотслеживаемый корневой `.env` для переменных `docker compose`, например:

- `POSTGRES_DB`
- `POSTGRES_USER`
- `POSTGRES_PASSWORD`

## Локальная разработка

Установка зависимостей:

```bash
npm install
```

Генерация Prisma Client:

```bash
npm run prisma:generate
```

Запуск API:

```bash
npm run dev:api
```

Запуск web:

```bash
npm run dev:web
```

## Docker

Сборка и запуск:

```bash
docker compose --profile estate up -d --build
```

Остановка:

```bash
docker compose --profile estate down
```

## Проверка

Сборка API:

```bash
npm run --workspace @estate/api build
```

Сборка web:

```bash
npm run --workspace @estate/web build
```

Smoke test API:

```bash
npm run --workspace @estate/api test:smoke
```
