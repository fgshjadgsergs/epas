FROM node:24-alpine AS base
WORKDIR /app

COPY package.json tsconfig.base.json ./
COPY apps/web/package.json apps/web/package.json

RUN npm install

FROM base AS build
WORKDIR /app

COPY apps/web ./apps/web

RUN npm run --workspace @estate/web build

FROM node:24-alpine AS production
WORKDIR /app

ENV NODE_ENV=production
ENV PORT=3001
ENV HOSTNAME=0.0.0.0

COPY --from=build /app/apps/web/.next/standalone ./
COPY --from=build /app/apps/web/.next/static ./apps/web/.next/static
COPY --from=build /app/apps/web/public ./apps/web/public

CMD ["node", "apps/web/server.js"]
