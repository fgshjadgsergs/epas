FROM node:24-alpine AS base
WORKDIR /app
RUN apk add --no-cache chromium nss freetype harfbuzz ca-certificates ttf-freefont

COPY package.json tsconfig.base.json ./
COPY apps/api/package.json apps/api/package.json
COPY prisma ./prisma

RUN npm install
RUN npm run prisma:generate

FROM base AS development
WORKDIR /app
COPY apps/api ./apps/api
CMD ["npm", "run", "--workspace", "@estate/api", "start:dev"]

FROM base AS build
WORKDIR /app
COPY apps/api ./apps/api
RUN npm run prisma:generate
RUN npm run --workspace @estate/api build
RUN npm prune --omit=dev

FROM node:24-alpine AS production
WORKDIR /app
ENV NODE_ENV=production
ENV PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium-browser
RUN apk add --no-cache chromium nss freetype harfbuzz ca-certificates ttf-freefont

COPY --from=build /app/package.json ./package.json
COPY --from=build /app/package-lock.json ./package-lock.json
COPY --from=build /app/node_modules ./node_modules
COPY --from=build /app/prisma ./prisma
COPY --from=build /app/apps/api/package.json ./apps/api/package.json
COPY --from=build /app/apps/api/dist ./apps/api/dist
COPY --from=build /app/apps/api/src/modules/storage/assets ./apps/api/dist/modules/storage/assets

CMD ["node", "apps/api/dist/main.js"]
